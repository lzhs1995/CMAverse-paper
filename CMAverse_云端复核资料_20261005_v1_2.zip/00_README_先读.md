# CMAverse云端分析交接包

用途：评估Claude提出的调节/两部分/对称编码路线，复核已恢复基础回归与八链CMAverse结果，审查完整150规格探索。当前整合稿是恢复后版本，新增探索结果尚未进入正文，非最终交付。

## 从这里开始
1. 阅读01_方案评估与关键修正.md与manuscript内当前恢复稿PDF。
2. data/analysis_13092.rds为首选工作数据，CSV为跨语言备用；13092行98列（无新增估计）。两期名义/实际收入、本人/配偶满意度、名义/实际向上支持、个人/配偶/父母ID、家庭ID、23协变量均在内。begin/end是区间两端；period为2018–2020或2020–2022。
3. RDS保留类型。CSV ID请勿自动变成浮点科学计数法或丢失字符串信息。缺失按NA，不将负的缺失ID当真实共同成员。cluster字段与家庭ID不是一回事；统一簇生成方法见audit/CLUSTER_AUDIT.json及cluster_audit.R。
4. screening/feasible_population_v1/specifications.csv是150个FEAS正式探索登记；registry_v1为其父CORE历史版本，不重复算成300规格。ALL_300_ADJUSTED.csv是150×两个主检验，status_120_specs_v1是完整运行状态；30不可估规格仍保留。FROZEN_CANDIDATES是11项探索优先级，不是显著赢家。
5. scripts/01_build_analysis_data.R从包内恢复输入重建当前导出；scripts/02_load_screening_frames.R在包根目录直接运行/加载，可调用build_spec_frame("FEAS_031")得到冻结规格数据。两脚本已在本机实际运行通过；无新增模型拟合。RDS和CSV逐列读回已核。
6. data/formal_eight/提供原八链各自实际分析输入；请勿把统一13092误当各原模型样本。context/RESTORED_EIGHT_MODELS.md含恢复的原效应与比较；manuscript/恢复稿文本与表格.md便于定位原基础回归数值。
7. scripts/exploration_original、recovery_original、historical、historical_stata保留原脚本未修改，其绝对Mac路径需在云端映射。software/CMAverse_source为历史定制源码，避免CRAN/GitHub不同版本冒充同一实现。原bootstrap不应无目的重跑。
8. context包含chat-pro完整建议、全部探索说明及原Claude评估。INPUTS.rds提供紧凑筛选输入；未打包数GB重复cmest对象，原逐次大型模型对象仍由本机/冷备保存。

## 明确缺口
- 尚未提供2016微观数据/2016–2022四波完整长面板；不能运行建议中的四波三段变化中介。已有原始清理脚本仅为溯源，包内不包含整个CFPS原库及其所有外部依赖，不声称可从原CFPS库端到端重建。
- 完整分析数据由恢复RDS匹配，不是凭空重新清洗；其原CSV/字典恢复脚本、历史清理脚本保留。所有数据原件未改写。
- 23协变量完整12754，不保证新模型全13092可用。基期满意度作为W时勿在公式中重复同列；新增模型需明示其余固定调整和样本定义。
- 当前全体数据已参与探索，不能事后拆半声称未接触确认集。
- 当前没有新的B1000结果，没有NLM专项背书，没有新路线估计结果。

## 最短命令（解压后进入本目录）
```sh
Rscript scripts/01_build_analysis_data.R
Rscript scripts/02_load_screening_frames.R
```
上述仅重建导出/冻结样本。云端新模型另建文件并保存sessionInfo、随机种子、全部候选结果、模型诊断及逐步样本流，不覆盖本包。

SOURCE_MANIFEST.json记录复制来源。MANIFEST.json记录包内每个文件SHA256/字节；压缩包已逐成员核验。包由用户自行上传，未自动发送云端。
