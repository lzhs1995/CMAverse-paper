# 从已恢复的两个输入精确匹配目标13092行；只导出，不估计模型。
# 在解压后的资料包根目录运行：Rscript scripts/01_build_analysis_data.R
options(stringsAsFactors=FALSE, digits=17)
v <- readRDS("data/source/v6_provisional_dyad_intervals_recovered.rds")
d <- readRDS("data/source/identity_target_13092.rds")
key <- function(a,b)paste(a,b,sep="::")
stopifnot(nrow(d)==13092L,!anyDuplicated(d$stable_row_id),!anyDuplicated(key(v$dyad_id,v$period)))
j <- match(key(d$dyad_id,d$period_label),key(v$dyad_id,v$period))
stopifnot(!anyNA(j),!anyDuplicated(j))
z <- v[j,,drop=FALSE]
cm <- read.csv("audit/cluster_membership.csv")
stopifnot(nrow(cm)==nrow(z),identical(as.character(cm$dyad_id),as.character(z$dyad_id)),identical(as.character(cm$period),as.character(z$period)))
z$stable_row_id <- d$stable_row_id
z$target_row_index <- seq_len(nrow(d))
z$historical_cluster <- cm$historical_cluster
z$unified_component <- cm$unified_component
# 不覆盖v6原字段；身份版筛选标签独立保留，禁止混用。
z$identity_same_actor <- d$same_actor
z$identity_same_partner <- d$same_partner
z$identity_same_parent <- d$same_parent
z$identity_parent_status <- d$parent_identity_status
covars <- c('dwm_begin','gender_begin','aage_begin','actor_edu2_begin','actor_siops_begin','child_begin','ahw_begin','ahk_begin','total_debts_begin','qp201_actor_begin','fmlincc_begin','lifetime_begin','period_fe','prtmarr_begin','prtcor_begin','prtgender_begin','prtage_begin','prtedu_begin','baseline_support_ihs','baseline_actor_income_ihs','baseline_partner_income_ihs','self_sat_begin','spouse_sat_begin')
stopifnot(length(covars)==23L,all(covars %in% names(z)))
dir.create('data',showWarnings=FALSE)
saveRDS(z,'data/analysis_13092.rds',compress='gzip')
write.csv(z,'data/analysis_13092.csv',row.names=FALSE,na='NA',fileEncoding='UTF-8')
stopifnot(identical(z,readRDS('data/analysis_13092.rds')))
back <- read.csv('data/analysis_13092.csv',check.names=FALSE)
stopifnot(nrow(back)==nrow(z),identical(names(back),names(z)))
for(n in names(z)) {
 a<-z[[n]];b<-back[[n]]
 stopifnot(identical(is.na(a),is.na(b)))
 if(is.numeric(a))stopifnot(isTRUE(all.equal(as.numeric(a),as.numeric(b),tolerance=1e-12)))
 else stopifnot(identical(as.character(a),as.character(b)))
}
dict <- do.call(rbind,lapply(names(z),function(n){x<-z[[n]];data.frame(variable=n,class=paste(class(x),collapse='/'),missing=sum(is.na(x)),unique_nonmissing=length(unique(x[!is.na(x)])),label=if(is.null(attr(x,'label')))'' else as.character(attr(x,'label')),levels=if(is.factor(x))paste(levels(x),collapse=' | ')else '',is_fixed_covariate=n%in%covars)}))
write.csv(dict,'data/analysis_dictionary.csv',row.names=FALSE,fileEncoding='UTF-8')
writeLines(covars,'data/fixed_23_covariates.txt')
diag <- data.frame(check=c('rows','columns','unique_actors','unified_clusters','self_sat_baseline_nonmissing','self_sat_baseline_full5','spouse_sat_baseline_nonmissing','spouse_sat_baseline_full5','fixed23_complete_cases','all_identity_same','period_2018_2020','period_2020_2022'),value=c(nrow(z),ncol(z),length(unique(z$actor_pid_begin)),length(unique(z$unified_component)),sum(!is.na(z$self_sat_begin)),sum(z$self_sat_begin==5,na.rm=TRUE),sum(!is.na(z$spouse_sat_begin)),sum(z$spouse_sat_begin==5,na.rm=TRUE),sum(complete.cases(z[,covars])),sum(d$same_actor%in%TRUE & d$same_partner%in%TRUE & d$same_parent%in%TRUE),sum(z$period=='2018-2020'),sum(z$period=='2020-2022')))
write.csv(diag,'audit/PACKAGE_DATA_CHECKS.csv',row.names=FALSE)
writeLines(c('PASS: 13092 unique target records matched; 23 covariates present; RDS exact readback; CSV per-column values/missingness checked; 0 model fits.',capture.output(sessionInfo())),'audit/EXPORT_VALIDATION.txt')
print(diag);cat('EXPORT_PASS; NO_MODELS_FITTED\n')
