# 云端可移植的150规格数据构造，不启动估计或重跑bootstrap。
# 在资料包根目录source本文件，随后 build_spec_frame("FEAS_031")。
z <- readRDS('data/analysis_13092.rds')
covars <- readLines('data/fixed_23_covariates.txt')
C <- z[,covars,drop=FALSE]
for(nm in c('dwm_begin','gender_begin','ahk_begin','lifetime_begin','prtmarr_begin','prtcor_begin','prtgender_begin','prtedu_begin','period_fe')) C[[nm]]<-factor(C[[nm]])
X <- list(abs_increase=z$x_abs,abs_diff_10k=(z$actor_income_real_end-z$actor_income_real_begin)/10000,abs_log1p_10k=log1p(z$actor_income_real_end/10000)-log1p(z$actor_income_real_begin/10000),rel_transition_eligible=z$x_rel,rel_share_diff=z$share_end-z$share_begin)
M <- list(self_increase_eligible=z$m_self_abs,spouse_increase_eligible=z$m_spouse_abs,self_increase_all=as.numeric(z$dm_self_abs>0),spouse_increase_all=as.numeric(z$dm_spouse_abs>0),self_score_diff=z$dm_self_abs,spouse_score_diff=z$dm_spouse_abs,self_relative_transition=z$m_self_rel,spouse_relative_transition=z$m_spouse_rel,self_relative_gap_diff=z$dm_self_rel,spouse_relative_gap_diff=z$dm_spouse_rel)
Y <- list(support_increase=z$y_growth,support_diff_10k=(z$support_real_end-z$support_real_begin)/10000,support_log1p_10k=log1p(z$support_real_end/10000)-log1p(z$support_real_begin/10000))
registry <- read.csv('screening/feasible_population_v1/specifications.csv')
membership <- readRDS('screening/feasible_population_v1/sample_membership.rds')
build_spec_frame <- function(spec_id) {
 g<-registry[registry$spec_id==spec_id,,drop=FALSE];stopifnot(nrow(g)==1)
 m<-membership[[spec_id]];i<-m$row_index
 stopifnot(length(i)==g$n,identical(m$cluster,z$historical_cluster[i]))
 data.frame(X=X[[g$x]][i],M=M[[g$m]][i],Y=Y[[g$y]][i],C[i,,drop=FALSE],row_index=i,cluster=z$historical_cluster[i])
}
stopifnot(nrow(registry)==150L)
for(id in registry$spec_id) {f<-build_spec_frame(id);stopifnot(all(complete.cases(f)))}
cat('PASS: 150 frozen frames reconstructed; no estimation. Thirty original Gaussian absolute-M specifications remain inadmissible.\n')
