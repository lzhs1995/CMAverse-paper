# 只读编码等价诊断；不拟合、不修改冻结登记或筛选分母。
s <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1'
root <- dirname(dirname(dirname(s)))
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite);library(digest)
e<-new.env()
sys.source(file.path(s,'candidate_data.R'),e);sys.source(file.path(s,'baseline_adjustment.R'),e)
g<-read.csv(file.path(s,'feasible_population_v1/specifications.csv'))
mem<-readRDS(file.path(s,'feasible_population_v1/sample_membership.rds'))
dest<-file.path(s,'coding_equivalence_v1');stopifnot(!dir.exists(dest));dir.create(dest)
ans<-lapply(seq_len(nrow(g)),function(i){
 a<-g[i,];m<-mem[[a$spec_id]]
 dat<-data.frame(X=e$X[[a$x]],M=e$M[[a$m]],Y=e$Y[[a$y]],e$C)[m$row_index,,drop=FALSE]
 rownames(dat)<-NULL
 contract<-list(data=dat,row_index=m$row_index,cluster=m$cluster,
 astar=a$astar,a=a$a,mval0=a$mval0,mval1=a$mval1,mreg=a$mreg,yreg=a$yreg)
 data.frame(spec_id=a$spec_id,x=a$x,m=a$m,y=a$y,n=nrow(dat),
 signature=digest(contract,algo='sha256'))
})
tab<-do.call(rbind,ans);tab$group_size<-as.integer(table(tab$signature)[tab$signature])
write.csv(tab,file.path(dest,'ALL_150_SIGNATURES.csv'),row.names=FALSE)
pairs<-lapply(list(c('FEAS_001','FEAS_011'),c('FEAS_006','FEAS_016')),function(ids){
 a<-tab[match(ids,tab$spec_id),];list(specs=ids,exact_data_sample_contrast_equal=length(unique(a$signature))==1L,signature=a$signature)})
write_json(list(status='READ_ONLY_EQUIVALENCE_AUDIT',registered=150,unique_contracts=length(unique(tab$signature)),
 equivalent_specs=sum(tab$group_size>1),pairs=pairs,denominator_changed=FALSE,
 note='Exact same data/sample/contrast is duplicate evidence; no p-driven removal. Frozen 150-test families remain unchanged.',
 source=list(registry_sha256=digest(file=file.path(s,'feasible_population_v1/specifications.csv'),algo='sha256'),
 membership_sha256=digest(file=file.path(s,'feasible_population_v1/sample_membership.rds'),algo='sha256'))),
 file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('EQUIVALENCE_AUDIT unique=',length(unique(tab$signature)),'of150\n')
