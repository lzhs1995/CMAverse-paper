# 离线实值及模型矩阵等价审计；冻结登记和bootstrap不变。
s <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1'
root <- dirname(dirname(dirname(s)))
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite);library(digest)
e<-new.env();sys.source(file.path(s,'candidate_data.R'),e);sys.source(file.path(s,'baseline_adjustment.R'),e)
g<-read.csv(file.path(s,'feasible_population_v1/specifications.csv'))
mem<-readRDS(file.path(s,'feasible_population_v1/sample_membership.rds'))
dest<-file.path(s,'coding_equivalence_v2');stopifnot(!dir.exists(dest));dir.create(dest)
contracts<-lapply(seq_len(nrow(g)),function(i){
 a<-g[i,];m<-mem[[a$spec_id]]
 d<-data.frame(X=e$X[[a$x]],M=e$M[[a$m]],Y=e$Y[[a$y]],e$C)[m$row_index,,drop=FALSE];rownames(d)<-NULL
 list(data=d,row_index=m$row_index,cluster=m$cluster,contrast=as.numeric(a[1,c('astar','a','mval0','mval1')]),mreg=a$mreg,yreg=a$yreg)
})
names(contracts)<-g$spec_id
canonical<-function(v){
 if(is.data.frame(v))return(lapply(v,canonical))
 if(is.factor(v))return(list(values=as.character(v),levels=levels(v),ordered=is.ordered(v)))
 if(is.numeric(v)||is.integer(v))return(as.numeric(v))
 if(is.list(v))return(lapply(v,canonical))
 v
}
sig<-vapply(contracts,function(z)digest(canonical(z),algo='sha256'),'')
tab<-data.frame(spec_id=g$spec_id,x=g$x,m=g$m,y=g$y,n=g$n,signature=sig)
tab$group_size<-as.integer(table(sig)[sig]);write.csv(tab,file.path(dest,'SIGNATURES.csv'),row.names=FALSE)
groups<-split(names(sig),sig);groups<-Filter(function(v)length(v)>1,groups)
checks<-lapply(groups,function(ids){
 ref<-contracts[[ids[1]]];covs<-setdiff(names(ref$data),c('X','M','Y'))
 fm<-reformulate(c('X',covs));fy<-reformulate(c('X*M',covs))
 result<-lapply(ids[-1],function(id){
 z<-contracts[[id]]
 list(spec=id,raw_identical=identical(ref,z),value_equal=isTRUE(all.equal(ref,z,check.attributes=FALSE)),
 mediator_matrix_equal=isTRUE(all.equal(model.matrix(fm,ref$data),model.matrix(fm,z$data),check.attributes=FALSE)),
 outcome_matrix_equal=isTRUE(all.equal(model.matrix(fy,ref$data),model.matrix(fy,z$data),check.attributes=FALSE)),
 M_types=c(typeof(ref$data$M),typeof(z$data$M)))
 })
 stopifnot(all(vapply(result,function(r)r$value_equal&&r$mediator_matrix_equal&&r$outcome_matrix_equal,logical(1))))
 list(reference=ids[1],comparisons=result)
})
write_json(list(status='PASS_NUMERIC_AND_MODEL_MATRIX_EQUIVALENCE',registered=150,unique_contracts=length(unique(sig)),groups=checks,
 denominator_changed=FALSE,note='Integer/double storage is normalized for grouping; values and design matrices independently compared. Frozen families remain 150. Equivalent specifications do not constitute independent corroboration.'),file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('Unique numerical contracts:',length(unique(sig)),'of 150; duplicate groups:',length(groups),'\n')
