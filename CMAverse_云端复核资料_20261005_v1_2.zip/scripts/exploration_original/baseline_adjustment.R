# 固定23项基线调整；依赖candidate_data.R创建z。
covars <- c('dwm_begin','gender_begin','aage_begin','actor_edu2_begin',
 'actor_siops_begin','child_begin','ahw_begin','ahk_begin','total_debts_begin',
 'qp201_actor_begin','fmlincc_begin','lifetime_begin','period_fe',
 'prtmarr_begin','prtcor_begin','prtgender_begin','prtage_begin','prtedu_begin',
 'baseline_support_ihs','baseline_actor_income_ihs','baseline_partner_income_ihs',
 'self_sat_begin','spouse_sat_begin')
factors <- c('dwm_begin','gender_begin','ahk_begin','lifetime_begin',
 'prtmarr_begin','prtcor_begin','prtgender_begin','prtedu_begin','period_fe')
stopifnot(all(covars %in% names(z)))
C <- z[,covars,drop=FALSE]
for(nm in factors) C[[nm]] <- factor(C[[nm]])
