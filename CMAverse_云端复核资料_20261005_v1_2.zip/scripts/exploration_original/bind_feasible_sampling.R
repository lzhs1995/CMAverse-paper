# 复用已冻结的全局簇随机流，为新人群重新映射实际行索引；不复用旧行索引。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite);library(digest)
s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest <- file.path(s,'feasible_sampling_v1');stopifnot(!dir.exists(dest));dir.create(dest)
rp<-file.path(s,'feasible_population_v1/specifications.csv');mp<-file.path(s,'feasible_population_v1/sample_membership.rds')
reg<-read.csv(rp);members<-readRDS(mp);cm<-read.csv(file.path(s,'cluster_membership.csv'))
checks<-list()
for(stage in c('screen','verify')) {
 original<-file.path(s,'sampling_plan_v1',paste0(stage,'.rds'));p<-readRDS(original)
 p$parent_plan_sha256<-digest(file=original,algo='sha256')
 p$registry_sha256<-digest(file=rp,algo='sha256');p$membership_sha256<-digest(file=mp,algo='sha256')
 p$population_registry<-'feasible_population_v1';p$index_policy<-'Remap global cluster draws to each retained population; no original row indices reused'
 for(i in seq_len(nrow(reg))) {
  g<-reg[i,];m<-members[[g$spec_id]]
  stopifnot(identical(m$cluster,cm$historical_cluster[m$row_index]),length(m$row_index)==g$n,
   identical(digest(m$row_index,algo='sha256'),g$sample_sha256))
  map<-split(seq_along(m$row_index),factor(m$cluster,levels=p$clusters))
  lens<-vapply(p$draws,function(draw) {
   ix<-unlist(map[match(draw,p$clusters)],use.names=FALSE)
   stopifnot(length(ix)>0,all(ix>=1L & ix<=g$n),length(ix)==sum(lengths(map)[match(draw,p$clusters)]))
   length(ix)
  },integer(1))
  checks[[length(checks)+1L]]<-data.frame(spec_id=g$spec_id,stage=stage,n=g$n,B=p$B,min_n=min(lens),max_n=max(lens))
 }
 saveRDS(p,file.path(dest,paste0(stage,'.rds')),compress='gzip')
 stopifnot(identical(p,readRDS(file.path(dest,paste0(stage,'.rds')))))
 cat(stage,':',nrow(reg)*p$B,'actual row mappings checked\n');flush.console()
}
tab<-do.call(rbind,checks);write.csv(tab,file.path(dest,'mapping_validation.csv'),row.names=FALSE)
paths<-file.path(dest,c('screen.rds','verify.rds','mapping_validation.csv'))
write_json(list(status='PASS_NEW_POPULATION_MAPPING_ONLY',checked_mappings=sum(tab$B),specifications=nrow(reg),
 models_fitted=0,formal_screen_started=FALSE,source_script_sha256=digest(file=file.path(s,'bind_feasible_sampling.R'),algo='sha256'),
 registry_sha256=digest(file=rp,algo='sha256'),membership_sha256=digest(file=mp,algo='sha256'),
 artifacts=lapply(paths,function(p)list(path=p,sha256=digest(file=p,algo='sha256'),bytes=file.info(p)$size)),
 note='Shares the original frozen global cluster draws; screen and verify remain distinct streams. New memberships remapped, no inference or admission.',
 at=as.character(Sys.time())),file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
