# 冻结编码、完整病例、干预对比及脚本身份；不拟合、不读结果p值。
options(stringsAsFactors=FALSE)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite); library(digest)
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
source(file.path(out,'candidate_data.R')); source(file.path(out,'baseline_adjustment.R'))
dest <- file.path(out,'registry_v1');stopifnot(!dir.exists(dest));dir.create(dest)
cm <- read.csv(file.path(out,'cluster_membership.csv'))
stopifnot(nrow(cm)==nrow(d),identical(as.character(cm$dyad_id),as.character(d$dyad_id)))
grid <- expand.grid(x=names(X),m=names(M),y=names(Y),stringsAsFactors=FALSE)
binary <- function(x) all(unique(x[is.finite(x)]) %in% c(0,1))
rows <- vector('list',nrow(grid)); samples <- vector('list',nrow(grid))
for(i in seq_len(nrow(grid))) {
 g<-grid[i,];xx<-X[[g$x]];mm<-M[[g$m]];yy<-Y[[g$y]]
 dat<-data.frame(X=xx,M=mm,Y=yy,C)
 keep<-complete.cases(dat)
 for(nm in names(dat)) if(is.numeric(dat[[nm]]))keep<-keep & is.finite(dat[[nm]])
 ac<-if(binary(xx))c(0,1) else as.numeric(quantile(xx,c(.25,.75),na.rm=TRUE))
 # 相对满意度互为相反数：相应受控对比使用反号，不伪装独立证据。
 mc<-if(g$m=='spouse_relative_gap_diff')c(0,-1) else c(0,1)
 supported<-all(ac>=min(xx[keep]) & ac<=max(xx[keep])) && all(mc>=min(mm[keep]) & mc<=max(mm[keep]))
 sid<-sprintf('CORE_%03d',i)
 samples[[i]]<-list(spec_id=sid,row_index=which(keep),cluster=cm$historical_cluster[keep])
 rows[[i]]<-data.frame(spec_id=sid,data_support_id=sprintf('DATA_%03d',i),g,
 n=sum(keep),clusters=length(unique(cm$historical_cluster[keep])),
 astar=ac[1],a=ac[2],mval0=mc[1],mval1=mc[2],
 mreg=if(binary(mm))'logistic' else 'linear',yreg=if(binary(yy))'logistic' else 'linear',
 outcome_scale=if(binary(yy))'ratio_log_for_testing' else 'difference',
 contrast_in_marginal_range=supported,
 support_note='Range check only; conditional positivity and feasible relative interventions require diagnostic review',
 sample_sha256=digest(which(keep),algo='sha256'),
 equivalent_m_family=if(g$m %in% c('self_relative_gap_diff','spouse_relative_gap_diff'))'relative_gap_sign_pair' else g$m,
 adjustment='fixed23_baseline',time_structure='concurrent_two_year_changes',
 stage='REGISTERED_NOT_RUN',B_screen=200L,B_verify=1000L)
}
reg<-do.call(rbind,rows)
stopifnot(nrow(reg)==150L,!anyDuplicated(reg$spec_id),all(reg$n>0))
write.csv(reg,file.path(dest,'specifications.csv'),row.names=FALSE)
names(samples)<-reg$spec_id;saveRDS(samples,file.path(dest,'sample_membership.rds'),compress='gzip')
writeLines(covars,file.path(dest,'baseline_covariates.txt'))
inputs<-c(file.path(root,'data/v6_provisional_dyad_intervals_recovered.rds'),file.path(root,'data/identity_target_13092.rds'),
 file.path(out,c('candidate_data.R','baseline_adjustment.R','cluster_membership.csv','build_registry.R')))
sources<-lapply(inputs,function(p)list(path=p,sha256=digest(file=p,algo='sha256'),bytes=file.info(p)$size))
outputs<-file.path(dest,c('specifications.csv','sample_membership.rds','baseline_covariates.txt'))
write_json(list(status='CORE_REGISTRY_CREATED_NOT_EXECUTION_APPROVAL',specifications=150,
 sample_range=range(reg$n),marginal_range_supported=sum(reg$contrast_in_marginal_range),
 source=sources,artifacts=lapply(outputs,function(p)list(path=p,sha256=digest(file=p,algo='sha256'),bytes=file.info(p)$size)),
 remaining_gates=c('selection contract implementation','conditional support and estimand checks','storage budget','native RStudio smoke'),
 B200_started=FALSE,at=as.character(Sys.time())),file.path(dest,'MANIFEST.json'),auto_unbox=TRUE,pretty=TRUE)
cat('REGISTRY_CREATED specs=',nrow(reg),' sample=',min(reg$n),'-',max(reg$n),'\n');flush.console()
