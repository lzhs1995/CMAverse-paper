# 从独立验证过的紧凑结果构建筛选输入；未全部终态时禁止冻结候选。
library(jsonlite)
library(digest)
args <- commandArgs(TRUE)
stopifnot(length(args)==2L)
s <- dirname(normalizePath(args[1]))
status_path <- normalizePath(args[1])
s <- dirname(s)
out <- args[2]
stopifnot(!dir.exists(out))
source(file.path(s,"screening_records.R"))
status <- read_json(status_path,simplifyVector=FALSE)
meta <- read.csv(file.path(s,"feasible_population_v1/specifications.csv"))
sig <- read.csv(file.path(s,"coding_equivalence_v2/SIGNATURES.csv"))
stopifnot(nrow(meta)==150L,!anyDuplicated(meta$spec_id),setequal(meta$spec_id,sig$spec_id))
meta$signature <- sig$signature[match(meta$spec_id,sig$spec_id)]
metrics <- c("TNIE","Delta_CDE")
point <- setNames(lapply(metrics,function(x)rep(NA_real_,150)),metrics)
draws <- setNames(lapply(metrics,function(x)matrix(NA_real_,200,150,dimnames=list(NULL,meta$spec_id))),metrics)
verified <- rep(FALSE,150)
proofs <- list()
ref <- function(p)list(path=normalizePath(p),sha256=digest(file=p,algo="sha256"),bytes=unname(file.info(p)$size))
for(e in status$validated_evidence) {
 p <- e$path
 stopifnot(identical(ref(p)$sha256,e$sha256),ref(p)$bytes==e$bytes)
 v <- read_json(p,simplifyVector=TRUE)
 stopifnot(v$B==200L,v$valid==200L,isTRUE(v$exact_grid_vs_full_bootstrap),isTRUE(v$full_paired_cmest))
 j <- match(v$spec_id,meta$spec_id)
 stopifnot(!is.na(j),!verified[j])
 d <- dirname(p)
 r <- readRDS(file.path(d,"METRICS.rds"))
 tab <- read.csv(file.path(d,"METRICS.csv"))
 stopifnot(identical(names(r$point$test_value),metrics),
  identical(dim(r$bootstrap_test_values),c(200L,2L)),
  identical(colnames(r$bootstrap_test_values),metrics),
  all(is.finite(r$bootstrap_test_values)),all(is.finite(r$point$test_value)))
 native <- read.csv(file.path(d,"ALL_NATIVE_EFFECTS.csv"))
 en <- native$effect[native$mval==meta$mval0[j]]
 stopifnot(length(en)>0L,!anyDuplicated(en))
 gridroot <- file.path(d,v$spec_id,"grids")
 gridproofs <- vector("list",200)
 for(b in seq_len(200)) {
  gp <- file.path(gridroot,sprintf("bootstrap_%02d.rds",b))
  g <- readRDS(gp)
  z <- extract_screening_metrics(g,en)
  stopifnot(isTRUE(all.equal(unname(z$test_value),unname(r$bootstrap_test_values[b,]),tolerance=0)))
  gridproofs[[b]] <- ref(gp)
 }
 for(k in metrics) {
  row <- tab[tab$metric==k,]
  stopifnot(nrow(row)==1L,row$valid==200L,row$spec_id==v$spec_id)
  t <- centered_bootstrap_test(r$point$test_value[[k]],r$bootstrap_test_values[,k],200,rep(TRUE,200))
  stopifnot(isTRUE(all.equal(row$p_exploratory,t$p,tolerance=1e-12)),
   isTRUE(all.equal(row$estimate,unname(r$point$effect[[k]]),tolerance=1e-12)))
  point[[k]][j] <- r$point$test_value[[k]]
  draws[[k]][,j] <- r$bootstrap_test_values[,k]
 }
 verified[j] <- TRUE
 proofs[[v$spec_id]] <- list(validation=ref(p),metrics=ref(file.path(d,"METRICS.rds")),
  table=ref(file.path(d,"METRICS.csv")),native_effects=ref(file.path(d,"ALL_NATIVE_EFFECTS.csv")),grids=gridproofs)
}
stopifnot(sum(verified)==status$validated_specifications)
dir.create(out,recursive=TRUE)
saveRDS(list(meta=meta,point=point,draws=draws,verified=verified,
 final_selection=FALSE,status_source=ref(status_path)),file.path(out,"INPUTS.rds"))
write_json(proofs,file.path(out,"SOURCE_PROOFS.json"),auto_unbox=TRUE)
result <- list(status="PASS_COMPACT_INPUT_AUDIT",validated=sum(verified),
 bootstrap_grids_checked=sum(verified)*200L,full_objects_read=0L,
 final_selection=FALSE,source_deleted=FALSE,
 inputs=ref(file.path(out,"INPUTS.rds")),source_proofs=ref(file.path(out,"SOURCE_PROOFS.json")),
 status_source=ref(status_path),at=as.character(Sys.time()))
write_json(result,file.path(out,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
print(result)
