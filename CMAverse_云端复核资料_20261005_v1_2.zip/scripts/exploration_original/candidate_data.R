# 统一候选数据构造；仅加载与构造，不写输出、不拟合。
options(stringsAsFactors=FALSE)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
v <- readRDS(file.path(root,'data/v6_provisional_dyad_intervals_recovered.rds'))
d <- readRDS(file.path(root,'data/identity_target_13092.rds'))
j <- match(paste(d$dyad_id,d$period_label),paste(v$dyad_id,v$period)); stopifnot(!anyNA(j))
z <- v[j,]
# 金额使用万元单位；零值可进入log1p，单位作为规格固定，不搜索变换常数。
X <- list(abs_increase=z$x_abs,
 abs_diff_10k=(z$actor_income_real_end-z$actor_income_real_begin)/10000,
 abs_log1p_10k=log1p(z$actor_income_real_end/10000)-log1p(z$actor_income_real_begin/10000),
 rel_transition_eligible=z$x_rel,
 rel_share_diff=z$share_end-z$share_begin)
M <- list(self_increase_eligible=z$m_self_abs,spouse_increase_eligible=z$m_spouse_abs,
 self_increase_all=as.numeric(z$dm_self_abs>0),spouse_increase_all=as.numeric(z$dm_spouse_abs>0),
 self_score_diff=z$dm_self_abs,spouse_score_diff=z$dm_spouse_abs,
 self_relative_transition=z$m_self_rel,spouse_relative_transition=z$m_spouse_rel,
 self_relative_gap_diff=z$dm_self_rel,spouse_relative_gap_diff=z$dm_spouse_rel)
Y <- list(support_increase=z$y_growth,
 support_diff_10k=(z$support_real_end-z$support_real_begin)/10000,
 support_log1p_10k=log1p(z$support_real_end/10000)-log1p(z$support_real_begin/10000))
grid <- expand.grid(x=names(X),m=names(M),y=names(Y),stringsAsFactors=FALSE)
