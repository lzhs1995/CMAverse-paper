# 合法候选的数据支持清点；不是模型估计或显著性筛选。
options(stringsAsFactors=FALSE)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
v <- readRDS(file.path(root,'data/v6_provisional_dyad_intervals_recovered.rds'))
d <- readRDS(file.path(root,'data/identity_target_13092.rds'))
j <- match(paste(d$dyad_id,d$period_label),paste(v$dyad_id,v$period)); stopifnot(!anyNA(j))
z <- v[j,]
# 金额使用万元单位；零值可进入log1p，单位作为规格固定，不搜索变换常数。
X <- list(abs_increase=z$x_abs,
 abs_diff_10k=(z$actor_income_real_end-z$actor_income_real_begin)/10000,
 abs_log1p_10k=log1p(z$actor_income_real_end/10000)-log1p(z$actor_income_real_begin/10000),
 rel_transition_eligible=z$x_rel,
 rel_share_diff=z$share_end-z$share_begin)
M <- list(self_increase_eligible=z$m_self_abs,spouse_increase_eligible=z$m_spouse_abs,
 self_increase_all=as.numeric(z$dm_self_abs>0),spouse_increase_all=as.numeric(z$dm_spouse_abs>0),
 self_score_diff=z$dm_self_abs,spouse_score_diff=z$dm_spouse_abs,
 self_relative_transition=z$m_self_rel,spouse_relative_transition=z$m_spouse_rel,
 self_relative_gap_diff=z$dm_self_rel,spouse_relative_gap_diff=z$dm_spouse_rel)
Y <- list(support_increase=z$y_growth,
 support_diff_10k=(z$support_real_end-z$support_real_begin)/10000,
 support_log1p_10k=log1p(z$support_real_end/10000)-log1p(z$support_real_begin/10000))
grid <- expand.grid(x=names(X),m=names(M),y=names(Y),stringsAsFactors=FALSE)
rows <- lapply(seq_len(nrow(grid)),function(i){
 g<-grid[i,]; a<-X[[g$x]]; b<-M[[g$m]]; c<-Y[[g$y]]
 keep<-is.finite(a)&is.finite(b)&is.finite(c)
 data.frame(spec_id=sprintf('DATA_%03d',i),g,n=sum(keep),actors=length(unique(z$actor_pid_begin[keep])),
 x_unique=length(unique(a[keep])),m_unique=length(unique(b[keep])),y_unique=length(unique(c[keep])),
 m_zero=sum(b[keep]==0),y_zero=sum(c[keep]==0),
 stage='DATA_SUPPORT_ONLY',fit_approved=FALSE)
})
result<-do.call(rbind,rows)
write.csv(result,file.path(out,'candidate_data_support.csv'),row.names=FALSE)
trans<-do.call(rbind,lapply(c('self','spouse'),function(w){
 t<-as.data.frame(table(begin=z[[paste0(w,'_sat_begin')]],end=z[[paste0(w,'_sat_end')]],useNA='ifany'))
 cbind(person=w,t)
}))
write.csv(trans,file.path(out,'satisfaction_transition_counts.csv'),row.names=FALSE)
jsonlite::write_json(list(status='DATA_SUPPORT_COMPLETE_NOT_MODEL_APPROVAL',combinations=nrow(result),minimum_rows=min(result$n),maximum_rows=max(result$n),
 unresolved=c('DAG and post-treatment confounders','time ordering','relative share both-zero construction','ordinal and two-part estimators require separate contracts','fixed candidate selection and multiplicity families','original source lineage gaps'),
 note='150 core coding combinations only; not final exhaustive specification universe. Relative gaps are algebraically related and not independent replications. No fitting or p values.'),file.path(out,'CANDIDATE_SUPPORT.json'),pretty=TRUE,auto_unbox=TRUE)
cat('DATA_SUPPORT_COMPLETE combinations=',nrow(result),' n_range=',min(result$n),'-',max(result$n),'\n',sep='')
