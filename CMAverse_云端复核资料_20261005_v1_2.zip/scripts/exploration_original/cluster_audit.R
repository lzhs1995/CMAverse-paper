# 保留历史聚类，另核跨角色同一人的依赖连接。
library(igraph)
library(jsonlite)
library(digest)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
source(file.path(out,'candidate_data.R'))
inputs <- file.path(root,c('data/v6_provisional_dyad_intervals_recovered.rds','data/identity_target_13092.rds'))
sha <- vapply(inputs,digest::digest,'',file=TRUE,algo='sha256')
fields <- c('actor_pid_begin','actor_pid_end','partner_pid_begin','partner_pid_end',
 'parent_pid_begin','parent_pid_end','fid_begin','fid_end')
stopifnot(all(fields %in% names(v)))
bad <- vapply(v[,fields],function(x)sum(!is.na(x)&(!is.finite(as.numeric(x))|as.numeric(x)<=0)),0L)
write_json(list(initial_strict_check='FAILED_NONPOSITIVE_IDENTIFIERS',counts=as.list(bad),
 action='Do not connect missing-code identities; preserve every observation row and historical cluster.'),
 file.path(out,'CLUSTER_INVALID_IDS.json'),pretty=TRUE,auto_unbox=TRUE)
edges <- do.call(rbind,lapply(fields,function(nm){
 x<-v[[nm]]; keep<-!is.na(x)&is.finite(as.numeric(x))&as.numeric(x)>0
 data.frame(from=paste0('ROW:',which(keep)),to=paste0(if(grepl('^fid',nm)) 'F:' else 'PERSON:',x[keep]))
}))
g <- graph_from_data_frame(edges,directed=FALSE)
cc <- components(g)$membership
unified <- as.integer(cc[paste0('ROW:',seq_len(nrow(v)))])
stopifnot(!anyNA(unified))
map <- data.frame(row=seq_len(nrow(d)),dyad_id=d$dyad_id,period=d$period_label,
 historical_cluster=d$cluster_id,v6_component=z$component_id,unified_component=unified[j])
# 判断分区是否同构，而非依赖整数标签相等。
partition <- function(a,b) list(a_count=length(unique(a)),b_count=length(unique(b)),
 a_split=sum(vapply(split(b,a),function(x)length(unique(x))>1,TRUE)),
 b_split=sum(vapply(split(a,b),function(x)length(unique(x))>1,TRUE)))
old_v6 <- partition(map$historical_cluster,map$v6_component)
old_new <- partition(map$historical_cluster,map$unified_component)
write.csv(map,file.path(out,'cluster_membership.csv'),row.names=FALSE)
sizes <- sort(table(map$unified_component),decreasing=TRUE)
write.csv(data.frame(component=names(sizes),rows=as.integer(sizes)),file.path(out,'unified_cluster_sizes.csv'),row.names=FALSE)
stopifnot(identical(sha,vapply(inputs,digest::digest,'',file=TRUE,algo='sha256')))
write_json(list(status='CLUSTER_STRUCTURE_AUDITED',rows=nrow(map),historical_vs_v6=old_v6,
 historical_vs_role_unified=old_new,unified_clusters=length(sizes),maximum_rows=max(sizes),
 median_rows=median(as.numeric(sizes)),largest_row_share=max(sizes)/nrow(map),
 nonpositive_or_nonfinite_ids=as.list(bad),sources_unchanged=TRUE,source_sha=as.list(sha),
 definition='Full restored v6 universe; row hubs connect valid positive PERSON identity across actor/partner/parent roles and both endpoints, plus valid positive family identities. Missing codes do not create edges. All rows and historical values retained.',
 bootstrap_started=FALSE),file.path(out,'CLUSTER_AUDIT.json'),pretty=TRUE,auto_unbox=TRUE)
cat('CLUSTER_AUDIT_COMPLETE clusters=',length(sizes),' largest=',max(sizes),'\n')
