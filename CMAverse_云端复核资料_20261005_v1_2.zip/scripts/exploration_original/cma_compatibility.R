# 独立Rscript兼容性小试：8类型组合、共享簇B10；非正式筛选。
options(stringsAsFactors=FALSE)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(CMAverse);library(jsonlite);library(digest)
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
source(file.path(out,'candidate_data.R'));source(file.path(out,'baseline_adjustment.R'))
dest <- file.path(out,'compatibility_b10_v1')
stopifnot(!dir.exists(dest));dir.create(dest)
source(file.path(root,'next_phase/PLAN12_八链适用性评估_20260928/scripts/shared_bootstrap_diagnostic.R'))
cm <- read.csv(file.path(out,'cluster_membership.csv'))
stopifnot(nrow(cm)==nrow(z),identical(as.character(cm$dyad_id),as.character(d$dyad_id)))
clusters <- sort(unique(cm$historical_cluster));set.seed(202610051L)
draws <- replicate(10,sample(clusters,length(clusters),replace=TRUE),simplify=FALSE)
saveRDS(list(clusters=clusters,draws=draws,seed=202610051L),file.path(dest,'sampling_plan.rds'))
cg <- expand.grid(x=c('abs_increase','abs_log1p_10k'),m=c('self_increase_all','self_score_diff'),
 y=c('support_increase','support_log1p_10k'),stringsAsFactors=FALSE)
sanitize <- function(a) {
 if(inherits(a,'glm')) {
  f<-family(a);a$family<-if(f$family=='binomial') binomial(link=f$link) else gaussian(link=f$link)
  if(!is.null(a$terms))attr(a$terms,'.Environment')<-baseenv()
  if(inherits(a$formula,'formula'))environment(a$formula)<-baseenv()
  if(inherits(a$call$formula,'formula'))environment(a$call$formula)<-baseenv()
  if(!is.null(attr(a$model,'terms')))attr(attr(a$model,'terms'),'.Environment')<-baseenv()
  return(a)
 }
 if(is.list(a))return(lapply(a,sanitize));a
}
summary <- list()
for(i in seq_len(nrow(cg))) {
 g<-cg[i,];sid<-sprintf('TYPE_%02d',i);sd<-file.path(dest,sid);dir.create(sd)
 dat<-data.frame(X=X[[g$x]],M=M[[g$m]],Y=Y[[g$y]],C)
 keep<-complete.cases(dat);for(nm in names(dat))if(is.numeric(dat[[nm]]))keep<-keep&is.finite(dat[[nm]])
 dat<-dat[keep,,drop=FALSE];map<-split(seq_len(nrow(dat)),factor(cm$historical_cluster[keep],levels=clusters))
 indices<-lapply(draws,function(x)unlist(map[match(x,clusters)],use.names=FALSE))
 bridge<-make_shared_cmest(indices,202610100L+seq_len(10),function(b,R,last){cat(sid,b,'/',R,'\n');flush.console()})
 bridge$state$save_grid<-function(gr,label){
  gr<-lapply(gr,function(x){x$reg.output<-sanitize(x$reg.output);x})
  saveRDS(gr,file.path(sd,paste0(label,'.rds')),compress='gzip')
 }
 binaryx<-g$x=='abs_increase';binarym<-g$m=='self_increase_all';binaryy<-g$y=='support_increase'
 contrast<-if(binaryx)c(0,1) else as.numeric(quantile(X[[g$x]],c(.25,.75),na.rm=TRUE))
 warns<-character();started<-Sys.time();set.seed(202610200L+i)
 cat('START',sid,g$x,g$m,g$y,'n=',nrow(dat),'\n');flush.console()
 args<-list(data=dat,model='gformula',outcome='Y',exposure='X',mediator='M',basec=covars,
 yreg=if(binaryy)'logistic' else 'linear',mreg=list(if(binarym)'logistic' else 'linear'),
 EMint=TRUE,astar=contrast[1],a=contrast[2],mval_grid=list(c(0,1)),
 estimation='imputation',inference='bootstrap',nboot=10L,boot.ci.type='per',full=TRUE)
 if(binaryy)args$yval<-1
 fit<-tryCatch(withCallingHandlers(do.call(bridge$cmest,args),warning=function(w){warns<<-c(warns,conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e)e)
 ok<-!inherits(fit,'error')
 if(ok){
  fit$reg.output<-sanitize(fit$reg.output)
  for(nm in names(fit$mval_results))fit$mval_results[[nm]]$reg.output<-sanitize(fit$mval_results[[nm]]$reg.output)
  fit$execution_provenance<-list(purpose='compatibility_only',B=10,runtime='standalone_Rscript',formal_inference=FALSE)
  p<-file.path(sd,'cmest_full.rds');saveRDS(fit,p,compress='gzip')
  stopifnot(isTRUE(all.equal(fit,readRDS(p),check.environment=FALSE)))
 }
 dg<-if(length(bridge$state$diagnostics))do.call(rbind,bridge$state$diagnostics) else data.frame()
 write.csv(dg,file.path(sd,'repeat_diagnostics.csv'),row.names=FALSE)
 writeLines(unique(warns),file.path(sd,'warnings.txt'))
 row<-data.frame(id=sid,g,n=nrow(dat),astar=contrast[1],a=contrast[2],execution_ok=ok,
 repeats=nrow(dg),valid=if(nrow(dg))sum(dg$fits_valid) else 0,
 seconds=as.numeric(difftime(Sys.time(),started,units='secs')),error=if(ok)'' else conditionMessage(fit))
 summary[[i]]<-row;write.csv(do.call(rbind,summary),file.path(dest,'SUMMARY.csv'),row.names=FALSE)
 write_json(list(stage='COMPATIBILITY',completed=i,total=8,pid=Sys.getpid(),updated_at=as.character(Sys.time())),
 file.path(dest,'PROGRESS.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('END',sid,'ok=',ok,'\n');flush.console();rm(fit,bridge);gc()
}
writeLines(capture.output(sessionInfo()),file.path(dest,'sessionInfo.txt'))
write_json(list(status='COMPLETED',types=8,B=10,formal_search_started=FALSE),file.path(dest,'TERMINAL.json'),auto_unbox=TRUE)
