# 全登记中介支持诊断：零bootstrap、零p值筛选、不修改原样本。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite); library(digest)
s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest <- file.path(s,'all_mediator_support_v1'); stopifnot(!dir.exists(dest));dir.create(dest)
source(file.path(s,'candidate_data.R'));source(file.path(s,'baseline_adjustment.R'))
paths <- file.path(s,c('feasible_population_v1/specifications.csv','feasible_population_v1/sample_membership.rds'))
before <- vapply(paths,function(p)digest(file=p,algo='sha256'),character(1))
reg <- read.csv(paths[1]);members <- readRDS(paths[2]); out <- list()
for(i in seq_len(nrow(reg))) {
 g<-reg[i,];idx<-members[[g$spec_id]]$row_index
 stopifnot(identical(digest(idx,algo='sha256'),g$sample_sha256))
 dat<-data.frame(X=X[[g$x]][idx],M=M[[g$m]][idx],C[idx,,drop=FALSE])
 binary<-g$mreg=='logistic'
 fit<-glm(reformulate(c('X',covars),'M'),data=dat,family=if(binary)binomial() else gaussian(),control=glm.control(maxit=100))
 stopifnot(fit$converged,fit$rank==ncol(model.matrix(fit)),all(is.finite(coef(fit))))
 sdres<-if(binary)NA_real_ else sqrt(sum(residuals(fit,type='response')^2)/fit$df.residual)
 if(!binary) {
  base<-if(grepl('^self_',g$m))z$self_sat_begin[idx] else z$spouse_sat_begin[idx]
  if(grepl('relative_gap_diff$',g$m)) {
   base<-if(grepl('^self_',g$m))z$self_sat_begin[idx]-z$spouse_sat_begin[idx] else z$spouse_sat_begin[idx]-z$self_sat_begin[idx]
   lo<- -4-base;hi<-4-base
  } else {stopifnot(grepl('score_diff$',g$m));lo<-1-base;hi<-5-base}
  stopifnot(sdres>0,all(dat$M>=lo & dat$M<=hi))
 }
 for(k in c('astar','a')) {
  nd<-dat;nd$X<-g[[k]];mu<-predict(fit,newdata=nd,type='response');stopifnot(all(is.finite(mu)))
  tail<-if(binary)rep(NA_real_,length(mu)) else pnorm(lo,mu,sdres)+pnorm(hi,mu,sdres,lower.tail=FALSE)
  out[[length(out)+1L]]<-data.frame(spec_id=g$spec_id,x=g$x,m=g$m,y=g$y,n=length(idx),intervention=k,x_value=g[[k]],
   mediator_family=g$mreg,residual_sd=sdres,pred_min=min(mu),pred_max=max(mu),
   binary_below001=if(binary)sum(mu<.01) else NA_integer_,binary_above099=if(binary)sum(mu>.99) else NA_integer_,
   gaussian_tail_mean=if(binary)NA_real_ else mean(tail),gaussian_tail_max=if(binary)NA_real_ else max(tail),
   gaussian_tail_over01=if(binary)NA_integer_ else sum(tail>.01),gaussian_tail_over05=if(binary)NA_integer_ else sum(tail>.05),
   mean_outside_bounds=if(binary)NA_integer_ else sum(mu<lo | mu>hi),sample_sha256=g$sample_sha256)
 }
 if(i%%10==0){cat('MEDIATOR_SUPPORT',i,'/150\n');flush.console()}
}
tab<-do.call(rbind,out);stopifnot(nrow(tab)==300L,identical(before,vapply(paths,function(p)digest(file=p,algo='sha256'),character(1))))
write.csv(tab,file.path(dest,'prediction_support.csv'),row.names=FALSE)
write_json(list(status='DIAGNOSTICS_COMPLETE_NOT_ADMISSION',specifications=150,rows=nrow(tab),pid=Sys.getpid(),
 gaussian_specs=length(unique(tab$spec_id[tab$mediator_family!='logistic'])),
 binary_specs_with_extreme_prediction=unique(tab$spec_id[which(tab$binary_below001+tab$binary_above099>0)]),
 source_unchanged=TRUE,bootstrap_submitted=FALSE,runtime='standalone_Rscript_diagnostic',
 limitations=c('Gaussian tail uses untruncated normal residual approximation; quantify actual CMAverse simulator separately',
 'Endpoint bounds for relative gap are necessary, not sufficient for a unique joint intervention',
 'Prediction ranges are not proof of positivity or causal identification; no rows trimmed'),at=as.character(Sys.time())),
 file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('ALL_MEDIATOR_SUPPORT_COMPLETE\n');flush.console()
