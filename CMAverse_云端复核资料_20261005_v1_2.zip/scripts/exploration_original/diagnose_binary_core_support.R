# 首批绝对收入/满意度提升核心的条件支持诊断，不计算效应或筛选p值。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite);library(digest)
s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest <- file.path(s,'binary_core_support_v1');stopifnot(!dir.exists(dest));dir.create(dest)
source(file.path(s,'candidate_data.R'));source(file.path(s,'baseline_adjustment.R'))
reg <- read.csv(file.path(s,'feasible_population_v1/specifications.csv'))
members <- readRDS(file.path(s,'feasible_population_v1/sample_membership.rds'))
sel <- reg[reg$x=='abs_increase' & reg$m %in% c('self_increase_eligible','spouse_increase_eligible'),]
stopifnot(nrow(sel)==6L)
rows<-list();strata_out<-list()
for(i in seq_len(nrow(sel))) {
 g<-sel[i,];idx<-members[[g$spec_id]]$row_index
 stopifnot(identical(digest(idx,algo='sha256'),g$sample_sha256))
 dat<-data.frame(X=X[[g$x]][idx],M=M[[g$m]][idx],C[idx,,drop=FALSE])
 fm<-glm(reformulate(c('X',covars),'M'),data=dat,family=binomial(),control=glm.control(maxit=100))
 fx<-glm(reformulate(covars,'X'),data=dat,family=binomial(),control=glm.control(maxit=100))
 stopifnot(fm$converged,fx$converged,all(is.finite(coef(fm))),all(is.finite(coef(fx))),
 fm$rank==ncol(model.matrix(fm)),fx$rank==ncol(model.matrix(fx)))
 # 两次固定X干预的M分布，与观察X条件支持分列；尾部阈值仅描述，不裁剪。
 pp<-list(exposure_observed=predict(fx,type='response'))
 for(a in c(0,1)) {nd<-dat;nd$X<-a;pp[[paste0('mediator_at_x',a)]]<-predict(fm,newdata=nd,type='response')}
 for(nm in names(pp)) {
  p<-pp[[nm]];stopifnot(all(is.finite(p)),all(p>=0 & p<=1))
  rows[[length(rows)+1L]]<-data.frame(spec_id=g$spec_id,kind=nm,n=length(p),min=min(p),
   q01=as.numeric(quantile(p,.01)),median=median(p),q99=as.numeric(quantile(p,.99)),max=max(p),
   below_001=sum(p<.01),above_099=sum(p>.99),below_005=sum(p<.05),above_095=sum(p>.95))
 }
 groups<-split(seq_len(nrow(dat)),interaction(z$self_sat_begin[idx],z$spouse_sat_begin[idx],z$period_fe[idx],drop=TRUE))
 for(nm in names(groups)) {
  j<-groups[[nm]];strata_out[[length(strata_out)+1L]]<-data.frame(spec_id=g$spec_id,stratum=nm,
   n=length(j),x0=sum(dat$X[j]==0),x1=sum(dat$X[j]==1),m0=sum(dat$M[j]==0),m1=sum(dat$M[j]==1),
   x0m0=sum(dat$X[j]==0 & dat$M[j]==0),x0m1=sum(dat$X[j]==0 & dat$M[j]==1),
   x1m0=sum(dat$X[j]==1 & dat$M[j]==0),x1m1=sum(dat$X[j]==1 & dat$M[j]==1))
 }
 cat(g$spec_id,'CONDITIONAL_SUPPORT_DIAGNOSTIC_COMPLETE\n');flush.console()
}
tab<-do.call(rbind,rows);strata<-do.call(rbind,strata_out)
write.csv(tab,file.path(dest,'prediction_support.csv'),row.names=FALSE)
write.csv(strata,file.path(dest,'observed_strata.csv'),row.names=FALSE)
write_json(list(status='BINARY_CORE_SUPPORT_DIAGNOSTICS_COMPLETE_NOT_CAUSAL_IDENTIFICATION',specifications=sel$spec_id,
 sample_sha256=as.list(setNames(sel$sample_sha256,sel$spec_id)),
 any_probability_outside_001_099=any(tab$below_001+tab$above_099>0),
 strata_single_m=sum(strata$m0==0 | strata$m1==0),strata_total=nrow(strata),
 bootstrap_submitted=FALSE,rows_trimmed=0,
 limitations=c('Parametric conditional prediction is not proof of positivity',
 'Sparse observed strata retained; no significance-based trimming',
 'Binary changes represent compound interventions with unspecified endpoint versions',
 'Concurrent interval changes do not identify temporal order; exploratory model-based effects require strong assumptions'),
 registry_sha256=digest(file=file.path(s,'feasible_population_v1/specifications.csv'),algo='sha256'),
 at=as.character(Sys.time())),file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
