# 收入条件支持：诊断而非删样本或显著性选择。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite);library(digest)
s<-file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest<-file.path(s,'exposure_support_v1');stopifnot(!dir.exists(dest));dir.create(dest)
source(file.path(s,'candidate_data.R'));source(file.path(s,'baseline_adjustment.R'))
reg<-read.csv(file.path(s,'feasible_population_v1/specifications.csv'));members<-readRDS(file.path(s,'feasible_population_v1/sample_membership.rds'))
rows<-list()
for(i in seq_len(nrow(reg))) {
 g<-reg[i,];idx<-members[[g$spec_id]]$row_index;stopifnot(identical(digest(idx,algo='sha256'),g$sample_sha256))
 dat<-data.frame(X=X[[g$x]][idx],C[idx,,drop=FALSE]);binary<-g$x %in% c('abs_increase','rel_transition_eligible')
 fit<-glm(reformulate(covars,'X'),data=dat,family=if(binary)binomial() else gaussian(),control=glm.control(maxit=100))
 stopifnot(fit$converged,fit$rank==ncol(model.matrix(fit)),all(is.finite(coef(fit))))
 mu<-predict(fit,type='response');sdres<-if(binary)NA_real_ else sigma(fit)
 for(k in c('astar','a')) {
  val<-if(binary)if(g[[k]]==1)mu else 1-mu else (g[[k]]-mu)/sdres
  rows[[length(rows)+1L]]<-data.frame(spec_id=g$spec_id,x=g$x,intervention=k,value=g[[k]],n=length(idx),
   type=if(binary)'binary_intervention_probability' else 'gaussian_standardized_distance',
   min=min(val),q01=as.numeric(quantile(val,.01)),median=median(val),q99=as.numeric(quantile(val,.99)),max=max(val),
   below001=if(binary)sum(val<.01) else NA_integer_,abs_over2=if(binary)NA_integer_ else sum(abs(val)>2),
   abs_over3=if(binary)NA_integer_ else sum(abs(val)>3),residual_sd=sdres,sample_sha256=g$sample_sha256)
 }
 if(i%%25==0){cat('EXPOSURE_SUPPORT',i,'/150\n');flush.console()}
}
tab<-do.call(rbind,rows);write.csv(tab,file.path(dest,'prediction_support.csv'),row.names=FALSE)
write_json(list(status='DIAGNOSTICS_COMPLETE_NOT_CAUSAL_IDENTIFICATION',specifications=150,rows=nrow(tab),pid=Sys.getpid(),
 bootstrap_submitted=FALSE,rows_trimmed=0,at=as.character(Sys.time()),
 limitations=c('Gaussian distance is a working location-scale diagnostic, not a validated exposure density',
 'No automatic exclusion threshold; relative exposure has multiple intervention versions',
 'No significance results read')),file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
