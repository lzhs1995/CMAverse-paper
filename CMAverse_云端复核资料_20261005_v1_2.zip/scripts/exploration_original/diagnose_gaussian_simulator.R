# 只读适用性诊断：核已安装估计器与源码，量化模拟越界；不估计效应、不读p值。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(CMAverse);library(jsonlite);library(digest)
s <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1'
dest<-file.path(s,'gaussian_simulator_support_v1');stopifnot(!dir.exists(dest));dir.create(dest)
src<-file.path(root,'runtime/CMAverse_source_install/R/est.gformula.R')
e<-new.env();sys.source(src,e)
f<-get('est.gformula',asNamespace('CMAverse'))
stopifnot(identical(body(f),body(e$est.gformula)),identical(formals(f),formals(e$est.gformula)))
writeLines(deparse(body(f)),file.path(dest,'installed_est_gformula_body.R'))
source(file.path(s,'candidate_data.R'));source(file.path(s,'baseline_adjustment.R'))
reg<-read.csv(file.path(s,'feasible_population_v1/specifications.csv'))
reg<-reg[reg$mreg!='logistic',]; stopifnot(nrow(reg)==60L)
members<-readRDS(file.path(s,'feasible_population_v1/sample_membership.rds'))
prior<-read.csv(file.path(s,'all_mediator_support_v1/prediction_support.csv'))
out<-list()
for(i in seq_len(nrow(reg))) {
 g<-reg[i,];idx<-members[[g$spec_id]]$row_index
 stopifnot(identical(digest(idx,algo='sha256'),g$sample_sha256))
 dat<-data.frame(X=X[[g$x]][idx],M=M[[g$m]][idx],C[idx,,drop=FALSE])
 fit<-glm(reformulate(c('X',covars),'M'),data=dat,family=gaussian(),control=glm.control(maxit=100))
 stopifnot(fit$converged,fit$rank==ncol(model.matrix(fit)))
 base<-if(grepl('^self_',g$m))z$self_sat_begin[idx] else z$spouse_sat_begin[idx]
 if(grepl('relative_gap_diff$',g$m)) {
 base<-if(grepl('^self_',g$m))z$self_sat_begin[idx]-z$spouse_sat_begin[idx] else z$spouse_sat_begin[idx]-z$self_sat_begin[idx]
 lo<- -4-base;hi<-4-base
 } else {stopifnot(grepl('score_diff$',g$m));lo<-1-base;hi<-5-base}
 # 相同error用于a与astar，严格复用原估计器的配对规则；此为诊断抽样，非原cmest内部轨迹。
 set.seed(202650000L+i);error<-rnorm(nrow(dat),0,sigma(fit))
 for(k in c('astar','a')) {
 nd<-dat;nd$X<-g[[k]];mu<-predict(fit,newdata=nd,type='response');sim<-mu+error
 tail<-pnorm(lo,mu,sigma(fit))+pnorm(hi,mu,sigma(fit),lower.tail=FALSE)
 p<-prior[prior$spec_id==g$spec_id & prior$intervention==k,]
 stopifnot(nrow(p)==1L,abs(mean(tail)-p$gaussian_tail_mean)<1e-10,abs(sigma(fit)-p$residual_sd)<1e-10)
 out[[length(out)+1L]]<-data.frame(spec_id=g$spec_id,intervention=k,n=nrow(dat),sigma=sigma(fit),
 exact_expected_tail=mean(tail),max_individual_tail=max(tail),simulated_outside=sum(sim<lo|sim>hi),
 simulated_fraction=mean(sim<lo|sim>hi),diagnostic_seed=202650000L+i,sample_sha256=g$sample_sha256)
 }
}
tab<-do.call(rbind,out);write.csv(tab,file.path(dest,'SIMULATOR_SUPPORT.csv'),row.names=FALSE)
write_json(list(status='SIMULATOR_DIAGNOSTIC_COMPLETE_NOT_ADMISSION',specifications=60,rows=nrow(tab),
 installed_source_body_identical=TRUE,source_sha256=digest(file=src,algo='sha256'),
 expected_tail_range=range(tab$exact_expected_tail),all_prior_analytic_tails_match=TRUE,
 no_truncation=TRUE,no_p_read=TRUE,no_effect_estimation=TRUE,pid=Sys.getpid(),at=as.character(Sys.time()),
 limitations=c('Conditional Gaussian tails are exact for fitted diagnostic models; not bootstrap refit distributions',
 'Draws use the installed simulator formula with diagnostic seeds; not the actual cmest RNG trace',
 'Relative gap bounds are necessary only; causal identification and model admission remain separate',
 'Gaussian approximation to discrete bounded changes requires explicit qualification or a bounded model')),
 file.path(dest,'RESULT.json'),pretty=TRUE,auto_unbox=TRUE)
cat('GAUSSIAN_SIMULATOR_DIAGNOSTIC_COMPLETE\n')
