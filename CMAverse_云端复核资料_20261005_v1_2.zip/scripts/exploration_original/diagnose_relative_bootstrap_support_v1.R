# 独立离线诊断：复用冻结簇抽样，检查相对连续M；不计算Y效应、不读取p值。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite); library(digest)
s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest <- file.path(s,'relative_bootstrap_support_v1')
stopifnot(!dir.exists(dest));dir.create(dest)
inputs <- file.path(s,c('candidate_data.R','baseline_adjustment.R','feasible_population_v1/specifications.csv',
 'feasible_population_v1/sample_membership.rds','feasible_sampling_v1/screen.rds','diagnose_relative_bootstrap_support_v1.R'))
inputs <- c(inputs,file.path(root,'data/v6_provisional_dyad_intervals_recovered.rds'),file.path(root,'data/identity_target_13092.rds'))
hashes <- vapply(inputs,function(p)digest(file=p,algo='sha256'),character(1))
source(file.path(s,'candidate_data.R'));source(file.path(s,'baseline_adjustment.R'))
reg <- read.csv(file.path(s,'feasible_population_v1/specifications.csv'))
members <- readRDS(file.path(s,'feasible_population_v1/sample_membership.rds'))
plan <- readRDS(file.path(s,'feasible_sampling_v1/screen.rds'))
stopifnot(plan$B==200L,identical(plan$registry_sha256,digest(file=inputs[3],algo='sha256')),
 identical(plan$membership_sha256,digest(file=inputs[4],algo='sha256')))
reg <- reg[reg$m=='self_relative_gap_diff',];stopifnot(nrow(reg)==15L)
progress <- function(stage,message) {
 write_json(list(stage=stage,message=message,pid=Sys.getpid(),updated_at=as.character(Sys.time())),
 file.path(dest,'PROGRESS.json'),auto_unbox=TRUE,pretty=TRUE)
 cat(stage,message,'\n');flush.console()
}
allrows <- list(); checks <- list()
for(i in seq_len(nrow(reg))) {
 g<-reg[i,];member<-members[[g$spec_id]];idx<-member$row_index
 stopifnot(identical(digest(idx,algo='sha256'),g$sample_sha256))
 dat<-data.frame(X=X[[g$x]][idx],M=M[[g$m]][idx],C[idx,,drop=FALSE])
 form<-reformulate(c('X',covars),'M');mm<-model.matrix(form,dat)
 fit<-glm(form,data=dat,family=gaussian());fast<-lm.fit(mm,dat$M)
 stopifnot(isTRUE(all.equal(unname(coef(fit)),unname(fast$coefficients),tolerance=1e-8)),
 abs(sigma(fit)-sqrt(sum(fast$residuals^2)/fast$df.residual))<1e-8)
 base<-z$self_sat_begin[idx]-z$spouse_sat_begin[idx];lo<- -4-base;hi<-4-base
 map<-split(seq_len(nrow(dat)),factor(member$cluster,levels=plan$clusters))
 nd0<-nd1<-dat;nd0$X<-g$astar;nd1$X<-g$a
 mm0<-model.matrix(form,nd0);mm1<-model.matrix(form,nd1)
 checks[[i]]<-data.frame(spec_id=g$spec_id,n=nrow(dat),full_sample_glm_lm_agree=TRUE,sample_sha256=g$sample_sha256)
 rows<-list()
 for(b in seq_len(plan$B)) {
  j<-unlist(map[match(plan$draws[[b]],plan$clusters)],use.names=FALSE)
  f<-lm.fit(mm[j,,drop=FALSE],dat$M[j]);ok<-f$rank==ncol(mm)&&all(is.finite(f$coefficients))&&f$df.residual>0
  sdres<-if(ok)sqrt(sum(f$residuals^2)/f$df.residual) else NA_real_
  ok<-ok&&is.finite(sdres)&&sdres>0
  # 诊断专属随机种子；不冒充cmest内部RNG轨迹。两个X端点共用误差。
  set.seed(202670000L+i*1000L+b);err<-if(ok)rnorm(length(j),sd=sdres) else rep(NA_real_,length(j))
  for(k in c('astar','a')) {
   mu<-if(ok)as.vector((if(k=='astar')mm0 else mm1)[j,,drop=FALSE]%*%f$coefficients) else rep(NA_real_,length(j))
   tail<-if(ok)pnorm(lo[j],mu,sdres)+pnorm(hi[j],mu,sdres,lower.tail=FALSE) else NA_real_
   sim<-mu+err
   rows[[length(rows)+1L]]<-data.frame(spec_id=g$spec_id,replicate=b,intervention=k,n=length(j),
    fit_valid=ok,residual_sd=sdres,expected_tail_mean=mean(tail),max_individual_tail=max(tail),
    simulated_outside=if(ok)sum(sim<lo[j]|sim>hi[j]) else NA_integer_,
    fixed_mval_outside=sum(g$mval0<lo[j]|g$mval0>hi[j]|g$mval1<lo[j]|g$mval1>hi[j]),
    observed_m_outside=sum(dat$M[j]<lo[j]|dat$M[j]>hi[j]),
    diagnostic_seed=202670000L+i*1000L+b,index_sha256=digest(j,algo='sha256'))
  }
  if(b%%50L==0L)progress('bootstrap_support',paste(g$spec_id,b,'of',plan$B))
 }
 tab<-do.call(rbind,rows);write.csv(tab,file.path(dest,paste0(g$spec_id,'.csv')),row.names=FALSE)
 allrows[[i]]<-tab
}
tab<-do.call(rbind,allrows);write.csv(tab,file.path(dest,'ALL_REPLICATES.csv'),row.names=FALSE)
write.csv(do.call(rbind,checks),file.path(dest,'NUMERICAL_EQUIVALENCE.csv'),row.names=FALSE)
stopifnot(identical(hashes,vapply(inputs,function(p)digest(file=p,algo='sha256'),character(1))))
write_json(list(status='DIAGNOSTIC_COMPLETE_NOT_ADMISSION',transport='OFFLINE_RSCRIPT',specifications=15,
 B=plan$B,rows=nrow(tab),invalid_rows=sum(!tab$fit_valid),observed_outside=sum(tab$observed_m_outside),
 fixed_mval_outside=sum(tab$fixed_mval_outside),expected_tail_range=range(tab$expected_tail_mean,na.rm=TRUE),
 worst_individual_tail=max(tab$max_individual_tail,na.rm=TRUE),simulated_outside=sum(tab$simulated_outside,na.rm=TRUE),
 simulated_draws=sum(tab$n),effect_models=0,p_values_read=FALSE,source_sha256=as.list(hashes),
 limitations=c('No causal time ordering or unique joint intervention established',
 'Diagnostic RNG is not cmest RNG; no natural or controlled effects estimated',
 'Spouse mirror not separately fitted; no claim of independent replication',
 'Gaussian continuous approximation still assigns mass outside bounded discrete support'),
 pid=Sys.getpid(),at=as.character(Sys.time())),file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
progress('complete','15 specifications x 200 frozen cluster refits; no effect estimation')
