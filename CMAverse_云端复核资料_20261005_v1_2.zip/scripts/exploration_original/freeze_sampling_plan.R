# 冻结两阶段独立的共享簇抽样；不估计模型、不读取显著性结果。
options(stringsAsFactors=FALSE)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite); library(digest)
s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest <- file.path(s,'sampling_plan_v1')
stopifnot(!dir.exists(dest))
regpath <- file.path(s,'registry_v1/specifications.csv')
membpath <- file.path(s,'registry_v1/sample_membership.rds')
cm <- read.csv(file.path(s,'cluster_membership.csv'))
reg <- read.csv(regpath); memberships <- readRDS(membpath)
clusters <- sort(unique(cm$historical_cluster))
stopifnot(length(clusters)==3212L, nrow(reg)==150L,
          identical(names(memberships),reg$spec_id),!anyNA(clusters))
dir.create(dest)
RNGkind('Mersenne-Twister','Inversion','Rejection')
plans <- list()
for(stage in c('screen','verify')) {
  B <- if(stage=='screen')200L else 1000L
  seed <- if(stage=='screen')202610052L else 202610053L
  set.seed(seed)
  draws <- replicate(B,sample(clusters,length(clusters),replace=TRUE),simplify=FALSE)
  # 每次CMAverse内部随机性也固定；与簇抽样随机流分开。
  replicate_seeds <- if(stage=='screen')202620000L+seq_len(B) else 202630000L+seq_len(B)
  p <- list(stage=stage,B=B,seed=seed,rng_kind=RNGkind(),clusters=clusters,
            draws=draws,replicate_seeds=replicate_seeds,
            point_seed=if(stage=='screen')202640001L else 202640002L,
            registry_sha256=digest(file=regpath,algo='sha256'),
            membership_sha256=digest(file=membpath,algo='sha256'))
  path <- file.path(dest,paste0(stage,'.rds'))
  saveRDS(p,path,compress='gzip'); stopifnot(identical(p,readRDS(path)))
  plans[[stage]] <- p
}
stopifnot(!identical(plans$screen$draws,plans$verify$draws[seq_len(200L)]))
# 校验150项实际行索引映射及全部200次抽样长度，不保存150份冗余索引。
checks <- lapply(seq_len(nrow(reg)),function(i) {
  g <- reg[i,]; m <- memberships[[g$spec_id]]
  stopifnot(identical(m$cluster,cm$historical_cluster[m$row_index]),
            length(m$row_index)==g$n,
            identical(digest(m$row_index,algo='sha256'),g$sample_sha256))
  map <- split(seq_along(m$row_index),factor(m$cluster,levels=clusters))
  lengths_expected <- vapply(plans$screen$draws,function(draw) {
    idx <- unlist(map[match(draw,clusters)],use.names=FALSE)
    stopifnot(length(idx)>0L,all(idx>=1L & idx<=g$n),
              length(idx)==sum(lengths(map)[match(draw,clusters)]))
    length(idx)
  },integer(1))
  data.frame(spec_id=g$spec_id,n=g$n,min_draw_n=min(lengths_expected),
             max_draw_n=max(lengths_expected),checked_draws=length(lengths_expected))
})
write.csv(do.call(rbind,checks),file.path(dest,'mapping_validation.csv'),row.names=FALSE)
paths <- file.path(dest,c('screen.rds','verify.rds','mapping_validation.csv'))
write_json(list(status='PASS_SAMPLING_ONLY',specifications=150L,screen_B=200L,verify_B=1000L,
  checked_mappings=30000L,models_fitted=0L,formal_screen_started=FALSE,
  source_script_sha256=digest(file=file.path(s,'freeze_sampling_plan.R'),algo='sha256'),
  artifacts=lapply(paths,function(p)list(path=p,sha256=digest(file=p,algo='sha256'),bytes=file.info(p)$size)),
  at=as.character(Sys.time())),file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('PASS: independent B200/B1000 plans; 30000 mappings verified; no models fitted\n')
