# 固定基线调整的数值诊断；不计算中介bootstrap或筛选p值。
options(stringsAsFactors=FALSE)
library(jsonlite)
library(digest)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
inputs <- file.path(root,c('data/v6_provisional_dyad_intervals_recovered.rds','data/identity_target_13092.rds'))
before <- vapply(inputs,digest::digest,'',file=TRUE,algo='sha256')
source(file.path(out,'candidate_data.R'))
covars <- c('dwm_begin','gender_begin','aage_begin','actor_edu2_begin',
 'actor_siops_begin','child_begin','ahw_begin','ahk_begin','total_debts_begin',
 'qp201_actor_begin','fmlincc_begin','lifetime_begin','period_fe',
 'prtmarr_begin','prtcor_begin','prtgender_begin','prtage_begin','prtedu_begin',
 'baseline_support_ihs','baseline_actor_income_ihs','baseline_partner_income_ihs',
 'self_sat_begin','spouse_sat_begin')
factors <- c('dwm_begin','gender_begin','ahk_begin','lifetime_begin',
 'prtmarr_begin','prtcor_begin','prtgender_begin','prtedu_begin','period_fe')
stopifnot(all(covars %in% names(z)))
C <- z[,covars,drop=FALSE]
for(nm in factors) C[[nm]] <- factor(C[[nm]])
missing <- do.call(rbind,lapply(covars,function(nm) data.frame(variable=nm,
 missing=sum(is.na(C[[nm]])),distinct=length(unique(na.omit(C[[nm]]))),
 type=if(nm %in% factors) 'factor' else 'numeric')))
write.csv(missing,file.path(out,'covariate_missingness.csv'),row.names=FALSE)
progress <- function(i,state) {
 write_json(list(stage=state,completed=i,total=nrow(grid),updated_at=format(Sys.time(),tz='UTC',usetz=TRUE)),
 file.path(out,'GLM_PROGRESS.json'),pretty=TRUE,auto_unbox=TRUE)
 cat(state, i,'/',nrow(grid),'\n');flush.console()
}
fit_one <- function(formula,data,binary) {
 warnings <- character(); error <- ''
 fit <- tryCatch(withCallingHandlers(glm(formula,data=data,
 family=if(binary) binomial() else gaussian(),control=glm.control(maxit=100)),
 warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}),
 error=function(e){error<<-conditionMessage(e);NULL})
 if(is.null(fit)) return(data.frame(converged=FALSE,full_rank=FALSE,finite=FALSE,
 rank=NA_integer_,columns=NA_integer_,iterations=NA_integer_,boundary=NA,
 warning=paste(unique(warnings),collapse=' | '),error=error))
 mm <- model.matrix(fit)
 data.frame(converged=isTRUE(fit$converged),full_rank=fit$rank==ncol(mm),
 finite=all(is.finite(coef(fit))),rank=fit$rank,columns=ncol(mm),
 iterations=fit$iter,boundary=isTRUE(fit$boundary),
 warning=paste(unique(warnings),collapse=' | '),error=error)
}
fm <- reformulate(c('X',covars),response='M')
fy <- reformulate(c('X*M',covars),response='Y')
result <- list(); categories <- list(); progress(0,'FITTING_DIAGNOSTIC_SUBMODELS')
for(i in seq_len(nrow(grid))) {
 g <- grid[i,]; frame <- data.frame(X=X[[g$x]],M=M[[g$m]],Y=Y[[g$y]],C)
 keep <- complete.cases(frame)
 for(nm in names(frame)) if(is.numeric(frame[[nm]])) keep <- keep & is.finite(frame[[nm]])
 frame <- frame[keep,,drop=FALSE]
 # 固定所有母样本类别，零列/秩亏不静默删除。
 for(nm in factors) categories[[length(categories)+1L]] <- data.frame(spec_id=sprintf('CORE_%03d',i),
 variable=nm,level=levels(frame[[nm]]),count=as.integer(table(frame[[nm]])))
 binary_m <- !grepl('score_diff|gap_diff',g$m)
 for(role in c('mediator','outcome')) {
 f <- fit_one(if(role=='mediator') fm else fy,frame,if(role=='mediator') binary_m else g$y=='support_increase')
 result[[length(result)+1L]] <- cbind(data.frame(spec_id=sprintf('CORE_%03d',i),g,role=role,
 n=nrow(frame),actors=length(unique(z$actor_pid_begin[keep])),
 family=if(if(role=='mediator') binary_m else g$y=='support_increase') 'binomial_logit' else 'gaussian_identity'),f)
 }
 if(i%%10==0 || i==nrow(grid)) progress(i,'FITTING_DIAGNOSTIC_SUBMODELS')
}
res <- do.call(rbind,result)
write.csv(res,file.path(out,'glm_diagnostics.csv'),row.names=FALSE)
write.csv(do.call(rbind,categories),file.path(out,'covariate_category_counts.csv'),row.names=FALSE)
after <- vapply(inputs,digest::digest,'',file=TRUE,algo='sha256')
stopifnot(identical(before,after))
write_json(list(status='DIAGNOSTICS_COMPLETE_NOT_BOOTSTRAP',specifications=nrow(grid),
 fits=nrow(res),converged=sum(res$converged),full_rank=sum(res$full_rank),finite=sum(res$finite),
 warning_fits=sum(nzchar(res$warning)),error_fits=sum(nzchar(res$error)),n_range=range(res$n),
 source_hashes=as.list(before),sources_unchanged=TRUE,
 runtime='standalone_Rscript_not_RStudio',bootstrap_started=FALSE,
 note='Ordinary submodel diagnostics only; no indirect-effect inference, no p-value ranking; baseline adjustment shared by both submodels.'),
 file.path(out,'GLM_DIAGNOSTICS.json'),pretty=TRUE,auto_unbox=TRUE)
progress(nrow(grid),'COMPLETE')
