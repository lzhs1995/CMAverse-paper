# 只读结构支持审计；不拟合、不改样本、不按显著性筛选。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite); library(digest)
s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest <- file.path(s,'intervention_support_v1')
stopifnot(!dir.exists(dest))
source(file.path(s,'candidate_data.R')); source(file.path(s,'baseline_adjustment.R'))
reg <- read.csv(file.path(s,'registry_v1/specifications.csv'))
members <- readRDS(file.path(s,'registry_v1/sample_membership.rds'))
inputs <- c(file.path(root,'data/v6_provisional_dyad_intervals_recovered.rds'),
 file.path(root,'data/identity_target_13092.rds'),file.path(s,'registry_v1/specifications.csv'),
 file.path(s,'registry_v1/sample_membership.rds'),file.path(s,'candidate_data.R'),
 file.path(s,'baseline_adjustment.R'),file.path(s,'intervention_support_audit.R'))
hashes <- vapply(inputs,function(p)digest(file=p,algo='sha256'),character(1))
stopifnot(all(z$self_sat_begin %in% c(1:5,NA)),all(z$spouse_sat_begin %in% c(1:5,NA)))
stopifnot(isTRUE(all.equal(z$dm_self_rel,z$dm_self_abs-z$dm_spouse_abs,check.attributes=FALSE)),
 isTRUE(all.equal(z$dm_spouse_rel,-z$dm_self_rel,check.attributes=FALSE)))
# 固定端点约束。相对量只检必要范围，不能据此证明干预唯一或可识别。
xbad <- function(x,contrast,zz) {
 switch(x,
  abs_diff_10k=zz$actor_income_real_begin+10000*contrast < -1e-8,
  abs_log1p_10k=log1p(zz$actor_income_real_begin/10000)+contrast < -1e-12,
  rel_share_diff=zz$share_begin+contrast < -1e-12 | zz$share_begin+contrast > 1+1e-12,
  abs_increase=rep(FALSE,nrow(zz)),rel_transition_eligible=rep(FALSE,nrow(zz)),
  stop('Unknown X'))
}
mbad <- function(m,contrast,zz) {
 b <- if(grepl('^self_',m))zz$self_sat_begin else zz$spouse_sat_begin
 if(grepl('increase_',m))return(contrast==1 & b>=5)
 if(grepl('score_diff$',m))return(b+contrast<1 | b+contrast>5)
 if(grepl('relative_gap_diff$',m)) {
  gap <- if(grepl('^self_',m))zz$self_sat_begin-zz$spouse_sat_begin else zz$spouse_sat_begin-zz$self_sat_begin
  return(gap+contrast < -4 | gap+contrast > 4)
 }
 if(grepl('relative_transition$',m))return(rep(FALSE,nrow(zz)))
 stop('Unknown M')
}
rows <- vector('list',nrow(reg)); details <- vector('list',nrow(reg))
for(i in seq_len(nrow(reg))) {
 g<-reg[i,]; member<-members[[g$spec_id]]; idx<-member$row_index;zz<-z[idx,]
 stopifnot(length(idx)==g$n,identical(digest(idx,algo='sha256'),g$sample_sha256))
 bad <- data.frame(x_astar=xbad(g$x,g$astar,zz),x_a=xbad(g$x,g$a,zz),
  m_0=mbad(g$m,g$mval0,zz),m_1=mbad(g$m,g$mval1,zz))
 stopifnot(!anyNA(bad))
 # 每个基线满意度配对/时期格实际是否同时观察到两种M状态；只是诊断。
 strata<-interaction(zz$self_sat_begin,zz$spouse_sat_begin,zz$period_fe,drop=TRUE)
 groups<-split(M[[g$m]][idx],strata)
 single_m<-if(g$mreg=='logistic')sum(vapply(groups,function(a)length(unique(a))<2L,logical(1))) else NA_integer_
 rows[[i]]<-data.frame(spec_id=g$spec_id,x=g$x,m=g$m,y=g$y,n=g$n,
  x_astar_impossible=sum(bad$x_astar),x_a_impossible=sum(bad$x_a),
  m0_impossible=sum(bad$m_0),m1_impossible=sum(bad$m_1),
  any_fixed_contrast_impossible=sum(rowSums(bad)>0L),
  baseline_sat_period_strata=length(groups),single_observed_binary_m_strata=single_m,
  relative_intervention_needs_definition=grepl('rel',g$x)|grepl('relative',g$m),
  assessment=if(any(as.matrix(bad)))'STRUCTURAL_CONTRAST_VIOLATION' else 'NECESSARY_BOUNDS_ONLY_PASS')
 details[[i]]<-list(spec_id=g$spec_id,original_rows=idx[rowSums(bad)>0L],
  flags=bad[rowSums(bad)>0L,,drop=FALSE])
}
tab<-do.call(rbind,rows)
stopifnot(identical(hashes,vapply(inputs,function(p)digest(file=p,algo='sha256'),character(1))))
dir.create(dest)
write.csv(tab,file.path(dest,'specification_support.csv'),row.names=FALSE)
saveRDS(details,file.path(dest,'violating_rows.rds'),compress='gzip')
result<-list(status='AUDIT_COMPLETED_NOT_MODEL_ADMISSION',models_fitted=0L,
 specs=nrow(tab),structural_violation_specs=sum(tab$assessment=='STRUCTURAL_CONTRAST_VIOLATION'),
 bounds_only_pass_specs=sum(tab$assessment=='NECESSARY_BOUNDS_ONLY_PASS'),
 limitations=c('Necessary endpoint bounds are not conditional positivity or causal identification',
 'No sample restriction, contrast alteration, model exclusion or fitting performed',
 'Binary change interventions have multiple endpoint versions; relative interventions require joint definition',
 'Natural-effect simulations may violate bounded mediator support even if fixed mval is feasible'),
 input_sha256=as.list(hashes),at=as.character(Sys.time()))
write_json(result,file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
print(table(tab$assessment));cat('NO_MODELS_FITTED\n')
