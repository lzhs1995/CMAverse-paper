# 只读输入清点；不拟合或变更正式数据。
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927"
out <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1"
d <- readRDS(file.path(root,"data/identity_target_13092.rds"))
stopifnot(nrow(d)==13092,!anyDuplicated(d$stable_row_id))
summarize <- function(n) {
 x<-d[[n]]; z<-x[!is.na(x)]
 numeric<-is.numeric(x)
 data.frame(variable=n,class=paste(class(x),collapse="/"),rows=length(x),missing=sum(is.na(x)),
 distinct=length(unique(z)),min=if(numeric&&length(z))min(z) else NA_real_,
 max=if(numeric&&length(z))max(z) else NA_real_,
 zeros=if(numeric)sum(z==0) else NA_integer_,
 negatives=if(numeric)sum(z<0) else NA_integer_,
 label=if(is.null(attr(x,"label")))"" else as.character(attr(x,"label")),
 stringsAsFactors=FALSE)
}
inventory<-do.call(rbind,lapply(names(d),summarize))
write.csv(inventory,file.path(out,"variable_inventory.csv"),row.names=FALSE,na="")
wanted<-grepl("aincc|^inc_|msat|esup|eligible|target|event_all|same_|period|cluster",names(d))
write.csv(inventory[wanted,],file.path(out,"xmy_variable_inventory.csv"),row.names=FALSE,na="")
gate<-d$same_actor %in% TRUE & d$same_parent %in% TRUE & d$same_partner %in% TRUE
targets<-grep("(_target|_event_all|^eligible_)",names(d),value=TRUE)
tab<-do.call(rbind,lapply(targets,function(n){
 t<-table(d[[n]][gate],useNA="always")
 data.frame(variable=n,value=names(t),n=as.integer(t))
}))
write.csv(tab,file.path(out,"identity_kept_target_counts.csv"),row.names=FALSE)
cat("READ_ONLY_COMPLETE rows=",nrow(d)," variables=",ncol(d)," identity_kept=",sum(gate),"\n",sep="")
print(inventory[wanted,c("variable","missing","distinct","min","max")],row.names=FALSE)

