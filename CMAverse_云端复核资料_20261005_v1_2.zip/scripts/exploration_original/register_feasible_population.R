# 固定端点可行人群登记及子模型诊断；不计算或读取效应p值。
options(stringsAsFactors=FALSE)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite); library(digest)
s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
dest <- file.path(s,'feasible_population_v1')
stopifnot(!dir.exists(dest))
inputs <- c(file.path(root,c('data/v6_provisional_dyad_intervals_recovered.rds','data/identity_target_13092.rds')),
 file.path(s,c('candidate_data.R','baseline_adjustment.R','cluster_membership.csv','registry_v1/specifications.csv',
 'registry_v1/sample_membership.rds','intervention_support_v1/violating_rows.rds','register_feasible_population.R')))
before <- vapply(inputs,function(p)digest(file=p,algo='sha256'),character(1))
source(file.path(s,'candidate_data.R')); source(file.path(s,'baseline_adjustment.R'))
reg <- read.csv(file.path(s,'registry_v1/specifications.csv'))
old <- readRDS(file.path(s,'registry_v1/sample_membership.rds'))
bad <- readRDS(file.path(s,'intervention_support_v1/violating_rows.rds'))
names(bad) <- vapply(bad,`[[`,'','spec_id')
cm <- read.csv(file.path(s,'cluster_membership.csv'))
stopifnot(nrow(cm)==nrow(z),identical(as.character(cm$dyad_id),as.character(d$dyad_id)))
dir.create(dest)
progress <- function(i) {
 write_json(list(stage='FEASIBLE_POPULATION_DIAGNOSTICS',completed=i,total=nrow(reg),pid=Sys.getpid(),
 updated_at=as.character(Sys.time())),file.path(dest,'PROGRESS.json'),auto_unbox=TRUE,pretty=TRUE)
 cat('FEASIBLE_POPULATION',i,'/',nrow(reg),'\n');flush.console()
}
# 不使用结果列：依据原基线与预定干预值独立重建所有越界判断。
flags <- function(g,zz) {
 bx <- function(a) switch(g$x,
  abs_diff_10k=zz$actor_income_real_begin+10000*a < -1e-8,
  abs_log1p_10k=log1p(zz$actor_income_real_begin/10000)+a < -1e-12,
  rel_share_diff=zz$share_begin+a < -1e-12 | zz$share_begin+a > 1+1e-12,
  abs_increase=rep(FALSE,nrow(zz)),rel_transition_eligible=rep(FALSE,nrow(zz)),stop('unknown X'))
 bm <- function(a) {
  b <- if(grepl('^self_',g$m))zz$self_sat_begin else zz$spouse_sat_begin
  if(grepl('increase_',g$m))return(a==1 & b>=5)
  if(grepl('score_diff$',g$m))return(b+a<1 | b+a>5)
  if(grepl('relative_gap_diff$',g$m)) {
   gap <- if(grepl('^self_',g$m))zz$self_sat_begin-zz$spouse_sat_begin else zz$spouse_sat_begin-zz$self_sat_begin
   return(gap+a < -4 | gap+a > 4)
  }
  if(grepl('relative_transition$',g$m))return(rep(FALSE,nrow(zz)))
  stop('unknown M')
 }
 data.frame(x_astar=bx(g$astar),x_a=bx(g$a),m_0=bm(g$mval0),m_1=bm(g$mval1))
}
members <- list(); rows <- list(); composition <- list(); diagnostics <- list()
fm <- reformulate(c('X',covars),'M'); fy <- reformulate(c('X*M',covars),'Y')
progress(0)
for(i in seq_len(nrow(reg))) {
 g <- reg[i,]; parent <- g$spec_id; idx <- old[[parent]]$row_index
 stopifnot(identical(digest(idx,algo='sha256'),g$sample_sha256))
 f <- flags(g,z[idx,,drop=FALSE]); stopifnot(!anyNA(f))
 removed <- idx[rowSums(f)>0]
 stopifnot(identical(removed,bad[[parent]]$original_rows),identical(f[rowSums(f)>0,,drop=FALSE],bad[[parent]]$flags))
 use <- idx[rowSums(f)==0]; sid <- sub('CORE','FEAS',parent)
 stopifnot(length(use)>0,!any(as.matrix(flags(g,z[use,,drop=FALSE]))))
 members[[sid]] <- list(spec_id=sid,parent_spec_id=parent,row_index=use,excluded_row_index=removed,
  cluster=cm$historical_cluster[use],parent_sample_sha256=g$sample_sha256)
 g$parent_spec_id <- parent;g$spec_id <- sid;g$parent_n <- g$n;g$parent_clusters <- g$clusters
 g$n <- length(use);g$clusters <- length(unique(cm$historical_cluster[use]));g$excluded_n <- length(removed)
 g$excluded_fraction <- length(removed)/length(idx);g$sample_sha256 <- digest(use,algo='sha256')
 g$stage <- 'FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED'
 g$support_note <- 'Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate'
 rows[[i]] <- g
 for(nm in covars) {
  if(is.factor(C[[nm]])) {
   a<-table(C[[nm]][idx]); b<-table(C[[nm]][use])
   composition[[length(composition)+1L]]<-data.frame(spec_id=sid,variable=nm,level=names(a),
    statistic='proportion',original=as.numeric(a)/length(idx),retained=as.numeric(b)/length(use))
  } else composition[[length(composition)+1L]]<-data.frame(spec_id=sid,variable=nm,level='',statistic='mean',
   original=mean(C[[nm]][idx]),retained=mean(C[[nm]][use]))
 }
 frame <- data.frame(X=X[[g$x]][use],M=M[[g$m]][use],Y=Y[[g$y]][use],C[use,,drop=FALSE])
 for(role in c('mediator','outcome')) {
  warnings<-character();err<-'';binary<-if(role=='mediator')g$mreg=='logistic' else g$yreg=='logistic'
  fit<-tryCatch(withCallingHandlers(glm(if(role=='mediator')fm else fy,data=frame,
   family=if(binary)binomial() else gaussian(),control=glm.control(maxit=100)),
   warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}),
   error=function(e){err<<-conditionMessage(e);NULL})
  ok<-!is.null(fit)
  pred<-if(ok)predict(fit,type='response') else NA_real_
  diagnostics[[length(diagnostics)+1L]]<-data.frame(spec_id=sid,role=role,n=length(use),
   converged=ok && isTRUE(fit$converged),full_rank=ok && fit$rank==ncol(model.matrix(fit)),
   finite=ok && all(is.finite(coef(fit))),warning=paste(unique(warnings),collapse=' | '),error=err,
   prediction_min=if(ok)min(pred) else NA_real_,prediction_max=if(ok)max(pred) else NA_real_,
   observed_extreme_probability_fraction=if(ok && binary)mean(pred<.01 | pred>.99) else NA_real_)
 }
 if(i%%10==0 || i==nrow(reg))progress(i)
}
tab<-do.call(rbind,rows);diag<-do.call(rbind,diagnostics)
stopifnot(nrow(tab)==150L,nrow(diag)==300L,!anyDuplicated(tab$spec_id),
 identical(before,vapply(inputs,function(p)digest(file=p,algo='sha256'),character(1))))
write.csv(tab,file.path(dest,'specifications.csv'),row.names=FALSE)
saveRDS(members,file.path(dest,'sample_membership.rds'),compress='gzip')
write.csv(do.call(rbind,composition),file.path(dest,'baseline_composition.csv'),row.names=FALSE)
write.csv(diag,file.path(dest,'glm_diagnostics.csv'),row.names=FALSE)
artifacts<-file.path(dest,c('specifications.csv','sample_membership.rds','baseline_composition.csv','glm_diagnostics.csv'))
write_json(list(status='REGISTRATION_AND_SUBMODEL_DIAGNOSTICS_COMPLETE_NOT_BOOTSTRAP',specifications=nrow(tab),
 changed_populations=sum(tab$excluded_n>0),sample_range=range(tab$n),cluster_range=range(tab$clusters),
 excluded_fraction_range=range(tab$excluded_fraction),submodels=nrow(diag),converged=sum(diag$converged),
 full_rank=sum(diag$full_rank),finite=sum(diag$finite),warning_fits=sum(nzchar(diag$warning)),error_fits=sum(nzchar(diag$error)),
 B200_submitted=FALSE,runtime='standalone_Rscript_diagnostic',source_unchanged=TRUE,
 source=lapply(seq_along(inputs),function(j)list(path=inputs[j],sha256=before[j])),
 artifacts=lapply(artifacts,function(p)list(path=p,sha256=digest(file=p,algo='sha256'),bytes=file.info(p)$size)),
 limitations=c('Different baseline target populations are different estimands','Observed fitted probabilities do not establish positivity',
 'No indirect-effect p-values calculated; no statistical significance selection','Continuous natural mediator support remains to be assessed'),
 at=as.character(Sys.time())),file.path(dest,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('FEASIBLE_REGISTRATION_COMPLETE changed=',sum(tab$excluded_n>0),' n=',paste(range(tab$n),collapse=':'),
 ' fullrank=',sum(diag$full_rank),'/300\n');flush.console()
