# 全族终态后执行既定筛选；不改变编码、样本或原始结果。
library(jsonlite)
library(digest)
args <- commandArgs(TRUE)
stopifnot(length(args)==2L)
input_dir <- normalizePath(args[1])
s <- dirname(input_dir)
out <- args[2]
stopifnot(!file.exists(out))
ref <- function(p) list(path=normalizePath(p),sha256=digest(file=p,algo="sha256"),bytes=unname(file.info(p)$size))
check_ref <- function(r) {
 z <- ref(r$path)
 stopifnot(identical(z$sha256,r$sha256),z$bytes==r$bytes)
}
audit <- read_json(file.path(input_dir,"RESULT.json"),simplifyVector=TRUE)
stopifnot(audit$status=="PASS_COMPACT_INPUT_AUDIT")
check_ref(audit$inputs);check_ref(audit$source_proofs);check_ref(audit$status_source)
status <- read_json(audit$status_source$path,simplifyVector=TRUE)
if(status$pending_specifications!=0L ||
 status$validated_specifications+status$unsuitable_specifications!=150L)
 stop("INCOMPLETE_UNIVERSE: all 150 specifications must be terminal before selection")
input <- readRDS(audit$inputs$path)
check_ref(input$status_source);check_ref(status$decision_evidence)
meta <- read.csv(file.path(s,"feasible_population_v1/specifications.csv"))
sig <- read.csv(file.path(s,"coding_equivalence_v2/SIGNATURES.csv"))
meta$signature <- sig$signature[match(meta$spec_id,sig$spec_id)]
stopifnot(identical(meta,input$meta),length(input$verified)==150L,
 sum(input$verified)==status$validated_specifications)
decisions <- read.csv(status$decision_evidence$path)
unsuitable_ids <- decisions$spec_id[grepl("^UNSUITABLE_",decisions$status)]
unsuitable <- meta$spec_id %in% unsuitable_ids
stopifnot(sum(unsuitable)==status$unsuitable_specifications,!any(unsuitable & input$verified))
terminal <- input$verified | unsuitable
stopifnot(all(terminal))
source(file.path(s,"selection_and_stability_v1.R"))
result <- freeze_core_selection(meta,input$point,input$draws,terminal,input$verified)
# 独立读回原表，防止检验尺度或p值在汇总阶段被改变。
original <- read.csv(file.path(dirname(audit$status_source$path),"ALL_300_STATUS.csv"))
key <- function(d) paste(d$spec_id,d$metric,sep="|")
ix <- match(key(result$results),key(original))
stopifnot(!anyNA(ix))
q <- result$results$eligible
stopifnot(all(abs(result$results$p[q]-original$p_exploratory[ix[q]])<1e-12),
 all(is.na(result$results$p[!q])),
 length(result$candidate_ids)<=12L,!anyDuplicated(result$candidate_ids))
for(metric in unique(result$results$metric)) {
 r <- result$results[result$results$metric==metric,]
 internal <- ifelse(r$eligible,r$p,1)
 stopifnot(all(abs(r$BH[r$eligible]-p.adjust(internal,"BH")[r$eligible])<1e-12),
 all(abs(r$BY[r$eligible]-p.adjust(internal,"BY")[r$eligible])<1e-12))
}
dir.create(out,recursive=TRUE)
saveRDS(result,file.path(out,"SELECTION.rds"))
write.csv(result$results,file.path(out,"ALL_300_ADJUSTED.csv"),row.names=FALSE,na="")
write.csv(result$stability,file.path(out,"STABILITY.csv"),row.names=FALSE,na="")
write.csv(result$meta[result$meta$spec_id %in% result$candidate_ids,],
 file.path(out,"FROZEN_CANDIDATES.csv"),row.names=FALSE)
proof <- list(status="PASS_FROZEN_EXPLORATORY_SELECTION",at=as.character(Sys.time()),
 registered=150L,validated=sum(input$verified),unsuitable=sum(unsuitable),
 candidate_ids=result$candidate_ids,new_candidate_B1000_completed=0L,
 independent_confirmation=FALSE,all_results_retained=TRUE,
 input_audit=ref(file.path(input_dir,"RESULT.json")),
 selection_code=ref(file.path(s,"selection_and_stability_v1.R")),
 driver=ref(file.path(s,"run_final_selection_v1.R")),
 artifacts=lapply(file.path(out,c("SELECTION.rds","ALL_300_ADJUSTED.csv",
 "STABILITY.csv","FROZEN_CANDIDATES.csv")),ref))
write_json(proof,file.path(out,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
print(proof[c("status","validated","unsuitable","candidate_ids")])
