# 新探索专用记录器：每个规格仍须另存完整cmest；逐次只保存效应与拟合诊断。
# 抽样计划、逐次种子、源数据和运行脚本由正式worker单独固定。
compact_grid <- function(grid) {
  lapply(grid, function(g) {
    models <- c(list(yreg=g$reg.output$yreg), g$reg.output$mreg,
                g$reg.output$postcreg)
    list(est=g$est, models=lapply(models,function(m) {
      stopifnot(inherits(m,'glm'))
      list(coefficients=coef(m),rank=m$rank,converged=m$converged,
           nobs=nobs(m),df_residual=df.residual(m),family=m$family$family,
           link=m$family$link,deviance=m$deviance)
    }))
  })
}

make_grid_recorder <- function(directory) {
  stopifnot(!dir.exists(directory))
  dir.create(directory,recursive=TRUE)
  function(grid,label) {
    stopifnot(length(label)==1L,grepl('^(bootstrap_[0-9]+|bootstrap_t0|point_[0-9]+)$',label))
    p <- file.path(directory,paste0(label,'.rds'))
    stopifnot(!file.exists(p))
    x <- compact_grid(grid)
    saveRDS(x,p,compress='gzip')
    stopifnot(identical(x,readRDS(p)))
    invisible(p)
  }
}

# 基于实际CMAverse列名固定尺度；比值之差Delta_Rcde不能取log。
extract_screening_metrics <- function(grid,effect_names) {
  stopifnot(length(grid)==2L)
  a <- grid[[1]]$est; b <- grid[[2]]$est
  stopifnot(length(a)==length(effect_names),length(b)==length(effect_names),
            !anyDuplicated(effect_names))
  names(a) <- names(b) <- effect_names
  # estinf中的原始statistic前六列是log比值，最终effect.pe才指数转换。
  if ('Rtnie' %in% effect_names) {
    stopifnot(identical(effect_names[1:6],c('Rcde','Rpnde','Rtnde','Rpnie','Rtnie','Rte')))
    a[1:6] <- exp(a[1:6]); b[1:6] <- exp(b[1:6])
  }
  if (all(c('Rtnie','Rcde') %in% names(a))) {
    stopifnot(all(c('Rtnie','Rcde') %in% names(b)),a[['Rtnie']]>0,b[['Rtnie']]>0)
    key <- 'Rtnie'; cde <- 'Rcde'; scale <- 'log_ratio'
  } else {
    stopifnot(all(c('tnie','cde') %in% names(a)),all(c('tnie','cde') %in% names(b)))
    key <- 'tnie'; cde <- 'cde'; scale <- 'additive'
  }
  # 自然间接效应不依赖受控M值；不从两个M值挑更显著的一项。
  stopifnot(isTRUE(all.equal(a[[key]],b[[key]],tolerance=1e-12)))
  pe <- c(TNIE=a[[key]],Delta_CDE=b[[cde]]-a[[cde]])
  transformed <- pe
  if(scale=='log_ratio')transformed[['TNIE']] <- log(pe[['TNIE']])
  stopifnot(all(is.finite(transformed)))
  list(effect=pe,test_value=transformed,
       scale=c(TNIE=scale,Delta_CDE=if(scale=='log_ratio')'ratio_difference' else 'additive'))
}

centered_bootstrap_test <- function(point,draws,expected_B,valid) {
  stopifnot(length(point)==1L,expected_B>=2L,length(draws)==expected_B,
            length(valid)==expected_B,is.logical(valid))
  if(!is.finite(point)||anyNA(valid)||!all(valid)||!all(is.finite(draws))) {
    return(list(p=NA_real_,status='INELIGIBLE',B=expected_B))
  }
  exceed <- sum(abs(draws-point)>=abs(point))
  list(p=(1+exceed)/(expected_B+1),status='VALID',B=expected_B,
       exceed=exceed,resolution=1/(expected_B+1),
       ci=unname(quantile(draws,c(.025,.975),type=7)))
}
