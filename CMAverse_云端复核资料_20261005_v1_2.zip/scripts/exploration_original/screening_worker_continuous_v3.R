# 独立worker函数：由已验收的原生RStudio驱动调用；source本文件不会拟合。
run_screening_spec <- function(spec_id, destination, admission, native_progress) {
  root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
  .libPaths(c(file.path(root,'runtime/library'),.libPaths()))
  library(CMAverse); library(jsonlite); library(digest)
  s <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
  stopifnot(is.list(admission), identical(admission$spec_id,spec_id),
    identical(admission$stage,'screen'), isTRUE(admission$native_smoke_verified),
    isTRUE(admission$support_reviewed),isTRUE(admission$storage_budget_verified),
    !dir.exists(destination))
  # 驱动必须提供可读回的准入原件；此函数不以空布尔标记代替证据。
  for(key in c('native_smoke','support','storage')) {
    ev <- admission[[paste0(key,'_evidence')]]
    stopifnot(is.list(ev),file.exists(ev$path),
      identical(digest(file=ev$path,algo='sha256'),ev$sha256))
  }
  stopifnot(is.function(native_progress), identical(admission$population_registry,'feasible_population_v1'))
  for(ev in admission$source_manifest) {
    stopifnot(file.exists(ev$path), identical(digest(file=ev$path,algo='sha256'),ev$sha256))
  }
  support <- read_json(admission$support_evidence$path,simplifyVector=FALSE)
  stopifnot(spec_id %in% support$specifications,
    identical(support$status,"EXPLORATORY_SCIENTIFIC_ADJUDICATION_COMPLETE"),
    identical(support$causal_identification_verified,FALSE))
  for(ev in support$evidence) {
    stopifnot(file.exists(ev$path),
      identical(digest(file=ev$path,algo="sha256"),ev$sha256))
  }
  storage <- read_json(admission$storage_evidence$path,simplifyVector=TRUE)
  stopifnot(storage$free_bytes >= storage$reserve_bytes + storage$planned_write_bytes + storage$download_buffer_bytes,
    as.numeric(Sys.time())-storage$checked_at_epoch < 600)
  native_progress('input_validation',paste(spec_id,'validating frozen identities'))
  registry <- read.csv(file.path(s,'feasible_population_v1/specifications.csv'))
  g <- registry[registry$spec_id==spec_id,,drop=FALSE];stopifnot(nrow(g)==1L)
  stopifnot(g$mreg == "linear",
    g$m %in% c("self_relative_gap_diff","spouse_relative_gap_diff"))
  plan <- readRDS(file.path(s,'feasible_sampling_v1/screen.rds'))
  stopifnot(plan$B==200L,
    identical(plan$registry_sha256,digest(file=file.path(s,'feasible_population_v1/specifications.csv'),algo='sha256')),
    identical(plan$membership_sha256,digest(file=file.path(s,'feasible_population_v1/sample_membership.rds'),algo='sha256')))
  env <- new.env(parent=environment())
  sys.source(file.path(s,'candidate_data.R'),env)
  sys.source(file.path(s,'baseline_adjustment.R'),env)
  m <- readRDS(file.path(s,'feasible_population_v1/sample_membership.rds'))[[spec_id]]
  stopifnot(identical(digest(m$row_index,algo='sha256'),g$sample_sha256))
  stopifnot(identical(support$sample_sha256[[spec_id]],g$sample_sha256))
  dat <- data.frame(X=env$X[[g$x]],M=env$M[[g$m]],Y=env$Y[[g$y]],env$C)[m$row_index,,drop=FALSE]
  stopifnot(nrow(dat)==g$n,all(complete.cases(dat)))
  map <- split(seq_len(nrow(dat)),factor(m$cluster,levels=plan$clusters))
  indices <- lapply(plan$draws,function(draw)unlist(map[match(draw,plan$clusters)],use.names=FALSE))
  stopifnot(all(lengths(indices)>0L))
  dir.create(destination,recursive=TRUE)
  write_json(admission,file.path(destination,'ADMISSION.json'),auto_unbox=TRUE,pretty=TRUE)
  saveRDS(list(actual_indices=indices,replicate_seeds=plan$replicate_seeds,
    point_seed=plan$point_seed,sample=m,spec=g),file.path(destination,'execution_inputs.rds'),compress='gzip')
  sys.source(file.path(s,'screening_records.R'),env)
  sys.source(file.path(root,'next_phase/PLAN12_八链适用性评估_20260928/scripts/shared_bootstrap_diagnostic.R'),env)
  progress <- function(b,R,last) {
    row <- list(stage='B200',spec_id=spec_id,completed=b,total=R,
      pid=Sys.getpid(),updated_at=as.character(Sys.time()),last=last)
    p <- file.path(destination,'PROGRESS.json'); tmp <- paste0(p,'.tmp')
    write_json(row,tmp,auto_unbox=TRUE,pretty=TRUE);stopifnot(file.rename(tmp,p))
    native_progress('bootstrap',paste(spec_id,b,'of',R,'completed'))
    cat(spec_id,': bootstrap',b,'/',R,'\n');flush.console()
  }
  bridge <- env$make_shared_cmest(indices,plan$replicate_seeds,progress)
  bridge$state$save_grid <- env$make_grid_recorder(file.path(destination,'grids'))
  # 清理捕获环境而保留完整拟合内容，避免每个glm序列化整个worker环境。
  sanitize <- function(a) {
    if(inherits(a,'glm')) {
      f <- family(a);a$family <- if(f$family=='binomial')binomial(link=f$link) else gaussian(link=f$link)
      if(!is.null(a$terms))attr(a$terms,'.Environment')<-baseenv()
      if(inherits(a$formula,'formula'))environment(a$formula)<-baseenv()
      if(inherits(a$call$formula,'formula'))environment(a$call$formula)<-baseenv()
      if(!is.null(attr(a$model,'terms')))attr(attr(a$model,'terms'),'.Environment')<-baseenv()
      return(a)
    }
    if(is.list(a))return(lapply(a,sanitize));a
  }
  args <- list(data=dat,model='gformula',outcome='Y',exposure='X',mediator='M',basec=env$covars,
    yreg=g$yreg,mreg=list(g$mreg),EMint=TRUE,astar=g$astar,a=g$a,
    mval_grid=list(c(g$mval0,g$mval1)),estimation='imputation',inference='bootstrap',
    nboot=plan$B,boot.ci.type='per',full=TRUE)
  if(g$yreg=='logistic')args$yval<-1
  warnings <- character();set.seed(plan$point_seed)
  progress(0L,plan$B,NULL)
  fit <- tryCatch(withCallingHandlers(do.call(bridge$cmest,args),warning=function(w){
    warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')
  }),error=function(e)e)
  dg <- if(length(bridge$state$diagnostics))do.call(rbind,bridge$state$diagnostics) else data.frame()
  write.csv(dg,file.path(destination,'repeat_diagnostics.csv'),row.names=FALSE)
  writeLines(unique(warnings),file.path(destination,'warnings.txt'))
  ok <- !inherits(fit,'error')
  if(ok) {
    native_progress('saving',paste(spec_id,'saving full cmest and readback'))
    fit$reg.output <- sanitize(fit$reg.output)
    for(nm in names(fit$mval_results))fit$mval_results[[nm]]$reg.output<-sanitize(fit$mval_results[[nm]]$reg.output)
    fit$execution_provenance <- list(spec_id=spec_id,B=plan$B,admission=admission,
      sampling_plan_sha256=digest(file=file.path(s,'feasible_sampling_v1/screen.rds'),algo='sha256'))
    p <- file.path(destination,'cmest_full.rds');saveRDS(fit,p,compress='gzip')
    stopifnot(isTRUE(all.equal(fit,readRDS(p),check.environment=FALSE)))
  }
  write_json(bridge$state$compatibility,file.path(destination,'ADAPTER_VALIDATION.json'),auto_unbox=TRUE,pretty=TRUE)
  writeLines(capture.output(sessionInfo()),file.path(destination,'sessionInfo.txt'))
  terminal <- list(status=if(ok)'COMPLETED' else 'FAILED',spec_id=spec_id,B=plan$B,
    execution_ok=ok,repeats=nrow(dg),valid=if(nrow(dg))sum(dg$fits_valid & dg$core_finite) else 0L,
    error=if(ok)NULL else conditionMessage(fit),pid=Sys.getpid(),at=as.character(Sys.time()),
    interpretation='Function terminal only; driver must separately collect child process exit')
  write_json(terminal,file.path(destination,'FUNCTION_TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE)
  native_progress(if(ok)'completed' else 'failed',paste(spec_id,terminal$status))
  invisible(terminal)
}
