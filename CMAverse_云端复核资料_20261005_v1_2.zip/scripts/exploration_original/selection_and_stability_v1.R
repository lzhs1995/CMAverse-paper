# 探索筛选汇总：只使用冻结家族；未终态不能冻结候选。
# 输入每个登记规格一行，另附B×规格的检验尺度bootstrap矩阵。
adjust_family <- function(p, eligible, family_n=150L) {
 stopifnot(length(p)==length(eligible),length(p)<=family_n,!anyNA(eligible))
 active <- eligible & is.finite(p)
 stopifnot(all(p[active]>=0 & p[active]<=1))
 internal <- rep(1,length(p));internal[active]<-p[active]
 list(BH=replace(p.adjust(internal,'BH',n=family_n),!active,NA_real_),
      BY=replace(p.adjust(internal,'BY',n=family_n),!active,NA_real_))
}
# 以数值等价及原反号等价的并集去重；保留150检验分母。
equivalence_components <- function(meta) {
 stopifnot(!anyDuplicated(meta$spec_id),all(c('signature','equivalent_m_family','x','y') %in% names(meta)))
 n<-nrow(meta);parent<-seq_len(n)
 root<-function(k){while(parent[k]!=k)k<-parent[k];k}
 link<-function(ix){if(length(ix)>1L)for(j in ix[-1L])parent[root(j)]<<-root(ix[1L])}
 for(key in c('signature','family')) {
  groups<-if(key=='signature')meta$signature else paste(meta$x,meta$y,meta$equivalent_m_family,sep='|')
  for(ix in split(seq_len(n),groups))link(ix)
 }
 vapply(seq_len(n),root,integer(1))
}
pick_candidates <- function(meta, eligible, primary, secondary) {
 stopifnot(nrow(meta)==length(eligible),length(primary)==nrow(meta),length(secondary)==nrow(meta))
 ans<-integer()
 for(y in unique(meta$y)) {
  ix<-which(eligible & meta$y==y & is.finite(primary) & is.finite(secondary))
  ix<-ix[order(primary[ix],secondary[ix],meta$spec_id[ix])]
  seen<-integer();taken<-0L
  for(j in ix) {
   if(meta$equivalence_group[j] %in% seen)next
   ans<-c(ans,j);seen<-c(seen,meta$equivalence_group[j]);taken<-taken+1L
   if(taken==2L)break
  }
 }
 ans
}
freeze_core_selection <- function(meta, point, draws, terminal, admissible) {
 stopifnot(nrow(meta)==150L,!anyDuplicated(meta$spec_id),
  length(terminal)==150L,!anyNA(terminal),all(terminal),length(admissible)==150L,!anyNA(admissible),
  identical(names(point),c('TNIE','Delta_CDE')),identical(names(draws),names(point)))
 meta$equivalence_group<-equivalence_components(meta)
 rows<-list();selected<-list();stability<-list();blocks<-list()
 for(metric in names(point)) {
  theta<-point[[metric]];mat<-draws[[metric]]
  stopifnot(length(theta)==150L,identical(dim(mat),c(200L,150L)),
   identical(colnames(mat),meta$spec_id))
  eligible<-admissible & is.finite(theta) & colSums(is.finite(mat))==200L
  p<-rep(NA_real_,150L)
  for(j in which(eligible))p[j]<-(1+sum(abs(mat[,j]-theta[j])>=abs(theta[j])))/201
  adj<-adjust_family(p,eligible)
  ix<-pick_candidates(meta,eligible,adj$BY,p)
  selected[[metric]]<-meta$spec_id[ix]
  rows[[metric]]<-data.frame(spec_id=meta$spec_id,metric=metric,eligible=eligible,
    test_value=theta,p=p,BH=adj$BH,BY=adj$BY,selected=seq_len(150L) %in% ix)
  se<-apply(mat,2,sd);rankable<-eligible & is.finite(se) & se>0
  chosen<-matrix(FALSE,200,150);ranks<-matrix(NA_real_,200,150)
  for(b in 1:200) {
   score<-abs(mat[b,])/se
   for(y in unique(meta$y)) {
    q<-which(rankable & meta$y==y)
    ranks[b,q]<-rank(-score[q],ties.method='min')
   }
   q<-pick_candidates(meta,rankable,-score,rep(0,150))
   chosen[b,q]<-TRUE
  }
  same_sign<-rep(NA_real_,150);same_sign[eligible]<-vapply(which(eligible),function(j)mean(sign(mat[,j])==sign(theta[j])),numeric(1))
  stability[[metric]]<-data.frame(spec_id=meta$spec_id,metric=metric,
   eligible=eligible,rankable=rankable,same_sign_fraction=same_sign,
   fixed_se_selection_frequency=ifelse(rankable,colMeans(chosen),NA_real_),
   median_within_y_rank=apply(ranks,2,function(x)if(all(is.na(x)))NA_real_ else median(x,na.rm=TRUE)))
  blocks[[metric]]<-lapply(1:10,function(k) {
   keep<-setdiff(1:200,((k-1L)*20L+1L):(k*20L));bp<-rep(NA_real_,150)
   for(j in which(eligible))bp[j]<-(1+sum(abs(mat[keep,j]-theta[j])>=abs(theta[j])))/181
   ba<-adjust_family(bp,eligible);q<-pick_candidates(meta,eligible,ba$BY,bp)
   list(omitted_block=k,p=bp,BH=ba$BH,BY=ba$BY,selected=meta$spec_id[q])
  })
 }
 candidates<-sort(unique(unlist(selected,use.names=FALSE)))
 stopifnot(length(candidates)<=12L)
 list(meta=meta,results=do.call(rbind,rows),candidate_ids=candidates,
  per_metric=selected,stability=do.call(rbind,stability),monte_carlo_blocks=blocks,
  B_screen=200L,B_verify=1000L,family_n=150L,
  interpretation='Exploratory selection; B1000 and internal stability are not independent confirmation')
}
