# 相对份额零分母、反向相对量与可用时间结构核验；不拟合。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
input <- file.path(root,'data/v6_provisional_dyad_intervals_recovered.rds')
sha <- digest::digest(file=input,algo='sha256')
v <- readRDS(input); d<-readRDS(file.path(root,'data/identity_target_13092.rds'))
j<-match(paste(d$dyad_id,d$period_label),paste(v$dyad_id,v$period));stopifnot(!anyNA(j));z<-v[j,]
same <- function(a,b) isTRUE(all.equal(a,b,check.attributes=FALSE,tolerance=1e-12))
share <- function(a,b)ifelse(is.na(a)|is.na(b),NA_real_,ifelse(a+b==0,.5,a/(a+b)))
stopifnot(same(z$share_begin,share(z$actor_income_real_begin,z$partner_income_real_begin)),same(z$share_end,share(z$actor_income_real_end,z$partner_income_real_end)))
stopifnot(same(z$dm_self_rel,(z$self_sat_end-z$spouse_sat_end)-(z$self_sat_begin-z$spouse_sat_begin)),same(z$dm_spouse_rel,-z$dm_self_rel))
zero0<-z$actor_income_real_begin+z$partner_income_real_begin==0
zero1<-z$actor_income_real_end+z$partner_income_real_end==0
write.csv(as.data.frame(table(baseline_both_zero=zero0,end_both_zero=zero1)),file.path(out,'income_zero_denominator.csv'),row.names=FALSE)
# 原始dyad仅有两区间；精确链接同本人/配偶/父母且中间观测年份相同。
a<-z[z$period=='2018-2020',];b<-z[z$period=='2020-2022',]
k<-function(q)paste(q$actor_pid_begin,q$partner_pid_begin,q$parent_pid_begin,q$parent_role,sep='::')
stopifnot(!anyDuplicated(k(a)),!anyDuplicated(k(b)))
ii<-match(k(a),k(b));ok<-!is.na(ii);aa<-a[ok,];bb<-b[ii[ok],]
mid <- c(actor_income_real='actor_income_real',partner_income_real='partner_income_real',self_sat='self_sat',spouse_sat='spouse_sat',support_real='support_real')
bridge<-do.call(rbind,lapply(names(mid),function(n){
 x<-aa[[paste0(n,'_end')]];y<-bb[[paste0(n,'_begin')]]
 data.frame(variable=n,linked=nrow(aa),na_mismatch=sum(is.na(x)!=is.na(y)),value_mismatch=sum(abs(x-y)>1e-10,na.rm=TRUE))
}))
write.csv(bridge,file.path(out,'three_wave_endpoint_bridge.csv'),row.names=FALSE)
res<-list(status='READ_ONLY_COMPLETE',input_sha256=sha,input_unchanged=identical(sha,digest::digest(file=input,algo='sha256')),
 both_zero_baseline=sum(zero0),both_zero_end=sum(zero1),both_zero_either=sum(zero0|zero1),
 existing_convention='share=0.5 when both incomes zero; exact reconstructed agreement',
 relative_mediators_exact_negatives=TRUE,linked_three_wave_rows=nrow(aa),unique_linked_actors=length(unique(aa$actor_pid_begin)),
 periods=unique(z$period),bridge=bridge,
 interpretation='Only two change intervals exist. Three sequential nonoverlapping X/M/Y change intervals cannot be constructed from this file. Lagged X-change / midpoint M-level / later Y-change is a different estimand and requires explicit timing assumptions.',
 decision='Register both-zero exclusion as a measurement sensitivity for continuous share; retain historical convention comparison. Reverse relative mediator is reparameterization, not independent corroboration.')
jsonlite::write_json(res,file.path(out,'STRUCTURE_AUDIT.json'),auto_unbox=TRUE,pretty=TRUE)
print(res[c('both_zero_baseline','both_zero_end','both_zero_either','linked_three_wave_rows','unique_linked_actors')]);print(bridge)
