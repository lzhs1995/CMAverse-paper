# 首次正式B200独立读回；不重新拟合，不改原模型。
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
.libPaths(c(file.path(root,'runtime/library'),.libPaths()))
library(jsonlite);library(digest)
s<-file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
source(file.path(s,'screening_records.R'))
argv<-commandArgs(TRUE);stopifnot(length(argv)==2L)
control<-argv[1];spec_id<-argv[2];p<-file.path(control,spec_id)
f<-readRDS(file.path(p,'cmest_full.rds'));inputs<-readRDS(file.path(p,'execution_inputs.rds'))
expected_names<-if(inputs$spec$yreg=='linear')c('cde','pnde','tnde','pnie','tnie','te','intref','intmed','cde(prop)','intref(prop)','intmed(prop)','pnie(prop)','pm','int','pe') else names(readRDS(file.path(s,'first_B200_v1/FEAS_001/cmest_full.rds'))$mval_results[[1]]$effect.pe)
dg<-read.csv(file.path(p,'repeat_diagnostics.csv'))
stopifnot(inherits(f,'cmest_mval_grid'),identical(names(f$mval_results),c('0','1')),
 nrow(dg)==200L,identical(dg$replicate,1:200),all(dg$execution_ok & dg$fits_valid & dg$core_finite))
ix<-inputs$actual_indices
pad<-matrix(NA_integer_,200,max(lengths(ix)))
for(b in 1:200)pad[b,seq_along(ix[[b]])]<-ix[[b]]
attr(pad,'row_lengths')<-lengths(ix)
attr(pad,'representation')<-'actual indices; right padding is not a sampled observation'
hash<-digest(pad,algo='sha256',serialize=TRUE,serializeVersion=2)
stopifnot(identical(pad,f$mval_grid$bootstrap_indices))
for(i in 1:2) {
 z<-f$mval_results[[i]]
 stopifnot(inherits(z,'cmest'),!is.null(z$reg.output),!is.null(z$call),
  nrow(z$data)==inputs$spec$n,ncol(z$data)==26L,identical(names(z$effect.pe),expected_names),
  z$ref$mval[[1]]==i-1L,identical(z$bootstrap_provenance$hash,hash))
}
en<-names(f$mval_results[[1]]$effect.pe)
pointgrid<-lapply(f$mval_results,function(z){
 v<-z$effect.pe
 if('Rtnie'%in%en)v[1:6]<-log(v[1:6])
 list(est=v)
})
pt<-extract_screening_metrics(pointgrid,en)
mat<-matrix(NA_real_,200,2,dimnames=list(NULL,c('TNIE','Delta_CDE')))
for(b in 1:200) {
 g<-readRDS(file.path(p,'grids',sprintf('bootstrap_%02d.rds',b)))
 raw<-unlist(lapply(g,`[[`,'est'),use.names=FALSE)
 stopifnot(isTRUE(all.equal(unname(raw),unname(f$mval_grid$bootstrap_t[b,]),tolerance=0)))
 for(v in g)for(mod in v$models)stopifnot(mod$converged,mod$rank==length(mod$coefficients),all(is.finite(mod$coefficients)))
 mat[b,]<-extract_screening_metrics(g,en)$test_value
}
rows<-lapply(names(pt$effect),function(k) {
 t<-centered_bootstrap_test(pt$test_value[[k]],mat[,k],200,rep(TRUE,200))
 ci<-t$ci;if(pt$scale[[k]]=='log_ratio')ci<-exp(ci)
 data.frame(spec_id=spec_id,metric=k,estimate=pt$effect[[k]],ci_low=ci[1],ci_high=ci[2],
  bootstrap_se_test_scale=sd(mat[,k]),test_scale=pt$scale[[k]],p_exploratory=t$p,
  p_resolution=t$resolution,valid=200,n=inputs$spec$n,clusters=length(unique(inputs$sample$cluster)),
  multiplicity='PENDING_FULL_150_FAMILY_NOT_SIGNIFICANCE_SELECTION')
})
tab<-do.call(rbind,rows);write.csv(tab,file.path(control,'METRICS.csv'),row.names=FALSE)
saveRDS(list(point=pt,bootstrap_test_values=mat),file.path(control,'METRICS.rds'))
all_effects<-do.call(rbind,lapply(1:2,function(i){
 z<-f$mval_results[[i]]
 data.frame(mval=i-1L,effect=names(z$effect.pe),estimate=unname(z$effect.pe),se=unname(z$effect.se),
 ci_low=unname(z$effect.ci.low),ci_high=unname(z$effect.ci.high),p_native=unname(z$effect.pval))
}))
write.csv(all_effects,file.path(control,'ALL_NATIVE_EFFECTS.csv'),row.names=FALSE)
term<-read_json(file.path(control,'DRIVER_TERMINAL.json'),simplifyVector=TRUE)
paths<-list.files(p,recursive=TRUE,full.names=TRUE)
result<-list(status='PASS_FIRST_B200_ARTIFACTS',spec_id=spec_id,B=200,valid=200,n=inputs$spec$n,clusters=length(unique(inputs$sample$cluster)),
 full_paired_cmest=TRUE,effects_per_mval=length(expected_names),data_columns=26,
 exact_grid_vs_full_bootstrap=TRUE,paired_actual_indices_sha256=hash,
 elapsed_sec=term$elapsed_sec,worker_pid=term$pid,full_object_bytes=file.info(file.path(p,'cmest_full.rds'))$size,
 output_bytes=sum(file.info(paths)$size),
 full_object_sha256=digest(file=file.path(p,'cmest_full.rds'),algo='sha256'),
 metadata_caveat='Native provenance sample_size describes padded index width; actual sample is recorded in n and bootstrap n varies. Actual lengths preserved and verified; padding is not observations.',
 interpretation='Exploratory, no full-family ranking yet; model validity does not establish causal identification',
 at=as.character(Sys.time()))
write_json(result,file.path(control,'ARTIFACT_VALIDATION.json'),auto_unbox=TRUE,pretty=TRUE)
print(tab);cat('PAIR_AND_ALL_200_GRID_VALIDATION_PASS\n')

