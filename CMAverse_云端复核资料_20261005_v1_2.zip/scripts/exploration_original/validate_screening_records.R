# 只重放已有B10对象，零重估、零删除；检查完整效应与记录器的等价性。
library(jsonlite);library(digest)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1'
source(file.path(root,'screening_records.R'))
dest <- file.path(root,'recording_validation_v2')
stopifnot(!dir.exists(dest));dir.create(dest)
rows <- list()
for(i in 1:8) {
  id <- sprintf('TYPE_%02d',i); base <- file.path(root,'compatibility_b10_v1',id)
  full <- readRDS(file.path(base,'cmest_full.rds'))
  paths <- list.files(base,pattern='^(bootstrap_|point_).*\\.rds$',full.names=TRUE)
  recorder <- make_grid_recorder(file.path(dest,id))
  point <- NULL; extracted <- list()
  for(p in paths) {
    before <- digest(file=p,algo='sha256');g <- readRDS(p)
    label <- sub('\\.rds$','',basename(p));q <- recorder(g,label);small <- readRDS(q)
    stopifnot(identical(lapply(g,`[[`,'est'),lapply(small,`[[`,'est')),
              identical(before,digest(file=p,algo='sha256')))
    metrics <- extract_screening_metrics(small,names(full$effect.pe))
    if(label=='bootstrap_t0')point <- metrics
    if(grepl('^bootstrap_[0-9]+$',label))extracted[[label]] <- metrics
    rows[[length(rows)+1L]] <- data.frame(type=id,label=label,
       original_bytes=file.info(p)$size,record_bytes=file.info(q)$size,source_sha=before)
  }
  full <- readRDS(file.path(base,'cmest_full.rds'))
  stopifnot(length(extracted)==10L,
    isTRUE(all.equal(unname(point$effect[['Delta_CDE']]),unname(full$delta_cde$effect.pe),tolerance=1e-12)))
  # 此处只验映射和边界，不报告B10显著性或筛选赢家。
  draws <- vapply(extracted,function(x)x$test_value[['TNIE']],numeric(1))
  check <- centered_bootstrap_test(point$test_value[['TNIE']],draws,10L,rep(TRUE,10L))
  stopifnot(check$p>=1/11,check$p<=1,
    is.na(centered_bootstrap_test(0,draws,10L,c(FALSE,rep(TRUE,9)))$p))
  cat(id,'records',length(paths),'PASS\n');flush.console()
}
stopifnot(centered_bootstrap_test(0,c(-1,0,1),3L,rep(TRUE,3))$p==1,
          centered_bootstrap_test(10,c(9,10,11),3L,rep(TRUE,3))$p==.25)
tab <- do.call(rbind,rows);write.csv(tab,file.path(dest,'record_sizes.csv'),row.names=FALSE)
write_json(list(status='PASS',types=8,records=nrow(tab),
   original_bytes=sum(tab$original_bytes),record_bytes=sum(tab$record_bytes),
   effect_vectors_exact=TRUE,source_sha_unchanged=TRUE,zero_refits=TRUE,
   full_cmest_still_required=TRUE,formal_screening_started=FALSE,
   module_sha=digest(file=file.path(root,'screening_records.R'),algo='sha256')),
   file.path(dest,'RESULT.json'),pretty=TRUE,auto_unbox=TRUE)
