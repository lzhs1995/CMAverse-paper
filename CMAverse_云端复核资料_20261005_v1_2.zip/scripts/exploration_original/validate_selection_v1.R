# 统计选择器边界验收，合成数据，不是研究估计或真实候选。
source("/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/selection_and_stability_v1.R")
library(jsonlite)
out<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/selection_validation_v1"
stopifnot(!dir.exists(out));dir.create(out)
a<-adjust_family(c(.001,.02,.3),c(TRUE,TRUE,TRUE))
stopifnot(isTRUE(all.equal(a$BH,c(.15,1,1))),a$BY[1]>.15)
b<-adjust_family(c(.001,1e-20,.3),c(TRUE,FALSE,TRUE))
stopifnot(is.na(b$BH[2]),b$BH[1]==.15)
meta<-data.frame(spec_id=sprintf('FEAS_%03d',1:150),signature=paste0('s',1:150),
 equivalent_m_family=paste0('m',1:150),x='x',y=rep(c('y1','y2','y3'),each=50))
meta$signature[2]<-meta$signature[1]
meta$equivalent_m_family[3]<-meta$equivalent_m_family[1]
g<-equivalence_components(meta);stopifnot(g[1]==g[2],g[1]==g[3],g[1]!=g[4])
set.seed(41);mat<-matrix(rnorm(200*150),200,150,dimnames=list(NULL,meta$spec_id))
theta<-rep(.2,150);theta[c(1,2,3,51,101)]<-3
inputs<-list(meta=meta,point=list(TNIE=theta,Delta_CDE=theta),
 draws=list(TNIE=mat,Delta_CDE=mat),terminal=rep(TRUE,150),admissible=rep(TRUE,150))
blocked<-inputs;blocked$terminal[150]<-FALSE
stopifnot(inherits(try(do.call(freeze_core_selection,blocked),silent=TRUE),'try-error'))
z<-do.call(freeze_core_selection,inputs)
stopifnot(length(z$candidate_ids)<=12,nrow(z$results)==300,nrow(z$stability)==300,
 all(z$results$p>=1/201),length(z$monte_carlo_blocks$TNIE)==10)
for(metric in names(z$per_metric)) {
 ix<-match(z$per_metric[[metric]],meta$spec_id)
 stopifnot(!anyDuplicated(g[ix]),all(table(meta$y[ix])<=2))
}
# 比值TNIE须由调用者先转为log；这里验证检验尺度同时反号不改变p与选择。
reflected<-inputs
reflected$point<-lapply(reflected$point,function(x)-x)
reflected$draws<-lapply(reflected$draws,function(x)-x)
zr<-do.call(freeze_core_selection,reflected)
stopifnot(identical(z$results$p,zr$results$p),identical(z$candidate_ids,zr$candidate_ids))
write_json(list(status='PASS_SYNTHETIC_ONLY',checks=c('BH_known_three_p_family150','invalid_hidden_minimum_not_selected','equivalence_transitive_union','pending_blocks_freeze','quota_and_dedup','finite_bootstrap_resolution','ten_omit_blocks','sign_reflection_invariance'),real_candidates_frozen=FALSE),file.path(out,'RESULT.json'),auto_unbox=TRUE,pretty=TRUE)
cat('SELECTION_BOUNDARIES_PASS no_real_selection\n')
