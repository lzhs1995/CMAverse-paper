# ==============================================================================
# 基础关系与候选机制诊断 v6
# 说明：
# 1. 从 predata_FE_16_22_unbal.dta 与上游 temple 数据重建，不读取旧差分变量作为主变量。
# 2. 当前本机缺少四期原始 person DTA，养老金结构性零/拒答及 QI203 旧插补无法彻底修复；
#    因而 composite income 标记为 provisional_legacy_pension。
# 3. 当前经营收入代理量在上游已截断负值；主结果同时标记为 provisional_nonnegative_business。
# 4. 本脚本完成数据血缘、八条链基础关系、支持度和时序门槛；不冒充正式 CMAverse。
# ==============================================================================

options(stringsAsFactors = FALSE, scipen = 999,
        contrasts = c("contr.treatment", "contr.poly"))

required_packages <- c(
  "haven", "dplyr", "tidyr", "readr", "tibble", "purrr", "stringr",
  "sandwich", "lmtest", "igraph", "digest", "jsonlite", "ggplot2"
)
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages)) stop("缺少R包：", paste(missing_packages, collapse = ", "))

suppressPackageStartupMessages({
  library(haven); library(dplyr); library(tidyr); library(readr)
  library(tibble); library(purrr); library(stringr); library(sandwich)
  library(lmtest); library(igraph); library(digest); library(ggplot2)
})

# ---- 冻结路径 ----------------------------------------------------------------
root <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260904_basic_mechanism_v6"
data_dir <- file.path(root, "data")
result_dir <- file.path(root, "results")
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)

raw_dta <- "/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/Prepare_data/predata_FE_16_22_unbal.dta"
id_dta <- "/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/Prepare_data/20230928 temple_2016_22_unbal.dta"
old_csv <- "/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/causal_mediation_18&20_20&22_bal.csv"
v2_marker <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260902_basic_regression_outputs_v2/07_common_sample_marker.csv"
stopifnot(file.exists(raw_dta), file.exists(id_dta), file.exists(old_csv), file.exists(v2_marker))

source_files <- tibble(
  source_id = c("analysis_long", "identity_wide", "old_difference", "v2_marker",
                "cfps2016_person", "cfps2018_person", "cfps2020_person", "cfps2022_person"),
  path = c(raw_dta, id_dta, old_csv, v2_marker, rep(NA_character_, 4)),
  available = c(rep(TRUE, 4), rep(FALSE, 4)),
  role = c(
    "既有上游长数据；收入/满意度/支持/协变量",
    "恢复actor、partner、parent PID",
    "仅用于旧值—新值审计",
    "仅用于复现v2共同样本375条变化",
    rep("养老金原始跳转、QI202/QI203及官方估计变量；本机未找到", 4)
  )
)
write_csv(source_files, file.path(result_dir, "00_source_availability.csv"))
all_source_names <- names(read_dta(raw_dta, n_max = 1))
weight_candidates <- all_source_names[str_detect(all_source_names,
                                                 regex("weight|(^|_)wt($|_)|rswt", ignore_case = TRUE))]
weight_audit <- tibble(
  available = length(weight_candidates) > 0,
  candidate = if (length(weight_candidates)) paste(weight_candidates, collapse = ";") else NA_character_,
  decision = if (length(weight_candidates)) "REVIEW_BEFORE_WEIGHTED_SENSITIVITY" else
    "UNAVAILABLE_ANALYSIS_SAMPLE_ESTIMAND_ONLY"
)
write_csv(weight_audit, file.path(result_dir, "00a_weight_availability.csv"))

# ---- 工具函数 ----------------------------------------------------------------
na_if_negative <- function(x) {
  x <- haven::zap_labels(x)
  x[!is.na(x) & x < 0] <- NA_real_
  as.numeric(x)
}

binary_change <- function(begin, end) {
  ifelse(is.na(begin) | is.na(end), NA_integer_, as.integer(end > begin))
}

eligible_binary_transition <- function(begin_status, end_status, eligible) {
  ifelse(is.na(begin_status) | is.na(end_status) | is.na(eligible), NA_integer_,
         ifelse(!eligible, NA_integer_, as.integer(begin_status == 0 & end_status == 1)))
}

deterministic_ridit <- function(x) {
  ok <- !is.na(x); out <- rep(NA_real_, length(x))
  if (any(ok)) out[ok] <- (rank(x[ok], ties.method = "average") - 0.5) / sum(ok)
  out
}

safe_factor <- function(x) factor(x, exclude = NULL)
`%||%` <- function(x, y) if (is.null(x)) y else x

formula_unique <- function(lhs, rhs) {
  rhs <- unique(rhs[!is.na(rhs) & nzchar(rhs)])
  as.formula(paste(lhs, "~", paste(rhs, collapse = " + ")))
}

formula_text <- function(x) paste(deparse(x, width.cutoff = 500L), collapse = " ")

fit_glm_capture <- function(formula, data, family) {
  warns <- character()
  fit <- withCallingHandlers(
    glm(formula, data = data, family = family, x = TRUE, y = TRUE, model = TRUE),
    warning = function(w) {
      warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning")
    }
  )
  list(fit = fit, warnings = unique(warns))
}

aligned_mm <- function(model, newdata) {
  mm <- model.matrix(delete.response(terms(model)), newdata,
                     contrasts.arg = model$contrasts, xlev = model$xlevels)
  bn <- names(coef(model))
  missing_cols <- setdiff(bn, colnames(mm))
  if (length(missing_cols)) stop("标准化矩阵缺列：", paste(missing_cols, collapse = ","))
  mm[, bn, drop = FALSE]
}

scenario <- function(model, data, set_values, weights = NULL) {
  nd <- data
  for (nm in names(set_values)) nd[[nm]] <- set_values[[nm]]
  mm <- aligned_mm(model, nd)
  eta <- as.numeric(mm %*% coef(model))
  p <- plogis(eta)
  if (is.null(weights)) weights <- rep(1, length(p))
  weights <- weights / sum(weights)
  list(p = sum(weights * p),
       grad = colSums(mm * as.numeric(p * (1 - p)) * weights))
}

probability_row <- function(name, s, vcov) {
  ci <- delta_ci(s$p, s$grad, vcov, "identity")
  tibble(estimand = name, estimate = ci[["estimate"]],
         std_error = ci[["std_error"]], conf_low = ci[["conf_low"]],
         conf_high = ci[["conf_high"]], p_value = NA_real_)
}

delta_ci <- function(est, grad, vcov, type = c("identity", "log")) {
  type <- match.arg(type)
  se <- sqrt(max(0, as.numeric(t(grad) %*% vcov %*% grad)))
  if (type == "identity") {
    c(estimate = est, std_error = se, conf_low = est - 1.96 * se,
      conf_high = est + 1.96 * se,
      p_value = ifelse(se > 0, 2 * pnorm(abs(est / se), lower.tail = FALSE), NA_real_))
  } else {
    c(estimate = exp(est), std_error_log = se,
      conf_low = exp(est - 1.96 * se), conf_high = exp(est + 1.96 * se),
      p_value = ifelse(se > 0, 2 * pnorm(abs(est / se), lower.tail = FALSE), NA_real_))
  }
}

standardized_binary_effect <- function(model, data, focal, vcov, weights = NULL) {
  s0 <- scenario(model, data, setNames(list(0), focal), weights)
  s1 <- scenario(model, data, setNames(list(1), focal), weights)
  rd <- delta_ci(s1$p - s0$p, s1$grad - s0$grad, vcov, "identity")
  lrr <- log(s1$p) - log(s0$p)
  glrr <- s1$grad / s1$p - s0$grad / s0$p
  rr <- delta_ci(lrr, glrr, vcov, "log")
  bind_rows(
    probability_row("P0", s0, vcov),
    probability_row("P1", s1, vcov),
    tibble(estimand = "RD", estimate = rd[["estimate"]], std_error = rd[["std_error"]],
           conf_low = rd[["conf_low"]], conf_high = rd[["conf_high"]], p_value = rd[["p_value"]]),
    tibble(estimand = "RR", estimate = rr[["estimate"]], std_error = rr[["std_error_log"]],
           conf_low = rr[["conf_low"]], conf_high = rr[["conf_high"]], p_value = rr[["p_value"]])
  )
}

standardized_interaction <- function(model, data, x, m, vcov, weights = NULL) {
  s00 <- scenario(model, data, setNames(list(0, 0), c(x, m)), weights)
  s10 <- scenario(model, data, setNames(list(1, 0), c(x, m)), weights)
  s01 <- scenario(model, data, setNames(list(0, 1), c(x, m)), weights)
  s11 <- scenario(model, data, setNames(list(1, 1), c(x, m)), weights)
  probs <- c(P00 = s00$p, P10 = s10$p, P01 = s01$p, P11 = s11$p)
  grads <- list(P00 = s00$grad, P10 = s10$grad, P01 = s01$grad, P11 = s11$grad)
  out_prob <- bind_rows(
    probability_row("P00", s00, vcov), probability_row("P10", s10, vcov),
    probability_row("P01", s01, vcov), probability_row("P11", s11, vcov)
  )
  rd0 <- delta_ci(s10$p - s00$p, s10$grad - s00$grad, vcov, "identity")
  rd1 <- delta_ci(s11$p - s01$p, s11$grad - s01$grad, vcov, "identity")
  aid <- delta_ci((s11$p - s01$p) - (s10$p - s00$p),
                  (s11$grad - s01$grad) - (s10$grad - s00$grad), vcov, "identity")
  # 比率尺度 RERI = RR11 - RR10 - RR01 + 1，以P00为共同参照
  reri <- s11$p / s00$p - s10$p / s00$p - s01$p / s00$p + 1
  greri <- (s11$grad - s10$grad - s01$grad) / s00$p -
    (s11$p - s10$p - s01$p) * s00$grad / (s00$p^2)
  reri_ci <- delta_ci(reri, greri, vcov, "identity")
  metric_row <- function(name, z) tibble(
    estimand = name, estimate = z[["estimate"]], std_error = z[["std_error"]],
    conf_low = z[["conf_low"]], conf_high = z[["conf_high"]], p_value = z[["p_value"]]
  )
  bind_rows(out_prob, metric_row("RD_X_M0", rd0), metric_row("RD_X_M1", rd1),
            metric_row("RD_interaction", aid), metric_row("RERI", reri_ci))
}

hash_rows <- function(data) digest::digest(data %>% arrange(dyad_id, begin_year) %>%
                                             select(dyad_id, begin_year), algo = "sha256")

# ---- 读取上游数据并恢复ID ------------------------------------------------------
analysis_vars <- c(
  "pid", "id", "year", "pid_", "fid_", "qf602_a__", "actor_income_",
  "partner_income_", "qi202_actor_", "qi202_partner_",
  "actor_foperate_1_", "partner_foperate_1_",
  "actor_foperate_1_handle_", "partner_foperate_1_handle_",
  "msat_c1_", "msat_c2_", "dwm_", "gender_", "aage_", "actor_edu2_",
  "actor_siops_", "child_", "ahw_", "ahk_", "total_debts_", "qp201_actor_",
  "fmlincc_", "lifetime_", "prtmarr_", "prtcor_", "prtgender_", "prtage_",
  "prtedu_"
)
raw <- read_dta(raw_dta, col_select = all_of(analysis_vars)) %>%
  filter(year %in% c(2018, 2020, 2022)) %>%
  mutate(year = as.integer(year), dyad_id = as.character(pid), stata_id = as.numeric(id))

ids_wide <- read_dta(
  id_dta,
  col_select = c(pair_pid_1,
                 pid_2018, pid_partner_2018, parentpid_2018,
                 pid_2020, pid_partner_2020, parentpid_2020,
                 pid_2022, pid_partner_2022, parentpid_2022)
) %>% mutate(dyad_id = as.character(pair_pid_1))

ids_long <- ids_wide %>%
  select(-pair_pid_1) %>%
  pivot_longer(cols = matches("^(pid|pid_partner|parentpid)_20"),
               names_to = c("id_type", "year"), names_pattern = "(.+)_(20[0-9]{2})",
               values_to = "value") %>%
  mutate(year = as.integer(year)) %>%
  pivot_wider(names_from = id_type, values_from = value) %>%
  rename(actor_pid_source = pid, partner_pid = pid_partner, parent_pid = parentpid)

stopifnot(!anyDuplicated(ids_long[c("dyad_id", "year")]))
stopifnot(!anyDuplicated(raw[c("dyad_id", "year")]))

dat_long <- raw %>%
  left_join(ids_long, by = c("dyad_id", "year")) %>%
  mutate(
    actor_pid = coalesce(as.character(actor_pid_source), as.character(pid_)),
    partner_pid = as.character(partner_pid),
    parent_pid = as.character(parent_pid),
    family_id = as.character(fid_),
    parent_role = substr(dyad_id, 1, 1),
    cpi_index = recode(year, `2018` = 103.7, `2020` = 109.4, `2022` = 112.6,
                       .default = NA_real_),
    cpi_deflator = 100 / cpi_index,
    actor_wage_nominal = na_if_negative(actor_income_),
    partner_wage_nominal = na_if_negative(partner_income_),
    actor_pension_monthly_legacy = na_if_negative(qi202_actor_),
    partner_pension_monthly_legacy = na_if_negative(qi202_partner_),
    actor_business_alloc_nonnegative = na_if_negative(actor_foperate_1_handle_),
    partner_business_alloc_nonnegative = na_if_negative(partner_foperate_1_handle_),
    # 仅为暂定复现：旧数据无法区分养老金结构性零和项目缺失。
    actor_pension_zero_legacy = replace_na(actor_pension_monthly_legacy, 0),
    partner_pension_zero_legacy = replace_na(partner_pension_monthly_legacy, 0),
    actor_income_nominal_provisional = actor_wage_nominal + 12 * actor_pension_zero_legacy +
      actor_business_alloc_nonnegative,
    partner_income_nominal_provisional = partner_wage_nominal + 12 * partner_pension_zero_legacy +
      partner_business_alloc_nonnegative,
    actor_income_real_provisional = actor_income_nominal_provisional * cpi_deflator,
    partner_income_real_provisional = partner_income_nominal_provisional * cpi_deflator,
    support_nominal_monthly = na_if_negative(qf602_a__),
    support_real_monthly = support_nominal_monthly * cpi_deflator,
    self_sat_raw = na_if_negative(msat_c1_),
    spouse_sat_raw = na_if_negative(msat_c2_),
    self_rel_income_status = ifelse(
      is.na(actor_income_real_provisional) | is.na(partner_income_real_provisional), NA_integer_,
      as.integer(actor_income_real_provisional > partner_income_real_provisional)
    ),
    self_rel_sat_status = ifelse(is.na(self_sat_raw) | is.na(spouse_sat_raw), NA_integer_,
                                 as.integer(self_sat_raw > spouse_sat_raw)),
    spouse_rel_sat_status = ifelse(is.na(self_sat_raw) | is.na(spouse_sat_raw), NA_integer_,
                                   as.integer(spouse_sat_raw > self_sat_raw))
  )

# 年度ridit按唯一actor-year计算，避免一个actor因双亲记录被重复加权。
ridit_map <- dat_long %>%
  distinct(actor_pid, year, self_sat_raw, spouse_sat_raw) %>%
  group_by(year) %>%
  mutate(self_ridit = deterministic_ridit(self_sat_raw),
         spouse_ridit = deterministic_ridit(spouse_sat_raw)) %>%
  ungroup() %>% select(actor_pid, year, self_ridit, spouse_ridit)
dat_long <- dat_long %>% left_join(ridit_map, by = c("actor_pid", "year"))

# 协变量去除负值编码；不对可能有合法负值的货币差值使用此规则。
covar_names <- c("dwm_", "gender_", "aage_", "actor_edu2_", "actor_siops_",
                 "child_", "ahw_", "ahk_", "total_debts_", "qp201_actor_",
                 "fmlincc_", "lifetime_", "prtmarr_", "prtcor_", "prtgender_",
                 "prtage_", "prtedu_")
dat_long <- dat_long %>% mutate(across(all_of(covar_names), na_if_negative))

variable_lineage <- tribble(
  ~analysis_variable, ~source, ~formula, ~status,
  "actor_income_real_provisional", "predata actor_income_/qi202_actor_/actor_foperate_1_handle_",
  "(wage + 12*pension_legacy_zero + actor business allocation)*100/CPI", "PROVISIONAL_PENSION_AND_BUSINESS",
  "partner_income_real_provisional", "predata partner_income_/qi202_partner_/partner_foperate_1_handle_",
  "(wage + 12*pension_legacy_zero + partner business allocation)*100/CPI", "PROVISIONAL_PENSION_AND_BUSINESS",
  "support_real_monthly", "qf602_a__", "parent-specific monthly support*100/CPI", "READY",
  "self_sat_raw", "msat_c1_", "original 1-5 response", "READY",
  "spouse_sat_raw", "msat_c2_", "partner original 1-5 response", "READY",
  "partner_pid", "temple pid_partner_year", "direct merge by dyad_id-year", "READY",
  "parent_pid", "temple parentpid_year", "direct merge by dyad_id-year", "READY"
)
write_csv(variable_lineage, file.path(result_dir, "01_variable_lineage.csv"))

# ---- 生成相邻区间 ------------------------------------------------------------
wide_vars <- c(
  "stata_id", "actor_pid", "partner_pid", "parent_pid", "family_id", "parent_role",
  "actor_income_nominal_provisional", "partner_income_nominal_provisional",
  "actor_income_real_provisional", "partner_income_real_provisional",
  "support_nominal_monthly", "support_real_monthly", "self_sat_raw", "spouse_sat_raw",
  "self_rel_income_status", "self_rel_sat_status", "spouse_rel_sat_status",
  "self_ridit", "spouse_ridit", covar_names
)
dat_wide <- dat_long %>% select(dyad_id, year, all_of(wide_vars)) %>%
  pivot_wider(names_from = year, values_from = all_of(wide_vars), names_sep = "_")

make_interval <- function(d, begin, end) {
  getv <- function(base, year) d[[paste0(base, "_", year)]]
  tibble(
    dyad_id = d$dyad_id, begin_year = begin, end_year = end,
    period = paste0(begin, "-", end),
    stata_id_begin = getv("stata_id", begin), stata_id_end = getv("stata_id", end),
    actor_pid_begin = as.character(getv("actor_pid", begin)),
    actor_pid_end = as.character(getv("actor_pid", end)),
    partner_pid_begin = as.character(getv("partner_pid", begin)),
    partner_pid_end = as.character(getv("partner_pid", end)),
    parent_pid_begin = as.character(getv("parent_pid", begin)),
    parent_pid_end = as.character(getv("parent_pid", end)),
    fid_begin = as.character(getv("family_id", begin)),
    fid_end = as.character(getv("family_id", end)),
    parent_role = as.character(getv("parent_role", begin)),
    actor_income_nominal_begin = getv("actor_income_nominal_provisional", begin),
    actor_income_nominal_end = getv("actor_income_nominal_provisional", end),
    partner_income_nominal_begin = getv("partner_income_nominal_provisional", begin),
    partner_income_nominal_end = getv("partner_income_nominal_provisional", end),
    actor_income_real_begin = getv("actor_income_real_provisional", begin),
    actor_income_real_end = getv("actor_income_real_provisional", end),
    partner_income_real_begin = getv("partner_income_real_provisional", begin),
    partner_income_real_end = getv("partner_income_real_provisional", end),
    support_nominal_begin = getv("support_nominal_monthly", begin),
    support_nominal_end = getv("support_nominal_monthly", end),
    support_real_begin = getv("support_real_monthly", begin),
    support_real_end = getv("support_real_monthly", end),
    self_sat_begin = getv("self_sat_raw", begin), self_sat_end = getv("self_sat_raw", end),
    spouse_sat_begin = getv("spouse_sat_raw", begin), spouse_sat_end = getv("spouse_sat_raw", end),
    self_income_status_begin = getv("self_rel_income_status", begin),
    self_income_status_end = getv("self_rel_income_status", end),
    self_rel_sat_status_begin = getv("self_rel_sat_status", begin),
    self_rel_sat_status_end = getv("self_rel_sat_status", end),
    spouse_rel_sat_status_begin = getv("spouse_rel_sat_status", begin),
    spouse_rel_sat_status_end = getv("spouse_rel_sat_status", end),
    self_ridit_begin = getv("self_ridit", begin), self_ridit_end = getv("self_ridit", end),
    spouse_ridit_begin = getv("spouse_ridit", begin), spouse_ridit_end = getv("spouse_ridit", end)
  ) %>%
    bind_cols(setNames(map_dfc(covar_names, ~getv(.x, begin)), paste0(covar_names, "begin")))
}

intervals <- bind_rows(make_interval(dat_wide, 2018, 2020), make_interval(dat_wide, 2020, 2022)) %>%
  filter(!is.na(actor_pid_begin), !is.na(actor_pid_end)) %>%
  mutate(
    same_actor = actor_pid_begin == actor_pid_end,
    same_partner = !is.na(partner_pid_begin) & !is.na(partner_pid_end) &
      partner_pid_begin == partner_pid_end,
    same_parent = !is.na(parent_pid_begin) & !is.na(parent_pid_end) &
      parent_pid_begin == parent_pid_end,
    period_fe = factor(period, levels = c("2018-2020", "2020-2022")),
    x_abs = binary_change(actor_income_real_begin, actor_income_real_end),
    eligible_x_rel = ifelse(is.na(self_income_status_begin) | is.na(self_income_status_end), NA,
                            self_income_status_begin == 0),
    x_rel = eligible_binary_transition(self_income_status_begin, self_income_status_end, eligible_x_rel),
    eligible_m_self_abs = ifelse(is.na(self_sat_begin) | is.na(self_sat_end), NA, self_sat_begin < 5),
    m_self_abs = ifelse(is.na(eligible_m_self_abs) | !eligible_m_self_abs, NA_integer_,
                        as.integer(self_sat_end > self_sat_begin)),
    eligible_m_spouse_abs = ifelse(is.na(spouse_sat_begin) | is.na(spouse_sat_end), NA, spouse_sat_begin < 5),
    m_spouse_abs = ifelse(is.na(eligible_m_spouse_abs) | !eligible_m_spouse_abs, NA_integer_,
                          as.integer(spouse_sat_end > spouse_sat_begin)),
    eligible_m_self_rel = ifelse(is.na(self_rel_sat_status_begin) | is.na(self_rel_sat_status_end), NA,
                                 self_rel_sat_status_begin == 0),
    m_self_rel = eligible_binary_transition(self_rel_sat_status_begin, self_rel_sat_status_end,
                                             eligible_m_self_rel),
    eligible_m_spouse_rel = ifelse(is.na(spouse_rel_sat_status_begin) | is.na(spouse_rel_sat_status_end), NA,
                                   spouse_rel_sat_status_begin == 0),
    m_spouse_rel = eligible_binary_transition(spouse_rel_sat_status_begin, spouse_rel_sat_status_end,
                                               eligible_m_spouse_rel),
    y_growth = binary_change(support_real_begin, support_real_end),
    x_abs_nominal = binary_change(actor_income_nominal_begin, actor_income_nominal_end),
    y_growth_nominal = binary_change(support_nominal_begin, support_nominal_end),
    dx_abs_ihs = asinh(actor_income_real_end) - asinh(actor_income_real_begin),
    dx_rel_share = actor_income_real_end / (actor_income_real_end + partner_income_real_end) -
      actor_income_real_begin / (actor_income_real_begin + partner_income_real_begin),
    dm_self_abs = self_sat_end - self_sat_begin,
    dm_spouse_abs = spouse_sat_end - spouse_sat_begin,
    dm_self_rel = (self_sat_end - spouse_sat_end) - (self_sat_begin - spouse_sat_begin),
    dm_spouse_rel = -dm_self_rel,
    dm_self_ridit = self_ridit_end - self_ridit_begin,
    dm_spouse_ridit = spouse_ridit_end - spouse_ridit_begin,
    baseline_actor_income_ihs = asinh(actor_income_real_begin),
    baseline_partner_income_ihs = asinh(partner_income_real_begin),
    baseline_support_ihs = asinh(support_real_begin)
  )

# 修复零分母：夫妻均为0时份额定义为0.5；仅用于连续份额诊断。
share_fun <- function(a, p) ifelse(is.na(a) | is.na(p), NA_real_, ifelse(a + p == 0, .5, a / (a + p)))
intervals <- intervals %>% mutate(
  share_begin = share_fun(actor_income_real_begin, partner_income_real_begin),
  share_end = share_fun(actor_income_real_end, partner_income_real_end),
  dx_rel_share = share_end - share_begin
)

# ---- 聚类连通组：actor、partner、parent、begin/end family ---------------------
edge_frame <- bind_rows(
  intervals %>% transmute(from = paste0("A:", actor_pid_begin), to = paste0("P:", partner_pid_begin)),
  intervals %>% transmute(from = paste0("A:", actor_pid_begin), to = paste0("R:", parent_pid_begin)),
  intervals %>% transmute(from = paste0("A:", actor_pid_begin), to = paste0("F:", fid_begin)),
  intervals %>% transmute(from = paste0("A:", actor_pid_end), to = paste0("P:", partner_pid_end)),
  intervals %>% transmute(from = paste0("A:", actor_pid_end), to = paste0("R:", parent_pid_end)),
  intervals %>% transmute(from = paste0("A:", actor_pid_end), to = paste0("F:", fid_end))
) %>% filter(!str_detect(from, ":NA$"), !str_detect(to, ":NA$")) %>% distinct()
g <- graph_from_data_frame(edge_frame, directed = FALSE)
cc <- components(g)
actor_component <- tibble(node = names(cc$membership),
                          component_id = as.integer(cc$membership)) %>%
  filter(str_starts(node, "A:")) %>%
  transmute(actor_pid_begin = str_remove(node, "^A:"), component_id)
intervals <- intervals %>% left_join(actor_component, by = "actor_pid_begin") %>%
  mutate(component_id = as.character(component_id))

cluster_sizes <- tibble(node = names(cc$membership), component_id = as.integer(cc$membership)) %>%
  count(component_id, name = "nodes")
cluster_summary <- tibble(
  metric = c("components", "median_nodes", "max_nodes", "largest_component_node_share"),
  value = c(nrow(cluster_sizes), median(cluster_sizes$nodes), max(cluster_sizes$nodes),
            max(cluster_sizes$nodes) / sum(cluster_sizes$nodes))
)
write_csv(cluster_sizes, file.path(result_dir, "02_component_cluster_sizes.csv"))
write_csv(cluster_summary, file.path(result_dir, "03_component_cluster_summary.csv"))

# ---- 样本流程与旧新编码 -------------------------------------------------------
core_covars_begin <- paste0(covar_names, "begin")
sample_flow <- tibble(
  step = c("S0 adjacent intervals", "S1 same actor", "S2 same parent", "S3 same partner",
           "S4 Y observed", "S5 baseline covariates observed"),
  n = c(
    nrow(intervals),
    sum(intervals$same_actor, na.rm = TRUE),
    sum(intervals$same_actor & intervals$same_parent, na.rm = TRUE),
    sum(intervals$same_actor & intervals$same_parent & intervals$same_partner, na.rm = TRUE),
    sum(intervals$same_actor & intervals$same_parent & intervals$same_partner & !is.na(intervals$y_growth)),
    sum(intervals$same_actor & intervals$same_parent & intervals$same_partner & !is.na(intervals$y_growth) &
          complete.cases(intervals[, core_covars_begin]))
  )
)
write_csv(sample_flow, file.path(result_dir, "04_sample_flow.csv"))

analysis_unit_counts <- intervals %>%
  filter(same_actor, same_parent, same_partner) %>%
  summarise(
    records = n(), dyads = n_distinct(dyad_id), actors = n_distinct(actor_pid_begin),
    parents = n_distinct(parent_pid_begin), families = n_distinct(fid_begin),
    components = n_distinct(component_id),
    period_2018_2020 = sum(period == "2018-2020"),
    period_2020_2022 = sum(period == "2020-2022")
  )
write_csv(analysis_unit_counts, file.path(result_dir, "04a_analysis_unit_counts.csv"))

ceiling_transition <- bind_rows(
  intervals %>% filter(same_actor, same_parent, same_partner, !is.na(self_sat_begin), !is.na(self_sat_end)) %>%
    count(period, baseline_score = self_sat_begin,
          improved = self_sat_end > self_sat_begin, name = "n") %>% mutate(role = "self"),
  intervals %>% filter(same_actor, same_parent, same_partner, !is.na(spouse_sat_begin), !is.na(spouse_sat_end)) %>%
    count(period, baseline_score = spouse_sat_begin,
          improved = spouse_sat_end > spouse_sat_begin, name = "n") %>% mutate(role = "spouse")
) %>% group_by(role, period, baseline_score) %>%
  mutate(total_baseline = sum(n), improvement_probability = sum(n[improved]) / total_baseline) %>%
  ungroup()
write_csv(ceiling_transition, file.path(result_dir, "04b_satisfaction_ceiling_transitions.csv"))

x_overlap <- intervals %>%
  filter(same_actor, same_parent, same_partner, !is.na(x_abs), !is.na(x_rel)) %>%
  count(period, x_abs, x_rel, name = "n") %>%
  group_by(period) %>% mutate(proportion = n / sum(n)) %>% ungroup()
write_csv(x_overlap, file.path(result_dir, "04c_absolute_relative_x_overlap.csv"))

old <- read_csv(old_csv, show_col_types = FALSE) %>% mutate(.row_id = row_number())
marker <- read_csv(v2_marker, show_col_types = FALSE) %>% select(.row_id, analysis_sample)
crosswalk <- intervals %>%
  filter(stata_id_begin == stata_id_end | is.na(stata_id_end)) %>%
  transmute(id = stata_id_begin,
            dyad_id, time_period = ifelse(begin_year == 2018, 0, 1),
            # 审计旧inc_3时保留完整0/1定义；正式x_rel则把基期已高于配偶者排除在资格总体外。
            new_inc_3 = ifelse(
              is.na(self_income_status_begin) | is.na(self_income_status_end), NA_integer_,
              as.integer(self_income_status_begin == 0 & self_income_status_end == 1)
            )) %>%
  inner_join(old %>% select(.row_id, id, time_period, old_inc_3 = inc_3), by = c("id", "time_period")) %>%
  left_join(marker, by = ".row_id") %>%
  mutate(changed = old_inc_3 != new_inc_3)
write_csv(crosswalk %>% filter(changed %in% TRUE),
          file.path(result_dir, "05_income_assignment_change_log.csv"))
crosswalk_summary <- tibble(
  sample = c("all_13129", "v2_common_12662"),
  n = c(nrow(crosswalk), sum(crosswalk$analysis_sample, na.rm = TRUE)),
  old_upgrade = c(sum(crosswalk$old_inc_3 == 1, na.rm = TRUE),
                  sum(crosswalk$old_inc_3 == 1 & crosswalk$analysis_sample, na.rm = TRUE)),
  new_upgrade = c(sum(crosswalk$new_inc_3 == 1, na.rm = TRUE),
                  sum(crosswalk$new_inc_3 == 1 & crosswalk$analysis_sample, na.rm = TRUE)),
  changed = c(sum(crosswalk$changed, na.rm = TRUE),
              sum(crosswalk$changed & crosswalk$analysis_sample, na.rm = TRUE))
)
write_csv(crosswalk_summary, file.path(result_dir, "06_income_assignment_change_summary.csv"))

# 缺失传播断言
missing_checks <- tribble(
  ~check, ~pass,
  "x_abs missing iff either real income endpoint missing",
  identical(is.na(intervals$x_abs), is.na(intervals$actor_income_real_begin) | is.na(intervals$actor_income_real_end)),
  "y missing iff either support endpoint missing",
  identical(is.na(intervals$y_growth), is.na(intervals$support_real_begin) | is.na(intervals$support_real_end)),
  "m_self_abs never 1 outside eligibility", !any(intervals$m_self_abs == 1 & !intervals$eligible_m_self_abs, na.rm = TRUE),
  "m_spouse_abs never 1 outside eligibility", !any(intervals$m_spouse_abs == 1 & !intervals$eligible_m_spouse_abs, na.rm = TRUE),
  "x_rel never 1 outside eligibility", !any(intervals$x_rel == 1 & !intervals$eligible_x_rel, na.rm = TRUE)
)
write_csv(missing_checks, file.path(result_dir, "07_binary_missingness_validation.csv"))
stopifnot(all(missing_checks$pass))

# ---- Estimand registry --------------------------------------------------------
registry <- tribble(
  ~estimand_id, ~x, ~m, ~role, ~native_eligibility, ~intervention, ~reference,
  "AA-S", "x_abs", "m_self_abs", "self", "same spouse; self baseline sat<5",
  "real personal composite income increased", "did not increase",
  "AA-P", "x_abs", "m_spouse_abs", "spouse", "same spouse; spouse baseline sat<5",
  "real personal composite income increased", "did not increase",
  "AR-S", "x_abs", "m_self_rel", "self", "same spouse; self baseline sat<=spouse",
  "real personal composite income increased", "did not increase",
  "AR-P", "x_abs", "m_spouse_rel", "spouse", "same spouse; spouse baseline sat<=self",
  "real personal composite income increased", "did not increase",
  "RA-S", "x_rel", "m_self_abs", "self", "same spouse; actor income<=spouse; self baseline sat<5",
  "actor income position upgraded above spouse", "eligible but not upgraded",
  "RA-P", "x_rel", "m_spouse_abs", "spouse", "same spouse; actor income<=spouse; spouse baseline sat<5",
  "actor income position upgraded above spouse", "eligible but not upgraded",
  "RR-S", "x_rel", "m_self_rel", "self", "same spouse; actor income<=spouse; self sat<=spouse",
  "actor income position upgraded above spouse", "eligible but not upgraded",
  "RR-P", "x_rel", "m_spouse_rel", "spouse", "same spouse; actor income<=spouse; spouse sat<=self",
  "actor income position upgraded above spouse", "eligible but not upgraded"
) %>% mutate(
  unit = "parent-adult-child dyad interval",
  outcome = "parent-specific real monthly support increased",
  weighting = "equal dyad-interval records; pooled periods with period fixed effect",
  primary_basic_scale = "standardized RR; RD/RERI auxiliary",
  formal_scale = "CMAverse native RR/ER",
  data_status = "PROVISIONAL: pension zero/imputation and negative business unresolved",
  prohibited_interpretation = "not a fixed-amount policy effect; Model 3 is not path b"
)
write_csv(registry, file.path(result_dir, "08_estimand_registry.csv"))

# ---- 链条样本与模型 -----------------------------------------------------------
actor_controls <- c("dwm_begin", "gender_begin", "aage_begin", "actor_edu2_begin",
                    "actor_siops_begin", "child_begin", "ahw_begin", "ahk_begin",
                    "total_debts_begin", "qp201_actor_begin", "fmlincc_begin",
                    "lifetime_begin", "baseline_actor_income_ihs",
                    "baseline_partner_income_ihs", "period_fe")
parent_controls <- c("prtmarr_begin", "prtcor_begin", "prtgender_begin",
                     "prtage_begin", "prtedu_begin", "baseline_support_ihs")
factor_controls <- c("dwm_begin", "gender_begin", "ahk_begin", "lifetime_begin",
                     "prtmarr_begin", "prtcor_begin", "prtgender_begin",
                     "prtedu_begin", "period_fe")

# make_interval 保留的原变量名带下划线，规范为清晰名称。
rename_map <- c(
  dwm_begin = "dwm_begin", gender_begin = "gender_begin", aage_begin = "aage_begin",
  actor_edu2_begin = "actor_edu2_begin", actor_siops_begin = "actor_siops_begin",
  child_begin = "child_begin", ahw_begin = "ahw_begin", ahk_begin = "ahk_begin",
  total_debts_begin = "total_debts_begin", qp201_actor_begin = "qp201_actor_begin",
  fmlincc_begin = "fmlincc_begin", lifetime_begin = "lifetime_begin",
  prtmarr_begin = "prtmarr_begin", prtcor_begin = "prtcor_begin",
  prtgender_begin = "prtgender_begin", prtage_begin = "prtage_begin",
  prtedu_begin = "prtedu_begin"
)
for (new_nm in names(rename_map)) {
  old_nm <- paste0(sub("_begin$", "_", rename_map[[new_nm]]), "begin")
  if (old_nm %in% names(intervals) && !(new_nm %in% names(intervals))) names(intervals)[names(intervals) == old_nm] <- new_nm
}
# 实际由 bind_cols 生成如 dwm_begin，无需重命名；下行仅断言。
missing_model_columns <- setdiff(c(actor_controls, parent_controls), names(intervals))
if (length(missing_model_columns)) stop("模型协变量缺失：", paste(missing_model_columns, collapse = ", "))

chain_data <- function(row) {
  x <- row$x[[1]]; m <- row$m[[1]]
  base_m <- if (row$role[[1]] == "self") "self_sat_begin" else "spouse_sat_begin"
  needed <- unique(c(x, m, "y_growth", actor_controls, parent_controls,
                     base_m, "component_id", "actor_pid_begin", "fid_begin"))
  d <- intervals %>%
    filter(same_actor, same_parent, same_partner) %>%
    filter(if_all(all_of(needed), ~!is.na(.x))) %>%
    mutate(across(any_of(factor_controls), safe_factor))
  attr(d, "base_m") <- base_m
  d
}

all_models <- list(); all_coef <- list(); all_effects <- list(); chain_samples <- list(); cells <- list()

for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]; chain <- meta$estimand_id; x <- meta$x; m <- meta$m
  d <- chain_data(meta); base_m <- attr(d, "base_m")
  if (!nrow(d)) next
  chain_samples[[chain]] <- tibble(
    estimand_id = chain, n_records = nrow(d), dyads = n_distinct(d$dyad_id),
    actors = n_distinct(d$actor_pid_begin), families = n_distinct(d$fid_begin),
    components = n_distinct(d$component_id), sample_hash = hash_rows(d),
    x_rate = mean(d[[x]]), m_rate = mean(d[[m]]), y_rate = mean(d$y_growth)
  )
  cell_one <- d %>% count(.data[[x]], .data[[m]], y_growth, name = "n")
  names(cell_one)[match(c(x, m), names(cell_one))] <- c("x_value", "m_value")
  cells[[chain]] <- cell_one %>% mutate(estimand_id = chain, .before = 1)

  m_controls <- unique(c(base_m, actor_controls))
  y_controls <- unique(c(actor_controls, parent_controls))
  specs <- list(
    M1 = list(lhs = m, rhs = c(x, m_controls), focal = x, label = "X->M adjusted association"),
    M2 = list(lhs = "y_growth", rhs = c(x, y_controls), focal = x, label = "X->Y adjusted association"),
    M3 = list(lhs = "y_growth", rhs = c(m, y_controls), focal = m, label = "M-Y adjusted association without concurrent X"),
    M4 = list(lhs = "y_growth", rhs = c(x, m, y_controls), focal = x, label = "X+M->Y"),
    M5 = list(lhs = "y_growth", rhs = c(paste0(x, "*", m), y_controls), focal = x, label = "X+M+X*M->Y")
  )
  for (model_no in names(specs)) {
    sp <- specs[[model_no]]; form <- formula_unique(sp$lhs, sp$rhs)
    obj <- fit_glm_capture(form, d, binomial("logit")); fit <- obj$fit
    vc <- vcovCL(fit, cluster = d$component_id, type = "HC1", cadjust = TRUE)
    model_id <- paste(chain, model_no, sep = "_")
    all_models[[model_id]] <- list(model = fit, vcov = vc, data = d, meta = meta,
                                   warnings = obj$warnings, formula = formula_text(form))
    ct <- coeftest(fit, vcov. = vc)
    all_coef[[model_id]] <- tibble(
      estimand_id = chain, model = model_no, model_label = sp$label,
      formula = formula_text(form), term = rownames(ct), estimate_logit = ct[, 1],
      robust_se = ct[, 2], z = ct[, 3], p_value = ct[, 4],
      odds_ratio = exp(ct[, 1]), conf_low = exp(ct[, 1] - 1.96 * ct[, 2]),
      conf_high = exp(ct[, 1] + 1.96 * ct[, 2]), n = nrow(d),
      components = n_distinct(d$component_id), warnings = paste(obj$warnings, collapse = " | ")
    )
    if (model_no != "M5") {
      eff <- standardized_binary_effect(fit, d, sp$focal, vc) %>%
        mutate(estimand_id = chain, model = model_no, focal = sp$focal, .before = 1)
    } else {
      eff <- standardized_interaction(fit, d, x, m, vc) %>%
        mutate(estimand_id = chain, model = model_no, focal = paste0(x, "*", m), .before = 1)
    }
    all_effects[[model_id]] <- eff
  }
}

chain_samples_df <- bind_rows(chain_samples)
cell_df <- bind_rows(cells)
coef_df <- bind_rows(all_coef)
effect_df <- bind_rows(all_effects)
write_csv(chain_samples_df, file.path(result_dir, "09_chain_sample_summary.csv"))
write_csv(cell_df, file.path(result_dir, "10_joint_cell_counts.csv"))
write_csv(coef_df, file.path(result_dir, "11_all_model_coefficients.csv"))
write_csv(effect_df, file.path(result_dir, "12_standardized_effects.csv"))

# 聚类口径敏感性：主口径为关系图连通组；另给actor、家庭及actor+家庭多向聚类。
cluster_sensitivity <- list(); model_diagnostics <- list(); estimator_sensitivity <- list()
for (model_id in names(all_models)) {
  z <- all_models[[model_id]]; fit <- z$model; d <- z$data
  model_no <- str_extract(model_id, "M[1-5]$")
  x <- z$meta$x[[1]]; m <- z$meta$m[[1]]
  cluster_specs <- list(
    connected_component = list(cluster = d$component_id, multi0 = FALSE),
    actor = list(cluster = d$actor_pid_begin, multi0 = FALSE),
    family = list(cluster = d$fid_begin, multi0 = FALSE),
    actor_family_multiway = list(
      cluster = data.frame(actor = d$actor_pid_begin, family = d$fid_begin),
      multi0 = all(count(d, actor_pid_begin, fid_begin)$n == 1)
    )
  )
  for (cl_name in names(cluster_specs)) {
    cs <- cluster_specs[[cl_name]]
    vc_try <- try(vcovCL(fit, cluster = cs$cluster, type = "HC1", cadjust = TRUE,
                         multi0 = cs$multi0, fix = TRUE), silent = TRUE)
    if (inherits(vc_try, "try-error")) next
    eff <- if (model_no == "M5") {
      standardized_interaction(fit, d, x, m, vc_try)
    } else {
      focal <- if (model_no == "M3") m else x
      standardized_binary_effect(fit, d, focal, vc_try)
    }
    cluster_sensitivity[[paste(model_id, cl_name)]] <- eff %>% mutate(
      model_id = model_id, estimand_id = z$meta$estimand_id,
      model = model_no, cluster_method = cl_name, multi0 = cs$multi0, .before = 1
    )
  }
  pred <- fitted(fit)
  model_diagnostics[[model_id]] <- tibble(
    model_id, estimand_id = z$meta$estimand_id, model = model_no,
    converged = isTRUE(fit$converged), rank = fit$rank,
    coefficients = length(coef(fit)), aliased = sum(is.na(coef(fit))),
    min_fitted = min(pred), max_fitted = max(pred),
    extreme_fitted_share = mean(pred < 0.01 | pred > 0.99),
    max_abs_logit_coefficient = max(abs(coef(fit)), na.rm = TRUE),
    warnings = paste(z$warnings, collapse = " | ")
  )
  # 同一公式、同一样本下的估计器敏感性；不作为核心估计量择优工具。
  for (est_name in c("modified_poisson", "lpm")) {
    fam <- if (est_name == "modified_poisson") poisson(link = "log") else gaussian()
    est_fit <- fit_glm_capture(formula(fit), d, fam)$fit
    est_vc <- vcovCL(est_fit, cluster = d$component_id, type = "HC1", cadjust = TRUE, fix = TRUE)
    ct <- coeftest(est_fit, vcov. = est_vc)
    focal_pattern <- if (model_no == "M3") m else x
    keep_terms <- rownames(ct)[str_detect(rownames(ct), fixed(focal_pattern)) |
                                  (model_no == "M5" & str_detect(rownames(ct), fixed(m)))]
    if (length(keep_terms)) {
      estimator_sensitivity[[paste(model_id, est_name)]] <- tibble(
        model_id, estimand_id = z$meta$estimand_id, model = model_no,
        estimator = est_name, term = keep_terms,
        estimate = ct[keep_terms, 1], robust_se = ct[keep_terms, 2],
        conf_low = ct[keep_terms, 1] - 1.96 * ct[keep_terms, 2],
        conf_high = ct[keep_terms, 1] + 1.96 * ct[keep_terms, 2],
        exponentiated = if (est_name == "modified_poisson") exp(ct[keep_terms, 1]) else NA_real_,
        min_fitted = min(fitted(est_fit)), max_fitted = max(fitted(est_fit)), n = nrow(d)
      )
    }
  }
}
write_csv(bind_rows(cluster_sensitivity), file.path(result_dir, "12a_cluster_sensitivity_effects.csv"))
write_csv(bind_rows(model_diagnostics), file.path(result_dir, "12b_model_diagnostics.csv"))
write_csv(bind_rows(estimator_sensitivity), file.path(result_dir, "12c_estimator_sensitivity.csv"))

chain_cluster_diagnostics <- imap_dfr(chain_samples, function(unused, chain) {
  d <- all_models[[paste0(chain, "_M1")]]$data
  comp_n <- count(d, component_id, name = "records")
  af_n <- count(d, actor_pid_begin, fid_begin, name = "records")
  tibble(
    estimand_id = chain, components = n_distinct(d$component_id),
    max_component_records = max(comp_n$records),
    max_component_record_share = max(comp_n$records) / nrow(d),
    median_component_records = median(comp_n$records),
    actor_family_intersections = nrow(af_n),
    all_actor_family_intersections_singleton = all(af_n$records == 1),
    multi0_used = all(af_n$records == 1)
  )
})
write_csv(chain_cluster_diagnostics, file.path(result_dir, "12d_chain_cluster_diagnostics.csv"))

model_manifest <- imap_dfr(all_models, function(z, id) tibble(
  model_id = id, estimand_id = z$meta$estimand_id, formula = z$formula,
  n = nrow(z$data), sample_hash = hash_rows(z$data),
  data_version = "v6_provisional_legacy_pension_nonnegative_business",
  estimator = "logistic standardization", effect_scales = "RR,RD,RERI",
  cluster = "actor-partner-parent-family connected component"
))
write_csv(model_manifest, file.path(result_dir, "13_model_manifest.csv"))

# 时期敏感性：同一合并模型按两期各50%标准化，以及各时期单独重估。
equal_period_effects <- imap_dfr(all_models, function(z, model_id) {
  d <- z$data
  period_n <- table(d$period)
  w <- 0.5 / as.numeric(period_n[as.character(d$period)])
  model_no <- str_extract(model_id, "M[1-5]$")
  x <- z$meta$x[[1]]; m <- z$meta$m[[1]]
  eff <- if (model_no == "M5") {
    standardized_interaction(z$model, d, x, m, z$vcov, weights = w)
  } else {
    focal <- if (model_no == "M3") m else x
    standardized_binary_effect(z$model, d, focal, z$vcov, weights = w)
  }
  eff %>% mutate(model_id, estimand_id = z$meta$estimand_id,
                 model = model_no, weighting = "periods_50_50", .before = 1)
})
write_csv(equal_period_effects, file.path(result_dir, "13a_equal_period_standardization.csv"))

period_specific_effects <- list(); period_specific_manifest <- list()
for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]; chain <- meta$estimand_id; x <- meta$x; m <- meta$m
  d_all <- chain_data(meta); base_m <- attr(d_all, "base_m")
  for (period_value in levels(intervals$period_fe)) {
    d <- d_all %>% filter(period == period_value) %>% droplevels()
    if (nrow(d) < 100) next
    m_controls <- setdiff(unique(c(base_m, actor_controls)), "period_fe")
    y_controls <- setdiff(unique(c(actor_controls, parent_controls)), "period_fe")
    specs <- list(
      M1 = list(lhs = m, rhs = c(x, m_controls), focal = x),
      M2 = list(lhs = "y_growth", rhs = c(x, y_controls), focal = x),
      M3 = list(lhs = "y_growth", rhs = c(m, y_controls), focal = m),
      M5 = list(lhs = "y_growth", rhs = c(paste0(x, "*", m), y_controls), focal = x)
    )
    for (model_no in names(specs)) {
      sp <- specs[[model_no]]; form <- formula_unique(sp$lhs, sp$rhs)
      obj <- fit_glm_capture(form, d, binomial("logit")); fit <- obj$fit
      vc <- vcovCL(fit, cluster = d$component_id, type = "HC1", cadjust = TRUE, fix = TRUE)
      eff <- if (model_no == "M5") standardized_interaction(fit, d, x, m, vc) else
        standardized_binary_effect(fit, d, sp$focal, vc)
      key <- paste(chain, period_value, model_no, sep = "_")
      period_specific_effects[[key]] <- eff %>% mutate(
        estimand_id = chain, period = period_value, model = model_no, .before = 1
      )
      period_specific_manifest[[key]] <- tibble(
        estimand_id = chain, period = period_value, model = model_no,
        n = nrow(d), dyads = n_distinct(d$dyad_id), actors = n_distinct(d$actor_pid_begin),
        families = n_distinct(d$fid_begin), components = n_distinct(d$component_id),
        formula = formula_text(form), sample_hash = hash_rows(d),
        warnings = paste(obj$warnings, collapse = " | ")
      )
    }
  }
}
write_csv(bind_rows(period_specific_effects), file.path(result_dir, "13b_period_specific_effects.csv"))
write_csv(bind_rows(period_specific_manifest), file.path(result_dir, "13c_period_specific_manifest.csv"))

nominal_sensitivity <- list()
for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]; chain <- meta$estimand_id
  x_real <- meta$x[[1]]; m <- meta$m[[1]]
  x <- if (x_real == "x_abs") "x_abs_nominal" else x_real
  d <- chain_data(meta) %>% filter(!is.na(.data[[x]]), !is.na(y_growth_nominal))
  base_m <- attr(chain_data(meta), "base_m")
  m_controls <- unique(c(base_m, actor_controls)); y_controls <- unique(c(actor_controls, parent_controls))
  specs <- list(
    M1 = list(lhs = m, rhs = c(x, m_controls), focal = x),
    M2 = list(lhs = "y_growth_nominal", rhs = c(x, y_controls), focal = x),
    M3 = list(lhs = "y_growth_nominal", rhs = c(m, y_controls), focal = m),
    M4 = list(lhs = "y_growth_nominal", rhs = c(x, m, y_controls), focal = x),
    M5 = list(lhs = "y_growth_nominal", rhs = c(paste0(x, "*", m), y_controls), focal = x)
  )
  for (model_no in names(specs)) {
    sp <- specs[[model_no]]; fit <- fit_glm_capture(formula_unique(sp$lhs, sp$rhs), d, binomial())$fit
    vc <- vcovCL(fit, cluster = d$component_id, type = "HC1", cadjust = TRUE, fix = TRUE)
    eff <- if (model_no == "M5") standardized_interaction(fit, d, x, m, vc) else
      standardized_binary_effect(fit, d, sp$focal, vc)
    nominal_sensitivity[[paste(chain, model_no)]] <- eff %>% mutate(
      estimand_id = chain, model = model_no, x_variable = x,
      outcome = ifelse(model_no == "M1", m, "y_growth_nominal"), .before = 1
    )
  }
}
write_csv(bind_rows(nominal_sensitivity), file.path(result_dir, "13d_nominal_amount_sensitivity.csv"))

# ---- 倾向概率/支持度 ----------------------------------------------------------
propensity_rows <- list()
for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]; chain <- meta$estimand_id; x <- meta$x; m <- meta$m
  d <- chain_data(meta); if (!nrow(d)) next
  base_m <- attr(d, "base_m")
  xfit <- glm(formula_unique(x, actor_controls), data = d, family = binomial())
  mfit <- glm(formula_unique(m, c(x, base_m, actor_controls)), data = d, family = binomial())
  for (what in c("X", "M")) {
    p <- if (what == "X") fitted(xfit) else fitted(mfit)
    observed <- if (what == "X") d[[x]] else d[[m]]
    q_by_group <- split(p, observed)
    overlap_low <- max(vapply(q_by_group, quantile, numeric(1), probs = .01, na.rm = TRUE))
    overlap_high <- min(vapply(q_by_group, quantile, numeric(1), probs = .99, na.rm = TRUE))
    propensity_rows[[paste(chain, what)]] <- tibble(
      estimand_id = chain, variable = what, n = length(p),
      q01 = quantile(p, .01), q05 = quantile(p, .05), median = median(p),
      q95 = quantile(p, .95), q99 = quantile(p, .99),
      prop_lt_001 = mean(p < .01), prop_gt_099 = mean(p > .99),
      empirical_overlap_low = overlap_low, empirical_overlap_high = overlap_high,
      outside_empirical_overlap_share = mean(p < overlap_low | p > overlap_high)
    )
  }
}
propensity_df <- bind_rows(propensity_rows)
write_csv(propensity_df, file.path(result_dir, "14_propensity_support_diagnostics.csv"))

# ---- 连续与混合尺度诊断清单 ---------------------------------------------------
diagnostic_manifest <- tidyr::crossing(
  x_construct = c("absolute", "relative"),
  m_construct = c("absolute", "relative"),
  role = c("self", "spouse"),
  x_scale = c("binary", "continuous"),
  m_scale = c("binary", "continuous")
) %>% mutate(
  specification_id = sprintf("%s-%s-%s-%s-%s", x_construct, m_construct, role, x_scale, m_scale),
  x_variable = case_when(
    x_construct == "absolute" & x_scale == "binary" ~ "x_abs",
    x_construct == "absolute" ~ "dx_abs_ihs",
    x_construct == "relative" & x_scale == "binary" ~ "x_rel",
    TRUE ~ "dx_rel_share"
  ),
  m_variable = case_when(
    m_construct == "absolute" & role == "self" & m_scale == "binary" ~ "m_self_abs",
    m_construct == "absolute" & role == "spouse" & m_scale == "binary" ~ "m_spouse_abs",
    m_construct == "relative" & role == "self" & m_scale == "binary" ~ "m_self_rel",
    m_construct == "relative" & role == "spouse" & m_scale == "binary" ~ "m_spouse_rel",
    m_construct == "absolute" & role == "self" ~ "dm_self_abs",
    m_construct == "absolute" & role == "spouse" ~ "dm_spouse_abs",
    m_construct == "relative" & role == "self" ~ "dm_self_rel",
    TRUE ~ "dm_spouse_rel"
  ),
  classification = case_when(
    x_scale == "binary" & m_scale == "binary" ~ "core_estimand",
    x_scale == "continuous" & m_scale == "continuous" ~ "continuous_dose_diagnostic",
    TRUE ~ "mixed_scale_diagnostic"
  )
)
write_csv(diagnostic_manifest, file.path(result_dir, "15_diagnostic_specification_manifest.csv"))

# 为连续/混合规格仅估计三条关系与交互，完整结果进入补充材料。
diagnostic_results <- list()
for (j in seq_len(nrow(diagnostic_manifest))) {
  sp <- diagnostic_manifest[j, ]; xv <- sp$x_variable; mv <- sp$m_variable
  eligibility_row <- registry %>% filter(
    str_sub(estimand_id, 1, 2) == paste0(str_sub(sp$x_construct, 1, 1) %>% toupper(),
                                         str_sub(sp$m_construct, 1, 1) %>% toupper()),
    role == sp$role
  )
  if (!nrow(eligibility_row)) next
  d <- chain_data(eligibility_row[1, ]) %>% filter(!is.na(.data[[xv]]), !is.na(.data[[mv]]))
  if (nrow(d) < 100) next
  base_m <- attr(d, "base_m") %||% ifelse(sp$role == "self", "self_sat_begin", "spouse_sat_begin")
  forms <- list(
    XM = formula_unique(mv, c(xv, base_m, actor_controls)),
    XY = formula_unique("y_growth", c(xv, actor_controls, parent_controls)),
    MY = formula_unique("y_growth", c(mv, actor_controls, parent_controls)),
    INT = formula_unique("y_growth", c(paste0(xv, "*", mv), actor_controls, parent_controls))
  )
  for (nm in names(forms)) {
    fam <- if (nm == "XM" && sp$m_scale == "continuous") gaussian() else binomial()
    fit <- fit_glm_capture(forms[[nm]], d, fam)$fit
    vc <- vcovCL(fit, cluster = d$component_id, type = "HC1", cadjust = TRUE)
    ct <- coeftest(fit, vcov. = vc)
    focal_terms <- rownames(ct)[str_detect(rownames(ct), fixed(xv)) | str_detect(rownames(ct), fixed(mv))]
    if (length(focal_terms)) {
      diagnostic_results[[paste(j, nm)]] <- tibble(
        specification_id = sp$specification_id, model = nm, formula = formula_text(forms[[nm]]),
        term = focal_terms, estimate = ct[focal_terms, 1], robust_se = ct[focal_terms, 2],
        p_value = ct[focal_terms, 4], n = nrow(d), sample_hash = hash_rows(d)
      )
    }
  }
}
write_csv(bind_rows(diagnostic_results), file.path(result_dir, "16_continuous_mixed_diagnostics.csv"))

# ---- 关键汇总与图 -------------------------------------------------------------
core_summary <- bind_rows(
  effect_df %>% filter(model == "M1", estimand == "RR") %>%
    transmute(estimand_id, relation = "X→M", estimate, conf_low, conf_high),
  effect_df %>% filter(model == "M2", estimand == "RR") %>%
    transmute(estimand_id, relation = "X→Y", estimate, conf_low, conf_high),
  effect_df %>% filter(model == "M3", estimand == "RR") %>%
    transmute(estimand_id, relation = "M–Y", estimate, conf_low, conf_high),
  effect_df %>% filter(model == "M5", estimand == "RERI") %>%
    transmute(estimand_id, relation = "RERI", estimate, conf_low, conf_high)
)
write_csv(core_summary, file.path(result_dir, "17_core_chain_map.csv"))

p <- core_summary %>%
  mutate(null = ifelse(relation == "RERI", 0, 1),
         relation = factor(relation, levels = c("X→M", "X→Y", "M–Y", "RERI"))) %>%
  ggplot(aes(x = estimate, y = estimand_id, xmin = conf_low, xmax = conf_high)) +
  geom_vline(aes(xintercept = null), colour = "grey65", linetype = 2) +
  geom_errorbarh(height = .15, colour = "#2C3E50") +
  geom_point(size = 2, colour = "#0072B2") +
  facet_wrap(~relation, scales = "free_x", ncol = 2) +
  labs(x = "标准化效应及95% CI", y = NULL,
       title = "八条候选链的基础关系与交互诊断",
       subtitle = "暂定数据版本：养老金与经营亏损尚未完成原始源修复") +
  theme_minimal(base_family = "sans", base_size = 11) +
  theme(panel.grid.minor = element_blank(), strip.text = element_text(face = "bold"))
ggsave(file.path(result_dir, "figure_2_1_core_chain_map.png"), p, width = 10, height = 7, dpi = 300)
ggsave(file.path(result_dir, "figure_2_1_core_chain_map.pdf"), p, width = 10, height = 7)

# ---- 时间顺序与正式分析门槛 ---------------------------------------------------
time_gate <- tribble(
  ~variable, ~measurement, ~reference_window, ~ordering_implication, ~gate,
  "X income", "wave endpoint income components", "annual/current components mixed",
  "income reference windows may overlap support window", "YELLOW_RED",
  "M marital satisfaction", "wave interview", "current evaluation",
  "measured after much of the endpoint support reference window", "RED_FOR_STRICT_X_M_Y_SEQUENCE",
  "Y qf602", "wave interview", "average monthly transfer during previous six months",
  "partly precedes contemporaneous marital satisfaction interview", "RED_FOR_SAME_WINDOW_MEDIATION",
  "three-wave candidate", "X 2018-2020; M 2020; Y 2020-2022", "sequential waves",
  "potentially usable after exact income reference verification", "YELLOW"
)
write_csv(time_gate, file.path(result_dir, "18_time_order_stop_go_gate.csv"))

formal_gate <- tribble(
  ~gate_id, ~status, ~reason, ~required_resolution,
  "PENSION_SOURCE", "BLOCK", "raw person files and skip/QI203 fields unavailable",
  "restore 2016/2018/2020/2022 person DTA and rebuild pension",
  "BUSINESS_LOSS", "BLOCK", "available actor/partner allocation already floors negative values at zero",
  "restore family economy components and participant roster or accept a revised nonnegative-income estimand",
  "SAME_WINDOW_ORDER", "BLOCK", "qf602 previous-six-month window precedes/overlaps endpoint M",
  "use temporally ordered three-wave estimand or downgrade to association",
  "CLUSTER_GRAPH", "REVIEW", "connected actor-partner-parent-family graph may contain a giant component",
  "review component sizes and compare actor/family/multiway inference before formal bootstrap",
  "STATA_R_CROSSCHECK", "BLOCK", "Stata executable/source run not available in current RStudio environment",
  "run generated data contract in Stata and compare row hashes",
  "BASIC_RELATION_MODELS", "PASS_PROVISIONAL", "all eight chains fitted on traceable provisional data",
  "rerun after upstream blockers resolved"
)
write_csv(formal_gate, file.path(result_dir, "19_formal_analysis_gate.csv"))

# ---- 保存数据、模型和验证信息 -------------------------------------------------
contract_input <- intervals %>% transmute(
  contract_row = row_number(), dyad_id, begin_year, end_year,
  actor_income_real_begin, actor_income_real_end,
  partner_income_real_begin, partner_income_real_end,
  self_sat_begin, self_sat_end, spouse_sat_begin, spouse_sat_end,
  support_real_begin, support_real_end
)
contract_expected <- contract_input %>% transmute(
  contract_row, dyad_id, begin_year, end_year,
  r_x_abs = binary_change(actor_income_real_begin, actor_income_real_end),
  r_x_rel_full = ifelse(
    is.na(actor_income_real_begin) | is.na(actor_income_real_end) |
      is.na(partner_income_real_begin) | is.na(partner_income_real_end), NA_integer_,
    as.integer(actor_income_real_begin <= partner_income_real_begin &
                 actor_income_real_end > partner_income_real_end)
  ),
  r_m_self_abs = ifelse(
    is.na(self_sat_begin) | is.na(self_sat_end) | self_sat_begin >= 5, NA_integer_,
    as.integer(self_sat_end > self_sat_begin)
  ),
  r_m_spouse_abs = ifelse(
    is.na(spouse_sat_begin) | is.na(spouse_sat_end) | spouse_sat_begin >= 5, NA_integer_,
    as.integer(spouse_sat_end > spouse_sat_begin)
  ),
  r_m_self_rel = ifelse(
    is.na(self_sat_begin) | is.na(self_sat_end) | is.na(spouse_sat_begin) | is.na(spouse_sat_end) |
      self_sat_begin > spouse_sat_begin, NA_integer_,
    as.integer(self_sat_end > spouse_sat_end)
  ),
  r_m_spouse_rel = ifelse(
    is.na(self_sat_begin) | is.na(self_sat_end) | is.na(spouse_sat_begin) | is.na(spouse_sat_end) |
      spouse_sat_begin > self_sat_begin, NA_integer_,
    as.integer(spouse_sat_end > self_sat_end)
  ),
  r_y_growth = binary_change(support_real_begin, support_real_end)
)
write_csv(contract_input, file.path(data_dir, "stata_r_contract_input.csv"), na = "")
write_csv(contract_expected, file.path(data_dir, "stata_r_contract_expected.csv"), na = "")

saveRDS(intervals, file.path(data_dir, "v6_provisional_dyad_intervals.rds"), compress = "xz")
write_csv(intervals, file.path(data_dir, "v6_provisional_dyad_intervals.csv"))
saveRDS(all_models, file.path(result_dir, "20_basic_model_bundle.rds"), compress = "xz")

hash_paths <- c(raw_dta, id_dta, old_csv, v2_marker,
                file.path(data_dir, "v6_provisional_dyad_intervals.rds"))
file_hashes <- tibble(
  path = hash_paths,
  sha256 = vapply(hash_paths, digest::digest, character(1), file = TRUE, algo = "sha256")
)
write_csv(file_hashes, file.path(result_dir, "21_file_hashes.csv"))

capture.output(sessionInfo(), file = file.path(result_dir, "22_sessionInfo.txt"))
validation <- bind_rows(
  missing_checks %>% transmute(check, pass, detail = NA_character_),
  tibble(check = "all eight registry chains produced samples",
         pass = nrow(chain_samples_df) == 8,
         detail = paste("chains=", nrow(chain_samples_df))),
  tibble(check = "all five models fitted per chain",
         pass = nrow(model_manifest) == 40,
         detail = paste("models=", nrow(model_manifest))),
  tibble(check = "all core logistic models converged without aliased coefficients",
         pass = all(bind_rows(model_diagnostics)$converged) && all(bind_rows(model_diagnostics)$aliased == 0),
         detail = paste("failed=", sum(!bind_rows(model_diagnostics)$converged |
                                         bind_rows(model_diagnostics)$aliased > 0))),
  tibble(check = "partner business correction reproduces 387/375 inc_3 changes",
         pass = identical(as.integer(crosswalk_summary$changed), c(387L, 375L)),
         detail = paste(crosswalk_summary$changed, collapse = "/")),
  tibble(check = "component clustering available",
         pass = n_distinct(intervals$component_id, na.rm = TRUE) > 100,
         detail = paste("components=", n_distinct(intervals$component_id, na.rm = TRUE))),
  tibble(check = "formal CMAverse gate clear",
         pass = !any(formal_gate$status == "BLOCK"),
         detail = paste(formal_gate$gate_id[formal_gate$status == "BLOCK"], collapse = ";"))
)
write_csv(validation, file.path(result_dir, "23_validation.csv"))

run_manifest <- list(
  run_id = "20260904_basic_mechanism_v6",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  analysis_unit = "parent-adult-child dyad interval",
  data_status = "PROVISIONAL",
  formal_cma_status = "BLOCKED_BY_UPSTREAM_DATA_AND_TIME_ORDER",
  chains = registry$estimand_id,
  n_models = nrow(model_manifest),
  output_root = root
)
jsonlite::write_json(run_manifest, file.path(result_dir, "24_run_manifest.json"),
                     pretty = TRUE, auto_unbox = TRUE)

cat("V6_BASIC_COMPLETE\n")
cat("records=", nrow(intervals), " chains=", nrow(chain_samples_df),
    " models=", nrow(model_manifest), "\n", sep = "")
cat("formal_cma_status=BLOCKED_BY_UPSTREAM_DATA_AND_TIME_ORDER\n")
