options(stringsAsFactors = FALSE)
required <- c("readr", "dplyr", "tidyr")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Missing packages: ", paste(missing, collapse = ", "))
suppressPackageStartupMessages({library(readr); library(dplyr); library(tidyr)})

root <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260904_basic_mechanism_v6"
expected_path <- file.path(root, "data", "stata_r_contract_expected.csv")
stata_path <- file.path(root, "data", "stata_r_contract_output.csv")
gate_path <- file.path(root, "results", "19_formal_analysis_gate.csv")
validation_path <- file.path(root, "results", "23_validation.csv")
stopifnot(file.exists(expected_path), file.exists(stata_path), file.exists(gate_path))

expected <- read_csv(expected_path, show_col_types = FALSE)
stata <- read_csv(stata_path, show_col_types = FALSE)
joined <- expected %>% inner_join(stata, by = "contract_row")
mapping <- c(
  r_x_abs = "stata_x_abs", r_x_rel_full = "stata_x_rel_full",
  r_m_self_abs = "stata_m_self_abs", r_m_spouse_abs = "stata_m_spouse_abs",
  r_m_self_rel = "stata_m_self_rel", r_m_spouse_rel = "stata_m_spouse_rel",
  r_y_growth = "stata_y_growth"
)

check_one <- function(r_name, stata_name) {
  r <- joined[[r_name]]; s <- joined[[stata_name]]
  mismatch <- xor(is.na(r), is.na(s)) | (!is.na(r) & !is.na(s) & r != s)
  tibble(variable_r = r_name, variable_stata = stata_name,
         n = length(r), mismatches = sum(mismatch), pass = !any(mismatch))
}
checks <- bind_rows(Map(check_one, names(mapping), unname(mapping)))
write_csv(checks, file.path(root, "results", "25_stata_r_crosscheck.csv"))

gate <- read_csv(gate_path, show_col_types = FALSE) %>%
  mutate(
    status = ifelse(gate_id == "STATA_R_CROSSCHECK" & all(checks$pass), "PASS", status),
    reason = ifelse(gate_id == "STATA_R_CROSSCHECK" & all(checks$pass),
                    paste0("Stata and R exact row-wise agreement across ", nrow(checks), " core variables"), reason),
    required_resolution = ifelse(gate_id == "STATA_R_CROSSCHECK" & all(checks$pass),
                                 "none", required_resolution)
  )
write_csv(gate, gate_path)
if (file.exists(validation_path)) {
  validation <- read_csv(validation_path, show_col_types = FALSE)
  blockers <- gate$gate_id[gate$status == "BLOCK"]
  validation <- validation %>% mutate(
    pass = ifelse(check == "formal CMAverse gate clear", length(blockers) == 0, pass),
    detail = ifelse(check == "formal CMAverse gate clear",
                    if (length(blockers)) paste(blockers, collapse = ";") else "all formal gates clear",
                    detail)
  )
  write_csv(validation, validation_path)
}
if (!all(checks$pass)) stop("Stata/R contract mismatch; see 25_stata_r_crosscheck.csv")
cat("STATA_R_CONTRACT_PASS variables=", nrow(checks), " rows=", nrow(joined), "\n", sep = "")
