options(stringsAsFactors = FALSE, scipen = 999, warn = 1)

root <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260905_basic_regression_cmaverse_v7_4_1"
out_dir <- file.path(root, "cma", "contracts")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

native_lib <- "/Users/lzhs/Library/Caches/org.R-project.R/R/renv/library/CMAverse-mval-grid-v741/macos/R-4.6/aarch64-apple-darwin23"
.libPaths(c(native_lib, .libPaths()))
suppressPackageStartupMessages(library(CMAverse))

make_data <- function(n = 2500L, seed = 74101L) {
  set.seed(seed)
  C <- stats::rnorm(n)
  X <- stats::rbinom(n, 1, stats::plogis(-0.1 + 0.35 * C))
  L <- 0.45 * X + 0.30 * C + stats::rnorm(n, sd = 0.7)
  M <- stats::rbinom(n, 1, stats::plogis(-0.3 + 0.55 * X + 0.25 * C + 0.30 * L))
  Y <- stats::rbinom(n, 1, stats::plogis(-1.0 + 0.50 * X + 0.35 * M - 0.20 * X * M + 0.20 * C + 0.25 * L))
  data.frame(Y = Y, X = X, M = M, C = C, L = L)
}

fit_inputs <- function(data, remove_m_effect = FALSE) {
  mreg <- stats::glm(M ~ X + C + L, family = stats::binomial(), data = data)
  yreg <- stats::glm(Y ~ X + M + X:M + C + L, family = stats::binomial(), data = data)
  postcreg <- list(stats::glm(L ~ X + C, family = stats::gaussian(), data = data))
  list(mreg = mreg, yreg = yreg, postcreg = postcreg)
}

make_zero_mechanism_data <- function() {
  cells <- expand.grid(X = 0:1, C = 0:1, L = 0:1, M = 0:1)
  do.call(rbind, lapply(seq_len(nrow(cells)), function(i) {
    z <- cells[i, ]
    n_cell <- if (z$M == z$X) 60L else 40L
    risk <- 0.20 + 0.15 * z$X + 0.05 * z$C + 0.05 * z$L
    successes <- as.integer(round(n_cell * risk))
    data.frame(
      Y = c(rep(1, successes), rep(0, n_cell - successes)),
      X = z$X, M = z$M, C = z$C, L = z$L
    )
  }))
}

cmest_args <- function(data, fits) {
  list(
    data = data, model = "gformula", outcome = "Y", exposure = "X", mediator = "M",
    basec = "C", postc = "L", mreg = list(fits$mreg), yreg = fits$yreg,
    postcreg = fits$postcreg, EMint = TRUE, a = 1, astar = 0, yval = 1,
    estimation = "imputation", inference = "bootstrap", boot.ci.type = "per",
    nboot = 10, full = TRUE
  )
}

data_compat <- make_data()
fits_compat <- fit_inputs(data_compat)
args_compat <- cmest_args(data_compat, fits_compat)
set.seed(74102L)
single_m0 <- do.call(CMAverse::cmest, c(args_compat, list(mval = list(0))))
set.seed(74102L)
paired <- do.call(CMAverse::cmest, c(args_compat, list(mval_grid = list(c(0, 1)))))

paired_m0 <- paired$mval_results[["0"]]
compatibility <- data.frame(
  check = c(
    "single_child_class", "paired_parent_class", "paired_m0_child_class",
    "point_estimates_m0", "standard_errors_m0", "confidence_low_m0",
    "confidence_high_m0", "p_values_m0", "paired_indices_preserved",
    "paired_indices_hash_matches"
  ),
  pass = c(
    inherits(single_m0, "cmest"), inherits(paired, "cmest_mval_grid"), inherits(paired_m0, "cmest"),
    isTRUE(all.equal(single_m0$effect.pe, paired_m0$effect.pe, tolerance = 1e-10)),
    isTRUE(all.equal(single_m0$effect.se, paired_m0$effect.se, tolerance = 1e-10)),
    isTRUE(all.equal(single_m0$effect.ci.low, paired_m0$effect.ci.low, tolerance = 1e-10)),
    isTRUE(all.equal(single_m0$effect.ci.high, paired_m0$effect.ci.high, tolerance = 1e-10)),
    isTRUE(all.equal(single_m0$effect.pval, paired_m0$effect.pval, tolerance = 1e-10)),
    is.matrix(paired$mval_grid$bootstrap_indices) && nrow(paired$mval_grid$bootstrap_indices) == 10L,
    identical(
      paired$mval_grid$bootstrap_provenance$hash,
      digest::digest(paired$mval_grid$bootstrap_indices, algo = "sha256", serialize = TRUE, serializeVersion = 2)
    )
  ),
  stringsAsFactors = FALSE
)
utils::write.csv(compatibility, file.path(out_dir, "synthetic_paired_compatibility.csv"), row.names = FALSE, fileEncoding = "UTF-8")
saveRDS(list(single_m0 = single_m0, paired = paired), file.path(out_dir, "synthetic_paired_compatibility_objects.rds"), compress = TRUE)

data_zero <- make_zero_mechanism_data()
fits_zero <- fit_inputs(data_zero)
args_zero <- cmest_args(data_zero, fits_zero)
set.seed(74104L)
zero_fit <- do.call(CMAverse::cmest, c(args_zero, list(mval_grid = list(c(0, 1)))))

zero_effect_names <- c("rERintref", "rERintmed", "rERpnie")
zero_contract <- do.call(rbind, lapply(c("0", "1"), function(mval) {
  child <- zero_fit$mval_results[[mval]]
  data.frame(
    mval = mval,
    effect = zero_effect_names,
    estimate = as.numeric(child$effect.pe[zero_effect_names]),
    expected = 0,
    tolerance = 1e-6,
    pass = abs(as.numeric(child$effect.pe[zero_effect_names])) <= 1e-6,
    interpretation = "M-related mechanism should be zero when outcome risks are exactly invariant to M within X-C-L cells",
    stringsAsFactors = FALSE
  )
}))
utils::write.csv(zero_contract, file.path(out_dir, "synthetic_semantic_contract.csv"), row.names = FALSE, fileEncoding = "UTF-8")
saveRDS(zero_fit, file.path(out_dir, "synthetic_semantic_contract_object.rds"), compress = TRUE)

scale_contract <- data.frame(
  field = c("Rte", "Rcde", "Delta_Rcde", "ERcde", "rERintref", "rERintmed", "rERpnie"),
  locked_source_semantics = c(
    "standardized marginal odds ratio for logistic yreg",
    "standardized marginal controlled direct odds ratio for logistic yreg",
    "difference between two standardized marginal controlled direct odds ratios",
    "native excess component; interpret only if semantic contract passes",
    "native excess component; interpret only if semantic contract passes",
    "native excess component; interpret only if semantic contract passes",
    "native excess component; interpret only if semantic contract passes"
  ),
  null_value = c(1, 1, 0, 0, 0, 0, 0),
  stringsAsFactors = FALSE
)
utils::write.csv(scale_contract, file.path(out_dir, "locked_scale_contract.csv"), row.names = FALSE, fileEncoding = "UTF-8")

summary_contract <- data.frame(
  contract = c("paired_compatibility", "zero_mechanism_semantics"),
  pass = c(all(compatibility$pass), all(zero_contract$pass)),
  stringsAsFactors = FALSE
)
utils::write.csv(summary_contract, file.path(out_dir, "contract_summary.csv"), row.names = FALSE, fileEncoding = "UTF-8")
writeLines(capture.output(sessionInfo()), file.path(out_dir, "sessionInfo.txt"))

cat("CMA_CONTRACT_TESTS_COMPLETE compatibility=", all(compatibility$pass),
    " semantic=", all(zero_contract$pass), "\n", sep = "")
