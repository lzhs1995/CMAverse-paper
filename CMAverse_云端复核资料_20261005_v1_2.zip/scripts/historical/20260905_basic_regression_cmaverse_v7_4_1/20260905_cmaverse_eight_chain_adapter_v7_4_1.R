options(stringsAsFactors = FALSE, scipen = 999, warn = 1)

# Minimal adapter around the manuscript's existing CMAverse code:
# - absolute-X specifications follow g_formula_new4.7.R;
# - relative-X specifications follow g_formula_new4.5.R;
# - model/estimation/inference/EMint and custom glm families are unchanged;
# - native mval_grid reuses the already validated paired-M extension.

root <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260905_basic_regression_cmaverse_v7_4_1"
overlay_path <- file.path(root, "data", "cmaverse_v7_4_1_corrected_overlay.rds")
output_root <- Sys.getenv("CMA_OUTPUT_ROOT", file.path(root, "cma"))
run_mode <- Sys.getenv("CMA_RUN_MODE", "smoke")
chain_id <- Sys.getenv("CMA_CHAIN", "AA-S")
nboot <- as.integer(Sys.getenv("CMA_NBOOT", if (run_mode == "formal") "1000" else "10"))
seed <- as.integer(Sys.getenv("CMA_SEED", "12345"))

native_lib <- "/Users/lzhs/Library/Caches/org.R-project.R/R/renv/library/CMAverse-mval-grid-v741/macos/R-4.6/aarch64-apple-darwin23"
package_source_root <- "/Users/lzhs/projects/CMAverse-mval-grid-mac"
adapter_path <- file.path(root, "scripts", "20260905_cmaverse_eight_chain_adapter_v7_4_1.R")
.libPaths(c(native_lib, .libPaths()))
suppressPackageStartupMessages(library(CMAverse))

if (!"mval_grid" %in% names(formals(CMAverse::cmest))) {
  stop("The locked CMAverse build does not expose mval_grid.")
}
if (!file.exists(overlay_path)) stop("Missing corrected overlay: ", overlay_path)

chain_registry <- data.frame(
  chain = c("AA-S", "AA-P", "AR-S", "AR-P", "RA-S", "RA-P", "RR-S", "RR-P"),
  exposure_type = c("absolute", "absolute", "absolute", "absolute", "relative", "relative", "relative", "relative"),
  mediator_type = c("self_abs", "spouse_abs", "self_rel", "spouse_rel", "self_abs", "spouse_abs", "self_rel", "spouse_rel"),
  exposure_source = c(rep("x_abs_target", 4), rep("x_rel_target", 4)),
  mediator_source = c("m_self_abs_target", "m_spouse_abs_target", "m_self_rel_target", "m_spouse_rel_target", "m_self_abs_target", "m_spouse_abs_target", "m_self_rel_target", "m_spouse_rel_target"),
  original_script = c(rep("g_formula_new4.7.R", 4), rep("g_formula_new4.5.R", 4)),
  stringsAsFactors = FALSE
)
if (!chain_id %in% chain_registry$chain) stop("Unknown chain: ", chain_id)
cfg <- chain_registry[chain_registry$chain == chain_id, , drop = FALSE]

run_dir <- file.path(output_root, run_mode, chain_id)
dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
state_path <- file.path(run_dir, "state.json")

json_write <- function(x, path) {
  if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite is required")
  tmp <- paste0(path, ".tmp")
  jsonlite::write_json(x, tmp, auto_unbox = TRUE, pretty = TRUE, null = "null")
  file.rename(tmp, path)
}
write_state <- function(status, message = NULL, extra = list()) {
  json_write(c(list(
    chain = chain_id, mode = run_mode, status = status, nboot = nboot,
    seed = seed, pid = Sys.getpid(), updated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
    message = message
  ), extra), state_path)
}

sha256_file <- function(path) {
  if (!file.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}

git_value <- function(args) {
  value <- tryCatch(
    system2("git", c("-C", package_source_root, args), stdout = TRUE, stderr = FALSE),
    error = function(e) character(0)
  )
  if (!length(value)) NA_character_ else paste(value, collapse = "\n")
}
options(error = function() {
  try(write_state("failed", geterrmessage()), silent = TRUE)
  q(save = "no", status = 1, runLast = FALSE)
})

utils::write.csv(
  chain_registry,
  file.path(output_root, "chain_registry.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

make_formula <- function(lhs, rhs) {
  stats::reformulate(unique(rhs), response = lhs)
}

center_if_present <- function(data, vars) {
  for (name in intersect(vars, names(data))) {
    data[[name]] <- data[[name]] - mean(data[[name]], na.rm = TRUE)
  }
  data
}

mediator_spec <- switch(
  cfg$mediator_type,
  self_abs = list(
    baseline = c("msat_c1_begin"),
    auxiliary = c("msateco_c1_2", "msathw_c1_2"),
    other_m = c("msat_c2_2")
  ),
  spouse_abs = list(
    baseline = c("msat_c2_begin"),
    auxiliary = c("msateco_c2_2", "msathw_c2_2"),
    other_m = c("msat_c1_2")
  ),
  self_rel = list(
    baseline = c("msat_c12_begin", "msat_c1_begin"),
    auxiliary = c("msateco_c12_3", "msathw_c12_3"),
    other_m = c("msat_c1_2", "msat_c2_2")
  ),
  spouse_rel = list(
    baseline = c("msat_c21_begin", "msat_c1_begin"),
    auxiliary = c("msateco_c21_3", "msathw_c21_3"),
    other_m = c("msat_c1_2", "msat_c2_2")
  )
)

base_common <- c(
  "dwm_begin", "gender_begin", "aage_begin", "actor_edu2_begin", "ahk_begin",
  "prtmarr_1", "prtcor_1", "prtgender_begin", "prtage_begin", "prtedu_begin",
  "actor_siops_begin", "child_begin", "ahw_begin", "prtmarr_begin",
  "prtcor_begin", "total_debts_scale_begin", "shealth_begin",
  "fmlincc_begin", "lifetime_begin", "time_period"
)
base_pred_common <- c(
  "dwm_begin", "gender_begin", "aage_begin", "actor_edu2_begin", "ahk_begin",
  "actor_siops_begin", "child_begin", "ahw_begin", "total_debts_scale_begin",
  "shealth_begin", "fmlincc_begin", "lifetime_begin",
  "time_period"
)
exposure_baseline <- c("aincc_begin_log", if (cfg$exposure_type == "relative") "inc_begin")
base_confounders <- unique(c(mediator_spec$baseline, exposure_baseline, "esup_begin_log", base_common))
base_confounders_pred <- unique(c(mediator_spec$baseline, exposure_baseline, "esup_begin_log", base_pred_common))

post_confounders <- unique(c(
  "total_debts_2", "shealth_2", "reside_ind_1",
  mediator_spec$auxiliary, mediator_spec$other_m,
  "child_2", if (cfg$exposure_type == "relative") "aincc_2",
  "ahw_2", "fmlincc_2", "actor_siops_2"
))

mreg_rhs <- unique(c(
  "X", mediator_spec$baseline, exposure_baseline, mediator_spec$auxiliary,
  "gender_begin", "aage_begin", "actor_edu2_begin", "actor_siops_2",
  "child_2", if (cfg$exposure_type == "relative") "aincc_2",
  "ahw_2", "ahk_begin", "total_debts_2", "shealth_2", "reside_ind_1",
  "actor_siops_begin", "child_begin", "ahw_begin", "total_debts_scale_begin",
  "shealth_begin", "fmlincc_begin", "lifetime_begin",
  "fmlincc_2", "time_period"
))

yreg_rhs <- unique(c(
  "X", "M", "X:M", mediator_spec$baseline, exposure_baseline,
  "esup_begin_log", mediator_spec$other_m,
  "dwm_begin", "gender_begin", "aage_begin", "actor_edu2_begin",
  "actor_siops_2", "child_2", if (cfg$exposure_type == "relative") "aincc_2",
  "ahw_2", "ahk_begin", "total_debts_2", "shealth_2", "reside_ind_1",
  "prtmarr_1", "prtcor_1", "prtgender_begin", "prtage_begin", "prtedu_begin",
  "actor_siops_begin", "child_begin", "ahw_begin", "prtmarr_begin",
  "prtcor_begin", "total_debts_scale_begin", "shealth_begin",
  "fmlincc_begin", "lifetime_begin", "fmlincc_2",
  "time_period"
))

write_state("running", "loading corrected overlay")
dat_all <- readRDS(overlay_path)
identity_required <- c(
  "stable_row_id", "dyad_id", "actor_pid", "actor_pid_begin", "actor_pid_end",
  "partner_pid_begin", "partner_pid_end", "parent_pid_begin", "parent_pid_end",
  "parent_role", "same_actor", "same_partner", "same_parent",
  "parent_identity_status", "parent_identity_included"
)
missing_identity <- setdiff(identity_required, names(dat_all))
if (length(missing_identity)) stop("Missing identity columns: ", paste(missing_identity, collapse = ", "))
if (anyDuplicated(dat_all$stable_row_id)) stop("stable_row_id is not unique")
if (!all(dat_all$same_actor == (dat_all$actor_pid_begin == dat_all$actor_pid_end), na.rm = TRUE)) {
  stop("same_actor does not match endpoint actor PIDs")
}
if (!all(dat_all$same_partner == (dat_all$partner_pid_begin == dat_all$partner_pid_end), na.rm = TRUE)) {
  stop("same_partner does not match endpoint partner PIDs")
}
if (!all(dat_all$same_parent == dat_all$parent_identity_included)) {
  stop("same_parent does not match the v7.4.1 parent identity rule")
}
if (!all(dat_all$parent_identity_status[dat_all$same_parent] %in% c("pid_confirmed", "role_link_assumed"))) {
  stop("Included parent identity state is invalid")
}

target_contract <- data.frame(
  target = c(
    "x_abs_target", "x_rel_target", "m_self_abs_target", "m_spouse_abs_target",
    "m_self_rel_target", "m_spouse_rel_target", "y_target"
  ),
  event_all = c(
    "x_abs_event_all", "x_rel_event_all", "m_self_abs_event_all", "m_spouse_abs_event_all",
    "m_self_rel_event_all", "m_spouse_rel_event_all", "y_event_all"
  ),
  eligible = c(
    "eligible_x_abs", "eligible_x_rel", "eligible_m_self_abs", "eligible_m_spouse_abs",
    "eligible_m_self_rel", "eligible_m_spouse_rel", NA_character_
  ),
  stringsAsFactors = FALSE
)
for (i in seq_len(nrow(target_contract))) {
  tname <- target_contract$target[[i]]
  ename <- target_contract$event_all[[i]]
  qname <- target_contract$eligible[[i]]
  if (!all(dat_all[[tname]] %in% c(0, 1, NA))) stop(tname, " is not binary/NA")
  if (!all(dat_all[[ename]] %in% c(0, 1, NA))) stop(ename, " is not binary/NA")
  if (any(!is.na(dat_all[[tname]]) & is.na(dat_all[[ename]]))) stop(tname, " exists when event_all is missing")
  if (!is.na(qname)) {
    if (!all(dat_all[[qname]] %in% c(TRUE, FALSE, NA))) stop(qname, " is not logical/NA")
    if (any(!is.na(dat_all[[tname]]) & !(dat_all[[qname]] %in% TRUE))) stop(tname, " exists outside eligibility")
  }
}

identity_keep <- dat_all$same_actor %in% TRUE & dat_all$same_parent %in% TRUE & dat_all$same_partner %in% TRUE
dat <- dat_all[identity_keep, , drop = FALSE]
dat$X <- dat[[cfg$exposure_source]]
dat$M <- dat[[cfg$mediator_source]]
dat$Y <- dat$y_target
if (any(dat$aincc_begin < -1, na.rm = TRUE) || any(dat$esup_begin < -1, na.rm = TRUE)) {
  stop("log(x + 1) is undefined for a retained baseline value")
}
dat$aincc_begin_log <- log(dat$aincc_begin + 1)
dat$esup_begin_log <- log(dat$esup_begin + 1)
center_vars <- c(
  "aage_begin", "actor_edu2_begin", "actor_siops_begin", "child_begin",
  "ahw_begin", "prtage_begin", "fmlincc_begin"
)
centering_constants <- data.frame(
  variable = intersect(center_vars, names(dat)),
  center = vapply(dat[intersect(center_vars, names(dat))], mean, numeric(1), na.rm = TRUE),
  stringsAsFactors = FALSE
)
utils::write.csv(centering_constants, file.path(run_dir, "centering_constants.csv"), row.names = FALSE, fileEncoding = "UTF-8")
dat <- center_if_present(dat, center_vars)

required <- unique(c("X", "M", "Y", base_confounders, base_confounders_pred, post_confounders, mreg_rhs, setdiff(yreg_rhs, "X:M")))
missing_columns <- setdiff(required, names(dat))
if (length(missing_columns)) stop("Missing required columns: ", paste(missing_columns, collapse = ", "))

finite_required <- vapply(dat[, required, drop = FALSE], function(x) {
  if (!is.numeric(x)) return(rep(TRUE, length(x)))
  is.na(x) | is.finite(x)
}, logical(nrow(dat)))
if (any(!finite_required)) stop("A required numeric variable contains non-finite values")

complete <- stats::complete.cases(dat[, required, drop = FALSE])
model_columns <- unique(c(
  required, "stable_row_id", "dyad_id", "actor_pid", "parent_role",
  "parent_identity_status", "period_label"
))
model_data <- dat[complete, model_columns, drop = FALSE]
if (!nrow(model_data)) stop("No complete cases for chain ", chain_id)
if (anyNA(model_data)) stop("Chain model data still contains missing values")
if (!all(model_data$X %in% c(0, 1)) || !all(model_data$M %in% c(0, 1)) || !all(model_data$Y %in% c(0, 1))) {
  stop("X, M, and Y must be binary after chain-specific eligibility filtering")
}
if (anyDuplicated(model_data$stable_row_id)) stop("Final model_data row IDs are not unique")

stage_masks <- list(
  S0_overlay = rep(TRUE, nrow(dat_all)),
  S1_same_actor = dat_all$same_actor %in% TRUE,
  S2_parent_identity = dat_all$same_actor %in% TRUE & dat_all$same_parent %in% TRUE,
  S3_same_partner = identity_keep,
  S4_X_target = identity_keep & !is.na(dat_all[[cfg$exposure_source]]),
  S5_M_target = identity_keep & !is.na(dat_all[[cfg$exposure_source]]) & !is.na(dat_all[[cfg$mediator_source]]),
  S6_Y_target = identity_keep & !is.na(dat_all[[cfg$exposure_source]]) & !is.na(dat_all[[cfg$mediator_source]]) & !is.na(dat_all$y_target)
)
sample_flow <- do.call(rbind, lapply(names(stage_masks), function(stage) {
  z <- dat_all[stage_masks[[stage]], , drop = FALSE]
  data.frame(
    chain = chain_id, stage = stage, records = nrow(z),
    dyads = length(unique(z$dyad_id)), actors = length(unique(z$actor_pid)),
    stringsAsFactors = FALSE
  )
}))
sample_flow <- rbind(sample_flow, data.frame(
  chain = chain_id, stage = "S7_model_complete", records = nrow(model_data),
  dyads = length(unique(model_data$dyad_id)), actors = length(unique(model_data$actor_pid)),
  stringsAsFactors = FALSE
))
utils::write.csv(sample_flow, file.path(run_dir, "sample_flow.csv"), row.names = FALSE, fileEncoding = "UTF-8")
utils::write.csv(
  model_data[, c("stable_row_id", "dyad_id", "actor_pid", "parent_role", "parent_identity_status", "period_label")],
  file.path(run_dir, "analysis_row_ids.csv"), row.names = FALSE, fileEncoding = "UTF-8"
)

cell_grid <- merge(
  expand.grid(X = 0:1, M = 0:1, Y = 0:1),
  as.data.frame(table(model_data$X, model_data$M, model_data$Y)),
  by.x = c("X", "M", "Y"), by.y = c("Var1", "Var2", "Var3"), all.x = TRUE
)
cell_grid$Freq[is.na(cell_grid$Freq)] <- 0
utils::write.csv(cell_grid, file.path(run_dir, "x_m_y_cells.csv"), row.names = FALSE)
if (any(cell_grid$Freq == 0)) stop("At least one X-M-Y cell is empty")

mreg_formula <- make_formula("M", mreg_rhs)
yreg_formula <- make_formula("Y", yreg_rhs)
postc_formulas <- setNames(lapply(post_confounders, function(z) make_formula(z, c("X", base_confounders_pred))), post_confounders)

postcreg <- lapply(postc_formulas, function(formula) {
  fit <- stats::glm(formula, family = stats::gaussian(), data = model_data)
  fit$call$formula <- formula
  fit
})
mreg <- stats::glm(mreg_formula, family = stats::binomial(), data = model_data)
yreg <- stats::glm(yreg_formula, family = stats::binomial(), data = model_data)
mreg$call$formula <- mreg_formula
yreg$call$formula <- yreg_formula

formula_manifest <- data.frame(
  chain = chain_id,
  model = c("mreg", "yreg", paste0("postcreg:", names(postc_formulas))),
  formula = c(
    paste(deparse(mreg_formula), collapse = " "),
    paste(deparse(yreg_formula), collapse = " "),
    vapply(postc_formulas, function(x) paste(deparse(x), collapse = " "), character(1))
  ),
  family = c("binomial", "binomial", rep("gaussian", length(postc_formulas))),
  stringsAsFactors = FALSE
)
utils::write.csv(formula_manifest, file.path(run_dir, "formula_manifest.csv"), row.names = FALSE, fileEncoding = "UTF-8")

role_bind <- function(role, variables) {
  data.frame(role = role, variable = unique(variables), stringsAsFactors = FALSE)
}
role_manifest <- do.call(rbind, list(
  role_bind("exposure", "X"),
  role_bind("mediator", "M"),
  role_bind("outcome", "Y"),
  role_bind("basec", base_confounders),
  role_bind("postc", post_confounders),
  role_bind("mreg_predictor", mreg_rhs),
  role_bind("yreg_predictor", setdiff(yreg_rhs, "X:M"))
))
role_manifest$source_column <- role_manifest$variable
role_manifest$source_column[role_manifest$variable == "X"] <- cfg$exposure_source
role_manifest$source_column[role_manifest$variable == "M"] <- cfg$mediator_source
role_manifest$source_column[role_manifest$variable == "Y"] <- "y_target"
role_manifest$time_status <- ifelse(
  role_manifest$variable %in% c("prtmarr_1", "prtcor_1"), "interval_change_assumption",
  ifelse(
    grepl("_begin(_log)?$", role_manifest$variable), "interval_baseline",
    ifelse(role_manifest$variable == "time_period", "period_indicator",
           ifelse(grepl("_(1|2|3)$", role_manifest$variable), "interval_change_or_status", "derived_or_other"))
  )
)
role_manifest$correction_status <- ifelse(
  role_manifest$source_column %in% c(
    "x_abs_target", "x_rel_target", "m_self_abs_target", "m_spouse_abs_target",
    "m_self_rel_target", "m_spouse_rel_target", "y_target", "aincc_begin",
    "inc_begin", "msat_c1_begin", "msat_c2_begin", "msat_c12_begin",
    "msat_c21_begin", "esup_begin", "msat_c1_2", "msat_c2_2"
  ),
  "v6_audited_overlay", "inherited_initial_draft_covariate"
)
role_manifest$transformation <- ifelse(
  role_manifest$variable %in% c("aincc_begin_log", "esup_begin_log"), "log(x+1)",
  ifelse(role_manifest$variable %in% center_vars, "centered using saved chain constant", "none")
)
role_manifest$class <- vapply(role_manifest$variable, function(v) paste(class(dat[[v]]), collapse = "|"), character(1))
role_manifest$n_missing_pre_complete <- vapply(role_manifest$variable, function(v) sum(is.na(dat[[v]])), integer(1))
role_manifest$n_nonfinite_pre_complete <- vapply(role_manifest$variable, function(v) {
  x <- dat[[v]]
  if (!is.numeric(x)) return(0L)
  as.integer(sum(!is.na(x) & !is.finite(x)))
}, integer(1))
role_manifest$minimum <- vapply(role_manifest$variable, function(v) {
  x <- dat[[v]]
  if (!is.numeric(x) || all(is.na(x))) return(NA_real_)
  min(x, na.rm = TRUE)
}, numeric(1))
role_manifest$maximum <- vapply(role_manifest$variable, function(v) {
  x <- dat[[v]]
  if (!is.numeric(x) || all(is.na(x))) return(NA_real_)
  max(x, na.rm = TRUE)
}, numeric(1))
utils::write.csv(role_manifest, file.path(run_dir, "variable_role_manifest.csv"), row.names = FALSE, fileEncoding = "UTF-8")

sample_audit <- data.frame(
  chain = chain_id,
  source_rows = nrow(dat),
  complete_rows = nrow(model_data),
  dyads = length(unique(model_data$dyad_id)),
  actors = length(unique(model_data$actor_pid)),
  x_rate = mean(model_data$X),
  m_rate = mean(model_data$M),
  y_rate = mean(model_data$Y),
  min_xmy_cell = min(cell_grid$Freq),
  stringsAsFactors = FALSE
)
utils::write.csv(sample_audit, file.path(run_dir, "sample_audit.csv"), row.names = FALSE, fileEncoding = "UTF-8")

alias_any <- function(fit) any(is.na(stats::coef(fit)))
preflight <- data.frame(
  chain = chain_id,
  mreg_converged = isTRUE(mreg$converged),
  yreg_converged = isTRUE(yreg$converged),
  postcreg_all_converged = all(vapply(postcreg, function(x) isTRUE(x$converged), logical(1))),
  any_alias = alias_any(mreg) || alias_any(yreg) || any(vapply(postcreg, alias_any, logical(1))),
  stringsAsFactors = FALSE
)
utils::write.csv(preflight, file.path(run_dir, "model_preflight.csv"), row.names = FALSE, fileEncoding = "UTF-8")
if (!preflight$mreg_converged || !preflight$yreg_converged || !preflight$postcreg_all_converged || preflight$any_alias) {
  stop("Preflight convergence/alias gate failed")
}

seed_existed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
if (seed_existed) seed_before_diagnostic <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
set.seed(seed + 700000L)
gaussian_support <- do.call(rbind, lapply(names(postcreg), function(z) {
  fit <- postcreg[[z]]
  observed <- model_data[[z]]
  fitted_mean <- stats::predict(fit, type = "response")
  sigma <- sqrt(summary(fit)$dispersion)
  if (!is.finite(sigma) || sigma < 0) {
    stop(sprintf("Non-finite Gaussian residual SD for postc variable %s", z))
  }
  simulated <- stats::rnorm(length(fitted_mean), fitted_mean, sigma)
  binary_observed <- all(unique(observed) %in% c(0, 1))
  data.frame(
    chain = chain_id, variable = z, observed_binary = binary_observed,
    observed_min = min(observed), observed_max = max(observed),
    fitted_min = min(fitted_mean), fitted_max = max(fitted_mean), sigma = sigma,
    simulated_min = min(simulated), simulated_max = max(simulated),
    simulated_outside_observed_fraction = mean(simulated < min(observed) | simulated > max(observed)),
    simulated_outside_unit_fraction = mean(simulated < 0 | simulated > 1),
    simulated_on_binary_support_fraction = if (binary_observed) mean(simulated %in% c(0, 1)) else NA_real_,
    stringsAsFactors = FALSE
  )
}))
if (seed_existed) {
  assign(".Random.seed", seed_before_diagnostic, envir = .GlobalEnv)
} else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
  rm(".Random.seed", envir = .GlobalEnv)
}
utils::write.csv(gaussian_support, file.path(run_dir, "gaussian_postc_support.csv"), row.names = FALSE, fileEncoding = "UTF-8")

set.seed(seed)
started <- Sys.time()
fit_grid <- CMAverse::cmest(
  data = model_data,
  model = "gformula",
  outcome = "Y",
  exposure = "X",
  mediator = "M",
  basec = base_confounders,
  postc = post_confounders,
  mreg = list(mreg),
  yreg = yreg,
  postcreg = postcreg,
  EMint = TRUE,
  a = 1,
  astar = 0,
  mval_grid = list(c(0, 1)),
  estimation = "imputation",
  inference = "bootstrap",
  boot.ci.type = "per",
  yval = 1,
  full = TRUE,
  nboot = nboot
)
elapsed <- as.numeric(difftime(Sys.time(), started, units = "secs"))

if (!inherits(fit_grid, "cmest_mval_grid")) stop("Expected cmest_mval_grid result")
if (!all(c("0", "1") %in% names(fit_grid$mval_results))) stop("Missing mval child")
if (is.null(fit_grid$delta_cde)) stop("Missing paired delta_cde")
for (mval in c("0", "1")) {
  if (!inherits(fit_grid$mval_results[[mval]], "cmest")) stop("Child is not a full cmest object: ", mval)
}

bootstrap_indices <- fit_grid$mval_grid$bootstrap_indices
bootstrap_t <- fit_grid$mval_grid$bootstrap_t
bootstrap_t0 <- fit_grid$mval_grid$bootstrap_t0
bootstrap_rng_state <- fit_grid$mval_grid$bootstrap_rng_state
if (is.null(bootstrap_indices) || !is.matrix(bootstrap_indices) || !all(dim(bootstrap_indices) == c(nboot, nrow(model_data)))) {
  stop("The paired extension did not preserve the actual bootstrap index matrix")
}
if (is.null(bootstrap_t) || !is.matrix(bootstrap_t) || nrow(bootstrap_t) != nboot) {
  stop("The paired extension did not preserve the bootstrap effect matrix")
}
if (is.null(bootstrap_rng_state) || !length(bootstrap_rng_state)) stop("Missing bootstrap RNG state")

package_commit <- git_value(c("rev-parse", "HEAD"))
package_status <- git_value(c("status", "--porcelain"))
package_source_files <- file.path(package_source_root, "R", c("cmest.R", "estinf.R", "est.gformula.R"))
package_provenance <- data.frame(
  package_version = as.character(utils::packageVersion("CMAverse")),
  package_lib = find.package("CMAverse"),
  source_root = package_source_root,
  source_commit = package_commit,
  source_dirty = !is.na(package_status) && nzchar(package_status),
  source_file = package_source_files,
  source_sha256 = vapply(package_source_files, sha256_file, character(1)),
  stringsAsFactors = FALSE
)
utils::write.csv(package_provenance, file.path(run_dir, "package_provenance.csv"), row.names = FALSE, fileEncoding = "UTF-8")

fit_grid$execution_provenance <- list(
  chain = chain_id,
  stable_row_ids = model_data$stable_row_id,
  model_data_sha256 = digest::digest(model_data, algo = "sha256", serialize = TRUE, serializeVersion = 2),
  adapter_sha256 = sha256_file(adapter_path),
  package_commit = package_commit,
  package_dirty = !is.na(package_status) && nzchar(package_status),
  sampling_unit = "dyad-interval record",
  pairing_scope = "M=0 and M=1 share row-bootstrap indices and internal RNG start",
  dependency_adjusted = FALSE
)

saveRDS(bootstrap_indices, file.path(run_dir, "bootstrap_indices.rds"), compress = TRUE)
saveRDS(bootstrap_t, file.path(run_dir, "bootstrap_effect_draws_raw.rds"), compress = TRUE)
saveRDS(bootstrap_t0, file.path(run_dir, "bootstrap_effect_point_raw.rds"), compress = TRUE)
saveRDS(bootstrap_rng_state, file.path(run_dir, "bootstrap_rng_state.rds"), compress = TRUE)

full_path <- file.path(run_dir, paste0("cmest_grid_", chain_id, "_nboot", nboot, ".rds"))
saveRDS(fit_grid, full_path, compress = FALSE)

extract_effects <- function(object, mval) {
  data.frame(
    chain = chain_id,
    mval = mval,
    effect = names(object$effect.pe),
    estimate = as.numeric(object$effect.pe),
    se = as.numeric(object$effect.se),
    conf_low = as.numeric(object$effect.ci.low),
    conf_high = as.numeric(object$effect.ci.high),
    p_value = as.numeric(object$effect.pval),
    stringsAsFactors = FALSE
  )
}
effects <- rbind(
  extract_effects(fit_grid$mval_results[["0"]], "0"),
  extract_effects(fit_grid$mval_results[["1"]], "1")
)
utils::write.csv(effects, file.path(run_dir, "effects_full.csv"), row.names = FALSE, fileEncoding = "UTF-8")

delta <- fit_grid$delta_cde
delta_table <- data.frame(
  chain = chain_id,
  effect = names(delta$effect.pe),
  estimate = as.numeric(delta$effect.pe),
  se = as.numeric(delta$effect.se),
  conf_low = as.numeric(delta$effect.ci.low),
  conf_high = as.numeric(delta$effect.ci.high),
  p_value = as.numeric(delta$effect.pval),
  scale = delta$scale,
  stringsAsFactors = FALSE
)
utils::write.csv(delta_table, file.path(run_dir, "delta_cde.csv"), row.names = FALSE, fileEncoding = "UTF-8")

n_effect <- length(fit_grid$mval_results[["0"]]$effect.pe)
p_metadata <- do.call(rbind, lapply(seq_along(c("0", "1")), function(i) {
  mval <- c("0", "1")[[i]]
  child <- fit_grid$mval_results[[mval]]
  cols <- ((i - 1L) * n_effect + 1L):(i * n_effect)
  do.call(rbind, lapply(seq_len(n_effect), function(j) {
    draws <- bootstrap_t[, cols[[j]]]
    finite <- is.finite(draws)
    positive <- sum(draws[finite] > 0)
    negative <- sum(draws[finite] < 0)
    zero <- sum(draws[finite] == 0)
    p_native <- as.numeric(child$effect.pval[[j]])
    data.frame(
      chain = chain_id, mval = mval, effect = names(child$effect.pe)[[j]],
      display_scale = if (j <= 6L) "ratio" else "native additive/proportion",
      bootstrap_test_scale = if (j <= 6L) "log ratio" else "native additive/proportion",
      null_value_display = if (j <= 6L) 1 else 0,
      null_value_bootstrap = 0,
      B_attempted = nboot, B_effective = sum(finite),
      positive_tail_count = positive, negative_tail_count = negative,
      zero_count = zero, tail_count = min(positive, negative),
      p_native = p_native, p_method = "CMAverse two-sided sign-tail bootstrap",
      p_display = if (isTRUE(p_native == 0)) {
        paste0("0 (no opposite-tail draw among ", sum(finite), "; below simulation resolution)")
      } else format.pval(p_native, digits = 3, eps = 0),
      stringsAsFactors = FALSE
    )
  }))
}))

delta_draws <- exp(bootstrap_t[, n_effect + 1L]) - exp(bootstrap_t[, 1L])
delta_finite <- is.finite(delta_draws)
delta_p_native <- as.numeric(delta$effect.pval[[1]])
p_metadata <- rbind(p_metadata, data.frame(
  chain = chain_id, mval = "paired", effect = names(delta$effect.pe)[[1]],
  display_scale = "difference of marginal odds ratios",
  bootstrap_test_scale = "difference of marginal odds ratios",
  null_value_display = 0, null_value_bootstrap = 0,
  B_attempted = nboot, B_effective = sum(delta_finite),
  positive_tail_count = sum(delta_draws[delta_finite] > 0),
  negative_tail_count = sum(delta_draws[delta_finite] < 0),
  zero_count = sum(delta_draws[delta_finite] == 0),
  tail_count = min(sum(delta_draws[delta_finite] > 0), sum(delta_draws[delta_finite] < 0)),
  p_native = delta_p_native,
  p_method = "CMAverse two-sided sign-tail bootstrap",
  p_display = if (isTRUE(delta_p_native == 0)) {
    paste0("0 (no opposite-tail draw among ", sum(delta_finite), "; below simulation resolution)")
  } else format.pval(delta_p_native, digits = 3, eps = 0),
  stringsAsFactors = FALSE
))
utils::write.csv(p_metadata, file.path(run_dir, "bootstrap_pvalue_metadata.csv"), row.names = FALSE, fileEncoding = "UTF-8")

core_bootstrap_validity <- data.frame(
  chain = chain_id,
  attempt_id = seq_len(nboot),
  all_effects_finite = apply(bootstrap_t, 1L, function(x) all(is.finite(x))),
  finite_effect_count = apply(bootstrap_t, 1L, function(x) sum(is.finite(x))),
  expected_effect_count = ncol(bootstrap_t),
  failure_reason = ifelse(
    apply(bootstrap_t, 1L, function(x) all(is.finite(x))), "", "one or more non-finite CMAverse effect draws"
  ),
  stringsAsFactors = FALSE
)
utils::write.csv(core_bootstrap_validity, file.path(run_dir, "core_bootstrap_validity.csv"), row.names = FALSE, fileEncoding = "UTF-8")

policy_chains <- c("AA-S", "AA-P", "RA-S", "RA-P")
if (chain_id %in% policy_chains) {
  policy_predict <- function(fit, data) {
    q_obs <- stats::predict(fit, newdata = data, type = "response")
    data_m1 <- data
    data_m0 <- data
    data_m1$M <- 1
    data_m0$M <- 0
    q_1 <- stats::predict(fit, newdata = data_m1, type = "response")
    q_0 <- stats::predict(fit, newdata = data_m0, type = "response")
    values <- c(q_obs, q_1, q_0)
    if (any(!is.finite(values)) || any(values < 0 | values > 1)) stop("Invalid policy probability")
    mu_obs <- mean(q_obs)
    mu_1 <- mean(q_1)
    mu_0 <- mean(q_0)
    rd <- mu_1 - mu_obs
    identity_rhs <- mean((1 - data$M) * (q_1 - q_0))
    c(
      observed_y = mean(data$Y), mu_obs = mu_obs, mu_1 = mu_1, mu_0 = mu_0,
      RD_policy = rd, RR_policy = if (mu_obs > 0) mu_1 / mu_obs else NA_real_,
      identity_rhs = identity_rhs, identity_residual = rd - identity_rhs
    )
  }

  policy_point <- policy_predict(yreg, model_data)
  policy_draws <- matrix(
    NA_real_, nrow = nboot, ncol = length(policy_point),
    dimnames = list(NULL, names(policy_point))
  )
  policy_status <- data.frame(
    chain = chain_id, attempt_id = seq_len(nboot), success = FALSE,
    warning = "", failure_reason = "", stringsAsFactors = FALSE
  )
  for (b in seq_len(nboot)) {
    warning_text <- character(0)
    result_b <- tryCatch(
      withCallingHandlers({
        db <- model_data[bootstrap_indices[b, ], , drop = FALSE]
        fit_b <- stats::glm(yreg_formula, family = stats::binomial(), data = db)
        if (!isTRUE(fit_b$converged)) stop("policy yreg did not converge")
        if (anyNA(stats::coef(fit_b))) stop("policy yreg contains aliased coefficients")
        policy_predict(fit_b, db)
      }, warning = function(w) {
        warning_text <<- c(warning_text, conditionMessage(w))
        invokeRestart("muffleWarning")
      }),
      error = function(e) e
    )
    policy_status$warning[[b]] <- paste(unique(warning_text), collapse = " | ")
    if (inherits(result_b, "error")) {
      policy_status$failure_reason[[b]] <- conditionMessage(result_b)
    } else {
      policy_draws[b, ] <- result_b
      policy_status$success[[b]] <- all(is.finite(result_b[c("mu_obs", "mu_1", "mu_0", "RD_policy")]))
      if (!policy_status$success[[b]]) policy_status$failure_reason[[b]] <- "non-finite policy output"
    }
  }
  saveRDS(policy_draws, file.path(run_dir, "policy_bootstrap_draws.rds"), compress = TRUE)
  utils::write.csv(policy_status, file.path(run_dir, "policy_bootstrap_status.csv"), row.names = FALSE, fileEncoding = "UTF-8")

  summarize_policy <- function(metric, null_value) {
    draws <- policy_draws[, metric]
    finite <- is.finite(draws)
    transformed <- if (metric == "RR_policy") log(draws[finite]) else draws[finite] - null_value
    tail_count <- min(sum(transformed > 0), sum(transformed < 0))
    p_value <- if (length(transformed)) 2 * tail_count / length(transformed) else NA_real_
    ci <- if (any(finite)) stats::quantile(draws[finite], c(0.025, 0.975), na.rm = TRUE) else c(NA_real_, NA_real_)
    data.frame(
      chain = chain_id, metric = metric, estimate = unname(policy_point[[metric]]),
      conf_low = unname(ci[[1]]), conf_high = unname(ci[[2]]),
      B_attempted = nboot, B_effective = sum(finite), tail_count = tail_count,
      p_value = p_value, null_value = null_value,
      stringsAsFactors = FALSE
    )
  }
  policy_summary <- do.call(rbind, list(
    summarize_policy("mu_obs", 0), summarize_policy("mu_1", 0), summarize_policy("mu_0", 0),
    summarize_policy("RD_policy", 0), summarize_policy("RR_policy", 1)
  ))
  policy_summary$observed_y <- unname(policy_point[["observed_y"]])
  policy_summary$identity_residual <- unname(policy_point[["identity_residual"]])
  utils::write.csv(policy_summary, file.path(run_dir, "policy_summary.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  if (!isTRUE(all.equal(unname(policy_point[["RD_policy"]]), unname(policy_point[["identity_rhs"]]), tolerance = 1e-10))) {
    stop("Policy identity check failed")
  }

  m_prob <- stats::predict(mreg, newdata = model_data, type = "response")
  at_risk <- model_data$M == 0
  support_values <- m_prob[at_risk]
  policy_support <- data.frame(
    chain = chain_id, observed_M0_records = sum(at_risk),
    propensity_min = min(support_values), propensity_p01 = unname(stats::quantile(support_values, 0.01)),
    propensity_p05 = unname(stats::quantile(support_values, 0.05)), propensity_median = stats::median(support_values),
    propensity_p95 = unname(stats::quantile(support_values, 0.95)), propensity_p99 = unname(stats::quantile(support_values, 0.99)),
    propensity_max = max(support_values), fraction_below_0_01 = mean(support_values < 0.01),
    fraction_above_0_99 = mean(support_values > 0.99), stringsAsFactors = FALSE
  )
  utils::write.csv(policy_support, file.path(run_dir, "policy_support_diagnostic.csv"), row.names = FALSE, fileEncoding = "UTF-8")
}

cde0 <- unname(fit_grid$mval_results[["0"]]$effect.pe[["Rcde"]])
cde1 <- unname(fit_grid$mval_results[["1"]]$effect.pe[["Rcde"]])
hash_m0 <- fit_grid$mval_results[["0"]]$bootstrap_provenance$hash
hash_m1 <- fit_grid$mval_results[["1"]]$bootstrap_provenance$hash
hash_delta <- fit_grid$delta_cde$bootstrap_provenance$hash
hash_indices <- digest::digest(bootstrap_indices, algo = "sha256", serialize = TRUE, serializeVersion = 2)
hashes_nonempty <- all(!is.na(c(hash_m0, hash_m1, hash_delta, hash_indices)) & nzchar(c(hash_m0, hash_m1, hash_delta, hash_indices)))
validation <- data.frame(
  chain = chain_id,
  class_grid = paste(class(fit_grid), collapse = "|"),
  child_m0_full_cmest = inherits(fit_grid$mval_results[["0"]], "cmest"),
  child_m1_full_cmest = inherits(fit_grid$mval_results[["1"]], "cmest"),
  n_effect_m0 = length(fit_grid$mval_results[["0"]]$effect.pe),
  n_effect_m1 = length(fit_grid$mval_results[["1"]]$effect.pe),
  delta_point = as.numeric(delta$effect.pe[[1]]),
  cde_m1_minus_m0 = cde1 - cde0,
  delta_point_equal = isTRUE(all.equal(as.numeric(delta$effect.pe[[1]]), cde1 - cde0, tolerance = 1e-10)),
  bootstrap_hash_m0 = hash_m0,
  bootstrap_hash_m1 = hash_m1,
  bootstrap_hash_delta = hash_delta,
  bootstrap_hash_recomputed = hash_indices,
  bootstrap_hashes_nonempty = hashes_nonempty,
  paired_bootstrap_hash_equal = hashes_nonempty && identical(hash_m0, hash_m1) && identical(hash_m0, hash_delta) && identical(hash_m0, hash_indices),
  package_version = as.character(utils::packageVersion("CMAverse")),
  package_lib = find.package("CMAverse"),
  package_source_commit = package_commit,
  package_source_dirty = !is.na(package_status) && nzchar(package_status),
  identity_filter = "same_actor & same_partner & parent_identity_included",
  sampling_unit = "dyad-interval record",
  dependency_adjusted_inference = FALSE,
  nboot = nboot,
  elapsed_seconds = elapsed,
  stringsAsFactors = FALSE
)
utils::write.csv(validation, file.path(run_dir, "validation.csv"), row.names = FALSE, fileEncoding = "UTF-8")
if (!validation$delta_point_equal || !validation$paired_bootstrap_hash_equal || !validation$bootstrap_hashes_nonempty) {
  stop("Paired mval validation failed")
}

session_file <- file.path(run_dir, "sessionInfo.txt")
writeLines(capture.output(sessionInfo()), session_file)
artifact_paths <- list.files(run_dir, full.names = TRUE, recursive = FALSE)
artifact_paths <- artifact_paths[file.exists(artifact_paths) & !dir.exists(artifact_paths) & basename(artifact_paths) != "manifest.csv"]
artifact_manifest <- data.frame(
  chain = chain_id, mode = run_mode, path = artifact_paths,
  bytes = file.info(artifact_paths)$size,
  sha256 = vapply(artifact_paths, sha256_file, character(1)),
  stringsAsFactors = FALSE
)
utils::write.csv(artifact_manifest, file.path(run_dir, "manifest.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write_state("complete", "CMAverse paired mval run complete", list(
  rows = nrow(model_data), actors = length(unique(model_data$actor_pid)),
  elapsed_seconds = elapsed, result = full_path,
  execution_complete = TRUE,
  numerical_checks_passed = TRUE,
  dependency_adjusted_inference = FALSE,
  causal_interpretation_status = "pending_semantic_contract_and_time-order_assessment"
))
cat("CMA_CHAIN_COMPLETE chain=", chain_id, " n=", nrow(model_data), " nboot=", nboot, " elapsed_seconds=", round(elapsed, 2), "\n", sep = "")
