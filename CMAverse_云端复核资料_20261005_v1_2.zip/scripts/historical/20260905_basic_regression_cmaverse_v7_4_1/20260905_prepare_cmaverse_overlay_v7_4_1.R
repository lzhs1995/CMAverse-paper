options(stringsAsFactors = FALSE, scipen = 999, warn = 1)

root <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260905_basic_regression_cmaverse_v7_4_1"
old_path <- "/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/causal_mediation_18&20_20&22_bal.csv"
v6_path <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260904_basic_mechanism_v6/data/v6_provisional_dyad_intervals.rds"
out_path <- file.path(root, "data", "cmaverse_v7_4_1_corrected_overlay.rds")
audit_path <- file.path(root, "cma", "01_overlay_change_audit.csv")
manifest_path <- file.path(root, "cma", "02_overlay_manifest.csv")
parent_audit_path <- file.path(root, "cma", "03_parent_identity_audit.csv")
identity_summary_path <- file.path(root, "cma", "04_identity_summary.csv")

dir.create(dirname(out_path), recursive = TRUE, showWarnings = FALSE)
dir.create(dirname(audit_path), recursive = TRUE, showWarnings = FALSE)

old <- suppressMessages(readr::read_csv(
  old_path,
  na = c("", "9999", "9999.00"),
  col_types = readr::cols(.default = readr::col_double()),
  progress = FALSE,
  show_col_types = FALSE
))
v6 <- readRDS(v6_path)

stopifnot(nrow(old) == nrow(v6))
stopifnot(all(old$id == v6$stata_id_begin, na.rm = TRUE))
stopifnot(all(old$id == v6$stata_id_end, na.rm = TRUE))
stopifnot(!anyDuplicated(paste(v6$dyad_id, v6$period, sep = "::")))

legacy_names <- c(
  "aincc_2", "inc_3", "msat_c1_2", "msat_c2_2", "msat_c12_3",
  "msat_c21_3", "esup_2", "aincc_begin", "inc_begin",
  "msat_c1_begin", "msat_c2_begin", "msat_c12_begin",
  "msat_c21_begin", "esup_begin"
)
stopifnot(all(legacy_names %in% names(old)))
for (name in legacy_names) old[[paste0("legacy_", name)]] <- old[[name]]

# Only the audited focal variables and their matching baseline scales are
# overlaid. All original baseline/post-treatment covariates remain unchanged.
old$aincc_2 <- v6$x_abs
old$inc_3 <- v6$x_rel
old$msat_c1_2 <- ifelse(is.na(v6$dm_self_abs), NA_real_, as.numeric(v6$dm_self_abs > 0))
old$msat_c2_2 <- ifelse(is.na(v6$dm_spouse_abs), NA_real_, as.numeric(v6$dm_spouse_abs > 0))
old$msat_c12_3 <- v6$m_self_rel
old$msat_c21_3 <- v6$m_spouse_rel
old$esup_2 <- v6$y_growth

# Preserve the original script's units: income/support are measured in 10,000
# yuan before log(x + 1); satisfaction differences are raw 1-5 score gaps.
old$aincc_begin <- v6$actor_income_real_begin / 10000
old$inc_begin <- v6$share_begin
old$msat_c1_begin <- v6$self_sat_begin
old$msat_c2_begin <- v6$spouse_sat_begin
old$msat_c12_begin <- v6$self_sat_begin - v6$spouse_sat_begin
old$msat_c21_begin <- v6$spouse_sat_begin - v6$self_sat_begin
old$esup_begin <- v6$support_real_begin / 10000

# Chain-specific targets retain the v7 eligibility definitions. The all-person
# corrected msat_c1_2/msat_c2_2 columns above remain available when the original
# script uses the other spouse's satisfaction change as a post-treatment covariate.
old$x_abs_target <- v6$x_abs
old$x_rel_target <- v6$x_rel
old$m_self_abs_target <- v6$m_self_abs
old$m_spouse_abs_target <- v6$m_spouse_abs
old$m_self_rel_target <- v6$m_self_rel
old$m_spouse_rel_target <- v6$m_spouse_rel
old$y_target <- v6$y_growth

# Preserve the distinction between an observed event, eligibility for a
# positive transition, and the chain-specific target used by CMAverse.
old$x_abs_event_all <- v6$x_abs
old$x_rel_event_all <- ifelse(
  is.na(v6$self_income_status_begin) | is.na(v6$self_income_status_end),
  NA_real_, as.numeric(v6$self_income_status_begin == 0 & v6$self_income_status_end == 1)
)
old$m_self_abs_event_all <- ifelse(is.na(v6$dm_self_abs), NA_real_, as.numeric(v6$dm_self_abs > 0))
old$m_spouse_abs_event_all <- ifelse(is.na(v6$dm_spouse_abs), NA_real_, as.numeric(v6$dm_spouse_abs > 0))
old$m_self_rel_event_all <- ifelse(
  is.na(v6$self_rel_sat_status_begin) | is.na(v6$self_rel_sat_status_end),
  NA_real_, as.numeric(v6$self_rel_sat_status_begin == 0 & v6$self_rel_sat_status_end == 1)
)
old$m_spouse_rel_event_all <- ifelse(
  is.na(v6$spouse_rel_sat_status_begin) | is.na(v6$spouse_rel_sat_status_end),
  NA_real_, as.numeric(v6$spouse_rel_sat_status_begin == 0 & v6$spouse_rel_sat_status_end == 1)
)
old$y_event_all <- v6$y_growth
old$eligible_x_abs <- !is.na(v6$x_abs)
old$eligible_x_rel <- v6$eligible_x_rel
old$eligible_m_self_abs <- v6$eligible_m_self_abs
old$eligible_m_spouse_abs <- v6$eligible_m_spouse_abs
old$eligible_m_self_rel <- v6$eligible_m_self_rel
old$eligible_m_spouse_rel <- v6$eligible_m_spouse_rel

old$dyad_id <- v6$dyad_id
old$stable_row_id <- sprintf("%05d|%s|%s", seq_len(nrow(v6)), v6$dyad_id, v6$period)
old$actor_pid <- v6$actor_pid_begin
old$actor_pid_begin <- v6$actor_pid_begin
old$actor_pid_end <- v6$actor_pid_end
old$partner_pid_begin <- v6$partner_pid_begin
old$partner_pid_end <- v6$partner_pid_end
old$parent_pid <- v6$parent_pid_begin
old$parent_pid_begin <- v6$parent_pid_begin
old$parent_pid_end <- v6$parent_pid_end
old$parent_role <- v6$parent_role
old$same_actor <- v6$same_actor
old$same_partner <- v6$same_partner
old$same_parent_legacy <- v6$same_parent
old$period_label <- v6$period

is_valid_pid <- function(x) {
  numeric_x <- suppressWarnings(as.numeric(as.character(x)))
  !is.na(x) & nzchar(as.character(x)) & is.finite(numeric_x) & numeric_x > 0
}
parent_begin_valid <- is_valid_pid(old$parent_pid_begin)
parent_end_valid <- is_valid_pid(old$parent_pid_end)
old$parent_identity_status <- ifelse(
  parent_begin_valid & parent_end_valid & old$parent_pid_begin == old$parent_pid_end,
  "pid_confirmed",
  ifelse(
    parent_begin_valid & parent_end_valid & old$parent_pid_begin != old$parent_pid_end,
    "pid_conflict",
    ifelse(
      xor(parent_begin_valid, parent_end_valid),
      "one_end_unresolved",
      ifelse(!is.na(old$dyad_id) & !is.na(old$parent_role), "role_link_assumed", "unresolved")
    )
  )
)
old$parent_identity_included <- old$parent_identity_status %in% c("pid_confirmed", "role_link_assumed")
old$same_parent <- old$parent_identity_included

binary_targets <- c(
  "x_abs_target", "x_rel_target", "m_self_abs_target",
  "m_spouse_abs_target", "m_self_rel_target", "m_spouse_rel_target",
  "y_target"
)
for (name in binary_targets) {
  stopifnot(all(old[[name]] %in% c(0, 1, NA)))
}
stopifnot(all(old$same_partner == (old$partner_pid_begin == old$partner_pid_end), na.rm = TRUE))
stopifnot(all(old$same_actor == (old$actor_pid_begin == old$actor_pid_end), na.rm = TRUE))
stopifnot(!anyDuplicated(old$stable_row_id))
stopifnot(!anyNA(old$parent_identity_status))
stopifnot(all(old$parent_identity_included == old$same_parent))

parent_audit <- old[, c(
  "stable_row_id", "dyad_id", "period_label", "actor_pid_begin", "actor_pid_end",
  "parent_pid_begin", "parent_pid_end", "parent_role", "same_actor", "same_partner",
  "same_parent_legacy", "parent_identity_status", "parent_identity_included"
)]
parent_audit$evidence_source <- ifelse(
  parent_audit$parent_identity_status == "pid_confirmed",
  "valid parent PID equality",
  ifelse(
    parent_audit$parent_identity_status == "role_link_assumed",
    "stable dyad-role design; parent PID unavailable",
    "endpoint parent PID evidence insufficient or conflicting"
  )
)
parent_audit$exclusion_reason <- ifelse(
  parent_audit$parent_identity_included,
  "",
  ifelse(parent_audit$parent_identity_status == "pid_conflict", "valid parent PID changed", "one endpoint parent PID unresolved")
)
utils::write.csv(parent_audit, parent_audit_path, row.names = FALSE, fileEncoding = "UTF-8")

identity_summary <- as.data.frame(table(old$parent_identity_status), stringsAsFactors = FALSE)
names(identity_summary) <- c("parent_identity_status", "records")
identity_summary$included <- identity_summary$parent_identity_status %in% c("pid_confirmed", "role_link_assumed")
utils::write.csv(identity_summary, identity_summary_path, row.names = FALSE, fileEncoding = "UTF-8")

diff_count <- function(before, after) {
  both <- !is.na(before) & !is.na(after)
  sum(xor(is.na(before), is.na(after))) + sum(before[both] != after[both])
}

audit_map <- c(
  aincc_2 = "aincc_2", inc_3 = "inc_3", msat_c1_2 = "msat_c1_2",
  msat_c2_2 = "msat_c2_2", msat_c12_3 = "msat_c12_3",
  msat_c21_3 = "msat_c21_3", esup_2 = "esup_2",
  aincc_begin = "aincc_begin", inc_begin = "inc_begin",
  msat_c1_begin = "msat_c1_begin", msat_c2_begin = "msat_c2_begin",
  msat_c12_begin = "msat_c12_begin", msat_c21_begin = "msat_c21_begin",
  esup_begin = "esup_begin"
)
audit <- do.call(rbind, lapply(names(audit_map), function(name) {
  before <- old[[paste0("legacy_", name)]]
  after <- old[[audit_map[[name]]]]
  data.frame(
    variable = name,
    n = length(after),
    legacy_missing = sum(is.na(before)),
    corrected_missing = sum(is.na(after)),
    changed_or_missingness_changed = diff_count(before, after),
    stringsAsFactors = FALSE
  )
}))

saveRDS(old, out_path, compress = FALSE)
utils::write.csv(audit, audit_path, row.names = FALSE, fileEncoding = "UTF-8")

sha256 <- function(path) {
  if (!requireNamespace("digest", quietly = TRUE)) return(NA_character_)
  digest::digest(file = path, algo = "sha256", serialize = FALSE)
}
manifest <- data.frame(
  role = c("legacy_201_column_input", "v6_corrected_interval_input", "v7_4_1_overlay"),
  path = c(old_path, v6_path, out_path),
  bytes = file.info(c(old_path, v6_path, out_path))$size,
  sha256 = vapply(c(old_path, v6_path, out_path), sha256, character(1)),
  rows = c(nrow(old), nrow(v6), nrow(old)),
  columns = c(length(setdiff(names(old), grep("^legacy_|_target$|^dyad_id$|^actor_pid$|^partner_pid_|^parent_pid$|^same_partner$|^period_label$", names(old), value = TRUE))), ncol(v6), ncol(old)),
  stringsAsFactors = FALSE
)
utils::write.csv(manifest, manifest_path, row.names = FALSE, fileEncoding = "UTF-8")

cat("OVERLAY_V7_4_1_READY\n")
cat("rows=", nrow(old), " columns=", ncol(old), " same_partner=", sum(old$same_partner %in% TRUE), "\n", sep = "")
cat("same_actor_parent_partner=", sum(old$same_actor %in% TRUE & old$same_parent %in% TRUE & old$same_partner %in% TRUE), "\n", sep = "")
cat("output=", out_path, "\n", sep = "")
