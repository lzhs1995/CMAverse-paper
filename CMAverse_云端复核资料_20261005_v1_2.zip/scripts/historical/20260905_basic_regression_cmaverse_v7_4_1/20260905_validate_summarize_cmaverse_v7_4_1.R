options(stringsAsFactors = FALSE, scipen = 999, warn = 1)

root <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260905_basic_regression_cmaverse_v7_4_1"
formal_root <- file.path(root, "cma", "formal")
summary_root <- file.path(root, "cma", "summary")
contract_root <- file.path(root, "cma", "contracts")
dir.create(summary_root, recursive = TRUE, showWarnings = FALSE)

chains <- c("AA-S", "AA-P", "AR-S", "AR-P", "RA-S", "RA-P", "RR-S", "RR-P")
policy_chains <- c("AA-S", "AA-P", "RA-S", "RA-P")

required_files <- c(
  "state.json", "analysis_row_ids.csv", "sample_flow.csv", "sample_audit.csv",
  "x_m_y_cells.csv", "centering_constants.csv", "variable_role_manifest.csv",
  "formula_manifest.csv", "model_preflight.csv", "gaussian_postc_support.csv",
  "effects_full.csv", "delta_cde.csv", "bootstrap_pvalue_metadata.csv",
  "core_bootstrap_validity.csv", "bootstrap_indices.rds",
  "bootstrap_effect_point_raw.rds", "bootstrap_effect_draws_raw.rds",
  "bootstrap_rng_state.rds", "package_provenance.csv", "validation.csv",
  "manifest.csv", "sessionInfo.txt"
)

read_one <- function(chain, name) {
  path <- file.path(formal_root, chain, name)
  if (!file.exists(path)) stop("Missing ", chain, "/", name)
  utils::read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
}

sign_tail_p <- function(draws) {
  draws <- draws[is.finite(draws)]
  if (!length(draws)) return(NA_real_)
  2 * min(sum(draws > 0), sum(draws < 0)) / length(draws)
}

summarize_draws <- function(chain, effect, estimate, draws, scale, semantic_status) {
  finite <- is.finite(draws)
  z <- draws[finite]
  data.frame(
    chain = chain, mval = 0, effect = effect, estimate = estimate,
    se = if (length(z) > 1) stats::sd(z) else NA_real_,
    conf_low = if (length(z)) unname(stats::quantile(z, 0.025, names = FALSE, type = 6)) else NA_real_,
    conf_high = if (length(z)) unname(stats::quantile(z, 0.975, names = FALSE, type = 6)) else NA_real_,
    p_value = sign_tail_p(z), B_attempted = length(draws), B_effective = length(z),
    scale = scale, semantic_status = semantic_status, stringsAsFactors = FALSE
  )
}

required_file_checks <- do.call(rbind, lapply(chains, function(chain) {
  chain_required <- c(required_files, if (chain %in% policy_chains) {
    c("policy_summary.csv", "policy_bootstrap_draws.rds", "policy_bootstrap_status.csv", "policy_support_diagnostic.csv")
  } else character(0))
  paths <- file.path(formal_root, chain, chain_required)
  data.frame(chain = chain, file = chain_required, exists = file.exists(paths),
             nonempty = file.exists(paths) & file.info(paths)$size > 0, stringsAsFactors = FALSE)
}))
if (!all(required_file_checks$exists & required_file_checks$nonempty)) {
  bad <- required_file_checks[!(required_file_checks$exists & required_file_checks$nonempty), ]
  stop("Missing or empty formal outputs: ", paste(paste0(bad$chain, "/", bad$file), collapse = ", "))
}

states <- do.call(rbind, lapply(chains, function(chain) {
  x <- jsonlite::fromJSON(file.path(formal_root, chain, "state.json"), simplifyVector = TRUE)
  data.frame(
    chain = chain, recorded_chain = x$chain, mode = x$mode, status = x$status,
    nboot = x$nboot, seed = x$seed, rows = x$rows, actors = x$actors,
    elapsed_seconds = x$elapsed_seconds, result = x$result,
    result_exists = file.exists(x$result), execution_complete = isTRUE(x$execution_complete),
    numerical_checks_passed = isTRUE(x$numerical_checks_passed),
    dependency_adjusted_inference = isTRUE(x$dependency_adjusted_inference),
    stringsAsFactors = FALSE
  )
}))

validations <- do.call(rbind, lapply(chains, read_one, name = "validation.csv"))
samples <- do.call(rbind, lapply(chains, read_one, name = "sample_audit.csv"))
sample_flow <- do.call(rbind, lapply(chains, read_one, name = "sample_flow.csv"))
preflight <- do.call(rbind, lapply(chains, read_one, name = "model_preflight.csv"))
effects <- do.call(rbind, lapply(chains, read_one, name = "effects_full.csv"))
deltas <- do.call(rbind, lapply(chains, read_one, name = "delta_cde.csv"))
p_metadata <- do.call(rbind, lapply(chains, read_one, name = "bootstrap_pvalue_metadata.csv"))
core_validity <- do.call(rbind, lapply(chains, read_one, name = "core_bootstrap_validity.csv"))
gaussian_support <- do.call(rbind, lapply(chains, read_one, name = "gaussian_postc_support.csv"))
roles <- do.call(rbind, lapply(chains, read_one, name = "variable_role_manifest.csv"))
formulas <- do.call(rbind, lapply(chains, read_one, name = "formula_manifest.csv"))
provenance <- do.call(rbind, lapply(chains, function(chain) {
  x <- read_one(chain, "package_provenance.csv")
  x$chain <- chain
  x
}))
cells <- do.call(rbind, lapply(chains, function(chain) {
  x <- read_one(chain, "x_m_y_cells.csv")
  x$chain <- chain
  x
}))

semantic_contract <- utils::read.csv(file.path(contract_root, "synthetic_semantic_contract.csv"),
                                     check.names = FALSE, stringsAsFactors = FALSE)
semantic_component <- aggregate(pass ~ effect, semantic_contract, all)
semantic_component$status <- ifelse(semantic_component$pass, "passed", "blocked")

object_checks <- list()
derived <- list()
evalue_status <- list()
for (chain in chains) {
  object_path <- file.path(formal_root, chain, paste0("cmest_grid_", chain, "_nboot1000.rds"))
  x <- readRDS(object_path)
  raw_draws <- readRDS(file.path(formal_root, chain, "bootstrap_effect_draws_raw.rds"))
  fx <- read_one(chain, "effects_full.csv")
  if (nrow(fx) != ncol(raw_draws)) stop("Effect/draw column mismatch for ", chain)

  for (mval in c("0", "1")) {
    child <- x$mval_results[[mval]]
    lhs <- unname(child$effect.pe[["Rte"]]) - 1
    rhs <- sum(unname(child$effect.pe[c("ERcde", "rERintref", "rERintmed", "rERpnie")]))
    object_checks[[length(object_checks) + 1L]] <- data.frame(
      chain = chain, mval = mval, full_grid = inherits(x, "cmest_mval_grid"),
      full_child = inherits(child, "cmest"), effect_count = length(child$effect.pe),
      child_hash = child$bootstrap_provenance$hash, delta_hash = x$delta_cde$bootstrap_provenance$hash,
      same_bootstrap_hash = identical(child$bootstrap_provenance$hash, x$delta_cde$bootstrap_provenance$hash),
      paired_children_hash_equal = identical(x$mval_results[["0"]]$bootstrap_provenance$hash,
                                              x$mval_results[["1"]]$bootstrap_provenance$hash),
      nboot = child$bootstrap_provenance$nboot, decomposition_residual = lhs - rhs,
      decomposition_identity = isTRUE(all.equal(lhs, rhs, tolerance = 1e-10)), stringsAsFactors = FALSE
    )
  }

  m0 <- fx$mval == 0
  idx_intref <- which(m0 & fx$effect == "rERintref")
  idx_intmed <- which(m0 & fx$effect == "rERintmed")
  idx_pnie <- which(m0 & fx$effect == "rERpnie")
  if (length(idx_intref) != 1L || length(idx_intmed) != 1L || length(idx_pnie) != 1L) {
    stop("Cannot identify unique decomposition columns for ", chain)
  }
  tie_draws <- raw_draws[, idx_intmed] + raw_draws[, idx_pnie]
  ia_draws <- raw_draws[, idx_intref] + raw_draws[, idx_intmed]
  tie_point <- fx$estimate[idx_intmed] + fx$estimate[idx_pnie]
  ia_point <- fx$estimate[idx_intref] + fx$estimate[idx_intmed]
  derived[[length(derived) + 1L]] <- summarize_draws(
    chain, "ERTIE", tie_point, tie_draws, "native excess sum",
    "limited: rERintmed and rERpnie passed zero-mechanism test"
  )
  derived[[length(derived) + 1L]] <- summarize_draws(
    chain, "ERIA", ia_point, ia_draws, "native excess sum",
    "blocked: includes rERintref, which failed zero-mechanism test"
  )

  evalue_status[[length(evalue_status) + 1L]] <- data.frame(
    chain = chain, mval = 0, cmsens_path_available = TRUE, computed = FALSE,
    value = NA_real_,
    reason = paste("CMAverse cmsens(sens='uc') delegates to EValue::evalues.RR,",
                   "whereas the locked logistic branch returns standardized marginal odds ratios;",
                   "the plan prohibits treating those ORs as RRs."), stringsAsFactors = FALSE
  )
}
object_checks <- do.call(rbind, object_checks)
derived <- do.call(rbind, derived)
evalue_status <- do.call(rbind, evalue_status)

policy <- do.call(rbind, lapply(policy_chains, read_one, name = "policy_summary.csv"))
policy_status <- do.call(rbind, lapply(policy_chains, read_one, name = "policy_bootstrap_status.csv"))
contract_summary <- utils::read.csv(file.path(contract_root, "contract_summary.csv"), stringsAsFactors = FALSE)

checks <- data.frame(
  check = c(
    "eight_chains_present", "nboot_1000", "full_grid_objects", "full_child_objects",
    "paired_bootstrap_hash", "delta_point_identity", "decomposition_identity",
    "all_models_converged", "no_aliases", "all_xmy_cells_positive",
    "all_core_bootstrap_draws_finite", "binary_targets", "package_provenance_recorded",
    "required_files_nonempty", "states_complete", "default_row_bootstrap_declared",
    "paired_compatibility_contract", "semantic_contract_component_status_recorded",
    "policy_identity_passed"
  ),
  pass = c(
    identical(sort(unique(validations$chain)), sort(chains)),
    all(validations$nboot == 1000) && all(object_checks$nboot == 1000),
    all(object_checks$full_grid), all(object_checks$full_child),
    all(validations$paired_bootstrap_hash_equal) && all(object_checks$same_bootstrap_hash) &&
      all(object_checks$paired_children_hash_equal),
    all(validations$delta_point_equal), all(object_checks$decomposition_identity),
    all(preflight$mreg_converged) && all(preflight$yreg_converged) && all(preflight$postcreg_all_converged),
    !any(preflight$any_alias), all(cells$Freq > 0), all(core_validity$all_effects_finite),
    all(samples$x_rate >= 0 & samples$x_rate <= 1 & samples$m_rate >= 0 & samples$m_rate <= 1 &
          samples$y_rate >= 0 & samples$y_rate <= 1),
    all(!is.na(provenance$source_commit) & nzchar(provenance$source_commit) &
          !is.na(provenance$source_sha256) & nzchar(provenance$source_sha256)),
    all(required_file_checks$exists & required_file_checks$nonempty),
    identical(states$recorded_chain, states$chain) && all(states$mode == "formal") &&
      all(states$status == "complete") && all(states$nboot == 1000) &&
      all(states$result_exists) && all(states$execution_complete) && all(states$numerical_checks_passed),
    !any(states$dependency_adjusted_inference),
    isTRUE(contract_summary$pass[contract_summary$contract == "paired_compatibility"]),
    all(semantic_component$status %in% c("passed", "blocked")),
    all(abs(policy$identity_residual) < 1e-10) && all(policy_status$success)
  ), stringsAsFactors = FALSE
)

effect_status <- merge(effects, semantic_component[, c("effect", "status")],
                       by = "effect", all.x = TRUE, sort = FALSE)
effect_status$display_scale <- ifelse(
  effect_status$effect %in% c("Rcde", "rRpnde", "rRtnde", "rRpnie", "rRtnie", "Rte"),
  "standardized marginal odds ratio (locked logistic branch)",
  "CMAverse native excess/proportion output"
)
effect_status$semantic_status <- ifelse(
  effect_status$effect == "rERintref", "blocked: failed zero-mechanism test",
  ifelse(effect_status$effect %in% c("rERintmed", "rERpnie"),
         "limited: passed zero-mechanism test; causal interpretation remains time-order dependent",
         ifelse(effect_status$effect %in% c("rint", "rpe", "rERintref(prop)"),
                "blocked: depends on rERintref", "not separately tested"))
)

table32_base <- effect_status[effect_status$mval == 0 & effect_status$effect %in% c(
  "Rte", "Rcde", "ERcde", "rERintref", "rERintmed", "rERpnie"
), c("chain", "mval", "effect", "estimate", "se", "conf_low", "conf_high", "p_value", "display_scale", "semantic_status")]
table32_derived <- derived[, c("chain", "mval", "effect", "estimate", "se", "conf_low", "conf_high", "p_value", "scale", "semantic_status")]
names(table32_derived)[names(table32_derived) == "scale"] <- "display_scale"
table32 <- rbind(table32_base, table32_derived)
table32 <- table32[order(match(table32$chain, chains), match(
  table32$effect, c("Rte", "Rcde", "ERcde", "rERintref", "rERintmed", "rERpnie", "ERTIE", "ERIA")
)), ]

table33 <- effect_status[effect_status$effect %in% c("Rcde", "rpe"),
  c("chain", "mval", "effect", "estimate", "se", "conf_low", "conf_high", "p_value", "display_scale", "semantic_status")]
delta_for_table <- deltas
delta_for_table$mval <- NA_integer_
delta_for_table$display_scale <- "difference between two standardized marginal controlled direct odds ratios"
delta_for_table$semantic_status <- "computationally paired; causal interpretation remains time-order dependent"
table33 <- rbind(table33, delta_for_table[, names(table33)])
table33$semantic_status[table33$effect == "rpe"] <- "blocked: PE depends on rERintref, which failed zero-mechanism test"
table33 <- table33[order(match(table33$chain, chains), match(table33$effect, c("Rcde", "Delta_Rcde", "rpe")), table33$mval), ]

table34 <- policy
table34$interpretation <- ifelse(
  table34$metric %in% c("RD_policy", "RR_policy"),
  "conditional hypothetical mediator-improvement scenario; extra M-Y time-order and proxy assumptions required",
  "standardized probability component"
)

add_family <- function(family, data, p_col = "p_value") {
  z <- data.frame(family = family, chain = data$chain, effect = data$effect,
                  p_native = data[[p_col]], stringsAsFactors = FALSE)
  z$q_bh <- stats::p.adjust(z$p_native, method = "BH")
  z
}
fdr_rows <- list()
fdr_rows[[1]] <- add_family("eight_chain_total_effect", effect_status[effect_status$mval == 0 & effect_status$effect == "Rte", ])
fdr_rows[[2]] <- add_family("eight_chain_total_mediation", derived[derived$effect == "ERTIE", ])
fdr_rows[[3]] <- add_family("eight_chain_total_interaction_blocked", derived[derived$effect == "ERIA", ])
fdr_rows[[4]] <- add_family("eight_chain_delta_Rcde", deltas)
policy_rd <- policy[policy$metric == "RD_policy", ]
policy_rd$effect <- "RD_policy"
fdr_rows[[5]] <- add_family("four_chain_policy_RD", policy_rd)
fdr <- do.call(rbind, fdr_rows)
fdr$p_note <- ifelse(fdr$p_native == 0,
  "No opposite-tail draw among effective bootstrap repeats; below current simulation resolution.",
  "CMAverse/sign-tail bootstrap p-value.")
fdr$interpretation_status <- ifelse(
  fdr$family == "eight_chain_total_interaction_blocked",
  "blocked by rERintref semantic contract failure", "eligible for limited interpretation"
)

outputs <- list(
  formal_validation_all_chains = validations,
  formal_sample_audit_all_chains = samples,
  formal_sample_flow_all_chains = sample_flow,
  formal_model_preflight_all_chains = preflight,
  formal_effects_all_chains_long = effect_status,
  formal_delta_cde_all_chains = deltas,
  formal_derived_TIE_IA = derived,
  formal_bootstrap_pvalue_metadata = p_metadata,
  formal_core_bootstrap_validity = core_validity,
  formal_gaussian_postc_support = gaussian_support,
  formal_variable_role_manifest = roles,
  formal_formula_manifest_all_chains = formulas,
  formal_package_provenance = provenance,
  formal_xmy_cells_all_chains = cells,
  formal_object_and_identity_checks = object_checks,
  formal_required_file_checks = required_file_checks,
  formal_state_manifest = states,
  formal_completion_checks = checks,
  synthetic_semantic_component_status = semantic_component,
  evalue_applicability_status = evalue_status,
  bh_fdr_families = fdr,
  table3_2_four_way_results_m0 = table32,
  table3_3_cde_m0_m1_pe = table33,
  table3_4_policy_probability_scenarios = table34,
  policy_bootstrap_status = policy_status
)
for (nm in names(outputs)) {
  utils::write.csv(outputs[[nm]], file.path(summary_root, paste0(nm, ".csv")),
                   row.names = FALSE, fileEncoding = "UTF-8")
}

analysis_files <- unique(c(
  list.files(file.path(root, "cma"), recursive = TRUE, full.names = TRUE),
  list.files(file.path(root, "data"), recursive = TRUE, full.names = TRUE),
  list.files(file.path(root, "scripts"), pattern = "\\.R$", recursive = TRUE, full.names = TRUE)
))
analysis_files <- analysis_files[file.exists(analysis_files) & !dir.exists(analysis_files)]
analysis_files <- analysis_files[basename(analysis_files) != "formal_file_hash_manifest.csv"]
sha256 <- function(path) digest::digest(file = path, algo = "sha256", serialize = FALSE)
hash_manifest <- data.frame(path = analysis_files, bytes = file.info(analysis_files)$size,
                            sha256 = vapply(analysis_files, sha256, character(1)), stringsAsFactors = FALSE)
utils::write.csv(hash_manifest, file.path(summary_root, "formal_file_hash_manifest.csv"),
                 row.names = FALSE, fileEncoding = "UTF-8")

manifest <- list(
  analysis_id = "CMAverse_inherited_v7.4.1",
  created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  data = list(
    overlay = file.path(root, "data", "cmaverse_v7_4_1_corrected_overlay.rds"),
    overlay_sha256 = sha256(file.path(root, "data", "cmaverse_v7_4_1_corrected_overlay.rds")),
    unit = "parent-child dyad-interval",
    identity_filter = "same_actor & same_partner & parent identity in {pid_confirmed, role_link_assumed}"
  ),
  model = list(
    chains = chains, nboot = 1000, bootstrap_unit = "row/record (CMAverse default)",
    dependency_adjusted_inference = FALSE,
    cma_scale = "standardized marginal OR for Rte/Rcde under locked logistic branch",
    basic_regression_scale = "separately standardized RR"
  ),
  contracts = list(
    paired_mval = "passed",
    rERintref = "blocked: synthetic zero-mechanism test failed",
    rERintmed = "passed synthetic zero-mechanism test; limited causal interpretation",
    rERpnie = "passed synthetic zero-mechanism test; limited causal interpretation",
    time_order = "limited: M measured at interview, Y refers to prior six months"
  ),
  tables = list(
    table_3_2 = file.path(summary_root, "table3_2_four_way_results_m0.csv"),
    table_3_3 = file.path(summary_root, "table3_3_cde_m0_m1_pe.csv"),
    table_3_4 = file.path(summary_root, "table3_4_policy_probability_scenarios.csv")
  ),
  scripts = list(
    overlay = file.path(root, "scripts", "20260905_prepare_cmaverse_overlay_v7_4_1.R"),
    adapter = file.path(root, "scripts", "20260905_cmaverse_eight_chain_adapter_v7_4_1.R"),
    summary = file.path(root, "scripts", "20260905_validate_summarize_cmaverse_v7_4_1.R")
  )
)
jsonlite::write_json(manifest, file.path(summary_root, "analysis_manifest.json"), auto_unbox = TRUE, pretty = TRUE)

if (!all(checks$pass)) {
  stop("Formal CMAverse validation failed: ", paste(checks$check[!checks$pass], collapse = ", "))
}
cat("CMA_FORMAL_VALIDATION_PASS checks=", nrow(checks), " chains=", length(chains), "\n", sep = "")
