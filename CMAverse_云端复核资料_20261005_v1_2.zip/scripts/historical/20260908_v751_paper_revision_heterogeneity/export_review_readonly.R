# Read saved data and results only. No model fitting, RNG draws or source updates.
root <- '/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260908_v751_paper_revision_heterogeneity'
out <- file.path(root, 'review_export_20260908')
dir.create(out, recursive=TRUE, showWarnings=FALSE)
stopifnot(requireNamespace('digest', quietly=TRUE), requireNamespace('jsonlite', quietly=TRUE))
sha <- function(p) digest::digest(file=p, algo='sha256', serialize=FALSE)
manifest <- list(); dictionaries <- list(); checks <- list()
emit <- function(x, relative, source, role, roundtrip=FALSE) {
  p <- file.path(out, relative); dir.create(dirname(p), recursive=TRUE, showWarnings=FALSE)
  stopifnot(!file.exists(p), is.data.frame(x), all(vapply(x,is.atomic,logical(1))))
  write.csv(x,p,row.names=FALSE,na='NA',fileEncoding='UTF-8')
  if(roundtrip) {
    z <- read.csv(p, check.names=FALSE, stringsAsFactors=FALSE, colClasses='character', na.strings='NA')
    stopifnot(identical(dim(z),dim(x)),identical(names(z),names(x)))
    ok <- vapply(names(x),function(n) {
      a<-x[[n]]; b<-z[[n]]
      if(is.numeric(a) && !is.factor(a)) isTRUE(all.equal(as.numeric(a),as.numeric(b),tolerance=1e-12,check.attributes=FALSE))
      else identical(as.character(a),b)
    },logical(1))
    stopifnot(all(ok)); checks[[relative]] <<- data.frame(file=relative,columns=ncol(x),rows=nrow(x),csv_roundtrip=TRUE)
  }
  manifest[[relative]] <<- data.frame(file=relative,role=role,rows=nrow(x),columns=ncol(x),source=source,source_sha256=sha(source),sha256=sha(p))
}
dictionary <- function(x,key) {
  for(n in names(x)) {
    a<-x[[n]]; lab<-attr(a,'label'); vals<-attr(a,'labels')
    dictionaries[[paste(key,n)]] <<- data.frame(dataset=key,variable=n,storage=paste(class(a),collapse=';'),
      label=if(is.null(lab))'' else as.character(lab),missing=sum(is.na(a)),
      factor_levels=as.character(jsonlite::toJSON(levels(a),auto_unbox=FALSE)),
      value_labels=as.character(jsonlite::toJSON(as.list(vals),auto_unbox=TRUE)))
  }
}
message('READONLY_EXPORT_START')
src<-file.path(root,'data/identity_target_readonly_copy.rds'); d<-readRDS(src)
stopifnot(nrow(d)==13092L,!anyDuplicated(d$stable_row_id))
emit(as.data.frame(d),'data/identity_target_13092.csv',src,'approved identity target, all saved columns',TRUE)
dictionary(d,'identity_target_13092')
plan_path<-file.path(root,'data/shared_cluster_plan.rds'); plan<-readRDS(plan_path)
emit(data.frame(replicate=seq_len(nrow(plan$draws)),plan$draws,check.names=FALSE),
     'sampling/shared_cluster_draws.csv',plan_path,'shared component draw order')
emit(data.frame(replicate=seq_along(plan$seeds),seed=plan$seeds),'sampling/repeat_seeds.csv',plan_path,'saved RNG seeds')
rm(d,plan);gc()
pre_path<-file.path(root,'data/prepared_group_arguments.rds'); prepared<-readRDS(pre_path)
stopifnot(length(prepared)==48L)
map<-read.csv(file.path(root,'qa/heterogeneity_bootstrap_column_map.csv'))
for(key in names(prepared)) {
  input<-as.data.frame(prepared[[key]]$args$data)
  emit(input,paste0('data/groups/',key,'.csv'),pre_path,'exact prepared subgroup analysis data',TRUE)
  dictionary(input,key)
  p<-file.path(root,'heterogeneity/formal',key,'cmest_paired_full.rds')
  before<-sha(p); f<-readRDS(p)
  stopifnot(isTRUE(all.equal(as.data.frame(f$data),input,check.attributes=FALSE)))
  b<-f$mval_grid$bootstrap_t
  stopifnot(identical(dim(b),c(1000L,34L)),identical(names(f$mval_results[['0']]$effect.pe),map$effect[1:17]))
  colnames(b)<-paste0('m',map$mval,'__',map$effect)
  emit(data.frame(replicate=seq_len(nrow(b)),b,check.names=FALSE),paste0('draws/',key,'__stored_scale.csv'),p,
       '1000 raw stored-scale repeats, no filtering; first six fields per mval are log OR')
  stopifnot(sha(p)==before)
  rm(f,b,input);gc(FALSE)
  message('EXPORTED ',key)
}
rm(prepared);gc()
for(p in list.files(file.path(root,'results'),pattern='paired_draws.rds$',full.names=TRUE)) {
  emit(readRDS(p),paste0('direct_difference_draws/',sub('rds$','csv',basename(p))),p,'saved direct paired differences; valid flag retained')
}
old<-file.path(dirname(root),'20260905_basic_regression_cmaverse_v7_4_1')
for(ch in c('AA-S','AA-P','AR-S','AR-P','RA-S','RA-P','RR-S','RR-P')) {
  p<-file.path(old,'cma/formal',ch,paste0('cmest_grid_',ch,'_nboot1000.rds'))
  f<-readRDS(p);input<-as.data.frame(f$data)
  emit(input,paste0('data/overall/',ch,'.csv'),p,'frozen v7.4.1 overall analysis data',TRUE);dictionary(input,paste0('overall_',ch))
  b<-f$mval_grid$bootstrap_t;stopifnot(ncol(b)==34L);colnames(b)<-paste0('m',map$mval,'__',map$effect)
  emit(data.frame(replicate=seq_len(nrow(b)),b,check.names=FALSE),paste0('overall_draws/',ch,'__stored_scale.csv'),p,'frozen overall repeats; not new estimates')
  rm(f,input,b);gc(FALSE)
}
write.csv(do.call(rbind,dictionaries),file.path(out,'data_dictionary.csv'),row.names=FALSE,fileEncoding='UTF-8')
write.csv(do.call(rbind,checks),file.path(out,'csv_roundtrip_checks.csv'),row.names=FALSE,fileEncoding='UTF-8')
write.csv(do.call(rbind,manifest),file.path(out,'export_manifest.csv'),row.names=FALSE,fileEncoding='UTF-8')
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo_export.txt'))
jsonlite::write_json(list(status='complete',model_refits=0,new_bootstrap_draws=0,identity_rows=13092,
  subgroup_files=48,overall_files=8,CSV_roundtrip_checks=length(checks),all_pass=TRUE),
  file.path(out,'export_status.json'),pretty=TRUE,auto_unbox=TRUE)
message('READONLY_REVIEW_EXPORT_COMPLETE')
