options(stringsAsFactors=FALSE,warn=1)
root <- '/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260908_v751_paper_revision_heterogeneity'
lib <- '/Users/lzhs/Library/Caches/org.R-project.R/R/renv/library/CMAverse-mval-grid-v741/macos/R-4.6/aarch64-apple-darwin23'
.libPaths(c(lib,.libPaths()))
suppressPackageStartupMessages(library(CMAverse))
source(file.path(root,'scripts/shared_bootstrap.R'),local=TRUE)
mode <- Sys.getenv('V751_MODE','smoke')
mediator_id <- Sys.getenv('V751_MEDIATOR','all')
B <- if(mode=='formal')1000L else 10L
if(mode=='formal' && Sys.getenv('V751_ARM_FORMAL')!='true')stop('Formal worker not armed')
out <- file.path(root,'heterogeneity',mode)
dir.create(out,recursive=TRUE,showWarnings=FALSE)
atomic_json <- function(x,p) {jsonlite::write_json(x,paste0(p,'.tmp'),auto_unbox=TRUE,pretty=TRUE,null='null');stopifnot(file.rename(paste0(p,'.tmp'),p))}
state_path <- file.path(out,paste0('state_',mediator_id,'.json'))
state <- function(stage,status='running',extra=list()) {
 atomic_json(c(list(stage=stage,status=status,updated_at=format(Sys.time(),'%FT%T%z'),pid=Sys.getpid(),worker=mediator_id,nboot=B),extra),state_path)
 cat(mediator_id,stage,status,'\n');flush.console()
}
state('read_inputs')
prepared <- readRDS(file.path(root,'data/prepared_group_arguments.rds'))
keys <- names(prepared)
if(mediator_id!='all') {
 chain_prefix <- switch(mediator_id,abs_self=c('AA-S','RA-S'),abs_spouse=c('AA-P','RA-P'),rel_self=c('AR-S','RR-S'),rel_spouse=c('AR-P','RR-P'),stop('unknown mediator'))
 keys<-keys[sub('__.*','',keys)%in%chain_prefix]
}
prepared<-prepared[keys]
plan<-readRDS(file.path(root,'data/shared_cluster_plan.rds'))
stopifnot(nrow(plan$draws)==1000L)
pkg_hash<-vapply(c('cmest','estinf','est.gformula'),function(n)digest::digest(body(get(n,asNamespace('CMAverse'))),algo='sha256'),'')
manifest<-list();validation<-list()
for(key in keys) {
 z<-prepared[[key]];args<-z$args;args$nboot<-B
 # Make saved GLM calls independently replayable; no fit/formula is changed.
 literal_family<-function(f) {
  f$call$family<-if(f$family$family=='binomial')bquote(stats::binomial(link=.(f$family$link))) else bquote(stats::gaussian(link=.(f$family$link)))
  f
 }
 args$yreg<-literal_family(args$yreg);args$mreg<-lapply(args$mreg,literal_family);args$postcreg<-lapply(args$postcreg,literal_family)
 dest<-file.path(out,key);dir.create(dest,showWarnings=FALSE)
 state('prepare_group',extra=list(key=key))
 if(!all(z$checks$converged & z$checks$full_rank))stop('Original-data preflight failed: ',key)
 data<-args$data
 map<-split(seq_len(nrow(data)),factor(data$cluster_id,levels=seq_len(ncol(plan$draws))))
 indices<-lapply(seq_len(B),function(b)unlist(map[plan$draws[b,]],use.names=FALSE))
 saveRDS(indices,file.path(dest,'actual_resampling_indices.rds'))
 write.csv(data[,c('stable_row_id','dyad_id','actor_pid','cluster_id')],file.path(dest,'analysis_row_ids.csv'),row.names=FALSE)
 fits<-c(list(args$yreg),args$mreg,args$postcreg)
 write.csv(data.frame(model=c('yreg',paste0('mreg',seq_along(args$mreg)),paste0('postcreg',seq_along(args$postcreg))),
  formula=vapply(fits,function(f)paste(deparse(formula(f)),collapse=' '),''),family=vapply(fits,function(f)family(f)$family,'')),file.path(dest,'formulas.csv'),row.names=FALSE)
 progress<-function(b,R,last) {
  atomic_json(list(stage='bootstrap',status='running',key=key,completed=b,total=R,updated_at=format(Sys.time(),'%FT%T%z'),pid=Sys.getpid()),file.path(dest,'state.json'))
  state('bootstrap',extra=list(key=key,completed=b,total=R))
 }
 bridge<-make_shared_cmest(indices,plan$seeds[seq_len(B)],progress)
 started<-Sys.time();set.seed(75112345L)
 state('paired_point_and_bootstrap',extra=list(key=key))
 fit<-tryCatch(do.call(bridge$cmest,args),error=function(e)e)
 diagnostics<-if(length(bridge$state$diagnostics))do.call(rbind,bridge$state$diagnostics) else data.frame()
 write.csv(diagnostics,file.path(dest,'repeat_diagnostics.csv'),row.names=FALSE)
 if(inherits(fit,'error')) {
  saveRDS(list(error=conditionMessage(fit),diagnostics=diagnostics,args=args),file.path(dest,'failed_fit_evidence.rds'))
  state('group_failed','failed',list(key=key,error=conditionMessage(fit)))
  stop('Group failed: ',key,': ',conditionMessage(fit))
 }
 stopifnot(inherits(fit,'cmest_mval_grid'),all(c('0','1')%in%names(fit$mval_results)))
 # do.call with a scoped function otherwise serializes the complete worker
 # environment through match.call's function-valued head. Preserve the full
 # scientific object, replacing only that nonportable call head.
 fit$call[[1]]<-quote(CMAverse::cmest)
 for(m in names(fit$mval_results))fit$mval_results[[m]]$call[[1]]<-quote(CMAverse::cmest)
 fit$execution_provenance<-list(statistical_version='v7.5.1_exploratory_heterogeneity',inherited_overall_version='v7.4.1',
  sampling_unit='actor-partner-valid-parent-year-qualified-household connected component',
  seed=7510908L,point_seed=75112345L,B_attempted=B,shared_plan_sha256=digest::digest(file=file.path(root,'data/shared_cluster_plan.rds'),algo='sha256',serialize=FALSE),
  row_id_sha256=digest::digest(data$stable_row_id,algo='sha256'),package_function_hash=pkg_hash,
  bootstrap_provenance_note='Native boot.array text is superseded: stored matrix contains actual indices with right NA padding; row_lengths gives true sample sizes.',
  fits_checked_each_repeat=TRUE,formula_change='remove grouping variable only where constant',
  indirect_scale='log OR in bootstrap matrix; OR for displayed native ratios',
  ER_and_proportion_interpretation='suspended as in overall manuscript',native_diagnostic_exact=bridge$state$compatibility)
 valid<-diagnostics$execution_ok & diagnostics$fits_valid & diagnostics$core_finite
 fit$execution_provenance$B_core_valid<-sum(valid)
 fit$execution_provenance$inference_status<-if(all(valid))'complete' else 'blocked_failed_repeats'
 saveRDS(fit,file.path(dest,'cmest_paired_full.rds'))
 stopifnot(inherits(readRDS(file.path(dest,'cmest_paired_full.rds'))$mval_results[['1']],'cmest'))
 manifest[[key]]<-data.frame(key=key,path=file.path(dest,'cmest_paired_full.rds'),sha256=digest::digest(file=file.path(dest,'cmest_paired_full.rds'),algo='sha256',serialize=FALSE),
  bytes=file.info(file.path(dest,'cmest_paired_full.rds'))$size,elapsed_seconds=as.numeric(difftime(Sys.time(),started,units='secs')),
  N=nrow(data),B_attempted=B,B_core_valid=sum(valid),status=fit$execution_provenance$inference_status)
 validation[[key]]<-data.frame(key=key,full_m0_m1=TRUE,indices_lengths_match=identical(attr(fit$mval_grid$bootstrap_indices,'row_lengths'),lengths(indices)),
  paired_t_dimensions=identical(dim(fit$mval_grid$bootstrap_t),c(B,34L)),all_original_and_repeat_fits_valid=all(valid),
  functions_unchanged=identical(pkg_hash,vapply(names(pkg_hash),function(n)digest::digest(body(get(n,asNamespace('CMAverse'))),algo='sha256'),'')))
 write.csv(do.call(rbind,manifest),file.path(out,paste0('manifest_',mediator_id,'.csv')),row.names=FALSE)
 write.csv(do.call(rbind,validation),file.path(out,paste0('validation_',mediator_id,'.csv')),row.names=FALSE)
 atomic_json(list(stage='saved',status='complete',key=key,updated_at=format(Sys.time(),'%FT%T%z'),inference_status=fit$execution_provenance$inference_status),file.path(dest,'state.json'))
 rm(fit,bridge,indices);gc()
}
writeLines(capture.output(sessionInfo()),file.path(out,paste0('sessionInfo_',mediator_id,'.txt')))
state('complete','complete',list(groups=length(keys),B_attempted=B))
cat('HETEROGENEITY_WORKER_DONE',mode,mediator_id,'\n')
