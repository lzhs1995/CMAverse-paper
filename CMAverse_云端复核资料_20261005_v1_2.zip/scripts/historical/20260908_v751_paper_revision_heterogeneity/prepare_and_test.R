root <- '/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260908_v751_paper_revision_heterogeneity'
base <- dirname(root)
old <- file.path(base,'20260905_basic_regression_cmaverse_v7_4_1')
lib <- '/Users/lzhs/Library/Caches/org.R-project.R/R/renv/library/CMAverse-mval-grid-v741/macos/R-4.6/aarch64-apple-darwin23'
.libPaths(c(lib,.libPaths()))
suppressPackageStartupMessages(library(CMAverse))
source(file.path(root,'scripts/shared_bootstrap.R'),local=TRUE)
dir.create(file.path(root,'results'),showWarnings=FALSE)
dir.create(file.path(root,'qa'),showWarnings=FALSE)
dir.create(file.path(root,'data'),showWarnings=FALSE)
sha <- function(p) digest::digest(file=p,algo='sha256',serialize=FALSE)
chains <- c('AA-S','AA-P','AR-S','AR-P','RA-S','RA-P','RR-S','RR-P')
paths <- file.path(old,'cma/formal',chains,paste0('cmest_grid_',chains,'_nboot1000.rds'))
protected <- c(paths,file.path(old,'data/cmaverse_v7_4_1_corrected_overlay.rds'),
 file.path(base,'20260907_table1_comparegroups_autofit/data/current.csv'))
write.csv(data.frame(path=protected,sha256=vapply(protected,sha,'')),file.path(root,'qa/frozen_inputs_sha256.csv'),row.names=FALSE)
d <- as.data.frame(readRDS(protected[9]))
d <- d[d$same_actor & d$same_partner & d$parent_identity_included,]
stopifnot(nrow(d)==13092L,!anyDuplicated(d$stable_row_id))
# Union-find of relation records, with valid persons sharing one namespace.
parent <- seq_len(nrow(d)); owner <- new.env(hash=TRUE,parent=emptyenv())
find <- function(a) {while(parent[a]!=a) {parent[a]<<-parent[parent[a]]; a<-parent[a]}; a}
join <- function(a,b) {a<-find(a);b<-find(b);if(a!=b)parent[max(a,b)]<<-min(a,b)}
valid <- function(x) !is.na(x) & suppressWarnings(as.numeric(x))>0
for(i in seq_len(nrow(d))) {
 persons <- unlist(d[i,c('actor_pid','partner_pid_begin','partner_pid_end','parent_pid_begin','parent_pid_end')],use.names=FALSE)
 keys <- paste0('pid:',persons[valid(persons)])
 years <- if(d$time_period[i]==0)c(2018,2020) else c(2020,2022)
 for(j in 1:2) {fid<-d[[c('fid_begin','fid_end')[j]]][i];if(valid(fid)) keys<-c(keys,paste0('fid',years[j],':',fid))}
 for(k in unique(keys)) {if(exists(k,owner,inherits=FALSE))join(i,get(k,owner)) else assign(k,i,owner)}
}
d$cluster_id <- match(vapply(seq_len(nrow(d)),find,integer(1)),unique(vapply(seq_len(nrow(d)),find,integer(1))))
counts <- table(d$cluster_id)
write.csv(data.frame(groups=length(counts),median=median(counts),maximum=max(counts),max_fraction=max(counts)/nrow(d)),file.path(root,'qa/dependence_components.csv'),row.names=FALSE)
set.seed(7510908L)
cluster_draws <- matrix(sample.int(length(counts),1000L*length(counts),replace=TRUE),1000L,byrow=TRUE)
repeat_seeds <- sample.int(.Machine$integer.max,1000L)
saveRDS(list(draws=cluster_draws,seeds=repeat_seeds,seed=7510908L),file.path(root,'data/shared_cluster_plan.rds'))
write.csv(d[,c('stable_row_id','dyad_id','actor_pid','cluster_id')],file.path(root,'data/row_cluster_map.csv'),row.names=FALSE)
saveRDS(d,file.path(root,'data/identity_target_readonly_copy.rds'))

# Formula inheritance helper; only remove the actual grouping term if constant.
prepare_args <- function(frozen,group_variable,level) {
  data <- as.data.frame(frozen$data)
  match_i <- match(data$stable_row_id,d$stable_row_id)
  stopifnot(!anyNA(match_i))
  group <- d[[group_variable]][match_i]
  data <- data[!is.na(group)&group==level,,drop=FALSE]
  data$cluster_id <- d$cluster_id[match(data$stable_row_id,d$stable_row_id)]
  reg <- frozen$mval_results[['0']]$reg.output
  adjust <- function(fit) {
    f <- formula(fit)
    if(group_variable %in% all.vars(f) && length(unique(data[[group_variable]]))==1L)
      f <- update(f,paste('. ~ . -',group_variable))
    environment(f)<-baseenv()
    z<-glm(f,data=data,family=family(fit));z$call$formula<-f;z$call$data<-quote(data)
    z$call$family<-if(family(fit)$family=='binomial')bquote(stats::binomial(link=.(family(fit)$link))) else bquote(stats::gaussian(link=.(family(fit)$link)))
    z
  }
  m <- lapply(reg$mreg,adjust); y <- adjust(reg$yreg); l <- lapply(reg$postcreg,adjust)
  models <- c(m,list(y),l)
  checks <- data.frame(model=c(paste0('m',seq_along(m)),'y',paste0('l',seq_along(l))),
    converged=vapply(models,function(z)isTRUE(z$converged),logical(1)),
    full_rank=vapply(models,function(z)z$rank==length(coef(z)) && all(is.finite(coef(z))),logical(1)))
  basec <- frozen$variables$basec
  if(group_variable %in% basec && length(unique(data[[group_variable]]))==1L)basec<-setdiff(basec,group_variable)
  args <- list(data=data,model='gformula',outcome='Y',exposure='X',mediator='M',
    basec=basec,postc=frozen$variables$postc,mreg=m,yreg=y,postcreg=l,
    EMint=TRUE,a=1,astar=0,mval_grid=list(c(0,1)),estimation='imputation',
    inference='bootstrap',boot.ci.type='per',yval=1,full=TRUE,nboot=10L)
  list(args=args,checks=checks)
}
make_indices <- function(data,B) {
  map <- split(seq_len(nrow(data)),factor(data$cluster_id,levels=seq_len(ncol(cluster_draws))))
  lapply(seq_len(B),function(b)unlist(map[cluster_draws[b,]],use.names=FALSE))
}

# Public-interface compatibility without modifying sampling: exact same random stream.
set.seed(317)
n <- 400L
s <- data.frame(X=rbinom(n,1,.5),C=rnorm(n));s$L<-rnorm(n,.3*s$X+.2*s$C);s$M<-rbinom(n,1,plogis(.3*s$X+.2*s$L));s$Y<-rbinom(n,1,plogis(-1+.3*s$X+.3*s$M+.2*s$L))
args <- list(data=s,model='gformula',outcome='Y',exposure='X',mediator='M',basec='C',postc='L',
 mreg=list(glm(M~X+C+L,data=s,family=binomial())),yreg=glm(Y~X*M+C+L,data=s,family=binomial()),
 postcreg=list(glm(L~X+C,data=s,family=gaussian())),EMint=TRUE,a=1,astar=0,mval_grid=list(c(0,1)),
 estimation='imputation',inference='bootstrap',boot.ci.type='per',yval=1,full=TRUE,nboot=10L)
clone <- make_shared_cmest()
set.seed(811);native<-do.call(CMAverse::cmest,args)
set.seed(811);copied<-do.call(clone$cmest,args)
stopifnot(identical(native$mval_grid$bootstrap_t,copied$mval_grid$bootstrap_t),
 identical(native$effect.pe,copied$effect.pe))
set.seed(8);ip<-lapply(1:10,function(b)sample.int(n, n+2*b, replace=TRUE))
wrapped<-make_shared_cmest(ip,seq(9001,9010))
set.seed(811);variable<-do.call(wrapped$cmest,args)
stopifnot(all(vapply(wrapped$state$diagnostics,function(z)z$fits_valid && z$core_finite,logical(1))),
 identical(variable$effect.pe,native$effect.pe),
 identical(attr(variable$mval_grid$bootstrap_indices,'row_lengths'),lengths(ip)))
saveRDS(list(native=native,clone=copied,variable=variable),file.path(root,'qa/synthetic_full_objects.rds'))
write.csv(data.frame(check=c('public_interface_exact','outReg_diagnostics_exact','variable_n_supported','m0_m1_same_rows_and_rng'),passed=TRUE),file.path(root,'qa/wrapper_compatibility.csv'),row.names=FALSE)

# Forty-eight original-data preflights; small cells alone are not a fit test.
preflight<-list(); cell_rows<-list(); prepared<-list()
for(chain in chains) {
  frozen<-readRDS(paths[match(chain,chains)])
  for(gvar in c('gender_begin','lifetime_begin','urban_begin'))for(level in 0:1){
    key<-paste(chain,gvar,level,sep='__')
    z<-prepare_args(frozen,gvar,level);prepared[[key]]<-z
    x<-z$args$data;cells<-as.data.frame(table(factor(x$X,0:1),factor(x$M,0:1),factor(x$Y,0:1)))
    cells$key<-key;cell_rows[[key]]<-cells
    preflight[[key]]<-data.frame(key=key,chain=chain,group=gvar,level=level,N=nrow(x),actors=length(unique(x$actor_pid)),
      clusters=length(unique(x$cluster_id)),min_cell=min(cells$Freq),all_converged=all(z$checks$converged),all_full_rank=all(z$checks$full_rank))
  }
}
write.csv(do.call(rbind,preflight),file.path(root,'qa/subgroup_preflight.csv'),row.names=FALSE)
write.csv(do.call(rbind,cell_rows),file.path(root,'qa/subgroup_all_eight_cells.csv'),row.names=FALSE)
saveRDS(prepared,file.path(root,'data/prepared_group_arguments.rds'))
writeLines(capture.output(sessionInfo()),file.path(root,'qa/sessionInfo_prepare.txt'))
cat('PREPARE_AND_COMPATIBILITY_DONE\n')
