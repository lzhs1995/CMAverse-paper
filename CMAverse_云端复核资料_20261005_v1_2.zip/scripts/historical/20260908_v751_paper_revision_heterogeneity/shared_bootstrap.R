# Scoped sampling adapter. Installed CMAverse functions and effect formulas are never changed.
make_shared_cmest <- function(index_plan = NULL, seeds = NULL, progress = NULL) {
  ns <- asNamespace('CMAverse')
  shim <- new.env(parent = ns)
  state <- new.env(parent = emptyenv())
  state$diagnostics <- list()
  state$indices <- index_plan
  state$compatibility <- list()
  # The only syntax substitution is the provenance accessor: custom samples have
  # variable row counts and cannot be regenerated with boot::boot.array.
  replace_accessor <- function(x) {
    if (!is.call(x)) return(x)
    if (identical(x[[1]], quote(boot::boot.array))) {
      x[[1]] <- as.name('shared_boot_array')
      state$accessor_count <- state$accessor_count + 1L
      return(x)
    }
    for (j in seq_along(x)[-1]) if (!identical(x[[j]], quote(expr=))) x[j] <- list(replace_accessor(x[[j]]))
    x
  }
  state$accessor_count <- 0L
  shim$estinf <- get('estinf', ns)
  body(shim$estinf) <- replace_accessor(body(shim$estinf))
  stopifnot(state$accessor_count == 1L)
  environment(shim$estinf) <- shim
  shim$shared_boot_array <- function(boots, indices = TRUE) {
    if (is.null(index_plan)) return(boot::boot.array(boots, indices=indices))
    stopifnot(indices, length(boots$shared_indices) == nrow(boots$t))
    pad <- matrix(NA_integer_, length(boots$shared_indices), max(lengths(boots$shared_indices)))
    for (b in seq_along(boots$shared_indices)) pad[b, seq_along(boots$shared_indices[[b]])] <- boots$shared_indices[[b]]
    attr(pad, 'row_lengths') <- lengths(boots$shared_indices)
    attr(pad, 'representation') <- 'actual indices; right padding is not a sampled observation'
    pad
  }
  find_binding <- function(e, name) {
    while (!identical(e, emptyenv())) {
      if (exists(name, e, inherits=FALSE)) return(e)
      e <- parent.env(e)
    }
    stop('Missing captured binding: ',name)
  }
  check_reg <- function(x) {
    models <- c(list(x$reg.output$yreg), x$reg.output$mreg, x$reg.output$postcreg)
    c(converged=all(vapply(models, function(z) isTRUE(z$converged), logical(1))),
      finite_coef=all(vapply(models, function(z) all(is.finite(coef(z))), logical(1))),
      full_rank=all(vapply(models, function(z) z$rank == length(coef(z)), logical(1))))
  }
  shim$boot <- function(data, statistic, R, outReg=FALSE, full=TRUE, ...) {
    if (is.null(index_plan)) return(boot::boot(data=data, statistic=statistic,R=R,outReg=outReg,full=full,...))
    stopifnot(R == length(index_plan), length(seeds) == R)
    n_env <- find_binding(environment(statistic), 'n')
    old_n <- get('n', n_env)
    on.exit(assign('n', old_n, n_env), add=TRUE)
    # t0 follows the same statistic and row-count convention as every repeat.
    assign('n', nrow(data), n_env)
    seed_t0 <- .Random.seed
    t0 <- statistic(data=data, indices=seq_len(nrow(data)),outReg=FALSE,full=full)
    # Exact wrapper compatibility on one captured draw: collecting glm diagnostics
    # must not change values or random stream relative to native outReg=FALSE.
    assign('.Random.seed',seed_t0,.GlobalEnv)
    diagnostic_t0 <- statistic(data=data,indices=seq_len(nrow(data)),outReg=TRUE,full=full)
    point_diagnostic <- unlist(lapply(diagnostic_t0, `[[`, 'est'),use.names=FALSE)
    stopifnot(isTRUE(all.equal(t0,point_diagnostic,tolerance=0)))
    state$compatibility <- list(native_vs_diagnostic_exact=TRUE, original_n=nrow(data))
    draws <- matrix(NA_real_,R,length(t0))
    for (b in seq_len(R)) {
      idx <- index_plan[[b]]
      warning_text <- character()
      started <- Sys.time()
      assign('n',length(idx),n_env)
      set.seed(seeds[b])
      ans <- tryCatch(withCallingHandlers({
        if (!length(idx)) stop('No selected rows')
        grid <- statistic(data=data,indices=idx,outReg=TRUE,full=full)
        checks <- lapply(grid,check_reg)
        values <- unlist(lapply(grid, `[[`, 'est'),use.names=FALSE)
        if (length(values) != length(t0)) stop('Effect dimension changed')
        # Core ratios must be finite; native proportions can be nonfinite if TE=0.
        core <- c(seq_len(6L),length(t0)/2L + seq_len(6L))
        list(values=values, checks=checks, core_finite=all(is.finite(values[core])))
      },warning=function(w) {warning_text <<- c(warning_text,conditionMessage(w)); invokeRestart('muffleWarning')}),error=function(e)e)
      ok <- !inherits(ans,'error')
      if (ok) draws[b,] <- ans$values
      checks <- if(ok) unlist(ans$checks) else FALSE
      state$diagnostics[[b]] <- data.frame(replicate=b,n=length(idx),execution_ok=ok,
        fits_valid=ok && all(checks), core_finite=ok && ans$core_finite,
        warnings=paste(unique(warning_text),collapse=' | '),
        error=if(ok) '' else conditionMessage(ans),
        seconds=as.numeric(difftime(Sys.time(),started,units='secs')))
      if (!is.null(progress) && (b == 1L || b %% 10L == 0L || b == R)) progress(b,R,state$diagnostics[[b]])
    }
    assign('n',old_n,n_env)
    structure(list(t0=t0,t=draws,R=R,data=data,seed=seed_t0,statistic=NULL,
      sim='ordinary',stype='i',strata=rep(1L,nrow(data)),weights=rep(1/nrow(data),nrow(data)),
      shared_indices=index_plan),class='boot')
  }
  fun <- get('cmest',ns)
  environment(fun) <- shim
  list(cmest=fun,state=state,estinf_body_hash=digest::digest(body(shim$estinf),algo='sha256'))
}
