root <- '/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260908_v751_paper_revision_heterogeneity'
dir.create(file.path(root,'results'),showWarnings=FALSE)
chains<-c('AA-S','AA-P','AR-S','AR-P','RA-S','RA-P','RR-S','RR-P')
dimensions<-c('gender_begin','lifetime_begin','urban_begin')
out<-file.path(root,'heterogeneity/formal')
source_rows<-list();group_rows<-list();difference_rows<-list();qa<-list();design_diagnostics<-list()
expected_names<-unique(read.csv(file.path(dirname(root),'20260906_cmaverse_manuscript_v7_5_1/results/native_272_results.csv'))$effect)
stopifnot(length(expected_names)==17L,identical(expected_names[1:6],c('Rcde','rRpnde','rRtnde','rRpnie','rRtnie','Rte')))
write.csv(data.frame(column=1:34,mval=rep(0:1,each=17L),effect=rep(expected_names,2L),
 stored_scale=rep(c(rep('log_OR',6L),rep('native',11L)),2L)),file.path(root,'qa/heterogeneity_bootstrap_column_map.csv'),row.names=FALSE)
for(g in dimensions)for(ch in chains) {
 fits<-lapply(0:1,function(level)readRDS(file.path(out,paste(ch,g,level,sep='__'),'cmest_paired_full.rds')))
 vals<-list()
 for(level in 0:1) {
  f<-fits[[level+1]]; key<-paste(ch,g,level,sep='__'); path<-file.path(out,key,'cmest_paired_full.rds')
  diag<-read.csv(file.path(out,key,'repeat_diagnostics.csv'))
  valid<-diag$execution_ok & diag$fits_valid & diag$core_finite
  child<-f$mval_results[['0']];nm<-names(child$effect.pe);k<-length(nm)
  stopifnot(k==17L,identical(names(f$mval_results[['1']]$effect.pe),nm),identical(dim(f$mval_grid$bootstrap_t),c(1000L,34L)))
  stopifnot(identical(nm,expected_names))
  displayed_core<-exp(f$mval_grid$bootstrap_t[,c(seq_len(6L),k+seq_len(6L)),drop=FALSE])
  valid<-valid & rowSums(is.finite(displayed_core))==12L
  # A finite log estimate alone is not sufficient if exponentiation overflows.
  stopifnot(all(vapply(f$mval_results,function(z)all(is.finite(z$effect.pe[1:6])),logical(1))))
  idx<-readRDS(file.path(out,key,'actual_resampling_indices.rds'))
  padded<-f$mval_grid$bootstrap_indices
  index_ok<-all(vapply(seq_along(idx),function(b)identical(unname(padded[b,seq_along(idx[[b]])]),idx[[b]]),logical(1)))
  stopifnot(index_ok)
  # Explain failed fit checks using the already-saved design matrices only.
  # No extra GLM fit, simulation or replacement bootstrap draw is performed.
  if(any(!valid)) {
   reg<-child$reg.output
   models<-c(list(yreg=reg$yreg),setNames(reg$mreg,paste0('mreg',seq_along(reg$mreg))),setNames(reg$postcreg,paste0('postcreg',seq_along(reg$postcreg))))
   for(name in names(models)) {
    mm<-model.matrix(models[[name]]);stopifnot(nrow(mm)==nrow(f$data))
    for(b in which(!valid)) {
     sub<-mm[idx[[b]],,drop=FALSE]
     design_diagnostics[[paste(key,name,b)]]<-data.frame(key=key,model=name,replicate=b,columns=ncol(mm),original_rank=models[[name]]$rank,
      resampled_design_rank=qr(sub)$rank,zero_columns=paste(colnames(sub)[colSums(abs(sub))==0],collapse=';'),note='read-only original design subsetting, not a refit')
    }
   }
  }
  qa[[key]]<-data.frame(key=key,index_exact=index_ok,all_repeats_valid=all(valid),B_attempted=nrow(diag),B_valid=sum(valid),full_children=all(vapply(f$mval_results,inherits,logical(1),'cmest')))
  for(m in c('0','1')) {
   c<-f$mval_results[[m]]
   draw_block<-f$mval_grid$bootstrap_t[,seq_len(k)+if(m=='1')k else 0L,drop=FALSE]
   draw_block[,seq_len(6L)]<-exp(draw_block[,seq_len(6L)])
   source_rows[[paste(key,m)]]<-data.frame(chain=ch,dimension=g,level=level,mval=m,effect=nm,estimate=unname(c$effect.pe),se=unname(c$effect.se),conf_low=unname(c$effect.ci.low),conf_high=unname(c$effect.ci.high),p_native=unname(c$effect.pval),N=nrow(f$data),actors=length(unique(f$data$actor_pid)),clusters=length(unique(f$data$cluster_id)),B_attempted=1000L,B_valid=sum(valid),B_finite_display_scale=colSums(is.finite(draw_block)),source=path,sha256=digest::digest(file=path,algo='sha256',serialize=FALSE),interpretation_status=ifelse(nm%in%nm[1:6],if(all(valid))'exploratory_OR_limited' else 'inference_blocked_failed_repeats','ER_proportion_interpretation_suspended'))
  }
  i<-match('rRtnie',nm);ic<-match('Rcde',nm)
  ie<-f$mval_grid$bootstrap_t[,i]
  delta<-exp(f$mval_grid$bootstrap_t[,k+ic])-exp(f$mval_grid$bootstrap_t[,ic])
  iepoint<-log(child$effect.pe[['rRtnie']])
  dpoint<-f$mval_results[['1']]$effect.pe[['Rcde']]-child$effect.pe[['Rcde']]
  vals[[level+1]]<-list(ie=ie,delta=delta,iepoint=iepoint,dpoint=dpoint,valid=valid)
  group_rows[[key]]<-data.frame(chain=ch,dimension=g,level=level,N=nrow(f$data),actors=length(unique(f$data$actor_pid)),clusters=length(unique(f$data$cluster_id)),
    IE_OR=exp(iepoint),IE_low=child$effect.ci.low[['rRtnie']],IE_high=child$effect.ci.high[['rRtnie']],
    delta_OR=dpoint,delta_low=if(all(is.finite(delta)))unname(quantile(delta,.025)) else NA_real_,delta_high=if(all(is.finite(delta)))unname(quantile(delta,.975)) else NA_real_,
    B_attempted=1000L,B_valid=sum(valid),status=if(all(valid))'estimable_limited' else 'blocked_failed_repeats')
 }
 # Pairing is by the shared component draw ID, not by equal row counts.
 stopifnot(identical(fits[[1]]$execution_provenance$shared_plan_sha256,fits[[2]]$execution_provenance$shared_plan_sha256))
 for(what in c('IE_logOR','Delta_OR')) {
  draws<-if(what=='IE_logOR')vals[[2]]$ie-vals[[1]]$ie else vals[[2]]$delta-vals[[1]]$delta
  point<-if(what=='IE_logOR')vals[[2]]$iepoint-vals[[1]]$iepoint else vals[[2]]$dpoint-vals[[1]]$dpoint
  valid<-vals[[1]]$valid & vals[[2]]$valid & is.finite(draws)
  status<-if(all(valid) && is.finite(point))'estimable_limited' else 'blocked_failed_repeats'
  # Centred-bootstrap two-sided test, plus-one correction; not p_native.
  p<-if(status=='estimable_limited')(1+sum(abs(draws-point)>=abs(point)))/(length(draws)+1) else NA_real_
  difference_rows[[paste(ch,g,what)]]<-data.frame(chain=ch,dimension=g,contrast=what,estimate=point,
    conf_low=if(all(valid))unname(quantile(draws,.025)) else NA_real_,conf_high=if(all(valid))unname(quantile(draws,.975)) else NA_real_,
    p_centered_bootstrap=p,B_attempted=1000L,B_valid=sum(valid),status=status,direction='group1_minus_group0')
  saveRDS(data.frame(replicate=1:1000,draw=draws,valid=valid),file.path(root,'results',paste(ch,g,what,'paired_draws.rds',sep='__')))
 }
}
diff<-do.call(rbind,difference_rows)
diff$q_BH<-NA_real_
for(what in unique(diff$contrast)) {
 rows<-which(diff$contrast==what)
 # Maintain the prespecified 24-comparison family even when a result is blocked.
 ok<-rows[is.finite(diff$p_centered_bootstrap[rows])]
 diff$q_BH[ok]<-p.adjust(diff$p_centered_bootstrap[ok],method='BH',n=24L)
}
write.csv(do.call(rbind,source_rows),file.path(root,'results/heterogeneity_native_1632_results.csv'),row.names=FALSE)
write.csv(do.call(rbind,group_rows),file.path(root,'results/heterogeneity_48_group_estimates.csv'),row.names=FALSE)
write.csv(diff,file.path(root,'results/heterogeneity_48_direct_differences.csv'),row.names=FALSE)
write.csv(do.call(rbind,qa),file.path(root,'qa/heterogeneity_sampling_qa.csv'),row.names=FALSE)
if(length(design_diagnostics))write.csv(do.call(rbind,design_diagnostics),file.path(root,'qa/failed_repeat_design_diagnostics.csv'),row.names=FALSE)
old<-read.csv(file.path(root,'qa/frozen_inputs_sha256.csv'))
old$current_sha256<-vapply(old$path,function(p)digest::digest(file=p,algo='sha256',serialize=FALSE),'')
old$unchanged<-old$sha256==old$current_sha256
write.csv(old,file.path(root,'qa/frozen_inputs_final_comparison.csv'),row.names=FALSE)
stopifnot(all(old$unchanged),nrow(do.call(rbind,source_rows))==1632L,nrow(diff)==48L)
cat('HETEROGENEITY_SUMMARY_COMPLETE\n')
