# Arithmetic and sampling-source QA only. No model fitting or simulation.
root<-'/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260908_v751_paper_revision_heterogeneity'
folder<-file.path(root,'heterogeneity/formal')
paths<-list.files(folder,pattern='^manifest_.*[.]csv$',full.names=TRUE)
records<-do.call(rbind,lapply(paths,read.csv))
plan<-readRDS(file.path(root,'data/shared_cluster_plan.rds'))
expected<-unique(read.csv(file.path(dirname(root),'20260906_cmaverse_manuscript_v7_5_1/results/native_272_results.csv'))$effect)
ans<-list()
for(i in seq_len(nrow(records))) {
 row<-records[i,];f<-readRDS(row$path)
 child<-f$mval_results[['0']];t<-f$mval_grid$bootstrap_t
 idx<-readRDS(file.path(dirname(row$path),'actual_resampling_indices.rds'))
 map<-split(seq_len(nrow(f$data)),factor(f$data$cluster_id,levels=seq_len(ncol(plan$draws))))
 index_exact<-all(vapply(seq_len(1000L),function(b)identical(idx[[b]],unlist(map[plan$draws[b,]],use.names=FALSE)),logical(1)))
 errors<-numeric()
 for(m in 0:1){z<-f$mval_results[[as.character(m)]];draws<-t[,seq_len(17L)+17L*m,drop=FALSE];draws[,1:6]<-exp(draws[,1:6]);s<-apply(draws,2,sd,na.rm=TRUE)
  errors<-c(errors,max(abs(s-z$effect.se),na.rm=TRUE))}
 ans[[row$key]]<-data.frame(key=row$key,source_hash=digest::digest(file=row$path,algo='sha256',serialize=FALSE)==row$sha256,
  columns_exact=identical(names(child$effect.pe),expected)&&identical(dim(t),c(1000L,34L)),
  actual_indices_equal_shared_plan=index_exact,max_native_se_abs_error=max(errors),
  m0_m1_total_draws_identical=identical(t[,6],t[,23]),
  scope='saved-object arithmetic and sampling audit; not independent re-estimation')
 rm(f,t,idx,map);gc(FALSE)
 cat('READ_ONLY_OBJECT_QA ',i,'/',nrow(records),'\n');flush.console()
}
q<-do.call(rbind,ans)
write.csv(q,file.path(root,'qa',paste0('completed_objects_preliminary_',nrow(records),'.csv')),row.names=FALSE)
stopifnot(all(q$source_hash),all(q$columns_exact),all(q$actual_indices_equal_shared_plan),all(q$max_native_se_abs_error<1e-10),all(q$m0_m1_total_draws_identical))
cat('READ_ONLY_OBJECT_QA_COMPLETE ',nrow(records),'\n')
