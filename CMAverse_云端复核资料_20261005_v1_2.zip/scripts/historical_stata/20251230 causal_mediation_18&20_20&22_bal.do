
/*
================================================================================
文件：20251230 causal_mediation_18&20_20&22_bal.do
目的：在家庭系统理论框架下，检验"婚姻满意度"如何（调节 and/or 中介）
      干预"子代收入"对"代际经济支持"的影响。

【研究问题的两条假设检验路径】
  路径(1) 绝对收入 → 代际经济支持：
    M = 子代本人婚姻满意度（msat_c1_）/ 配偶婚姻满意度（msat_c2_）
              / 夫妻相对婚姻满意度（msat_c12_）的调节and/or中介效应
  路径(2) 相对收入 → 代际经济支持：
    M = 同上三种满意度的调节and/or中介效应

因果框架（VanderWeele 2014 四分解）：
  X（处理）: 子代绝对收入 aincc_（万元）/ 相对收入 inc_（夫妻间占比）
  M（中介）: 本人婚姻满意度 msat_c1_ / 配偶满意度 msat_c2_ / 相对满意度 msat_c12_
  Y（结果）: 代际经济支持 esup_（万元）
  四分解成分: 纯间接效应(PNIE)、纯直接效应(PNDE)、参照交互(INTref)、中介交互(INTmed)
  等价表示: CDE + INTref = PNDE；INTmed + PNIE = TNIE

【识别假设与处理后混杂因素（Post-treatment Confounder）说明】
  自然直接/间接效应（PNDE/TNIE）的识别需同时满足四个无未测量混杂条件：
    Ⅰ. 给定V下，A→Y无混杂
    Ⅱ. 给定V,A下，M→Y无混杂
    Ⅲ. 给定V下，A→M无混杂
    Ⅳ. M-Y混杂因素均不受A影响（处理后混杂/暴露后混杂条件，最难满足）
  条件Ⅰ-Ⅲ可通过控制基准期变量V缓解；条件Ⅳ无法通过简单控制变量修复：
    - 若将处理后混杂Z纳入回归：过控制偏差（阻断A→Z→M→Y路径）
    - 若不纳入Z：中间混杂偏差（M与Y产生虚假相关）
  在一阶差分框架（模块二/三）中，理论上所有时变变量的变化量ΔZ均是潜在的
  处理后混杂（ΔX影响工作时长变化、健康变化、债务变化等，这些又影响ΔM和ΔY）。
  解决方案：在R的CMAverse包中使用 model="gcomp" 或 model="msm"（IPW加权），
  而非Stata的 med4way（不具备处理处理后混杂的能力）。

数据策略：
  使用2018/2020/2022三期CFPS数据，构建相邻两期平衡面板
  对关键变量计算跨期变化（一阶差分），控制个体时不变混杂变量
  婚姻满意度原始值替换为年份内CDF分位数排名，规避新冠疫情对绝对水平的干扰
  X（绝对收入/相对收入）和Y（代际支持）保留原始比率量表值，不做分位数转换
    → 原因：X/Y有基数意义，转换后CMAverse中a0/a1参数失去因果诠释

【分析生态：Stata（数据准备）→ R/CMAverse（因果中介估计）】
  本文件（.do）负责数据清洗、重塑宽格、构造差分变量、输出csv/dta
  因果中介分析迁移至R的CMAverse包（https://github.com/BS1125/CMAverse/）执行
  两种设计的互补性：
    差分模型（模块二/三/四）：识别收入变化（within-person）对满意度变化→支持变化的效应
      → 自动消除个体固定效应（稳定混杂），识别短期冲击机制
      → postc候选：ΔZ=受ΔX影响且影响ΔM和ΔY的时变量（工作时长变、健康变、债务变、同住变）
    前瞻中介（模块六）：识别基期收入水平（between-person）→中期满意度→末期支持的效应
      → 有明确时序：X₂₀₁₈ < M₂₀₂₀ < Y₂₀₂₂；4年总跨度拆为2+2年，各段有行为反应时间支撑
      → postc候选：2020年测量但受2018年收入影响的变量（aincc_2020, actor_siops_2020等）

代码结构（共6个 { } 块）：
  [模块一] L32-724   : 三期非平衡面板 → 收入/满意度/分位数标准化 → 基础数据集
  [模块二] L757-1509 : 2018-2020 平衡面板 → reshape宽格 → 差分变量 → 输出分析数据
  [模块三] L1512-2267: 2020-2022 平衡面板 → 结构与模块二完全对称
  [模块四] L2270-2755: 堆叠模块二+三 → begin/end通名 → 变量标签 → 描述性统计
  [模块五] L2901-3xxx: 2018-2022 平衡面板（保留探索，4年差分M时序弱，见模块五头注）
  [模块六] L3xxx-EOF : 三期完全平衡面板（前瞻中介主分析候选，见模块六头注）
================================================================================
*/

cls

*全局暂元定义工作路径
global workfolder  "C:\Users\LZHS\Desktop\开题报告" 
global pre_data 		"${workfolder}\0_data\Prepare_data"			// folder for data-files
global data 		"${workfolder}\0_data"			// folder for data-files
global code 		"${workfolder}\1_code"   		// folder for do-files
global table		"${workfolder}\4_tables" 		// folder for table output 
global graph		"${workfolder}\5_graphs" 		// folder for graph output 
global log			"${workfolder}\6_log" 			// folder for Stata log-files 

***定义工作路径
cd "$data"	/* 等价于 cd "C:\Users\LZHS\Desktop\开题报告\0_data" */

* 以下代码迁移自: C:\Users\LZHS\Desktop\开题报告\20240619 DV_IV_descriptives_2016_2022_unbal.do
*研究问题：子代收入对代际经济支持的影响如何受到（子代本人/配偶）婚姻满意度的影响
*数据要求：X(收入)、M(婚姻满意度)=子代夫妻配对, Y(代际经济支持)=子代亲子配对 
*潜在机制：
** 中介机制：子代绝对收入/相对收入→子代婚姻满意度/配偶婚姻满意度/相对婚姻满意度→代际经济支持
** 调节机制：子代绝对收入/相对收入✖(子代婚姻满意度/配偶婚姻满意度/相对婚姻满意度)→代际经济支持
*数据来源：基于一阶差分的18-20-22三期混合面板数据，
**一方面，完全的截面数据，如三期混合面板，混杂变量过多；
**另一方面，完全的平衡面板数据，样本量过小，无法满足理想的X\M\Y异时分析需求。
**借鉴一阶差分/固定效应的逻辑，使用2018、2020、2022三期数据，手动构建X\M\Y在2018-2020、2020-2022的跨期变化特征，据此检验 变化 对 变化 的影响。



/* ============================================================
[模块一] 三期非平衡面板数据准备（2018/2020/2022）
功能：清洗原始面板数据，构建收入变量和婚姻满意度变量，
      将满意度替换为年份内CDF分位数排名，输出基础数据集。
输入：predata_FE_16_22_unbal.dta
输出：causal_mediation_18_22_unbal.dta/.csv
============================================================ */
{
use "$pre_data\predata_FE_16_22_unbal.dta", clear

count // 48985
codebook pid //48985个亲子二元关系组-时间, 22219个个体-时间
*encode pid, gen(id) 

sum ///
year clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ actor_edu1_ ///
actor_edu2_ ///
prtedu_ ///
prthk_ ///
actor_siops_  ///
prtparty_ ///
prtchildn_ ///
actor_employ_ partner_employ_ ///
actor_income_ partner_income_ 

* 收入原始值
sum ///
actor_income_ partner_income_ /// 本人收入，配偶收入
inc_ // 本人收入占比'

* 代际关系原始值
sum qf602_a_ /// 子女报给父母的经济支持

***** 统一除以万
gen actor_income_scale_ = actor_income_ / 10000
gen partner_income_scale_ = partner_income_ / 10000
gen actor_esup_scale_ = qf602_a_ / 10000
gen qi202_actor_scale_ = (qi202_actor_*12) /10000 // 税后退休金(元/月)
gen qi202_partner_scale_ = (qi202_partner_*12) /10000 // 税后退休金(元/月)
gen actor_foperate_1_scale_ = actor_foperate_1_ /10000
gen partner_foperate_1_scale_ =  actor_foperate_1_ /10000
gen actor_foperate_1_handle_scale_ = actor_foperate_1_handle_ /10000
gen partner_foperate_1_handle_scale_ =  actor_foperate_1_handle_ /10000


sum ///
nonhousing_debts_ total_debts_

gen nonhousing_debts_scale_ =  nonhousing_debts_ /10000
replace nonhousing_debts_scale_ = 0 if nonhousing_debts_==.
gen total_debts_scale_ =  total_debts_ /10000
replace total_debts_scale_ = 0 if total_debts_==.

sum ///
actor_foperate_1_ ///
actor_foperate_1_ ///
actor_foperate_1_handle_ ///
actor_foperate_1_handle_ ///
nonhousing_debts_scale_ total_debts_scale_


sum ///
actor_foperate_1_scale_ ///
partner_foperate_1_scale_ ///
actor_foperate_1_handle_scale_ ///
partner_foperate_1_handle_scale_ //

count

recode qi202_actor_scale_ qi202_partner_scale_ (.=0)

* 补充养老金收入至工资性收入中
gen actor_income_scale2_ = actor_income_scale_ + qi202_actor_scale_
gen partner_income_scale2_ = partner_income_scale_ + qi202_partner_scale_

* 补充经营性收入至工资性收入+养老金收入中
gen actor_income_scale3_ = actor_income_scale2_ + actor_foperate_1_handle_scale_
gen partner_income_scale3_ = partner_income_scale2_ + partner_foperate_1_handle_scale_


gen actor_plus_partner_income_scale_ = (actor_income_scale3_+partner_income_scale3_)
gen actor_income_prop_ = actor_income_scale3_ / actor_plus_partner_income_scale_
replace actor_income_prop_ = 0.5 if actor_plus_partner_income_scale_==0


sum ///
actor_esup_scale_ ///
actor_income_scale_ partner_income_scale_  ///
actor_income_scale2_ partner_income_scale2_  ///
actor_income_scale3_ partner_income_scale3_  //

regress actor_esup_scale_ actor_income_scale_
regress actor_esup_scale_ actor_income_scale2_ 
regress actor_esup_scale_ actor_income_scale3_ 


sum ///
actor_income_ partner_income_ qf602_a_ inc_ ///
actor_income_scale_ partner_income_scale_ actor_esup_scale_ actor_income_prop_ ///
, sep(4)


sum ///
actor_income_ ///
actor_income_scale_ ///
aincc_ ///
qi202_actor_scale_ ///
qi202_partner_scale_ ///
actor_foperate_1_scale_ ///
partner_foperate_1_scale_ //

tab1 qi202_actor_scale_ if actor_income_scale_==0
tab1 qi202_partner_scale_ if partner_income_scale_==0

tab1 actor_income_scale_ if qi202_actor_scale_!=0



missings report ///
child_ dwm_ gender_ aage_ actor_edu1_ actor_edu2_ actor_siops_ childborn_ aincc_ ahw_ ahk_  /// agegap_ sibling_ atrust_
 prtmarr_ prtcor_ prtgender_ /// prtchildn_ prtparty_ prtage_ prtedu_ prthk_ 
lifetime_ // fmlincc_

***** Declare data to be panel data *****

drop if year==2016

count // 32,262

sort id year

gen year_n=0
replace year_n=1 if year==2018
replace year_n=2 if year==2020
replace year_n=3 if year==2022

lab define year_n 1 "2018年" 2 "2020年" 3 "2022年"
lab values year_n year_n

tab year_n,miss

igenerate year_n,gen(year_i) coding(dummy) omit(1) // 3 vars: 


tab1 actor_employ_ partner_employ_,miss nolab
recode actor_employ_ partner_employ_ (1=1) (else=0)
tab1 actor_employ_ partner_employ_,miss 

global covar ///
dwm_ gender_ aage_ actor_edu2_ actor_siops_ child_ childborn_ aincc_ ahw_ ahk_  /// agegap_ sibling_ atrust_
 prtmarr_ prtcor_ prtgender_ /// prtchildn_ prtparty_ prtage_ prtedu_ prthk_ 
lifetime_ year_i2 year_i3 // fmlincc_

*个体收入→个体婚姻满意度→代际经济支持
sum aincc_
sum msat_c1_
sum esup_

*个体收入→配偶婚姻满意度→代际经济支持
sum aincc_
sum msat_c2_
sum esup_

reg esup_ aincc_ msat_c1_ msat_c2_
reg actor_esup_scale_ actor_income_scale_ msat_c1_ msat_c2_


drop esup_ aincc_ inc_
rename (actor_esup_scale_ actor_income_scale3_ actor_income_prop_) (esup_ aincc_ inc_)

sum esup_ aincc_ inc_

reg esup_ aincc_ msat_c1_ msat_c2_


/*
preserve
*net install med4way, from("https://raw.githubusercontent.com/anddis/med4way/master/") replace
use "C:\Users\LZHS\Downloads\Stata17\ducument1\ado\base\m\med4way_example_1.dta",clear
*    Continuous outcome, continuous mediator
*    The following code reproduces an example from the SAS user's guide
*    Load the data
        use "C:\Users\LZHS\Downloads\Stata17\ducument1\ado\base\m\med4way_example_3.dta",clear
*    Calculate mean value for the exposure and the mediator
tab1 Encourage Motivation,miss
sum Encourage Motivation
        tabstat Encourage Motivation
*    Linear regression model for the outcome; Linear regression model for the mediator; Delta method standard errors. Note:
*    a0=mean(Encourage)-0.5; a1=mean(Encourage)+0.5; m=mean(Motivation)
        med4way CogPerform Encourage Motivation SocStatus FamSize, yreg(linear) mreg(linear) a0(33.91667) a1(34.91667) m(38.47)
*    Display the results using four decimal places and suppressing the p-values
        med4way, cformat(%6.4f) nopvalues
restore




tabstat aincc_ msat_c1_

med4way esup_ aincc_ msat_c1_ msat_c2_ gender_ aage_ year, yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(4.49063)
med4way esup_ aincc_ msat_c2_ msat_c1_ gender_ aage_, yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(4.49063)
med4way esup_ inccb_ msat_c1_ , yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(4.49063)

*/


*** 中介变量
tab1 year,miss
/*
       year |      Freq.     Percent        Cum.
------------+-----------------------------------
       2018 |     13,300       41.22       41.22
       2020 |     10,312       31.96       73.19
       2022 |      8,650       26.81      100.00
------------+-----------------------------------
      Total |     32,262      100.00

*/

*有四个婚姻满意度：
sum ///
msat_c1_ /// 本人婚姻满意度
msat_c2_ /// 配偶婚姻满意度
msateco_c1_ /// 本人对配偶收入满意度
msateco_c2_ // 配偶对本人收入满意度


** 本人相对婚姻满意度
* 绝对差
gen msat_c12_ = msat_c1_-msat_c2_ // 绝对差 [0,4]
* 相对差
gen msat_c12_2_ = (msat_c1_-msat_c2_)/(msat_c1_+msat_c2_) //相对差 [-1,1]
* 二分类: 0=不高于配偶，1=高于配偶
gen msat_c12_c_ = 0
replace msat_c12_c_ = 1 if msat_c1_>msat_c2_
* 二分类: 0=不低于配偶，1=低于配偶
gen msat_c12_c5_ = 0
replace msat_c12_c5_ = 1 if msat_c1_<msat_c2_


** 本人相对收入满意度
* 绝对差
gen msateco_c12_ = msateco_c1_-msateco_c2_ // 绝对差 [0,4]
* 二分类: 0=不高于配偶，1=高于配偶
gen msateco_c12_c_ = 0
replace msateco_c12_c_ = 1 if msateco_c1_>msateco_c2_
* 二分类: 0=不低于配偶，1=低于配偶
gen msateco_c12_c5_ = 0
replace msateco_c12_c5_ = 1 if msateco_c1_<msateco_c2_

** 本人相对家务满意度
* 绝对差
gen msathw_c12_ = msathw_c1_-msathw_c2_ // 绝对差 [0,4]
* 二分类: 0=不高于配偶，1=高于配偶
gen msathw_c12_c_ = 0
replace msathw_c12_c_ = 1 if msathw_c1_>msathw_c2_
* 二分类: 0=不低于配偶，1=低于配偶
gen msathw_c12_c5_ = 0
replace msathw_c12_c5_ = 1 if msathw_c1_<msathw_c2_





** 配偶相对婚姻满意度
* 绝对差
gen msat_c21_ = msat_c2_-msat_c1_ // 绝对差 [0,4]
* 相对差
gen msat_c21_2_ = (msat_c2_-msat_c1_)/(msat_c2_+msat_c1_) //相对差 [-1,1]
* 二分类: 0=不高于配偶，1=高于配偶
gen msat_c21_c_ = 0
replace msat_c21_c_ = 1 if msat_c2_>msat_c1_
* 二分类: 0=不低于配偶，1=低于配偶
gen msat_c21_c5_ = 0
replace msat_c21_c5_ = 1 if msat_c2_<msat_c1_


** 配偶相对收入满意度
* 绝对差
gen msateco_c21_ = msateco_c2_-msateco_c1_ // 绝对差 [0,4]
* 二分类: 0=不高于配偶，1=高于配偶
gen msateco_c21_c_ = 0
replace msateco_c21_c_ = 1 if msateco_c2_>msateco_c1_
* 二分类: 0=不低于配偶，1=低于配偶
gen msateco_c21_c5_ = 0
replace msateco_c21_c5_ = 1 if msateco_c2_<msateco_c1_

** 配偶相对家务满意度
* 绝对差
gen msathw_c21_ = msathw_c2_-msathw_c1_ // 绝对差 [0,4]
* 二分类: 0=不高于配偶，1=高于配偶
gen msathw_c21_c_ = 0
replace msathw_c21_c_ = 1 if msathw_c2_>msathw_c1_
* 二分类: 0=不低于配偶，1=低于配偶
gen msathw_c21_c5_ = 0
replace msathw_c21_c5_ = 1 if msathw_c2_<msathw_c1_

tab1 msat_c12_c_ msat_c12_c5_ msat_c21_c_ msat_c21_c5_,miss
/*

    Variable |        Obs        Mean    Std. dev.       Min        Max
-------------+---------------------------------------------------------
    msat_c1_ |     32,232     4.49063    .8277398          1          5
    msat_c2_ |     32,228    4.495066    .8232249          1          5
 msateco_c1_ |     32,221    4.300642    .9840232          1          5
 msateco_c2_ |     32,224    4.318924    .9703007          1          5

*/

/*
[设计说明] 为何用年份内分位数排名替代满意度绝对值？
新冠疫情（2020年）可能系统性地压低全社会婚姻满意度水平，
使2020年的绝对值与2018、2022年不可比（相同的绝对值，含义已改变）。
年份内CDF分位数排名只衡量个体相对于同年同伴的位置，
不受年度均值整体漂移影响，因此跨期变化（分位数差）更能反映真实的相对变化。
注意：下方生成分位数后，L521-525处用分位数覆盖原始满意度变量，
后续所有分析（模块二/三/四）均基于分位数版本。
*/
*分年份计算分位数，使用随机扰动解决大量并列值（满意度1-5分）问题

set seed 12345 // 设定随机种子，这步很关键，保证每次跑出来的随机排名是一致的

sum msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ msathw_c1_ msathw_c2_
missings report msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ msathw_c1_ msathw_c2_
tab1 year,miss

local vars "msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ msathw_c1_ msathw_c2_"

foreach v of local vars {
    * 1. 生成带有微小随机扰动的临时变量
    * 对于满意度：解决1-5分的大量同分
    * 对于收入：解决0收入或整数收入的同分
    gen double `v'_noise = `v' + runiform()/100000 
    * 注意：用了 double 精度，防止随机数太小被截断，分母改大一点更安全
    
    * 2. 生成存放排名的变量
    gen `v'_pct = .
    
    * 3. 分年份计算百分位 (0-1之间)
    forvalues y = 2018(2)2022 {
        * cumul 计算的是累积分布函数 (CDF)
        cumul `v'_noise if year == `y' , gen(temp_pct) 
        replace `v'_pct = temp_pct if year == `y' 
        drop temp_pct
    }
    
    * 4. 清理临时变量
    drop `v'_noise
    
    * 5. 添加标签
    label var `v'_pct "`v' 当年相对排名(分位数标准化)"
}

/*
(30 missing values generated)
(32,262 missing values generated)
(13,284 real changes made)
(10,304 real changes made)
(8,644 real changes made)
(34 missing values generated)
(32,262 missing values generated)
(13,287 real changes made)
(10,296 real changes made)
(8,645 real changes made)
(41 missing values generated)
(32,262 missing values generated)
(13,279 real changes made)
(10,300 real changes made)
(8,642 real changes made)
(38 missing values generated)
(32,262 missing values generated)
(13,285 real changes made)
(10,294 real changes made)
(8,645 real changes made)

*/

* 检查结果
sum *_pct
* 检查分布是否均匀
hist msat_c1__pct, by(year) percent
* 检查原始值与分位数的对应关系
bysort year: tab msat_c2_, sum(msat_c2__pct)
* 检查各年份分位数分布（均值应接近 0.5）
bysort year: sum msat_c1__pct msat_c2__pct msateco_c1__pct msateco_c2__pct msathw_c1__pct msathw_c2__pct


* ============================================
* 检验失访的随机性
* ============================================

* 生成失访标识
xtset id year
gen attrition_2020 = (year == 2018 & F2. year == .)  // 2018年观测到但2020年失访
gen attrition_2022 = (year == 2020 & F2.year == .)  // 2020年观测到但2022年失访

* 检验：失访者与留存者的2018年婚姻满意度是否有差异
ttest msat_c2_ if year == 2018, by(attrition_2020)
* 更详细的比较
tab msat_c2_ attrition_2020 if year == 2018, row chi2

* 检验：失访者与留存者的2020年婚姻满意度是否有差异
ttest msat_c2_ if year == 2020, by(attrition_2022)
* 更详细的比较
tab msat_c2_ attrition_2022 if year == 2020, row chi2

* Logit回归检验失访的预测因素
logit attrition_2020 msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ msathw_c1_ msathw_c2_ if year == 2018
logit attrition_2022 msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ msathw_c1_ msathw_c2_ if year == 2020



/*
. bysort year: tab msat_c1_, sum(msat_c1__pct)

------------------------------------------------------------------------------------
-> year = 2018

            |         Summary of msat_c1_
            |       当年相对排名(分位数标准
            |                 化)
   msat_c1_ |        Mean   Std. dev.       Freq.
------------+------------------------------------
          1 |   .00462963   .00266203         122
          2 |   .01663656   .00429187         197
          3 |   .07478922   .02930431       1,348
          4 |   .21680217   .05270864       2,425
          5 |   .65405751   .19976258       9,192
------------+------------------------------------
      Total |   .50003764     .288686      13,284

------------------------------------------------------------------------------------
-> year = 2020

            |         Summary of msat_c1_
            |       当年相对排名(分位数标准
            |                 化)
   msat_c1_ |        Mean   Std. dev.       Freq.
------------+------------------------------------
          1 |   .00490101   .00281556         100
          2 |   .01868207    .0051689         184
          3 |   .08123059    .0309715       1,105
          4 |   .24024651   .06086439       2,172
          5 |    .6728455   .18892476       6,743
------------+------------------------------------
      Total |   .50004852   .28868914      10,304

------------------------------------------------------------------------------------
-> year = 2022

            |         Summary of msat_c1_
            |       当年相对排名(分位数标准
            |                 化)
   msat_c1_ |        Mean   Std. dev.       Freq.
------------+------------------------------------
          1 |   .00578436   .00332286          99
          2 |   .01960898   .00469211         140
          3 |   .08971541   .03581722       1,072
          4 |   .26301481   .06427062       1,924
          5 |   .68718186   .18065573       5,409
------------+------------------------------------
      Total |   .50005784   .28869183       8,644


. * 检查各年份分位数分布（均值应接近 0.5）
. bysort year: sum msat_c1__pct msat_c2__pct msateco_c1__pct msateco_c2__pct

------------------------------------------------------------------------------------
-> year = 2018

    Variable |        Obs        Mean    Std. dev.       Min        Max
-------------+---------------------------------------------------------
msat_c1__pct |     13,284    .5000376     .288686   .0000753          1
msat_c2__pct |     13,287    .5000376     .288686   .0000753          1
msateco_c1~t |     13,279    .5000377     .288686   .0000753          1
msateco_c2~t |     13,285    .5000376     .288686   .0000753          1

------------------------------------------------------------------------------------
-> year = 2020

    Variable |        Obs        Mean    Std. dev.       Min        Max
-------------+---------------------------------------------------------
msat_c1__pct |     10,304    .5000485    .2886891    .000097          1
msat_c2__pct |     10,296    .5000486    .2886892   .0000971          1
msateco_c1~t |     10,300    .5000485    .2886891   .0000971          1
msateco_c2~t |     10,294    .5000486    .2886892   .0000971          1

------------------------------------------------------------------------------------
-> year = 2022

    Variable |        Obs        Mean    Std. dev.       Min        Max
-------------+---------------------------------------------------------
msat_c1__pct |      8,644    .5000578    .2886918   .0001157          1
msat_c2__pct |      8,645    .5000578    .2886918   .0001157          1
msateco_c1~t |      8,642    .5000579    .2886918   .0001157          1
msateco_c2~t |      8,645    .5000578    .2886918   .0001157          1

*/





drop msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ msathw_c1_ msathw_c2_

rename ///
(msat_c1__pct msat_c2__pct msateco_c1__pct msateco_c2__pct msathw_c1__pct msathw_c2__pct) ///
(msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ msathw_c1_ msathw_c2_)




/*
foreach var in msat_c1_ msat_c2_ msateco_c1_ msateco_c2_ {
    * 生成临时排名变量
    bysort year (`var'): gen temp_rank = _n if ! missing(`var')
    bysort year: egen temp_N = count(`var')
    
    * 计算百分位数 (0-1)
    gen `var'_pct = (temp_rank - 0.5) / temp_N if !missing(`var')
    
    * 清理临时变量
    drop temp_rank temp_N
    
    label var `var'_pct "`var' 年份内百分位数 (0-1)"
}

* ============================================
* 检验结果
* ============================================

* 查看各年份分位数分布
bysort year: sum msat_c1__pct msat_c2__pct msateco_c1__pct msateco_c2__pct

* 检验每年的分位数是否均匀分布（应该接近均匀分布）
tabstat msat_c1__pct, by(year) stats(min p25 p50 p75 max)



drop msat_c1_ msat_c2_ msateco_c1_ msateco_c2_

rename ///
(msat_c1__pct msat_c2__pct msateco_c1__pct msateco_c2__pct) ///
(msat_c1_ msat_c2_ msateco_c1_ msateco_c2_)

*/





*** 解释变量

sum ///
aincc_ /// 本人绝对收入(无CPI绝对值,万元)
inc_ // 相对收入占比[0,1]

** 相对收入类别化: 0=不高于配偶，1=高于配偶
gen inc_a = 0
replace inc_a=1 if inc_>0.5
** 相对收入类别化: 0=不低于配偶，1=低于配偶
gen inc_a5 = 0
replace inc_a5=1 if inc_<0.5

/*

*** 展示均值：解释变量均值上下±0.5, 中介变量 均值
tabstat aincc_ inc_a msat_c1_ msat_c2_ msat_c12_ msateco_c12_ msateco_c2_ msat_c12_2_
tabstat aincc_ inc_a msat_c1_ msat_c2_ msat_c12_ msateco_c12_ msateco_c2_ msat_c12_2_ if gender ==0
tabstat aincc_ inc_a msat_c1_ msat_c2_ msat_c12_ msateco_c12_ msateco_c2_ msat_c12_2_ if gender ==1

dis  5.893632 -0.5 //= 5.393632
dis  5.893632 +0.5 //= 6.393632

dis  4.712939  -0.5 //= 4.212939
dis  4.712939  +0.5 //= 5.212939

dis  7.050271 -0.5 //= 6.550271
dis  7.050271 +0.5 //= 7.550271

med4way esup_ aincc_ msat_c12_ , yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(0)
med4way esup_ inc_ msat_c12_ , yreg(linear) mreg(linear) a0(0) a1(1) m(0)
med4way esup_ incc_ msat_c12_ , yreg(linear) mreg(linear) a0(0) a1(1) m(0)
med4way esup_ inccb_ msat_c12_ , yreg(linear) mreg(linear) a0(1) a1(3) m(0)


reg esup_ aincc_
reg esup_ inc_a

***************
*** 4-way decomposition
***************

*** 绝对收入
med4way esup_ aincc_ msat_c1_ , yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(4.49063) 
med4way esup_ aincc_ msat_c1_ if gender ==0, yreg(linear) mreg(linear) a0(4.212939) a1(5.212939) m(4.322716) 
med4way esup_ aincc_ msat_c1_ if gender ==1, yreg(linear) mreg(linear) a0(6.550271) a1(7.550271) m(4.6551) 

med4way esup_ aincc_ msat_c2_ , yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m( 4.495066) 
med4way esup_ aincc_ msat_c2_ if gender ==0, yreg(linear) mreg(linear) a0(4.212939) a1(5.212939) m(4.665308) 
med4way esup_ aincc_ msat_c2_ if gender ==1, yreg(linear) mreg(linear) a0(6.550271) a1(7.550271) m(4.328213) 

med4way esup_ aincc_ msat_c12_ , yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(0) 
med4way esup_ aincc_ msat_c12_ if gender ==0, yreg(linear) mreg(linear) a0(4.212939) a1(5.212939) m(-.3430597) 
med4way esup_ aincc_ msat_c12_ if gender ==1, yreg(linear) mreg(linear) a0(6.550271) a1(7.550271) m(.326715) 

med4way esup_ aincc_ msat_c12_2_ , yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(-.000628) 
med4way esup_ aincc_ msat_c12_2_ if gender ==0, yreg(linear) mreg(linear) a0(4.212939) a1(5.212939) m(-.0437023) 
med4way esup_ aincc_ msat_c12_2_ if gender ==1, yreg(linear) mreg(linear) a0(6.550271) a1(7.550271) m(.0415673) 

* 勉勉强强
med4way esup_ aincc_ msat_c12_c_ $covar , yreg(linear) mreg(logistic) a0(5.393632) a1(6.393632) m(0) 
med4way esup_ aincc_ msat_c12_c_ $covar if gender ==0, yreg(linear) mreg(logistic) a0(4.212939) a1(5.212939) m(0) 
med4way esup_ aincc_ msat_c12_c_ $covar if gender ==1, yreg(linear) mreg(logistic) a0(6.550271) a1(7.550271) m(0) 

med4way esup_ aincc_ msateco_c2_ , yreg(linear) mreg(linear) a0(5.393632) a1(6.393632) m(4.318924) 
med4way esup_ aincc_ msateco_c2_ if gender ==0, yreg(linear) mreg(linear) a0(4.212939) a1(5.212939) m(4.474288) 
med4way esup_ aincc_ msateco_c2_ if gender ==1, yreg(linear) mreg(linear) a0(6.550271) a1(7.550271) m(4.166728) 


*** 相对收入
med4way esup_ inc_a msat_c1_ , yreg(linear) mreg(linear) a0(0) a1(1) m(4.49063) 
med4way esup_ inc_a msat_c1_ if gender ==0, yreg(linear) mreg(linear) a0(0) a1(1) m(4.322716) 
med4way esup_ inc_a msat_c1_ if gender ==1, yreg(linear) mreg(linear) a0(0) a1(1) m(4.6551) 

med4way esup_ inc_a msat_c2_ , yreg(linear) mreg(linear) a0(0) a1(1) m(4.495066) 
med4way esup_ inc_a msat_c2_ if gender ==0, yreg(linear) mreg(linear) a0(0) a1(1) m(4.665308)
med4way esup_ inc_a msat_c2_ if gender ==1, yreg(linear) mreg(linear) a0(0) a1(1) m(4.328213)

med4way esup_ inc_a msat_c12_ $covar , yreg(linear) mreg(linear) a0(0) a1(1) m(0)
med4way esup_ inc_a msat_c12_ $covar if gender ==0, yreg(linear) mreg(linear) a0(0) a1(1) m(-.3430597)
med4way esup_ inc_a msat_c12_ $covar if gender ==1, yreg(linear) mreg(linear) a0(0) a1(1) m(.326715)

med4way esup_ aincc_ msat_c12_2_ $covar, yreg(linear) mreg(linear) a0(0) a1(1) m(-.000628) 
med4way esup_ aincc_ msat_c12_2_ $covar if gender ==0, yreg(linear) mreg(linear) a0(0) a1(1) m(-.0437023) 
med4way esup_ aincc_ msat_c12_2_ $covar if gender ==1, yreg(linear) mreg(linear) a0(0) a1(1) m(.0415673) 


* 只有这个显著
med4way esup_ inc_a msat_c12_c_ $covar , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ inc_a msat_c12_c_ $covar , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_ inc_a msat_c12_c_ $covar if gender ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ inc_a msat_c12_c_ $covar if gender ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_ inc_a msat_c12_c_ $covar if gender ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ inc_a msat_c12_c_ $covar if gender ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)


med4way esup_ inc_a msateco_c12_c_ $covar, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ inc_a msateco_c12_c_ $covar, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_ inc_a msateco_c12_c_ $covar if gender ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ inc_a msateco_c12_c_ $covar if gender ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_ inc_a msateco_c12_c_ $covar if gender ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ inc_a msateco_c12_c_ $covar if gender ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)



*** 相对收入
/*
med4way esup_ actor_employ_ msat_c2_c_ $covar, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ actor_employ_ msat_c2_c_ $covar, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_ actor_employ_ msat_c2_c_ $covar if gender ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ actor_employ_ msat_c2_c_ $covar if gender ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_ actor_employ_ msat_c2_c_ $covar if gender ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_ actor_employ_ msat_c2_c_ $covar if gender ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
*/




*导出csv格式
/*
export delimited id fid_ ///
inc_a ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
year clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
year_i2 year_i3 ///
using "$data\causal_mediation_18_22_unbal.csv", nolabel replace  // 没有值标签
*/
 
 
*/ 

export delimited id fid_ ///
esup_ inc_a inc_a5 inc_ ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_c5_ msateco_c12_c5_ msathw_c12_c5_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
msat_c21_c_ msateco_c21_c_ msathw_c21_c_ ///
msat_c21_c5_ msateco_c21_c5_ msathw_c21_c5_ ///
msat_c21_ msateco_c21_ msathw_c21_ ///
msat_c1_ msat_c2_ ///
msateco_c1_ msateco_c2_ ///
msathw_c1_ msathw_c2_ ///
dwm_ gender_ aage_ actor_edu2_ actor_siops_ child_ childborn_ aincc_ ahw_ ahk_ urban_ /// agegap_ sibling_ atrust_
prtmarr_ prtcor_ prtgender_ prtage_ prtedu_ /// prtchildn_ prtparty_ prthk_  ///
lifetime_  fmlincc_ ///
year_i2 year_i3 ///
using "$data\causal_mediation_18_22_unbal.csv", nolabel replace  // 没有值标签
}
save "$pre_data\causal_mediation_18_22_unbal.dta",replace

* 一阶差分/固定效应模型试验证
xtset id year  
xtreg msat_c12_ aincc_ i.year_n
xtreg msat_c1_ aincc_ i.year_n
xtreg msat_c2_ aincc_ i.year_n
xtreg msateco_c2_ aincc_ i.year_n

xtreg esup_ msat_c12_ aincc_ i.year_n
xtreg esup_ msat_c1_ aincc_ i.year_n
xtreg esup_ msat_c2_ aincc_ i.year_n
xtreg esup_ msateco_c2_ aincc_ i.year_n

preserve
tab1 year_n,miss nolab
drop if year_n==2
xtset id year  
xtreg msat_c12_ aincc_ i.year_n
xtreg msat_c1_ aincc_ i.year_n
xtreg msat_c2_ aincc_ i.year_n
xtreg msateco_c2_ aincc_ i.year_n

xtreg esup_ msat_c12_ aincc_ i.year_n
xtreg esup_ msat_c1_ aincc_ i.year_n
xtreg esup_ msat_c2_ aincc_ i.year_n
xtreg esup_ msateco_c2_ aincc_ i.year_n

restore


/* ============================================================
[模块二] 2018-2020 两期平衡面板（一阶差分）
功能：从三期面板中取2018-2020同时观测个体，reshape为宽格后
      构建所有关键变量的跨期差分指标（量变/质变），输出分析数据。
差分命名约定（以 aincc 为例，其余变量均遵循同一规律）：
  _1 : 连续量变  = 变量_末期 - 变量_初期
  _2 : 质变-改善 = 1 if 量变 > 0
  _3 : 质变-升级 = 1 if 跨越阈值（如相对收入从≤配偶升至>配偶）
  _5 : 质变-恶化 = 1 if 量变 < 0
  _6 : 质变-降级 = 1 if 反向跨越阈值
输入：causal_mediation_18_22_unbal.dta
输出：causal_mediation_18&20_bal.dta/.csv / _rename.dta（后缀改为begin/end）
============================================================ */
{
use "$pre_data\causal_mediation_18_22_unbal.dta",clear

tab1 year_n,miss

*2018-2020 两期平衡面板（剔除2022年观测）
drop if year==2022
tab1 year_n,miss


***** Declare data to be panel data *****
xtset id year  // 非完全平衡面板
sort id year

****   New variables needed below       **********
*bysort id: egen treat = max(marry)        //indicator for treatment group = which id's marry state is marry==1 
bysort id (year): gen pynr    = _n        //person-year ID (within person): 人年ID, 1、2、3循环
bysort id:        gen pycount = _N        // of person-years (within person): 人年ID总量

order id fid_ pynr pycount

keep if pycount==2
count
codebook id



keep ///
id fid_ ///
inc_a inc_a5 ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_c5_ msateco_c12_c5_ msathw_c12_c5_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
msat_c21_c_ msateco_c21_c_ msathw_c21_c_ ///
msat_c21_c5_ msateco_c21_c5_ msathw_c21_c5_ ///
msat_c21_ msateco_c21_ msathw_c21_ ///
year clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ urban_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
actor_employ_ partner_employ_ ///
nonhousing_debts_scale_ ///
total_debts_scale_ /// 
qp201_actor_ /// 自评健康
qp202_actor_ /// 自评健康变化
fincome_cpi //

reshape wide fid_ ///
inc_a inc_a5 ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_c5_ msateco_c12_c5_ msathw_c12_c5_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
msat_c21_c_ msateco_c21_c_ msathw_c21_c_ ///
msat_c21_c5_ msateco_c21_c5_ msathw_c21_c5_ ///
msat_c21_ msateco_c21_ msathw_c21_ ///
clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ urban_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
actor_employ_ partner_employ_ ///
nonhousing_debts_scale_ ///
total_debts_scale_ /// 
qp201_actor_ /// 自评健康
qp202_actor_ /// 自评健康变化
fincome_cpi_ ///
,i(id) j(year) 

tab fincome_cpi_2018,miss //

** 非房贷借款变化
*量变
gen nonhousing_debts_1 = nonhousing_debts_scale_2020 - nonhousing_debts_scale_2018
*质变(非房贷借款增加与否: 0未增加, 1增加)
gen nonhousing_debts_2 = 0
replace nonhousing_debts_2 = 1 if nonhousing_debts_1>0
*质变(非房贷借款减少与否: 0未减少, 1减少)
gen nonhousing_debts_5 = 0
replace nonhousing_debts_5 = 1 if nonhousing_debts_1<0

** 总借款变化
*量变
gen total_debts_1 = total_debts_scale_2020 - total_debts_scale_2018
*质变(总借款增加与否: 0未增加, 1增加)
gen total_debts_2 = 0
replace total_debts_2 = 1 if total_debts_1>0
*质变(总借款减少与否: 0未减少, 1减少)
gen total_debts_5 = 0
replace total_debts_5 = 1 if total_debts_1<0


** 自评健康变化(逆向编码:1非常满意,5非常不满意)
*量变
gen shealth_1 = qp201_actor_2020 - qp201_actor_2018
*质变(自评健康增加与否: 0未增加, 1增加)
gen shealth_2 = 0
replace shealth_2 = 1 if shealth_1<0
*质变(自评健康减少与否: 0未减少, 1减少)
gen shealth_5 = 0
replace shealth_5 = 1 if shealth_1>0

*质变(自评健康变好: 0未变好, 1变好)
gen schealth_2 = 0
replace schealth_2 = 1 if qp202_actor_2020==1
*质变(自评健康变差: 0未变差, 1变差)
gen schealth_5 = 0
replace schealth_5 = 1 if qp202_actor_2020==5



** 绝对收入变化
*量变
gen aincc_1 = aincc_2020 - aincc_2018
*质变(绝对收入增加与否: 0未增加, 1增加)
gen aincc_2 = 0
replace aincc_2 = 1 if aincc_1>0
*质变(绝对收入减少与否: 0未减少, 1减少)
gen aincc_5 = 0
replace aincc_5 = 1 if aincc_1<0

** 相对收入变化
*量变
gen inc_1 = inc_2020 - inc_2018
*质变(相对收入改善与否: 0未改善, 1改善)
gen inc_2 = 0
replace inc_2 = 1 if inc_1>0
*质变(相对收入升级与否: 0小于等于配偶, 1高于配偶)
gen inc_3 = 0
replace inc_3 = 1 if inc_a2018==0 & inc_a2020==1
*质变(相对收入恶化与否: 0未恶化, 1恶化)
gen inc_5 = 0
replace inc_5 = 1 if inc_1<0
*质变(相对收入降级与否: 0大于等于配偶, 1低于配偶)
gen inc_6 = 0
replace inc_6 = 1 if inc_a52018==0 & inc_a52020==1

** 代际经济支持变化
*量变
gen esup_1 = esup_2020 - esup_2018
*质变(绝对代际支持增加与否: 0未增加, 1增加)
gen esup_2 = 0
replace esup_2 = 1 if esup_1>0
*质变(绝对代际支持减少与否: 0未减少, 1减少)
gen esup_5 = 0
replace esup_5 = 1 if esup_1<0



** 本人婚姻满意度变化
*量变
gen msat_c1_1 = msat_c1_2020 - msat_c1_2018
*质变(本人婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c1_2 = 0
replace msat_c1_2 = 1 if msat_c1_1>0
*质变(本人婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c1_5 = 0
replace msat_c1_5 = 1 if msat_c1_1<0

** 本人收入满意度变化
*量变
gen msateco_c1_1 = msateco_c1_2020 - msateco_c1_2018
*质变(本人收入满意度改善与否: 0未改善, 1改善)
gen msateco_c1_2 = 0
replace msateco_c1_2 = 1 if msateco_c1_1>0
*质变(本人收入满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c1_5 = 0
replace msateco_c1_5 = 1 if msateco_c1_1<0

** 本人家务满意度变化
*量变
gen msathw_c1_1 = msathw_c1_2020 - msathw_c1_2018
*质变(本人家务满意度改善与否: 0未改善, 1改善)
gen msathw_c1_2 = 0
replace msathw_c1_2 = 1 if msathw_c1_1>0
*质变(本人家务满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c1_5 = 0
replace msathw_c1_5 = 1 if msathw_c1_1<0


** 配偶婚姻满意度变化
*量变
gen msat_c2_1 = msat_c2_2020 - msat_c2_2018
*质变(配偶婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c2_2 = 0
replace msat_c2_2 = 1 if msat_c2_1>0
*质变(配偶婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c2_5 = 0
replace msat_c2_5 = 1 if msat_c2_1<0

** 配偶收入满意度变化
*量变
gen msateco_c2_1 = msateco_c2_2020 - msateco_c2_2018
*质变(配偶收入满意度改善与否: 0未改善, 1改善)
gen msateco_c2_2 = 0
replace msateco_c2_2 = 1 if msateco_c2_1>0
*质变(配偶收入满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c2_5 = 0
replace msateco_c2_5 = 1 if msateco_c2_1<0

** 配偶家务满意度变化
*量变
gen msathw_c2_1 = msathw_c2_2020 - msathw_c2_2018
*质变(配偶家务满意度改善与否: 0未改善, 1改善)
gen msathw_c2_2 = 0
replace msathw_c2_2 = 1 if msathw_c2_1>0
*质变(配偶家务满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c2_5 = 0
replace msathw_c2_5 = 1 if msathw_c2_1<0



** 本人相对婚姻满意度变化
*量变
gen msat_c12_1 = msat_c12_2020 - msat_c12_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c12_2 = 0
replace msat_c12_2 = 1 if msat_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msat_c12_3 = 0
replace msat_c12_3 = 1 if msat_c12_c_2018==0 & msat_c12_c_2020==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c12_5 = 0
replace msat_c12_5 = 1 if msat_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msat_c12_6 = 0
replace msat_c12_6 = 1 if msat_c12_c5_2018==0 & msat_c12_c5_2020==1


** 本人相对收入满意度变化
*量变
gen msateco_c12_1 = msateco_c12_2020 - msateco_c12_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msateco_c12_2 = 0
replace msateco_c12_2 = 1 if msateco_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msateco_c12_3 = 0
replace msateco_c12_3 = 1 if msateco_c12_c_2018==0 & msateco_c12_c_2020==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c12_5 = 0
replace msateco_c12_5 = 1 if msateco_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msateco_c12_6 = 0
replace msateco_c12_6 = 1 if msateco_c12_c5_2018==0 & msateco_c12_c5_2020==1


** 本人相对家务满意度变化
*量变
gen msathw_c12_1 = msathw_c12_2020 - msathw_c12_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msathw_c12_2 = 0
replace msathw_c12_2 = 1 if msathw_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msathw_c12_3 = 0
replace msathw_c12_3 = 1 if msathw_c12_c_2018==0 & msathw_c12_c_2020==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c12_5 = 0
replace msathw_c12_5 = 1 if msathw_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msathw_c12_6 = 0
replace msathw_c12_6 = 1 if msathw_c12_c5_2018==0 & msathw_c12_c5_2020==1





** 配偶相对婚姻满意度变化
*量变
gen msat_c21_1 = msat_c21_2020 - msat_c21_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c21_2 = 0
replace msat_c21_2 = 1 if msat_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msat_c21_3 = 0
replace msat_c21_3 = 1 if msat_c21_c_2018==0 & msat_c21_c_2020==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c21_5 = 0
replace msat_c21_5 = 1 if msat_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msat_c21_6 = 0
replace msat_c21_6 = 1 if msat_c21_c5_2018==0 & msat_c21_c5_2020==1


** 配偶相对收入满意度变化
*量变
gen msateco_c21_1 = msateco_c21_2020 - msateco_c21_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msateco_c21_2 = 0
replace msateco_c21_2 = 1 if msateco_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msateco_c21_3 = 0
replace msateco_c21_3 = 1 if msateco_c21_c_2018==0 & msateco_c21_c_2020==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c21_5 = 0
replace msateco_c21_5 = 1 if msateco_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msateco_c21_6 = 0
replace msateco_c21_6 = 1 if msateco_c21_c5_2018==0 & msateco_c21_c5_2020==1


** 配偶相对家务满意度变化
*量变
gen msathw_c21_1 = msathw_c21_2020 - msathw_c21_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msathw_c21_2 = 0
replace msathw_c21_2 = 1 if msathw_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msathw_c21_3 = 0
replace msathw_c21_3 = 1 if msathw_c21_c_2018==0 & msathw_c21_c_2020==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c21_5 = 0
replace msathw_c21_5 = 1 if msathw_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msathw_c21_6 = 0
replace msathw_c21_6 = 1 if msathw_c21_c5_2018==0 & msathw_c21_c5_2020==1


tab1 msat_c21_2 msat_c21_3 msat_c21_5 msat_c21_6 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ,miss











*** 控制变量

* TICs
sum ///
gender_2018 aage_2018 actor_edu2_2018 ahk_2018 /// agegap_ sibling_ atrust_
prtgender_2018 prtage_2018 prtedu_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
lifetime_2018 //

* TVCs 两期变化
sum ///
dwm_2018 actor_siops_2018 child_2018 aincc_2018 ahw_2018 ahk_2018  /// agegap_ sibling_ atrust_
prtmarr_2018 prtcor_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
fmlincc_2018 //

	 

** 父辈支持变化(0其他, 1无支持变有支持)
gen dwm_1 = 0
replace dwm_1 = 1 if dwm_2018==0 & dwm_2020==1

**子女数量变化
*量变
gen child_1 = child_2020 - child_2018
*质变(子女数量增加与否: 0未增加, 1增加)
gen child_2 = 0
replace child_2 = 1 if child_1>0 
*质变(子女数量减少与否: 0未减少, 1减少)
gen child_5 = 0
replace child_5 = 1 if child_1<0 

**绝对家务变化
*量变
gen ahw_1 = ahw_2020 - ahw_2018
*质变(绝对家务增加与否: 0未增加, 1增加)
gen ahw_2 = 0
replace ahw_2 = 1 if ahw_1>0 
*质变(绝对家务减少与否: 0未减少, 1减少)
gen ahw_5 = 0
replace ahw_5 = 1 if ahw_1<0 

** 相对家务变化
*量变
gen hw_1 = hw_2020 - hw_2018
*质变(相对家务改善与否: 0未改善, 1改善)
gen hw_2 = 0
replace hw_2 = 1 if hw_1>0
*质变(相对家务升级与否: 0小于等于配偶, 1高于配偶)
gen hw_3 = 0
replace hw_3 = 1 if hw_2018<=0 & hw_2020>0
*质变(相对家务恶化与否: 0未恶化, 1恶化)
gen hw_5 = 0
replace hw_5 = 1 if hw_1<0
*质变(相对家务降级与否: 0大于等于配偶, 1低于配偶)
gen hw_6 = 0
replace hw_6 = 1 if hw_2018>=0 & hw_2020<0

**绝对职业声望变化
*量变
gen actor_siops_1 = actor_siops_2020 - actor_siops_2018
*质变(绝对职业声望增加与否: 0未增加, 1增加)
gen actor_siops_2 = 0
replace actor_siops_2 = 1 if actor_siops_1>0 
*质变(绝对职业声望减少与否: 0未减少, 1减少)
gen actor_siops_5 = 0
replace actor_siops_5 = 1 if actor_siops_1<0 
 
 
** 父母婚姻变化(0其他, 1在婚变失婚)
gen prtmarr_1 = 0
replace prtmarr_1 = 1 if prtmarr_2018==0 & prtmarr_2020==1

** 父母同住变化(0其他, 1非同住变同住)
gen prtcor_1 = 0
replace prtcor_1 = 1 if prtcor_2018==0 & prtcor_2020==1
** 父母同住变化(0其他, 1同住变非同住)
gen reside_ind_1 = 0
replace reside_ind_1 = 1 if prtcor_2018==1 & prtcor_2020==0

** 家庭收入变化
gen fmlincc_1 = fmlincc_2020 - fmlincc_2018
*质变(家庭收入增加与否: 0未增加, 1增加)
gen fmlincc_2 = 0
replace fmlincc_2 = 1 if fmlincc_1>0 
*质变(家庭收入减少与否: 0未减少, 1减少)
gen fmlincc_5 = 0
replace fmlincc_5 = 1 if fmlincc_1<0 

*中介模型控制变量(增加→增加→增加)
sum ///
esup_1 esup_2 inc_1 inc_2 inc_3 msat_c12_1 msat_c12_2 msat_c12_3 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 ///
msat_c12_1 msat_c12_2 msat_c12_3 ///
gender_2018 aage_2018 actor_edu2_2018 actor_siops_1 actor_siops_2  ///
child_1 child_2 ahw_1 ahw_2 ahk_2018 ///
lifetime_2018 fmlincc_1 fmlincc_2

*结果模型控制变量(增加→增加→增加)		 
sum ///
msat_c1_1 msat_c1_2 msat_c2_1 msat_c2_2 ///
dwm_1 gender_2020 aage_2020 actor_edu2_2020 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2020 ///
prtmarr_1 prtcor_1 prtgender_2020 prtage_2020 prtedu_2020 ///
lifetime_2020 fmlincc_1 fmlincc_2	


*中介模型控制变量(减少→减少→减少)
sum ///
esup_1 esup_5 inc_1 inc_5 inc_6 msat_c12_1 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_5 msateco_c12_6 ///
msat_c12_1 msat_c12_5 msat_c12_6 ///
gender_2018 aage_2018 actor_edu2_2018 actor_siops_1 actor_siops_2  ///
child_1 child_2 ahw_1 ahw_2 ahk_2018 ///
lifetime_2018 fmlincc_1 fmlincc_2

*结果模型控制变量(减少→减少→减少)		 
sum ///
msat_c1_1 msat_c1_5 msat_c2_1 msat_c2_5 ///
dwm_1 gender_2020 aage_2020 actor_edu2_2020 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2020 ///
prtmarr_1 prtcor_1 prtgender_2020 prtage_2020 prtedu_2020 ///
lifetime_2020 fmlincc_1 fmlincc_2	





global covar ///
dwm_1 gender_2020 aage_2020 actor_edu2_2020 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2020 ///
prtmarr_1 prtcor_1 prtgender_2020 prtage_2020 prtedu_2020 ///
lifetime_2020 fmlincc_1 fmlincc_2	

sum $covar
/*
*** 收入变化→相对婚姻满意度变化→代际经济支持变化
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2020 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2020 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 esup_2018 gender_2018 prtgender_2020 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)


med4way esup_2 aincc_2 msat_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 esup_2018 gender_2018 prtgender_2020 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
* 只有这个显著
med4way esup_2 aincc_2 msat_c2_2 esup_2018  gender_2018 prtgender_2020 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 esup_2018 gender_2018 prtgender_2020 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
 

med4way esup_2 aincc_2 msateco_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2020 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
* 只有这个显著
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2020 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_2 aincc_2 msat_c12_3 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2020 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2020 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2020 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2020 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_1 aincc_2 msat_c1_2 gender_2018 prtgender_2020, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c1_2 gender_2018 prtgender_2020 if gender_2018==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c1_2 gender_2018 prtgender_2020 if gender_2018==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

med4way esup_1 aincc_2 msat_c2_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 if gender_2018==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 if gender_2018==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

med4way esup_1 aincc_2 msat_c12_3 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 if gender_2018==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 if gender_2018==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)






med4way esup_2 inc_3 msat_c1_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)


med4way esup_2 inc_3 msat_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c2_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



global covar ///
dwm_1 gender_2020 aage_2020 actor_edu2_2020 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2020 ///
prtmarr_1 prtcor_1 prtgender_2020 prtage_2020 prtedu_2020 ///
lifetime_2020 fmlincc_1 fmlincc_2	

global covar ///
        msat_c12_2018 ///
        msat_c1_2  msat_c2_2 ///
        dwm_2020  gender_2020  aage_2020  actor_edu2_2020  actor_siops_2 ///
        child_2  aincc_2  ahw_2  ahk_2020  ///
        prtmarr_1  prtcor_1  prtgender_2020  prtage_2020  prtedu_2020 ///
        lifetime_2020  fmlincc_2	//

sum $covar

*** 相对婚姻满意度
med4way esup_2 inc_3 msat_c12_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)




med4way esup_2 inc_3 msat_c12_3 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



*** 收入满意度
med4way esup_2 inc_3 msateco_c2_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



*** 收入满意度
med4way esup_2 inc_3 msateco_c1_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_1 aincc_2 msat_c1_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

logit esup_2 aincc_2  prtage_2020 prtgender_2020 if gender_2018==1

logit esup_2 inc_3  prtage_2020 prtgender_2020 if gender_2018==1 

reg esup_1 aincc_1 prtage_2020 
reg esup_1 aincc_1 prtage_2020 , vce(robust)
reg esup_1 aincc_1  prtage_2020, vce(cluster fid_2018)

logit esup_2 inc_3
logit esup_2 inc_2
reg esup_1 inc_1


logit esup_2  dwm_2020
tab1 esup_2 dwm_1

preserve
tab1 actor_employ_* partner_employ_*,miss
count if actor_employ_2018==1 & actor_employ_2020==1 & partner_employ_2018==1 & partner_employ_2020==1 
keep if actor_employ_2018==1 & actor_employ_2020==1 & partner_employ_2018==1 & partner_employ_2020==1 

logit esup_2 aincc_2
reg esup_1 aincc_1

logit esup_2 inc_3
logit esup_2 inc_2
reg esup_1 inc_1

restore


global covar2020 ///
dwm_2020 gender_2020 aage_2020 actor_edu2_2020 actor_siops_2020 child_2020 childborn_2020 aincc_2020 ahw_2020 ahk_2020  /// agegap_ sibling_ atrust_
 prtmarr_2020 prtcor_2020 prtgender_2020 prtage_2020 prtedu_2020 /// prtchildn_2020 prtparty_2020 prthk_2020  ///
lifetime_2020 fmlincc_2020 //

sum $covar2020

global covar2018 ///
dwm_2018 gender_2018 aage_2018 actor_edu2_2018 actor_siops_2018 child_2018 childborn_2018 aincc_2018 ahw_2018 ahk_2018  /// agegap_ sibling_ atrust_
 prtmarr_2018 prtcor_2018 prtgender_2018 prtage_2018 prtedu_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
lifetime_2018  fmlincc_2018 //

sum $covar2018

tabstat aincc_2018 msat_c1_2018 msat_c2_2018
dis 5.733915-0.5
dis 5.733915+0.5

* 不显著
med4way esup_2020 aincc_2018 msat_c1_2018 $covar2020 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.5379)
med4way esup_2020 aincc_2018 msat_c2_2018 $covar2020 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.55492)
med4way esup_2020 inc_a2018 msat_c1_2018 $covar2020 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.5379)
med4way esup_2020 inc_a2018 msat_c2_2018 $covar2020 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.55492)

* 只有这个显著
med4way esup_2020 inc_a2018 msat_c12_c_2018 $covar2020 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a2018 msat_c12_c_2018 $covar2020 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2020 inc_a2018 msat_c12_c_2018 $covar2020 if gender_2020 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a2018 msat_c12_c_2018 $covar2020 if gender_2020 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2020 inc_a2018 msat_c12_c_2018 $covar2020 if gender_2020 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a2018 msat_c12_c_2018 $covar2020 if gender_2020 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

gen inc_a201820 = 0 
replace inc_a201820 = 1 if inc_a2018==1 & inc_a2020==1

* 不显著
med4way esup_2020 inc_a201820 msat_c12_c_2020 $covar2020 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a201820 msat_c12_c_2018 $covar2020 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2020 inc_a201820 msat_c12_c_2020 $covar2020 if gender_2020 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a201820 msat_c12_c_2018 $covar2020 if gender_2020 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2020 inc_a201820 msat_c12_c_2020 $covar2020 if gender_2020 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a201820 msat_c12_c_2020 $covar2020 if gender_2020 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
*/

*导出csv格式
export delimited id fid_2018 fid_2020 ///
esup_2018 inc_a2018 inc_a52018 inc_2018 ///
msat_c12_c_2018 msateco_c12_c_2018 msathw_c12_c_2018 /// 相对满意度(增加与否)
msat_c12_c5_2018 msateco_c12_c5_2018 msathw_c12_c5_2018 /// 相对满意度(减少与否)
msat_c12_2018 msateco_c12_2018 msathw_c12_2018 ///
msat_c1_2018 msat_c2_2018 /// 
msateco_c1_2018 msateco_c2_2018 ///
msathw_c1_2018 msathw_c2_2018 ///
dwm_2018 gender_2018 aage_2018 actor_edu2_2018 actor_siops_2018 child_2018 childborn_2018 aincc_2018 ahw_2018 ahk_2018 urban_2018  /// agegap_ sibling_ atrust_
prtmarr_2018 prtcor_2018 prtgender_2018 prtage_2018 prtedu_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
lifetime_2018  fmlincc_2018 ///
esup_2020 inc_a2020 inc_2020 ///
msat_c12_c_2020 msateco_c12_c_2020 msathw_c12_c_2020 /// 相对满意度(增加与否)
msat_c12_c5_2020 msateco_c12_c5_2020 msathw_c12_c5_2020 /// 相对满意度(减少与否)
msat_c12_2020 msateco_c12_2020 msathw_c12_2020 ///
msat_c1_2020 msat_c2_2020 ///
msateco_c1_2020 msateco_c2_2020 ///
msathw_c1_2020 msathw_c2_2020 ///
dwm_2020 gender_2020 aage_2020 actor_edu2_2020 actor_siops_2020 child_2020 childborn_2020 aincc_2020 ahw_2020 ahk_2020 urban_2020  /// agegap_ sibling_ atrust_
prtmarr_2020 prtcor_2020 prtgender_2020 prtage_2020 prtedu_2020 /// prtchildn_2020 prtparty_2020 prthk_2020  ///
lifetime_2020 fmlincc_2020 ///
esup_1 esup_2 esup_5 aincc_1 aincc_2 aincc_5 inc_1 inc_2 inc_3 inc_5 inc_6 msat_c12_1 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 msateco_c12_5 msateco_c12_6 ///
msathw_c12_1 msathw_c12_2 msathw_c12_3 msathw_c12_5 msathw_c12_6 ///
msat_c1_1 msat_c1_2 msat_c1_5 msat_c2_1 msat_c2_2 msat_c2_5 ///
msateco_c1_1 msateco_c1_2 msateco_c1_5 msateco_c2_1 msateco_c2_2 msateco_c2_5 ///
msathw_c1_1 msathw_c1_2 msathw_c1_5 msathw_c2_1 msathw_c2_2 msathw_c2_5 ///
dwm_1 actor_siops_1 actor_siops_2 actor_siops_5 ///
child_1 child_2 ahw_1 ahw_2 ahw_5 ///
prtmarr_1 prtcor_1 fmlincc_1 fmlincc_2 fmlincc_5 ///
nonhousing_debts_1 nonhousing_debts_2 nonhousing_debts_5 ///
total_debts_1 total_debts_2 total_debts_5 ///
shealth_1 shealth_2 shealth_5 ///
schealth_2 schealth_5 ///
reside_ind_1 ///
using "$data\causal_mediation_18&20_bal.csv", nolabel replace  // 没有值标签

logit msat_c12_c_2018 inc_a2018 msateco_c12_c_2018 msathw_c12_c_2018

logit msat_c12_c_2018 inc_a2018 msateco_c12_2018 msathw_c12_2018

reg esup_2020 inc_a2018 aincc_2018 msat_c12_c_2018 msat_c12_2018 msat_c1_2018 msat_c2_2018

reg esup_2020 inc_a2018 msat_c12_c_2018 msat_c1_2018 msat_c2_2018
reg esup_2020 inc_a2018 msat_c12_c_2018 msat_c1_2018 msat_c2_2018
reg esup_2020 inc_a2018 msat_c12_c_2018 msat_c1_2018 msat_c2_2018
}
save "$pre_data\causal_mediation_18&20_bal.dta",replace
rename (*2018 *2020) (*begin *end)
save "$pre_data\causal_mediation_18&20_bal_rename.dta",replace
  
 
/* ============================================================
[模块三] 2020-2022 两期平衡面板（一阶差分）
功能：与模块二结构完全对称，差分方向改为 变量_2022 - 变量_2020。
差分命名约定与模块二相同（_1/_2/_3/_5/_6）。
输入：causal_mediation_18_22_unbal.dta
输出：causal_mediation_20&22_bal.dta/.csv / _rename.dta（后缀改为begin/end）
============================================================ */
{
use "$pre_data\causal_mediation_18_22_unbal.dta",clear

tab1 year_n,miss

*2020-2022 两期平衡面板（剔除2018年观测）
drop if year==2018
tab1 year_n,miss


***** Declare data to be panel data *****
xtset id year  // 非完全平衡面板
sort id year

****   New variables needed below       **********
*bysort id: egen treat = max(marry)        //indicator for treatment group = which id's marry state is marry==1 
bysort id (year): gen pynr    = _n        //person-year ID (within person): 人年ID, 1、2、3循环
bysort id:        gen pycount = _N        // of person-years (within person): 人年ID总量

order id fid_ pynr pycount

keep if pycount==2
count
codebook id



keep ///
id fid_ ///
inc_a inc_a5 ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_c5_ msateco_c12_c5_ msathw_c12_c5_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
msat_c21_c_ msateco_c21_c_ msathw_c21_c_ ///
msat_c21_c5_ msateco_c21_c5_ msathw_c21_c5_ ///
msat_c21_ msateco_c21_ msathw_c21_ ///
year clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ urban_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
actor_employ_ partner_employ_ ///
nonhousing_debts_scale_ ///
total_debts_scale_ /// 
qp201_actor_ /// 自评健康
qp202_actor_ /// 自评健康变化
fincome_cpi_ //

reshape wide fid_ ///
inc_a inc_a5 ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_c5_ msateco_c12_c5_ msathw_c12_c5_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
msat_c21_c_ msateco_c21_c_ msathw_c21_c_ ///
msat_c21_c5_ msateco_c21_c5_ msathw_c21_c5_ ///
msat_c21_ msateco_c21_ msathw_c21_ ///
clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ urban_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
actor_employ_ partner_employ_ ///
nonhousing_debts_scale_ ///
total_debts_scale_ /// 
qp201_actor_ /// 自评健康
qp202_actor_ /// 自评健康变化
fincome_cpi_ ///
,i(id) j(year) 


tab fincome_cpi_2020,miss //

** 非房贷借款变化
*量变
gen nonhousing_debts_1 = nonhousing_debts_scale_2022 - nonhousing_debts_scale_2020
*质变(非房贷借款增加与否: 0未增加, 1增加)
gen nonhousing_debts_2 = 0
replace nonhousing_debts_2 = 1 if nonhousing_debts_1>0
*质变(非房贷借款减少与否: 0未减少, 1减少)
gen nonhousing_debts_5 = 0
replace nonhousing_debts_5 = 1 if nonhousing_debts_1<0

** 总借款变化
*量变
gen total_debts_1 = total_debts_scale_2022 - total_debts_scale_2020
*质变(总借款增加与否: 0未增加, 1增加)
gen total_debts_2 = 0
replace total_debts_2 = 1 if total_debts_1>0
*质变(总借款减少与否: 0未减少, 1减少)
gen total_debts_5 = 0
replace total_debts_5 = 1 if total_debts_1<0


** 自评健康变化(1非常满意,5非常不满意)
*量变
gen shealth_1 = qp201_actor_2022 - qp201_actor_2020
*质变(自评健康增加与否: 0未增加, 1增加)
gen shealth_2 = 0
replace shealth_2 = 1 if shealth_1<0
*质变(自评健康减少与否: 0未减少, 1减少)
gen shealth_5 = 0
replace shealth_5 = 1 if shealth_1>0

*质变(自评健康变好: 0未变好, 1变好)
gen schealth_2 = 0
replace schealth_2 = 1 if qp202_actor_2022==1
*质变(自评健康变差: 0未变差, 1变差)
gen schealth_5 = 0
replace schealth_5 = 1 if qp202_actor_2022==5






** 绝对收入变化
*量变
gen aincc_1 = aincc_2022 - aincc_2020
*质变(绝对收入增加与否: 0未增加, 1增加)
gen aincc_2 = 0
replace aincc_2 = 1 if aincc_1>0
*质变(绝对收入减少与否: 0未减少, 1减少)
gen aincc_5 = 0
replace aincc_5 = 1 if aincc_1<0

** 相对收入变化
*量变
gen inc_1 = inc_2022 - inc_2020
*质变(相对收入改善与否: 0未改善, 1改善)
gen inc_2 = 0
replace inc_2 = 1 if inc_1>0
*质变(相对收入升级与否: 0小于等于配偶, 1高于配偶)
gen inc_3 = 0
replace inc_3 = 1 if inc_a2020==0 & inc_a2022==1
*质变(相对收入恶化与否: 0未恶化, 1恶化)
gen inc_5 = 0
replace inc_5 = 1 if inc_1<0
*质变(相对收入降级与否: 0大于等于配偶, 1低于配偶)
gen inc_6 = 0
replace inc_6 = 1 if inc_a52020==0 & inc_a52022==1

** 代际经济支持变化
*量变
sum esup_2022 esup_2020
tab1 esup_2022 esup_2020,miss
gen esup_1 = esup_2022 - esup_2020
*质变(绝对代际支持增加与否: 0未增加, 1增加)
gen esup_2 = 0
replace esup_2 = 1 if esup_1>0
*质变(绝对代际支持减少与否: 0未减少, 1减少)
gen esup_5 = 0
replace esup_5 = 1 if esup_1<0



** 本人婚姻满意度变化
*量变
gen msat_c1_1 = msat_c1_2022 - msat_c1_2020
*质变(本人婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c1_2 = 0
replace msat_c1_2 = 1 if msat_c1_1>0
*质变(本人婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c1_5 = 0
replace msat_c1_5 = 1 if msat_c1_1<0

** 本人收入满意度变化
*量变
gen msateco_c1_1 = msateco_c1_2022 - msateco_c1_2020
*质变(本人收入满意度改善与否: 0未改善, 1改善)
gen msateco_c1_2 = 0
replace msateco_c1_2 = 1 if msateco_c1_1>0
*质变(本人收入满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c1_5 = 0
replace msateco_c1_5 = 1 if msateco_c1_1<0

** 本人家务满意度变化
*量变
gen msathw_c1_1 = msathw_c1_2022 - msathw_c1_2020
*质变(本人家务满意度改善与否: 0未改善, 1改善)
gen msathw_c1_2 = 0
replace msathw_c1_2 = 1 if msathw_c1_1>0
*质变(本人家务满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c1_5 = 0
replace msathw_c1_5 = 1 if msathw_c1_1<0


** 配偶婚姻满意度变化
*量变
gen msat_c2_1 = msat_c2_2022 - msat_c2_2020
*质变(配偶婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c2_2 = 0
replace msat_c2_2 = 1 if msat_c2_1>0
*质变(配偶婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c2_5 = 0
replace msat_c2_5 = 1 if msat_c2_1<0

** 配偶收入满意度变化
*量变
gen msateco_c2_1 = msateco_c2_2022 - msateco_c2_2020
*质变(配偶收入满意度改善与否: 0未改善, 1改善)
gen msateco_c2_2 = 0
replace msateco_c2_2 = 1 if msateco_c2_1>0
*质变(配偶收入满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c2_5 = 0
replace msateco_c2_5 = 1 if msateco_c2_1<0

** 配偶家务满意度变化
*量变
gen msathw_c2_1 = msathw_c2_2022 - msathw_c2_2020
*质变(配偶家务满意度改善与否: 0未改善, 1改善)
gen msathw_c2_2 = 0
replace msathw_c2_2 = 1 if msathw_c2_1>0
*质变(配偶家务满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c2_5 = 0
replace msathw_c2_5 = 1 if msathw_c2_1<0




** 本人相对婚姻满意度变化
*量变
gen msat_c12_1 = msat_c12_2022 - msat_c12_2020
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c12_2 = 0
replace msat_c12_2 = 1 if msat_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msat_c12_3 = 0
replace msat_c12_3 = 1 if msat_c12_c_2020==0 & msat_c12_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c12_5 = 0
replace msat_c12_5 = 1 if msat_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msat_c12_6 = 0
replace msat_c12_6 = 1 if msat_c12_c5_2020==0 & msat_c12_c5_2022==1


** 本人相对收入满意度变化
*量变
gen msateco_c12_1 = msateco_c12_2022 - msateco_c12_2020
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msateco_c12_2 = 0
replace msateco_c12_2 = 1 if msateco_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msateco_c12_3 = 0
replace msateco_c12_3 = 1 if msateco_c12_c_2020==0 & msateco_c12_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c12_5 = 0
replace msateco_c12_5 = 1 if msateco_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msateco_c12_6 = 0
replace msateco_c12_6 = 1 if msateco_c12_c5_2020==0 & msateco_c12_c5_2022==1


** 本人相对家务满意度变化
*量变
gen msathw_c12_1 = msathw_c12_2022 - msathw_c12_2020
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msathw_c12_2 = 0
replace msathw_c12_2 = 1 if msathw_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msathw_c12_3 = 0
replace msathw_c12_3 = 1 if msathw_c12_c_2020==0 & msathw_c12_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c12_5 = 0
replace msathw_c12_5 = 1 if msathw_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msathw_c12_6 = 0
replace msathw_c12_6 = 1 if msathw_c12_c5_2020==0 & msathw_c12_c5_2022==1




** 配偶相对婚姻满意度变化
*量变
gen msat_c21_1 = msat_c21_2022 - msat_c21_2020
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c21_2 = 0
replace msat_c21_2 = 1 if msat_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msat_c21_3 = 0
replace msat_c21_3 = 1 if msat_c21_c_2020==0 & msat_c21_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c21_5 = 0
replace msat_c21_5 = 1 if msat_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msat_c21_6 = 0
replace msat_c21_6 = 1 if msat_c21_c5_2020==0 & msat_c21_c5_2022==1


** 配偶相对收入满意度变化
*量变
gen msateco_c21_1 = msateco_c21_2022 - msateco_c21_2020
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msateco_c21_2 = 0
replace msateco_c21_2 = 1 if msateco_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msateco_c21_3 = 0
replace msateco_c21_3 = 1 if msateco_c21_c_2020==0 & msateco_c21_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c21_5 = 0
replace msateco_c21_5 = 1 if msateco_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msateco_c21_6 = 0
replace msateco_c21_6 = 1 if msateco_c21_c5_2020==0 & msateco_c21_c5_2022==1


** 配偶相对家务满意度变化
*量变
gen msathw_c21_1 = msathw_c21_2022 - msathw_c21_2020
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msathw_c21_2 = 0
replace msathw_c21_2 = 1 if msathw_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msathw_c21_3 = 0
replace msathw_c21_3 = 1 if msathw_c21_c_2020==0 & msathw_c21_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c21_5 = 0
replace msathw_c21_5 = 1 if msathw_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msathw_c21_6 = 0
replace msathw_c21_6 = 1 if msathw_c21_c5_2020==0 & msathw_c21_c5_2022==1


tab1 msat_c21_2 msat_c21_3 msat_c21_5 msat_c21_6 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ,miss





*** 控制变量

* TICs
sum ///
gender_2020 aage_2020 actor_edu2_2020 ahk_2020 /// agegap_ sibling_ atrust_
prtgender_2020 prtage_2020 prtedu_2020 /// prtchildn_2020 prtparty_2020 prthk_2020  ///
lifetime_2020 //

* TVCs 两期变化
sum ///
dwm_2020 actor_siops_2020 child_2020 aincc_2020 ahw_2020 ahk_2020  /// agegap_ sibling_ atrust_
prtmarr_2020 prtcor_2020 /// prtchildn_2020 prtparty_2020 prthk_2020  ///
fmlincc_2020 //

	 

** 父辈支持变化(0其他, 1无支持变有支持)
gen dwm_1 = 0
replace dwm_1 = 1 if dwm_2020==0 & dwm_2022==1

**子女数量变化
*量变
gen child_1 = child_2022 - child_2020
*质变(子女数量增加与否: 0未增加, 1增加)
gen child_2 = 0
replace child_2 = 1 if child_1>0 
*质变(子女数量减少与否: 0未减少, 1减少)
gen child_5 = 0
replace child_5 = 1 if child_1<0 

**绝对家务变化
*量变
gen ahw_1 = ahw_2022 - ahw_2020
*质变(绝对家务增加与否: 0未增加, 1增加)
gen ahw_2 = 0
replace ahw_2 = 1 if ahw_1>0 
*质变(绝对家务减少与否: 0未减少, 1减少)
gen ahw_5 = 0
replace ahw_5 = 1 if ahw_1<0 

** 相对家务变化
*量变
gen hw_1 = hw_2022 - hw_2020
*质变(相对家务改善与否: 0未改善, 1改善)
gen hw_2 = 0
replace hw_2 = 1 if hw_1>0
*质变(相对家务升级与否: 0小于等于配偶, 1高于配偶)
gen hw_3 = 0
replace hw_3 = 1 if hw_2020<=0 & hw_2022>0
*质变(相对家务恶化与否: 0未恶化, 1恶化)
gen hw_5 = 0
replace hw_5 = 1 if hw_1<0
*质变(相对家务降级与否: 0大于等于配偶, 1低于配偶)
gen hw_6 = 0
replace hw_6 = 1 if hw_2020>=0 & hw_2022<0

**绝对职业声望变化
*量变
gen actor_siops_1 = actor_siops_2022 - actor_siops_2020
*质变(绝对职业声望增加与否: 0未增加, 1增加)
gen actor_siops_2 = 0
replace actor_siops_2 = 1 if actor_siops_1>0 
*质变(绝对职业声望减少与否: 0未减少, 1减少)
gen actor_siops_5 = 0
replace actor_siops_5 = 1 if actor_siops_1<0 
 
 
** 父母婚姻变化(0其他, 1在婚变失婚)
gen prtmarr_1 = 0
replace prtmarr_1 = 1 if prtmarr_2020==0 & prtmarr_2022==1

** 父母同住变化(0其他, 1非同住变同住)
gen prtcor_1 = 0
replace prtcor_1 = 1 if prtcor_2020==0 & prtcor_2022==1
** 父母同住变化(0其他, 1同住变非同住)
gen reside_ind_1 = 0
replace reside_ind_1 = 1 if prtcor_2020==1 & prtcor_2022==0


** 家庭收入变化
gen fmlincc_1 = fmlincc_2022 - fmlincc_2020
*质变(家庭收入增加与否: 0未增加, 1增加)
gen fmlincc_2 = 0
replace fmlincc_2 = 1 if fmlincc_1>0 
*质变(家庭收入减少与否: 0未减少, 1减少)
gen fmlincc_5 = 0
replace fmlincc_5 = 1 if fmlincc_1<0 

*中介模型控制变量(增加→增加→增加)
sum ///
esup_1 esup_2 inc_1 inc_2 inc_3 msat_c12_1 msat_c12_2 msat_c12_3 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 ///
msat_c12_1 msat_c12_2 msat_c12_3 ///
gender_2020 aage_2020 actor_edu2_2020 actor_siops_1 actor_siops_2  ///
child_1 child_2 ahw_1 ahw_2 ahk_2020 ///
lifetime_2020 fmlincc_1 fmlincc_2

*结果模型控制变量(增加→增加→增加)		 
sum ///
msat_c1_1 msat_c1_2 msat_c2_1 msat_c2_2 ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	


*中介模型控制变量(减少→减少→减少)
sum ///
esup_1 esup_5 inc_1 inc_5 inc_6 msat_c12_1 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_5 msateco_c12_6 ///
msat_c12_1 msat_c12_5 msat_c12_6 ///
gender_2020 aage_2020 actor_edu2_2020 actor_siops_1 actor_siops_2  ///
child_1 child_2 ahw_1 ahw_2 ahk_2020 ///
lifetime_2020 fmlincc_1 fmlincc_2

*结果模型控制变量(减少→减少→减少)		 
sum ///
msat_c1_1 msat_c1_5 msat_c2_1 msat_c2_5 ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	





global covar ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	

sum $covar
/*
*** 收入变化→相对婚姻满意度变化→代际经济支持变化
med4way esup_2 aincc_2 msat_c1_2 gender_2020 prtgender_2022 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2020 prtgender_2022 $covar if gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 esup_2020 gender_2020 prtgender_2022 $covar if gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)


med4way esup_2 aincc_2 msat_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 esup_2020 gender_2020 prtgender_2022 $covar if gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
* 只有这个显著
med4way esup_2 aincc_2 msat_c2_2 esup_2020  gender_2020 prtgender_2022 $covar if gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 esup_2020 gender_2020 prtgender_2022 $covar if gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2 aincc_2 msat_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
 

med4way esup_2 aincc_2 msateco_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2020 prtgender_2022 $covar if gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
* 只有这个显著
med4way esup_2 aincc_2 msateco_c2_2 gender_2020 prtgender_2022 $covar if gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_2 aincc_2 msat_c12_3 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2020 prtgender_2022 $covar if gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2020 prtgender_2022 $covar if gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2020 prtgender_2022 $covar if lifetime_2020==0 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2020 prtgender_2022 $covar if lifetime_2020==1 & gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_1 aincc_2 msat_c1_2 gender_2020 prtgender_2022, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c1_2 gender_2020 prtgender_2022 if gender_2020==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c1_2 gender_2020 prtgender_2022 if gender_2020==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

med4way esup_1 aincc_2 msat_c2_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 if gender_2020==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 if gender_2020==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

med4way esup_1 aincc_2 msat_c12_3 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 if gender_2020==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 if gender_2020==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)






med4way esup_2 inc_3 msat_c1_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if gender_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if gender_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2020==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2020==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2020==0 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2020==0 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2020==1 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2020==1 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)


med4way esup_2 inc_3 msat_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c2_2 $covar if gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 $covar if gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2 inc_3 msat_c2_2 if lifetime_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2020==0 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2020==0 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2020==1 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2020==1 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



global covar ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	

global covar ///
        msat_c12_2020 ///
        msat_c1_2  msat_c2_2 ///
        dwm_2022  gender_2022  aage_2022  actor_edu2_2022  actor_siops_2 ///
        child_2  aincc_2  ahw_2  ahk_2022  ///
        prtmarr_1  prtcor_1  prtgender_2022  prtage_2022  prtedu_2022 ///
        lifetime_2022  fmlincc_2	//

sum $covar

*** 相对婚姻满意度
med4way esup_2 inc_3 msat_c12_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2020==0 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2020==0 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2020==1 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2020==1 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)




med4way esup_2 inc_3 msat_c12_3 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2020==0 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2020==0 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2020==1 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2020==1 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



*** 收入满意度
med4way esup_2 inc_3 msateco_c2_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2020==0 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2020==0 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2020==1 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2020==1 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



*** 收入满意度
med4way esup_2 inc_3 msateco_c1_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2020==0 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2020==0 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2020==1 & gender_2020==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2020==1 & gender_2020==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_1 aincc_2 msat_c1_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

logit esup_2 aincc_2  prtage_2022 prtgender_2022 if gender_2020==1

logit esup_2 inc_3  prtage_2022 prtgender_2022 if gender_2020==1 

reg esup_1 aincc_1 prtage_2022 
reg esup_1 aincc_1 prtage_2022 , vce(robust)
reg esup_1 aincc_1  prtage_2022, vce(cluster fid_2020)

logit esup_2 inc_3
logit esup_2 inc_2
reg esup_1 inc_1


logit esup_2  dwm_2022
tab1 esup_2 dwm_1

preserve
tab1 actor_employ_* partner_employ_*,miss
count if actor_employ_2020==1 & actor_employ_2022==1 & partner_employ_2020==1 & partner_employ_2022==1 
keep if actor_employ_2020==1 & actor_employ_2022==1 & partner_employ_2020==1 & partner_employ_2022==1 

logit esup_2 aincc_2
reg esup_1 aincc_1

logit esup_2 inc_3
logit esup_2 inc_2
reg esup_1 inc_1

restore


global covar2022 ///
dwm_2022 gender_2022 aage_2022 actor_edu2_2022 actor_siops_2022 child_2022 childborn_2022 aincc_2022 ahw_2022 ahk_2022  /// agegap_ sibling_ atrust_
 prtmarr_2022 prtcor_2022 prtgender_2022 prtage_2022 prtedu_2022 /// prtchildn_2022 prtparty_2022 prthk_2022  ///
lifetime_2022 fmlincc_2022 //

sum $covar2022

global covar2020 ///
dwm_2020 gender_2020 aage_2020 actor_edu2_2020 actor_siops_2020 child_2020 childborn_2020 aincc_2020 ahw_2020 ahk_2020  /// agegap_ sibling_ atrust_
 prtmarr_2020 prtcor_2020 prtgender_2020 prtage_2020 prtedu_2020 /// prtchildn_2020 prtparty_2020 prthk_2020  ///
lifetime_2020  fmlincc_2020 //

sum $covar2020

tabstat aincc_2020 msat_c1_2020 msat_c2_2020
dis 5.733915-0.5
dis 5.733915+0.5

* 不显著
med4way esup_2022 aincc_2020 msat_c1_2020 $covar2022 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.5379)
med4way esup_2022 aincc_2020 msat_c2_2020 $covar2022 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.55492)
med4way esup_2022 inc_a2020 msat_c1_2020 $covar2022 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.5379)
med4way esup_2022 inc_a2020 msat_c2_2020 $covar2022 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.55492)

* 只有这个显著
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

gen inc_a202020 = 0 
replace inc_a202020 = 1 if inc_a2020==1 & inc_a2022==1

* 不显著
med4way esup_2022 inc_a202020 msat_c12_c_2022 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a202020 msat_c12_c_2020 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a202020 msat_c12_c_2022 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a202020 msat_c12_c_2020 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a202020 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a202020 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
*/

*导出csv格式
export delimited id fid_2020 fid_2022 ///
esup_2020 inc_a2020 inc_a52020 inc_2020 ///
msat_c12_c_2020 msateco_c12_c_2020 msathw_c12_c_2020 /// 相对满意度(增加与否)
msat_c12_c5_2020 msateco_c12_c5_2020 msathw_c12_c5_2020 /// 相对满意度(减少与否)
msat_c12_2020 msateco_c12_2020 msathw_c12_2020 ///
msat_c1_2020 msat_c2_2020 /// 
msateco_c1_2020 msateco_c2_2020 ///
msathw_c1_2020 msathw_c2_2020 ///
dwm_2020 gender_2020 aage_2020 actor_edu2_2020 actor_siops_2020 child_2020 childborn_2020 aincc_2020 ahw_2020 ahk_2020 urban_2020  /// agegap_ sibling_ atrust_
prtmarr_2020 prtcor_2020 prtgender_2020 prtage_2020 prtedu_2020 /// prtchildn_2020 prtparty_2020 prthk_2020  ///
lifetime_2020  fmlincc_2020 ///
esup_2022 inc_a2022 inc_2022 ///
msat_c12_c_2022 msateco_c12_c_2022 msathw_c12_c_2022 /// 相对满意度(增加与否)
msat_c12_c5_2022 msateco_c12_c5_2022 msathw_c12_c5_2022 /// 相对满意度(减少与否)
msat_c12_2022 msateco_c12_2022 msathw_c12_2022 ///
msat_c1_2022 msat_c2_2022 ///
msateco_c1_2022 msateco_c2_2022 ///
msathw_c1_2022 msathw_c2_2022 ///
dwm_2022 gender_2022 aage_2022 actor_edu2_2022 actor_siops_2022 child_2022 childborn_2022 aincc_2022 ahw_2022 ahk_2022 urban_2022  /// agegap_ sibling_ atrust_
prtmarr_2022 prtcor_2022 prtgender_2022 prtage_2022 prtedu_2022 /// prtchildn_2022 prtparty_2022 prthk_2022  ///
lifetime_2022 fmlincc_2022 ///
esup_1 esup_2 esup_5 aincc_1 aincc_2 aincc_5 inc_1 inc_2 inc_3 inc_5 inc_6 msat_c12_1 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 msateco_c12_5 msateco_c12_6 ///
msathw_c12_1 msathw_c12_2 msathw_c12_3 msathw_c12_5 msathw_c12_6 ///
msat_c1_1 msat_c1_2 msat_c1_5 msat_c2_1 msat_c2_2 msat_c2_5 ///
msateco_c1_1 msateco_c1_2 msateco_c1_5 msateco_c2_1 msateco_c2_2 msateco_c2_5 ///
msathw_c1_1 msathw_c1_2 msathw_c1_5 msathw_c2_1 msathw_c2_2 msathw_c2_5 ///
dwm_1 actor_siops_1 actor_siops_2 actor_siops_5 ///
child_1 child_2 ahw_1 ahw_2 ahw_5 ///
prtmarr_1 prtcor_1 fmlincc_1 fmlincc_2 fmlincc_5 ///
nonhousing_debts_1 nonhousing_debts_2 nonhousing_debts_5 ///
total_debts_1 total_debts_2 total_debts_5 ///
shealth_1 shealth_2 shealth_5 ///
schealth_2 schealth_5 ///
reside_ind_1 ///
using "$data\causal_mediation_20&22_bal.csv", nolabel replace  // 没有值标签

logit msat_c12_c_2020 inc_a2020 msateco_c12_c_2020 msathw_c12_c_2020

logit msat_c12_c_2020 inc_a2020 msateco_c12_2020 msathw_c12_2020

reg esup_2022 inc_a2020 aincc_2020 msat_c12_c_2020 msat_c12_2020 msat_c1_2020 msat_c2_2020

reg esup_2022 inc_a2020 msat_c12_c_2020 msat_c1_2020 msat_c2_2020
reg esup_2022 inc_a2020 msat_c12_c_2020 msat_c1_2020 msat_c2_2020
reg esup_2022 inc_a2020 msat_c12_c_2020 msat_c1_2020 msat_c2_2020
}
save "$pre_data\causal_mediation_20&22_bal.dta",replace
rename (*2020 *2022) (*begin *end)
save "$pre_data\causal_mediation_20&22_bal_rename.dta",replace


/* ============================================================
[模块四] 两期堆叠合并：2018-2020 与 2020-2022 纵向合并
功能：将模块二、三的 _rename 版（年份后缀已统一为 begin/end）用
      append 纵向堆叠，生成含 time_period 标识的两期混合面板。
      同时添加变量中文标签、生成三分类变量、个人/家庭收入中位数分组等。
      此数据集为后续 R 或 Stata 中介分析的最终输入。
输入：causal_mediation_18&20_bal_rename.dta + causal_mediation_20&22_bal_rename.dta
输出：causal_mediation_18&20_20&22_bal.dta/.csv
      time_period: 0=2018-2020期, 1=2020-2022期
============================================================ */
{
use "$pre_data\causal_mediation_18&20_bal_rename.dta",clear

append using "$pre_data\causal_mediation_20&22_bal_rename.dta",gen(time_period)

tab time_period,nolab
label define time_period 0 "2018-2020" 1 "2020-2022"
label values time_period time_period
tab time_period

clonevar reside_ind_begin=prtcor_begin
clonevar reside_ind_end=prtcor_end

clonevar shealth_begin=qp201_actor_begin
clonevar shealth_end=qp201_actor_end


sum ///
esup_2 esup_5 esup_1 /// Y 代际经济支持变化
aincc_2 aincc_5 aincc_1 /// X 绝对收入变化
inc_3 inc_6 inc_1 /// 相对收入变化
msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 msat_c12_1 /// M相对婚姻满意度变化
msat_c21_2 msat_c21_3 msat_c21_5 msat_c21_6 msat_c21_1 /// M相对婚姻满意度变化
msat_c1_2 msat_c1_5 msat_c1_1 /// 本人婚姻满意度变化
msat_c2_2 msat_c2_5 msat_c2_1 /// 配偶婚姻满意度变化
msateco_c2_2 msateco_c2_5 msateco_c2_1 // 配偶收入满意度变化


elabel variable  ///
( ///
esup_2 esup_5 esup_1 /// Y 代际经济支持变化
aincc_2 aincc_5 aincc_1 /// X 绝对收入变化
inc_3 inc_6 inc_1 /// 相对收入变化
msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 msat_c12_1 /// M相对婚姻满意度变化
msat_c21_2 msat_c21_3 msat_c21_5 msat_c21_6 msat_c21_1 /// M相对婚姻满意度变化
msat_c1_2 msat_c1_5 msat_c1_1 /// 本人婚姻满意度变化
msat_c2_2 msat_c2_5 msat_c2_1 /// 配偶婚姻满意度变化
msateco_c2_2 msateco_c2_5 msateco_c2_1 /// 配偶收入满意度变化
) ///
( ///
"代际经济支持增加" "代际经济支持减少" "代际经济支持变化" /// Y 
"绝对收入增加" "绝对收入减少" "绝对收入变化" /// X
"相对收入增加" "相对收入减少" "相对收入变化" /// X
"本人相对婚姻满意度增加" "本人相对婚姻满意度升级" "本人相对婚姻满意度减少" "本人相对婚姻满意度降级" "本人相对婚姻满意度变化" /// M
"配偶相对婚姻满意度增加" "配偶相对婚姻满意度升级" "配偶相对婚姻满意度减少" "配偶相对婚姻满意度降级" "配偶相对婚姻满意度变化" /// M
"本人婚姻满意度增加" "本人婚姻满意度减少" "本人婚姻满意度变化" /// M
"配偶婚姻满意度增加" "配偶婚姻满意度减少" "配偶婚姻满意度变化" /// M
"配偶收入满意度增加" "配偶收入满意度减少" "配偶收入满意度变化" /// M
) //




des ///
esup_2 esup_5 esup_1 /// Y 代际经济支持变化
aincc_2 aincc_5 aincc_1 /// X 绝对收入变化
inc_3 inc_6 inc_1 /// 相对收入变化
msat_c12_3 msat_c12_6 msat_c12_1 /// M相对婚姻满意度变化
msat_c1_2 msat_c1_5 msat_c1_1 /// 本人婚姻满意度变化
msat_c2_2 msat_c2_5 msat_c2_1 /// 配偶婚姻满意度变化
msateco_c2_2 msateco_c2_5 msateco_c2_1 /// 配偶收入满意度变化
,detail

elabel define increase 0 "未增加" 1 "增加",replace
elabel define decrease 0 "未减少" 1 "减少",replace

elabel values ///
esup_2 aincc_2 inc_3 msat_c12_3 msat_c1_2 msat_c2_2 msateco_c2_2 ///
increase

elabel values ///
esup_5 aincc_5 inc_6 msat_c12_6 msat_c1_5 msat_c2_5 msateco_c2_5 ///
increase

tab1 ///
esup_2 aincc_2 inc_3 msat_c12_3 msat_c1_2 msat_c2_2 msateco_c2_2 ///
esup_5 aincc_5 inc_6 msat_c12_6 msat_c1_5 msat_c2_5 msateco_c2_5 ///
,miss


// Covariates
// (in the initial year)
sum /// 
aage_begin /// adult child 年龄
gender_begin /// 性别
actor_edu2_begin /// 受教育程度
actor_siops_begin /// 职业声望
ahk_begin /// 户口类型
urban_begin /// 城乡
child_begin /// 子女数量
aincc_begin /// 绝对收入
ahw_begin /// 家务劳动时长
shealth_begin /// 自评健康状况
reside_ind_begin /// 同住情况
dwm_begin /// 接受父辈支持情况
prtgender_begin /// parent 父母性别
prtage_begin /// 父母年龄
prtedu_begin /// 父母受教育程度
prtmarr_begin /// 父母婚姻状况
prtcor_begin /// 父母同住状况
total_debts_scale_begin /// family家庭总负债(基期标准化)
fmlincc_begin /// 家庭总收入(基期)
lifetime_begin /// 生命周期阶段
esup_begin /// else 代际经济支持(基期)
aincc_begin /// 绝对收入(基期)
inc_begin /// 相对收入(基期)
msat_c12_begin  /// 相对婚姻满意度(基期)
msat_c1_begin  /// 本人婚姻满意度(基期)
msat_c2_begin  /// 配偶婚姻满意度(基期)
msateco_c2_begin // 配偶收入满意度(基期)


elabel variable  ///
( ///
aage_begin /// adult child 年龄
gender_begin /// 性别
actor_edu2_begin /// 受教育程度
actor_siops_begin /// 职业声望
ahk_begin /// 户口类型
urban_begin /// 城乡
child_begin /// 子女数量 aincc_begin /// 绝对收入
ahw_begin /// 家务劳动时长
shealth_begin /// 自评健康状况
reside_ind_begin /// 同住情况
dwm_begin /// 接受父辈支持情况
prtgender_begin /// parent 父母性别
prtage_begin /// 父母年龄
prtedu_begin /// 父母受教育程度
prtmarr_begin /// 父母婚姻状况
prtcor_begin /// 父母同住状况
total_debts_scale_begin /// family家庭总负债(基期标准化)
fmlincc_begin /// 家庭总收入(基期)
lifetime_begin /// 生命周期阶段
esup_begin /// else 代际经济支持(基期)
aincc_begin /// 绝对收入(基期)
inc_begin /// 相对收入(基期)
msat_c12_begin  /// 相对婚姻满意度(基期)
msat_c1_begin  /// 本人婚姻满意度(基期)
msat_c2_begin  /// 配偶婚姻满意度(基期)
msateco_c2_begin /// 配偶收入满意度(基期)
) ///
( ///
"年龄" ///
"性别" ///
"教育程度" ///
"职业声望" ///
"户口类型" ///
"城乡" ///
"子女数量" ///
"家务时长" ///
"自评健康" ///
"同住情况" ///
"父辈支持" ///
"父母性别" ///
"父母年龄" ///
"父母教育" ///
"父母婚姻" ///
"父母同住" ///
"家庭总负债" ///
"家庭总收入" ///
"生命周期阶段" ///
"代际经济支持" ///
"绝对收入" ///
"相对收入" ///
"相对婚姻满意度" ///
"本人婚姻满意度" ///
"配偶婚姻满意度" ///
"配偶收入满意度" ///
) //

des ///
aage_begin /// adult child 年龄
actor_edu2_begin /// 受教育程度
actor_siops_begin /// 职业声望
child_begin /// 子女数量 aincc_begin /// 绝对收入
ahw_begin /// 家务劳动时长
shealth_begin /// 自评健康状况
prtage_begin /// 父母年龄
total_debts_scale_begin /// family家庭总负债(基期标准化)
fmlincc_begin /// 家庭总收入(基期)
esup_begin /// else 代际经济支持(基期)
aincc_begin /// 绝对收入(基期)
inc_begin /// 相对收入(基期)
msat_c12_begin  /// 相对婚姻满意度(基期)
msat_c1_begin  /// 本人婚姻满意度(基期)
msat_c2_begin  /// 配偶婚姻满意度(基期)
msateco_c2_begin // 配偶收入满意度(基期)

tab1 shealth_begin,miss // 1=非常健康, 5=不健康

* 删除标签, 否则R会视其为 类别变量
label values aage_begin
label values actor_siops_begin
label values shealth_begin

tab1 ///
gender_begin /// 性别
ahk_begin /// 户口类型
urban_begin /// 城乡
reside_ind_begin /// 同住情况
dwm_begin /// 接受父辈支持情况
prtgender_begin /// parent 父母性别
prtedu_begin /// 父母受教育程度
prtmarr_begin /// 父母婚姻状况
prtcor_begin /// 父母同住状况
lifetime_begin /// 生命周期阶段
,miss




// Covariates
// (in the initial year)
sum ///
actor_siops_2 /// adult child职业声望(变化)
child_2 /// 子女数量(变化)
aincc_2 /// 绝对收入(变化)
ahw_2 /// 家务劳动时长(变化)
shealth_2 /// 自评健康状况(变化)
reside_ind_1 /// 同住情况(变化)
prtmarr_1 /// parent父母婚姻状况(变化)
prtcor_1 /// 父母同住状况(变化)
total_debts_2 /// family家庭总负债(变化)
fmlincc_2 // 家庭总收入(变化)

tab1 ///
actor_siops_2 /// adult child职业声望(变化)
child_2 /// 子女数量(变化)
aincc_2 /// 绝对收入(变化)
ahw_2 /// 家务劳动时长(变化)
shealth_2 /// 自评健康状况(变化)
reside_ind_1 /// 同住情况(变化)
prtmarr_1 /// parent父母婚姻状况(变化)
prtcor_1 /// 父母同住状况(变化)
total_debts_2 /// family家庭总负债(变化)
fmlincc_2 /// 家庭总收入(变化)
,miss


*为变化构建三分类类别变量, 便于描述性统计
*gen actor_siops_cat = 2
*replace actor_siops_cat = 1 if actor_siops_<0
*replace actor_siops_cat = 3 if actor_siops_>0
*replace actor_siops_cat = . if actor_siops_==.

foreach var in actor_siops child aincc ahw shealth total_debts fmlincc {

gen `var'_cat = 2
replace `var'_cat = 1 if `var'_1<0
replace `var'_cat = 3 if `var'_1>0
replace `var'_cat = . if `var'_1==.

label define three_cat 1 "减少" 2 "不变" 3 "增加",replace
label values `var'_cat three_cat
}

tab1 *_cat,miss


elabel variables ///
( ///
actor_siops_cat /// adult child职业声望(变化)
child_cat /// 子女数量(变化)
aincc_cat /// 绝对收入(变化)
ahw_cat /// 家务劳动时长(变化)
shealth_cat /// 自评健康状况(变化)
reside_ind_1 /// 同住情况(变化)
prtmarr_1 /// parent父母婚姻状况(变化)
prtcor_1 /// 父母同住状况(变化)
total_debts_cat /// family家庭总负债(变化)
fmlincc_cat /// 家庭总收入(变化)
) ///
( ///
"职业声望(变化)" ///
"子女数量(变化)" ///
"绝对收入(变化)" ///
"家务时长(变化)" ///
"自评健康(变化)" ///
"与父母同住(变化)" ///
"父母婚姻(变化)" ///
"与子女同住(变化)" ///
"家庭总负债(变化)" ///
"家庭总收入(变化)" ///
) //

tab1 ///
reside_ind_1 /// 同住情况(变化)
prtmarr_1 /// parent父母婚姻状况(变化)
prtcor_1 /// 父母同住状况(变化)
,miss

label define reside_ind_1 0 "其他" 1 "变为不同住",replace
label define prtmarr_1 0 "不变" 1 "变为失婚",replace
label define prtcor_1 0 "其他" 1 "变为同住",replace

label values reside_ind_1 reside_ind_1
label values prtmarr_1 prtmarr_1
label values prtcor_1 prtcor_1

tab1 ///
actor_siops_cat /// adult child职业声望(变化)
child_cat /// 子女数量(变化)
aincc_cat /// 绝对收入(变化)
ahw_cat /// 家务劳动时长(变化)
shealth_cat /// 自评健康状况(变化)
reside_ind_1 /// 同住情况(变化)
prtmarr_1 /// parent父母婚姻状况(变化)
prtcor_1 /// 父母同住状况(变化)
total_debts_cat /// family家庭总负债(变化)
fmlincc_cat /// 家庭总收入(变化)
,miss



***** 个人收入中位数二分法
{
* 按收入中位数二分—— 整体中位数
tab1 aincc_begin,miss
sum aincc_begin

* ────────────────────────────────────────────────
*  Step 1: 计算整体中位数（如果需要对比使用）
* ────────────────────────────────────────────────
summarize aincc_begin, detail
scalar med_all = r(p50)                  // 整体中位数

* ────────────────────────────────────────────────
*  Step 2: 分别计算男女的中位数
* ────────────────────────────────────────────────
* 假设 gender = 0 为女性，gender = 1 为男性
summarize aincc_begin if gender_begin == 0, detail
scalar med_female = r(p50)

summarize aincc_begin if gender_begin == 1, detail
scalar med_male = r(p50)

* ────────────────────────────────────────────────
*  Step 3: 生成分性别收入二分类变量（最推荐）
* ────────────────────────────────────────────────

gen aincc_c_begin = .
replace aincc_c_begin = 0 if aincc_begin <= med_all & !missing(aincc_begin)
replace aincc_c_begin = 1 if aincc_begin >  med_all & !missing(aincc_begin)
replace aincc_c_begin = 999 if aincc_c_begin == .

gen female_aincc_c_begin = .
replace female_aincc_c_begin = 0 if gender_begin == 0 & aincc_begin <= med_female & !missing(aincc_begin)
replace female_aincc_c_begin = 1 if gender_begin == 0 & aincc_begin >  med_female & !missing(aincc_begin)
replace female_aincc_c_begin = 999 if female_aincc_c_begin == .

gen male_aincc_c_begin = .
replace male_aincc_c_begin = 0 if gender_begin == 1 & aincc_begin <= med_male   & !missing(aincc_begin)
replace male_aincc_c_begin = 1 if gender_begin == 1 & aincc_begin >  med_male   & !missing(aincc_begin)
replace male_aincc_c_begin = 999 if male_aincc_c_begin == .

label var aincc_c_begin "收入等级"
label var female_aincc_c_begin "女性收入等级"
label var male_aincc_c_begin "女性收入等级"
label define yesno 0 "≤中位数" 1 ">中位数", replace
label values aincc_c_begin yesno
label values female_aincc_c_begin yesno
label values male_aincc_c_begin yesno
}
sum aincc_c_begin female_aincc_c_begin male_aincc_c_begin
tab1 aincc_c_begin female_aincc_c_begin male_aincc_c_begin
tab1 aincc_c_begin female_aincc_c_begin male_aincc_c_begin,miss

***** 家庭收入中位数二分法
{

* 按收入中位数二分—— 整体中位数
tab1 fincome_cpi_begin,miss
sum fincome_cpi_begin

* ────────────────────────────────────────────────
*  Step 1: 计算整体中位数（如果需要对比使用）
* ────────────────────────────────────────────────
summarize fincome_cpi_begin, detail
scalar med_all = r(p50)                  // 整体中位数

* ────────────────────────────────────────────────
*  Step 2: 分别计算男女的中位数
* ────────────────────────────────────────────────
* 假设 gender = 0 为女性，gender = 1 为男性
summarize fincome_cpi_begin if gender_begin == 0, detail
scalar med_female = r(p50)

summarize fincome_cpi_begin if gender_begin == 1, detail
scalar med_male = r(p50)

* ────────────────────────────────────────────────
*  Step 3: 生成分性别收入二分类变量（最推荐）
* ────────────────────────────────────────────────

gen fincome_c_begin = .
replace fincome_c_begin = 0 if fincome_cpi_begin <= med_all & !missing(fincome_cpi_begin)
replace fincome_c_begin = 1 if fincome_cpi_begin >  med_all & !missing(fincome_cpi_begin)
replace fincome_c_begin = 999 if fincome_c_begin == .

gen female_fincome_c_begin = .
replace female_fincome_c_begin = 0 if gender_begin == 0 & fincome_cpi_begin <= med_female & !missing(fincome_cpi_begin)
replace female_fincome_c_begin = 1 if gender_begin == 0 & fincome_cpi_begin >  med_female & !missing(fincome_cpi_begin)
replace female_fincome_c_begin = 999 if female_fincome_c_begin == .

gen male_fincome_c_begin = .
replace male_fincome_c_begin = 0 if gender_begin == 1 & fincome_cpi_begin <= med_male   & !missing(fincome_cpi_begin)
replace male_fincome_c_begin = 1 if gender_begin == 1 & fincome_cpi_begin >  med_male   & !missing(fincome_cpi_begin)
replace male_fincome_c_begin = 999 if male_fincome_c_begin == .

label var fincome_c_begin "收入等级"
label var female_fincome_c_begin "女性收入等级"
label var male_fincome_c_begin "女性收入等级"
label define yesno 0 "≤中位数" 1 ">中位数", replace
label values fincome_c_begin yesno
label values female_fincome_c_begin yesno
label values male_fincome_c_begin yesno
}
sum fincome_c_begin female_fincome_c_begin male_fincome_c_begin
tab1 fincome_c_begin female_fincome_c_begin male_fincome_c_begin
tab1 fincome_c_begin female_fincome_c_begin male_fincome_c_begin,miss


*导出csv格式
export delimited id fid_begin fid_end ///
esup_begin inc_abegin inc_a5begin inc_begin ///
msat_c12_c_begin msateco_c12_c_begin msathw_c12_c_begin /// 相对满意度(增加与否)
msat_c12_c5_begin msateco_c12_c5_begin msathw_c12_c5_begin /// 相对满意度(减少与否)
msat_c12_begin msateco_c12_begin msathw_c12_begin ///
msat_c21_c_begin msateco_c21_c_begin msathw_c21_c_begin /// 相对满意度(增加与否)
msat_c21_c5_begin msateco_c21_c5_begin msathw_c21_c5_begin /// 相对满意度(减少与否)
msat_c21_begin msateco_c21_begin msathw_c21_begin ///
msat_c1_begin msat_c2_begin /// 
msateco_c1_begin msateco_c2_begin ///
msathw_c1_begin msathw_c2_begin ///
dwm_begin gender_begin aage_begin actor_edu2_begin actor_siops_begin child_begin childborn_begin aincc_begin ahw_begin ahk_begin urban_begin  /// agegap_ sibling_ atrust_
prtmarr_begin prtcor_begin prtgender_begin prtage_begin prtedu_begin /// prtchildn_begin prtparty_begin prthk_begin  ///
lifetime_begin  fmlincc_begin ///
esup_end inc_aend inc_end ///
msat_c12_c_end msateco_c12_c_end msathw_c12_c_end /// 相对满意度(增加与否)
msat_c12_c5_end msateco_c12_c5_end msathw_c12_c5_end /// 相对满意度(减少与否)
msat_c12_end msateco_c12_end msathw_c12_end ///
msat_c21_c_end msateco_c21_c_end msathw_c21_c_end /// 相对满意度(增加与否)
msat_c21_c5_end msateco_c21_c5_end msathw_c21_c5_end /// 相对满意度(减少与否)
msat_c21_end msateco_c21_end msathw_c21_end ///
msat_c1_end msat_c2_end ///
msateco_c1_end msateco_c2_end ///
msathw_c1_end msathw_c2_end ///
dwm_end gender_end aage_end actor_edu2_end actor_siops_end child_end childborn_end aincc_end ahw_end ahk_end urban_end  /// agegap_ sibling_ atrust_
prtmarr_end prtcor_end prtgender_end prtage_end prtedu_end /// prtchildn_end prtparty_end prthk_end  ///
lifetime_end fmlincc_end ///
esup_1 esup_2 esup_5 aincc_1 aincc_2 aincc_5 inc_1 inc_2 inc_3 inc_5 inc_6 ///
msat_c12_1 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 msateco_c12_5 msateco_c12_6 ///
msathw_c12_1 msathw_c12_2 msathw_c12_3 msathw_c12_5 msathw_c12_6 ///
msat_c21_1 msat_c21_2 msat_c21_3 msat_c21_5 msat_c21_6 ///
msateco_c21_1 msateco_c21_2 msateco_c21_3 msateco_c21_5 msateco_c21_6 ///
msathw_c21_1 msathw_c21_2 msathw_c21_3 msathw_c21_5 msathw_c21_6 ///
msat_c1_1 msat_c1_2 msat_c1_5 msat_c2_1 msat_c2_2 msat_c2_5 ///
msateco_c1_1 msateco_c1_2 msateco_c1_5 msateco_c2_1 msateco_c2_2 msateco_c2_5 ///
msathw_c1_1 msathw_c1_2 msathw_c1_5 msathw_c2_1 msathw_c2_2 msathw_c2_5 ///
dwm_1 actor_siops_1 actor_siops_2 actor_siops_5 ///
child_1 child_2 ahw_1 ahw_2 ahw_5 ///
prtmarr_1 prtcor_1 fmlincc_1 fmlincc_2 fmlincc_5 time_period ///
nonhousing_debts_scale_begin nonhousing_debts_scale_end ///
total_debts_scale_begin total_debts_scale_end ///
reside_ind_begin reside_ind_end ///
shealth_begin shealth_end ///
nonhousing_debts_1 nonhousing_debts_2 nonhousing_debts_5 ///
total_debts_1 total_debts_2 total_debts_5 ///
shealth_1 shealth_2 shealth_5 ///
schealth_2 schealth_5 ///
reside_ind_1 ///
actor_siops_cat /// adult child职业声望(变化)
child_cat /// 子女数量(变化)
aincc_cat /// 绝对收入(变化)
ahw_cat /// 家务劳动时长(变化)
shealth_cat /// 自评健康状况(变化)
total_debts_cat /// family家庭总负债(变化)
fmlincc_cat /// 家庭总收入(变化)
aincc_c_begin female_aincc_c_begin male_aincc_c_begin /// 个人收入等级，女性/男性收入等级
fincome_c_begin female_fincome_c_begin male_fincome_c_begin /// 家庭收入等级，女性/男性收入等级
using "$data\causal_mediation_18&20_20&22_bal.csv", nolabel replace  // 没有值标签


}
save "$pre_data\causal_mediation_18&20_20&22_bal.dta",replace
     
** 一些描述性统计   
sum fmlincc_begin aincc_begin 
tab fmlincc_begin,miss
sum nonhousing_debts_scale_begin total_debts_scale_begin nonhousing_debts_scale_end total_debts_scale_end
* 家庭负债平均120多个 缺失，视为0
/*
    Variable |        Obs        Mean    Std. dev.       Min        Max
-------------+---------------------------------------------------------
nonhousing~n |     13,129    2.098088    8.605875          0        200
total_debt~n |     13,129    2.678954    9.478021          0    200.002
nonhousing~d |     13,129    2.504974    10.57429          0        200
total_debt~d |     13,129    2.505807    10.57466          0   200.0025
*/

* Summarize individual variables instead of tabulating (due to Stata value limits)
summarize msat_c12_1 ,detail
summarize msat_c1_1 ,detail
summarize msat_c2_1 ,detail
summarize msateco_c12_1 ,detail
summarize msat_c12_3 ,detail
summarize msat_c1_2 ,detail
summarize msat_c2_2 ,detail
summarize msateco_c12_2 ,detail
summarize aincc_2 ,detail

preserve
keep if time_period==1
reg msat_c12_1 aincc_1 aincc_begin
reg msat_c1_1 aincc_1 aincc_begin

reg msat_c2_1 aincc_1 aincc_begin
reg msateco_c2_1 aincc_1 aincc_begin


capture logit msat_c12_1 aincc_5 aincc_begin
capture logit msat_c1_1 aincc_5 aincc_begin

capture logit msat_c2_1 aincc_5 aincc_begin
capture logit msateco_c2_1 aincc_5 aincc_begin


capture logit msat_c12_1 aincc_2 
capture logit msat_c1_1 aincc_2 

capture logit msat_c2_1 aincc_2 
capture logit msateco_c2_1 aincc_2 

restore

tab1 time_period,miss nolab

xtset id time_period

capture logit l.msat_c12_6 aincc_5 
capture logit l.msat_c1_5 aincc_5 

capture logit l.msat_c2_5 aincc_5 
capture logit l.msateco_c12_5 aincc_5 

capture logit msat_c12_3 aincc_2 
capture logit msat_c12_3 aincc_2


sum aincc_*
count if inc_begin ==0.5

capture {
sum ///
msat_c12_c_2020 msateco_c12_c_2020 msathw_c12_c_2020 /// 相对满意度(增加与否)
msat_c12_c5_2020 msateco_c12_c5_2020 msathw_c12_c5_2020 /// 相对满意度(减少与否)
msat_c12_c_2022 msateco_c12_c_2022 msathw_c12_c_2022 /// 相对满意度(增加与否)
msat_c12_c5_2022 msateco_c12_c5_2022 msathw_c12_c5_2022 /// 相对满意度(减少与否)
esup_2 esup_5 ///
aincc_2 aincc_5 ///
inc_2 inc_3 inc_5 inc_6 ///
msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ///
msateco_c12_2 msateco_c12_3 msateco_c12_5 msateco_c12_6 ///
msathw_c12_2 msathw_c12_3 msathw_c12_5 msathw_c12_6 ///
msat_c1_2 msat_c1_5 msat_c2_2 msat_c2_5 ///
msateco_c1_2 msateco_c1_5 msateco_c2_2 msateco_c2_5 ///
msathw_c1_2 msathw_c1_5 msathw_c2_2 msathw_c2_5 ///
actor_siops_2 actor_siops_5 ///
child_2 child_5 ahw_2 ahw_5 ///
fmlincc_2 fmlincc_5 //
}

capture logit esup_2 msat_c12_c_2020
capture logit esup_2 msateco_c12_c_2020

capture logit esup_5 msat_c12_c5_2020 
capture logit esup_5 msateco_c12_c5_2020

capture logit msat_c12_c_2020 inc_1 inc_2 inc_3 inc_5 inc_6
capture logit msat_c12_c5_2020 inc_1 inc_2 inc_3 inc_5 inc_6

capture logit msateco_c12_c_2020 inc_1 inc_2 inc_3 inc_5 inc_6
capture logit msateco_c12_c5_2020 inc_1 inc_2 inc_3 inc_5 inc_6


capture logit msat_c12_c5_2020 inc_3 inc_2 // * 相对收入升级(低于等于配偶 转为 高于配偶)→婚姻满意度降级(负向显著)


capture logit msat_c12_c_2020 inc_6 inc_5 // * 相对收入降级(高于等于配偶 转为 低于配偶)→婚姻满意度升级
capture logit msat_c12_c5_2020 inc_6 inc_5 // * 相对收入降级(高于等于配偶 转为 低于配偶)→婚姻满意度降级(正向显著)
capture logit msat_c12_c5_2020 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→婚姻满意度降级(正向显著)
capture logit esup_5 msat_c12_c5_2020 msateco_c2_2020 msat_c1_2020 inc_6 inc_5

capture logit msateco_c2_2 inc_6 inc_5 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度升级(负向显著)
capture logit msateco_c2_5 inc_6 inc_5 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级


capture logit msateco_c2_2 inc_2 // * 相对收入增加(连续变量)→收入满意度升级(负向显著)
capture logit msateco_c2_2 inc_3 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度升级(不显著)

capture logit msateco_c2_5 inc_5 // * 相对收入降级(连续变量)→收入满意度降级(不显著)
capture logit msateco_c2_5 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)


capture logit msateco_c12_c_2020 inc_5
capture logit msateco_c12_c_2020 inc_6 inc_5 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级
capture logit msat_c12_c_2020 inc_6

capture logit esup_5 msat_c12_c5_2020 if gender_2020==0 & lifetime_2020==0
capture logit esup_5 msateco_c12_c5_2020 if gender_2020==0 & lifetime_2020==0

capture logit esup_2 msateco_c2_5 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)
capture logit esup_5 msateco_c2_5 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)

capture logit esup_2 msat_c2_5 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)


capture logit msateco_c2_5 inc_5 // * 相对收入降级(连续变量)→收入满意度降级(不显著)
capture logit msateco_c2_5 msat_c2_5 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)

capture logit esup_5 msat_c2_5 msateco_c2_5 inc_6 // * 配偶满意度减少→代际经济支持降级(正向显著) ?
capture logit esup_5 msat_c2_2 inc_6 // * 配偶满意度增加→代际经济支持降级(负向显著) ?



capture logit msat_c2_5 msateco_c2_5  inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)
capture logit esup_5 msateco_c2_5 msat_c2_5 inc_6 // * 配偶满意度减少→代际经济支持降级(正向显著) ?



capture logit esup_2 msat_c1_5 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)
capture logit esup_5 msat_c1_5 inc_6 // * 相对收入降级(高于等于配偶 转为 低于配偶)→收入满意度降级(正向显著)

capture logit esup_2 msat_c12_c_2020 inc_6 // * 相对婚姻满意度升级→代际经济支持升级(负向显著)
capture logit esup_5 msat_c12_c5_2020 inc_6 // *




/* ============================================================
[模块五] 2018-2022 两期平衡面板（已放弃 / 仅作敏感性分析参照）

【设计逻辑】
  一阶差分：ΔX₁₈₋₂₂ → ΔM₁₈₋₂₂ → ΔY₁₈₋₂₂
  通过差分消除个体固定效应，检验4年内"变化量"之间的因果中介路径。

【VanderWeele因果中介可行性评估】
  条件Ⅰ（A→Y无混杂）：✓  差分已控制时不变个体异质性
  条件Ⅱ（M→Y无混杂）：✓  协变量纳入可辅助控制
  条件Ⅲ（A→M无混杂）：✓  差分设计同样保证
  条件Ⅳ（无"处理后混杂"Z）：
    ✗  在4年差分框架下，理论上几乎不可满足。
       处理后混杂Z的定义：被处理变量ΔX影响（A→Z），
       且Z同时影响中介ΔM和结局ΔY（Z→M, Z→Y）。
       4年内所有时变变化量均可能充当Z，例如：
         - 2018→2022就业状态变化（受收入变化影响，同时影响婚姻满意度和代际支持）
         - 2018→2022健康变化、债务变化（均可被收入变化触发）
       更关键：新冠疫情（2020）是系统性外生冲击，
               破坏"变化连续平滑"的一阶差分基本前提，
               造成ΔM₁₈₋₂₂与疫情冲击高度混同，无法干净识别。

【结论与定位】
  差分框架可识别ΔX对ΔY的总效应及调节效应（主效应/调节框架有效），
  但VanderWeele四分解（CDE/PNDE/TNIE/PNIE）在此框架下条件Ⅳ不满足，
  中介分解结果存在处理后混杂偏误，不宜作为主要因果中介结论来源。
  建议定位：作为稳健性敏感性分析，对比"是否新冠冲击改变了效应方向"。
  正式因果中介分析迁移至R/CMAverse模块六前瞻性设计（见文件末）。

  注：变量构建已于2025年补充完整（msat_c21系列、债务、健康变量），
  与模块二/三差分变量集合对称，导出至：causal_mediation_18&22_bal.csv
============================================================ */
***** 2018 & 2022 两期平衡面板(一阶差分, 跨度太大、效果不好，放弃)
{
use "$pre_data\causal_mediation_18_22_unbal.dta",clear

tab1 year_n,miss

*2018-2022 两期平衡面板
drop if year==2020
tab1 year_n,miss


***** Declare data to be panel data *****
xtset id year  // 非完全平衡面板
sort id year

****   New variables needed below       **********
*bysort id: egen treat = max(marry)        //indicator for treatment group = which id's marry state is marry==1 
bysort id (year): gen pynr    = _n        //person-year ID (within person): 人年ID, 1、2、3循环
bysort id:        gen pycount = _N        // of person-years (within person): 人年ID总量

order id fid_ pynr pycount

keep if pycount==2
count
codebook id



keep ///
id fid_ ///
inc_a inc_a5 ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_c5_ msateco_c12_c5_ msathw_c12_c5_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
msat_c21_c_ msateco_c21_c_ msathw_c21_c_ ///
msat_c21_c5_ msateco_c21_c5_ msathw_c21_c5_ ///
msat_c21_ msateco_c21_ msathw_c21_ ///
year clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ urban_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
actor_employ_ partner_employ_ ///
nonhousing_debts_scale_ ///
total_debts_scale_ ///
qp201_actor_ /// 自评健康
qp202_actor_ /// 自评健康变化
fincome_cpi //


reshape wide fid_ ///
inc_a inc_a5 ///
msat_c12_c_ msateco_c12_c_ msathw_c12_c_ ///
msat_c12_c5_ msateco_c12_c5_ msathw_c12_c5_ ///
msat_c12_ msateco_c12_ msathw_c12_ ///
msat_c21_c_ msateco_c21_c_ msathw_c21_c_ ///
msat_c21_c5_ msateco_c21_c5_ msathw_c21_c5_ ///
msat_c21_ msateco_c21_ msathw_c21_ ///
clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ urban_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
actor_employ_ partner_employ_ ///
nonhousing_debts_scale_ ///
total_debts_scale_ ///
qp201_actor_ /// 自评健康
qp202_actor_ /// 自评健康变化
fincome_cpi_ ///
,i(id) j(year)



** 绝对收入变化
*量变
gen aincc_1 = aincc_2022 - aincc_2018
*质变(绝对收入增加与否: 0未增加, 1增加)
gen aincc_2 = 0
replace aincc_2 = 1 if aincc_1>0
*质变(绝对收入减少与否: 0未减少, 1减少)
gen aincc_5 = 0
replace aincc_5 = 1 if aincc_1<0

** 相对收入变化
*量变
gen inc_1 = inc_2022 - inc_2018
*质变(相对收入改善与否: 0未改善, 1改善)
gen inc_2 = 0
replace inc_2 = 1 if inc_1>0
*质变(相对收入升级与否: 0小于等于配偶, 1高于配偶)
gen inc_3 = 0
replace inc_3 = 1 if inc_a2018==0 & inc_a2022==1
*质变(相对收入恶化与否: 0未恶化, 1恶化)
gen inc_5 = 0
replace inc_5 = 1 if inc_1<0
*质变(相对收入降级与否: 0大于等于配偶, 1低于配偶)
gen inc_6 = 0
replace inc_6 = 1 if inc_a52018==0 & inc_a52022==1

** 代际经济支持变化
*量变
gen esup_1 = esup_2022 - esup_2018
*质变(绝对代际支持增加与否: 0未增加, 1增加)
gen esup_2 = 0
replace esup_2 = 1 if esup_1>0
*质变(绝对代际支持减少与否: 0未减少, 1减少)
gen esup_5 = 0
replace esup_5 = 1 if esup_1<0



** 本人婚姻满意度变化
*量变
gen msat_c1_1 = msat_c1_2022 - msat_c1_2018
*质变(本人婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c1_2 = 0
replace msat_c1_2 = 1 if msat_c1_1>0
*质变(本人婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c1_5 = 0
replace msat_c1_5 = 1 if msat_c1_1<0

** 本人收入满意度变化
*量变
gen msateco_c1_1 = msateco_c1_2022 - msateco_c1_2018
*质变(本人收入满意度改善与否: 0未改善, 1改善)
gen msateco_c1_2 = 0
replace msateco_c1_2 = 1 if msateco_c1_1>0
*质变(本人收入满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c1_5 = 0
replace msateco_c1_5 = 1 if msateco_c1_1<0

** 本人家务满意度变化
*量变
gen msathw_c1_1 = msathw_c1_2022 - msathw_c1_2018
*质变(本人家务满意度改善与否: 0未改善, 1改善)
gen msathw_c1_2 = 0
replace msathw_c1_2 = 1 if msathw_c1_1>0
*质变(本人家务满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c1_5 = 0
replace msathw_c1_5 = 1 if msathw_c1_1<0


** 配偶婚姻满意度变化
*量变
gen msat_c2_1 = msat_c2_2022 - msat_c2_2018
*质变(配偶婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c2_2 = 0
replace msat_c2_2 = 1 if msat_c2_1>0
*质变(配偶婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c2_5 = 0
replace msat_c2_5 = 1 if msat_c2_1<0

** 配偶收入满意度变化
*量变
gen msateco_c2_1 = msateco_c2_2022 - msateco_c2_2018
*质变(配偶收入满意度改善与否: 0未改善, 1改善)
gen msateco_c2_2 = 0
replace msateco_c2_2 = 1 if msateco_c2_1>0
*质变(配偶收入满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c2_5 = 0
replace msateco_c2_5 = 1 if msateco_c2_1<0

** 配偶家务满意度变化
*量变
gen msathw_c2_1 = msathw_c2_2022 - msathw_c2_2018
*质变(配偶家务满意度改善与否: 0未改善, 1改善)
gen msathw_c2_2 = 0
replace msathw_c2_2 = 1 if msathw_c2_1>0
*质变(配偶家务满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c2_5 = 0
replace msathw_c2_5 = 1 if msathw_c2_1<0




** 相对婚姻满意度变化
*量变
gen msat_c12_1 = msat_c12_2022 - msat_c12_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c12_2 = 0
replace msat_c12_2 = 1 if msat_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msat_c12_3 = 0
replace msat_c12_3 = 1 if msat_c12_c_2018==0 & msat_c12_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c12_5 = 0
replace msat_c12_5 = 1 if msat_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msat_c12_6 = 0
replace msat_c12_6 = 1 if msat_c12_c5_2018==0 & msat_c12_c5_2022==1


** 相对收入满意度变化
*量变
gen msateco_c12_1 = msateco_c12_2022 - msateco_c12_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msateco_c12_2 = 0
replace msateco_c12_2 = 1 if msateco_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msateco_c12_3 = 0
replace msateco_c12_3 = 1 if msateco_c12_c_2018==0 & msateco_c12_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c12_5 = 0
replace msateco_c12_5 = 1 if msateco_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msateco_c12_6 = 0
replace msateco_c12_6 = 1 if msateco_c12_c5_2018==0 & msateco_c12_c5_2022==1


** 相对家务满意度变化
*量变
gen msathw_c12_1 = msathw_c12_2022 - msathw_c12_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msathw_c12_2 = 0
replace msathw_c12_2 = 1 if msathw_c12_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msathw_c12_3 = 0
replace msathw_c12_3 = 1 if msathw_c12_c_2018==0 & msathw_c12_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c12_5 = 0
replace msathw_c12_5 = 1 if msathw_c12_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msathw_c12_6 = 0
replace msathw_c12_6 = 1 if msathw_c12_c5_2018==0 & msathw_c12_c5_2022==1


** 配偶相对婚姻满意度变化
*量变
gen msat_c21_1 = msat_c21_2022 - msat_c21_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msat_c21_2 = 0
replace msat_c21_2 = 1 if msat_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msat_c21_3 = 0
replace msat_c21_3 = 1 if msat_c21_c_2018==0 & msat_c21_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msat_c21_5 = 0
replace msat_c21_5 = 1 if msat_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msat_c21_6 = 0
replace msat_c21_6 = 1 if msat_c21_c5_2018==0 & msat_c21_c5_2022==1


** 配偶相对收入满意度变化
*量变
gen msateco_c21_1 = msateco_c21_2022 - msateco_c21_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msateco_c21_2 = 0
replace msateco_c21_2 = 1 if msateco_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msateco_c21_3 = 0
replace msateco_c21_3 = 1 if msateco_c21_c_2018==0 & msateco_c21_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msateco_c21_5 = 0
replace msateco_c21_5 = 1 if msateco_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msateco_c21_6 = 0
replace msateco_c21_6 = 1 if msateco_c21_c5_2018==0 & msateco_c21_c5_2022==1


** 配偶相对家务满意度变化
*量变
gen msathw_c21_1 = msathw_c21_2022 - msathw_c21_2018
*质变(相对婚姻满意度改善与否: 0未改善, 1改善)
gen msathw_c21_2 = 0
replace msathw_c21_2 = 1 if msathw_c21_1>0
*质变(相对婚姻满意度升级与否: 0小于等于配偶, 1高于配偶 )
gen msathw_c21_3 = 0
replace msathw_c21_3 = 1 if msathw_c21_c_2018==0 & msathw_c21_c_2022==1
*质变(相对婚姻满意度恶化与否: 0未恶化, 1恶化)
gen msathw_c21_5 = 0
replace msathw_c21_5 = 1 if msathw_c21_1<0
*质变(相对婚姻满意度降级与否: 0大于等于配偶, 1低于配偶 )
gen msathw_c21_6 = 0
replace msathw_c21_6 = 1 if msathw_c21_c5_2018==0 & msathw_c21_c5_2022==1

tab1 msat_c21_2 msat_c21_3 msat_c21_5 msat_c21_6 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ,miss

*** 控制变量

* TICs
sum ///
gender_2018 aage_2018 actor_edu2_2018 ahk_2018 /// agegap_ sibling_ atrust_
prtgender_2018 prtage_2018 prtedu_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
lifetime_2018 //

* TVCs 两期变化
sum ///
dwm_2018 actor_siops_2018 child_2018 aincc_2018 ahw_2018 ahk_2018  /// agegap_ sibling_ atrust_
prtmarr_2018 prtcor_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
fmlincc_2018 //

	 

** 父辈支持变化(0其他, 1无支持变有支持)
gen dwm_1 = 0
replace dwm_1 = 1 if dwm_2018==0 & dwm_2022==1

**子女数量变化
*量变
gen child_1 = child_2022 - child_2018
*质变(子女数量增加与否: 0未增加, 1增加)
gen child_2 = 0
replace child_2 = 1 if child_1>0 
*质变(子女数量减少与否: 0未减少, 1减少)
gen child_5 = 0
replace child_5 = 1 if child_1<0 

**绝对家务变化
*量变
gen ahw_1 = ahw_2022 - ahw_2018
*质变(绝对家务增加与否: 0未增加, 1增加)
gen ahw_2 = 0
replace ahw_2 = 1 if ahw_1>0 
*质变(绝对家务减少与否: 0未减少, 1减少)
gen ahw_5 = 0
replace ahw_5 = 1 if ahw_1<0 

** 相对家务变化
*量变
gen hw_1 = hw_2022 - hw_2018
*质变(相对家务改善与否: 0未改善, 1改善)
gen hw_2 = 0
replace hw_2 = 1 if hw_1>0
*质变(相对家务升级与否: 0小于等于配偶, 1高于配偶)
gen hw_3 = 0
replace hw_3 = 1 if hw_2018<=0 & hw_2022>0
*质变(相对家务恶化与否: 0未恶化, 1恶化)
gen hw_5 = 0
replace hw_5 = 1 if hw_1<0
*质变(相对家务降级与否: 0大于等于配偶, 1低于配偶)
gen hw_6 = 0
replace hw_6 = 1 if hw_2018>=0 & hw_2022<0

**绝对职业声望变化
*量变
gen actor_siops_1 = actor_siops_2022 - actor_siops_2018
*质变(绝对职业声望增加与否: 0未增加, 1增加)
gen actor_siops_2 = 0
replace actor_siops_2 = 1 if actor_siops_1>0 
*质变(绝对职业声望减少与否: 0未减少, 1减少)
gen actor_siops_5 = 0
replace actor_siops_5 = 1 if actor_siops_1<0 
 
 
** 父母婚姻变化(0其他, 1在婚变失婚)
gen prtmarr_1 = 0
replace prtmarr_1 = 1 if prtmarr_2018==0 & prtmarr_2022==1

** 父母同住变化(0其他, 1非同住变同住)
gen prtcor_1 = 0
replace prtcor_1 = 1 if prtcor_2018==0 & prtcor_2022==1
** 父母同住变化(0其他, 1同住变非同住)
gen reside_ind_1 = 0
replace reside_ind_1 = 1 if prtcor_2018==1 & prtcor_2022==0

** 家庭收入变化
gen fmlincc_1 = fmlincc_2022 - fmlincc_2018
*质变(家庭收入增加与否: 0未增加, 1增加)
gen fmlincc_2 = 0
replace fmlincc_2 = 1 if fmlincc_1>0
*质变(家庭收入减少与否: 0未减少, 1减少)
gen fmlincc_5 = 0
replace fmlincc_5 = 1 if fmlincc_1<0

** 非房贷借款变化
*量变
gen nonhousing_debts_1 = nonhousing_debts_scale_2022 - nonhousing_debts_scale_2018
*质变(非房贷借款增加与否: 0未增加, 1增加)
gen nonhousing_debts_2 = 0
replace nonhousing_debts_2 = 1 if nonhousing_debts_1>0
*质变(非房贷借款减少与否: 0未减少, 1减少)
gen nonhousing_debts_5 = 0
replace nonhousing_debts_5 = 1 if nonhousing_debts_1<0

** 总借款变化
*量变
gen total_debts_1 = total_debts_scale_2022 - total_debts_scale_2018
*质变(总借款增加与否: 0未增加, 1增加)
gen total_debts_2 = 0
replace total_debts_2 = 1 if total_debts_1>0
*质变(总借款减少与否: 0未减少, 1减少)
gen total_debts_5 = 0
replace total_debts_5 = 1 if total_debts_1<0

** 自评健康变化(逆向编码:1非常满意,5非常不满意)
*量变
gen shealth_1 = qp201_actor_2022 - qp201_actor_2018
*质变(自评健康改善与否: 0未改善, 1改善)
gen shealth_2 = 0
replace shealth_2 = 1 if shealth_1<0
*质变(自评健康恶化与否: 0未恶化, 1恶化)
gen shealth_5 = 0
replace shealth_5 = 1 if shealth_1>0

*质变(自评健康变好: 0未变好, 1变好)
gen schealth_2 = 0
replace schealth_2 = 1 if qp202_actor_2022==1
*质变(自评健康变差: 0未变差, 1变差)
gen schealth_5 = 0
replace schealth_5 = 1 if qp202_actor_2022==5

*中介模型控制变量(增加→增加→增加)
sum ///
esup_1 esup_2 inc_1 inc_2 inc_3 msat_c12_1 msat_c12_2 msat_c12_3 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 ///
msat_c12_1 msat_c12_2 msat_c12_3 ///
gender_2018 aage_2018 actor_edu2_2018 actor_siops_1 actor_siops_2  ///
child_1 child_2 ahw_1 ahw_2 ahk_2018 ///
lifetime_2018 fmlincc_1 fmlincc_2

*结果模型控制变量(增加→增加→增加)		 
sum ///
msat_c1_1 msat_c1_2 msat_c2_1 msat_c2_2 ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	


*中介模型控制变量(减少→减少→减少)
sum ///
esup_1 esup_5 inc_1 inc_5 inc_6 msat_c12_1 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_5 msateco_c12_6 ///
msat_c12_1 msat_c12_5 msat_c12_6 ///
gender_2018 aage_2018 actor_edu2_2018 actor_siops_1 actor_siops_2  ///
child_1 child_2 ahw_1 ahw_2 ahk_2018 ///
lifetime_2018 fmlincc_1 fmlincc_2

*结果模型控制变量(减少→减少→减少)		 
sum ///
msat_c1_1 msat_c1_5 msat_c2_1 msat_c2_5 ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	





global covar ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	

sum $covar
/*
*** 收入变化→相对婚姻满意度变化→代际经济支持变化
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2022 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2022 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 esup_2018 gender_2018 prtgender_2022 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c1_2 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)


med4way esup_2 aincc_2 msat_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 esup_2018 gender_2018 prtgender_2022 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
* 只有这个显著
med4way esup_2 aincc_2 msat_c2_2 esup_2018  gender_2018 prtgender_2022 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 esup_2018 gender_2018 prtgender_2022 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
 

med4way esup_2 aincc_2 msateco_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2022 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
* 只有这个显著
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2022 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msateco_c2_2 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_2 aincc_2 msat_c12_3 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2022 $covar if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2022 $covar if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2022 $covar if lifetime_2018==0 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 aincc_2 msat_c12_3 gender_2018 prtgender_2022 $covar if lifetime_2018==1 & gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_1 aincc_2 msat_c1_2 gender_2018 prtgender_2022, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c1_2 gender_2018 prtgender_2022 if gender_2018==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c1_2 gender_2018 prtgender_2022 if gender_2018==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

med4way esup_1 aincc_2 msat_c2_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 if gender_2018==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 if gender_2018==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

med4way esup_1 aincc_2 msat_c12_3 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 if gender_2018==0 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 if gender_2018==1 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)






med4way esup_2 inc_3 msat_c1_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if gender_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if gender_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==0, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==1, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c1_2 if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)


med4way esup_2 inc_3 msat_c2_2 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c2_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c2_2 if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



global covar ///
dwm_1 gender_2022 aage_2022 actor_edu2_2022 actor_siops_1 actor_siops_2 ///
child_1 child_2 ahw_1 ahw_2 ahk_2022 ///
prtmarr_1 prtcor_1 prtgender_2022 prtage_2022 prtedu_2022 ///
lifetime_2022 fmlincc_1 fmlincc_2	

global covar ///
        msat_c12_2018 ///
        msat_c1_2  msat_c2_2 ///
        dwm_2022  gender_2022  aage_2022  actor_edu2_2022  actor_siops_2 ///
        child_2  aincc_2  ahw_2  ahk_2022  ///
        prtmarr_1  prtcor_1  prtgender_2022  prtage_2022  prtedu_2022 ///
        lifetime_2022  fmlincc_2	//

sum $covar

*** 相对婚姻满意度
med4way esup_2 inc_3 msat_c12_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_2 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)




med4way esup_2 inc_3 msat_c12_3 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msat_c12_3 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



*** 收入满意度
med4way esup_2 inc_3 msateco_c2_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c2_2 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



*** 收入满意度
med4way esup_2 inc_3 msateco_c1_2 $covar, yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
*只有这个显著
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==0 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==0 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==1 & gender_2018==0 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2 inc_3 msateco_c1_2 $covar if lifetime_2018==1 & gender_2018==1 , yreg(logistic) mreg(logistic) a0(0) a1(1) m(0)



med4way esup_1 aincc_2 msat_c1_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c2_2 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_1 aincc_2 msat_c12_3 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)

logit esup_2 aincc_2  prtage_2022 prtgender_2022 if gender_2018==1

logit esup_2 inc_3  prtage_2022 prtgender_2022 if gender_2018==1 

reg esup_1 aincc_1 prtage_2022 
reg esup_1 aincc_1 prtage_2022 , vce(robust)
reg esup_1 aincc_1  prtage_2022, vce(cluster fid_2018)

logit esup_2 inc_3
logit esup_2 inc_2
reg esup_1 inc_1


logit esup_2  dwm_2022
tab1 esup_2 dwm_1

preserve
tab1 actor_employ_* partner_employ_*,miss
count if actor_employ_2018==1 & actor_employ_2022==1 & partner_employ_2018==1 & partner_employ_2022==1 
keep if actor_employ_2018==1 & actor_employ_2022==1 & partner_employ_2018==1 & partner_employ_2022==1 

logit esup_2 aincc_2
reg esup_1 aincc_1

logit esup_2 inc_3
logit esup_2 inc_2
reg esup_1 inc_1

restore


global covar2022 ///
dwm_2022 gender_2022 aage_2022 actor_edu2_2022 actor_siops_2022 child_2022 childborn_2022 aincc_2022 ahw_2022 ahk_2022  /// agegap_ sibling_ atrust_
 prtmarr_2022 prtcor_2022 prtgender_2022 prtage_2022 prtedu_2022 /// prtchildn_2022 prtparty_2022 prthk_2022  ///
lifetime_2022 fmlincc_2022 //

sum $covar2022

global covar2018 ///
dwm_2018 gender_2018 aage_2018 actor_edu2_2018 actor_siops_2018 child_2018 childborn_2018 aincc_2018 ahw_2018 ahk_2018  /// agegap_ sibling_ atrust_
 prtmarr_2018 prtcor_2018 prtgender_2018 prtage_2018 prtedu_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
lifetime_2018  fmlincc_2018 //

sum $covar2018

tabstat aincc_2018 msat_c1_2018 msat_c2_2018
dis 5.733915-0.5
dis 5.733915+0.5

* 不显著
med4way esup_2022 aincc_2018 msat_c1_2018 $covar2022 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.5379)
med4way esup_2022 aincc_2018 msat_c2_2018 $covar2022 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.55492)
med4way esup_2022 inc_a2018 msat_c1_2018 $covar2022 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.5379)
med4way esup_2022 inc_a2018 msat_c2_2018 $covar2022 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.55492)

* 只有这个显著
med4way esup_2022 inc_a2018 msat_c12_c_2018 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2018 msat_c12_c_2018 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2018 msat_c12_c_2018 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2018 msat_c12_c_2018 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2018 msat_c12_c_2018 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2018 msat_c12_c_2018 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

gen inc_a201820 = 0 
replace inc_a201820 = 1 if inc_a2018==1 & inc_a2022==1

* 不显著
med4way esup_2022 inc_a201820 msat_c12_c_2022 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a201820 msat_c12_c_2018 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a201820 msat_c12_c_2022 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a201820 msat_c12_c_2018 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a201820 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a201820 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
*/

*导出csv格式
export delimited id fid_2018 fid_2022 ///
esup_2018 inc_a2018 inc_a52018 inc_2018 ///
msat_c12_c_2018 msateco_c12_c_2018 msathw_c12_c_2018 /// 相对满意度(增加与否)
msat_c12_c5_2018 msateco_c12_c5_2018 msathw_c12_c5_2018 /// 相对满意度(减少与否)
msat_c12_2018 msateco_c12_2018 msathw_c12_2018 ///
msat_c21_2018 msateco_c21_2018 msathw_c21_2018 ///
msat_c1_2018 msat_c2_2018 ///
msateco_c1_2018 msateco_c2_2018 ///
msathw_c1_2018 msathw_c2_2018 ///
dwm_2018 gender_2018 aage_2018 actor_edu2_2018 actor_siops_2018 child_2018 childborn_2018 aincc_2018 ahw_2018 ahk_2018 urban_2018  /// agegap_ sibling_ atrust_
prtmarr_2018 prtcor_2018 prtgender_2018 prtage_2018 prtedu_2018 /// prtchildn_2018 prtparty_2018 prthk_2018  ///
lifetime_2018  fmlincc_2018 ///
esup_2022 inc_a2022 inc_a52022 inc_2022 ///
msat_c12_c_2022 msateco_c12_c_2022 msathw_c12_c_2022 /// 相对满意度(增加与否)
msat_c12_c5_2022 msateco_c12_c5_2022 msathw_c12_c5_2022 /// 相对满意度(减少与否)
msat_c12_2022 msateco_c12_2022 msathw_c12_2022 ///
msat_c21_2022 msateco_c21_2022 msathw_c21_2022 ///
msat_c1_2022 msat_c2_2022 ///
msateco_c1_2022 msateco_c2_2022 ///
msathw_c1_2022 msathw_c2_2022 ///
dwm_2022 gender_2022 aage_2022 actor_edu2_2022 actor_siops_2022 child_2022 childborn_2022 aincc_2022 ahw_2022 ahk_2022 urban_2022  /// agegap_ sibling_ atrust_
prtmarr_2022 prtcor_2022 prtgender_2022 prtage_2022 prtedu_2022 /// prtchildn_2022 prtparty_2022 prthk_2022  ///
lifetime_2022 fmlincc_2022 ///
esup_1 esup_2 esup_5 aincc_1 aincc_2 aincc_5 inc_1 inc_2 inc_3 inc_5 inc_6 msat_c12_1 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 msateco_c12_5 msateco_c12_6 ///
msathw_c12_1 msathw_c12_2 msathw_c12_3 msathw_c12_5 msathw_c12_6 ///
msat_c21_1 msat_c21_2 msat_c21_3 msat_c21_5 msat_c21_6 ///
msateco_c21_1 msateco_c21_2 msateco_c21_3 msateco_c21_5 msateco_c21_6 ///
msathw_c21_1 msathw_c21_2 msathw_c21_3 msathw_c21_5 msathw_c21_6 ///
msat_c1_1 msat_c1_2 msat_c1_5 msat_c2_1 msat_c2_2 msat_c2_5 ///
msateco_c1_1 msateco_c1_2 msateco_c1_5 msateco_c2_1 msateco_c2_2 msateco_c2_5 ///
msathw_c1_1 msathw_c1_2 msathw_c1_5 msathw_c2_1 msathw_c2_2 msathw_c2_5 ///
dwm_1 actor_siops_1 actor_siops_2 actor_siops_5 ///
child_1 child_2 ahw_1 ahw_2 ahw_5 ///
prtmarr_1 prtcor_1 fmlincc_1 fmlincc_2 fmlincc_5 ///
nonhousing_debts_1 nonhousing_debts_2 nonhousing_debts_5 ///
total_debts_1 total_debts_2 total_debts_5 ///
shealth_1 shealth_2 shealth_5 ///
schealth_2 schealth_5 ///
reside_ind_1 ///
using "$data\causal_mediation_18&22_bal.csv", nolabel replace  // 没有值标签

logit msat_c12_c_2018 inc_a2018 msateco_c12_c_2018 msathw_c12_c_2018

logit msat_c12_c_2018 inc_a2018 msateco_c12_2018 msathw_c12_2018

reg esup_2022 inc_a2018 aincc_2018 msat_c12_c_2018 msat_c12_2018 msat_c1_2018 msat_c2_2018

reg esup_2022 inc_a2018 msat_c12_c_2018 msat_c1_2018 msat_c2_2018
reg esup_2022 inc_a2018 msat_c12_c_2018 msat_c1_2018 msat_c2_2018
reg esup_2022 inc_a2018 msat_c12_c_2018 msat_c1_2018 msat_c2_2018

save "$pre_data\causal_mediation_18&22_bal.dta",replace

rename (*2018 *2022) (*begin *end)


*导出csv格式
export delimited id fid_begin fid_end ///
esup_begin inc_abegin inc_a5begin inc_begin ///
msat_c12_c_begin msateco_c12_c_begin msathw_c12_c_begin /// 相对满意度(增加与否)
msat_c12_c5_begin msateco_c12_c5_begin msathw_c12_c5_begin /// 相对满意度(减少与否)
msat_c12_begin msateco_c12_begin msathw_c12_begin ///
msat_c1_begin msat_c2_begin /// 
msateco_c1_begin msateco_c2_begin ///
msathw_c1_begin msathw_c2_begin ///
dwm_begin gender_begin aage_begin actor_edu2_begin actor_siops_begin child_begin childborn_begin aincc_begin ahw_begin ahk_begin urban_begin  /// agegap_ sibling_ atrust_
prtmarr_begin prtcor_begin prtgender_begin prtage_begin prtedu_begin /// prtchildn_begin prtparty_begin prthk_begin  ///
lifetime_begin  fmlincc_begin ///
esup_end inc_aend inc_end ///
msat_c12_c_end msateco_c12_c_end msathw_c12_c_end /// 相对满意度(增加与否)
msat_c12_c5_end msateco_c12_c5_end msathw_c12_c5_end /// 相对满意度(减少与否)
msat_c12_end msateco_c12_end msathw_c12_end ///
msat_c1_end msat_c2_end ///
msateco_c1_end msateco_c2_end ///
msathw_c1_end msathw_c2_end ///
dwm_end gender_end aage_end actor_edu2_end actor_siops_end child_end childborn_end aincc_end ahw_end ahk_end urban_end  /// agegap_ sibling_ atrust_
prtmarr_end prtcor_end prtgender_end prtage_end prtedu_end /// prtchildn_end prtparty_end prthk_end  ///
lifetime_end fmlincc_end ///
esup_1 esup_2 esup_5 aincc_1 aincc_2 aincc_5 inc_1 inc_2 inc_3 inc_5 inc_6 msat_c12_1 msat_c12_2 msat_c12_3 msat_c12_5 msat_c12_6 ///
msateco_c12_1 msateco_c12_2 msateco_c12_3 msateco_c12_5 msateco_c12_6 ///
msathw_c12_1 msathw_c12_2 msathw_c12_3 msathw_c12_5 msathw_c12_6 ///
msat_c1_1 msat_c1_2 msat_c1_5 msat_c2_1 msat_c2_2 msat_c2_5 ///
msateco_c1_1 msateco_c1_2 msateco_c1_5 msateco_c2_1 msateco_c2_2 msateco_c2_5 ///
msathw_c1_1 msathw_c1_2 msathw_c1_5 msathw_c2_1 msathw_c2_2 msathw_c2_5 ///
dwm_1 actor_siops_1 actor_siops_2 actor_siops_5 ///
child_1 child_2 ahw_1 ahw_2 ahw_5 ///
prtmarr_1 prtcor_1 fmlincc_1 fmlincc_2 fmlincc_5 ///
using "$data\causal_mediation_18&22_bal.csv", nolabel replace  // 没有值标签

}
save "$pre_data\causal_mediation_18&22_bal_rename.dta",replace


/* ============================================================
[模块六] 三期完全平衡面板——前瞻性中介设计（核心数据模块）

【与前五个模块的逻辑对比】
  模块    时间跨度   数据形式    X                M               Y
  模块一  无(横截面) 长格式      同期inc_a        同期msat        同期esup     （探索）
  模块二  2018-2020  宽格式差分  ΔX₁₈₋₂₀(2年)    ΔM₁₈₋₂₀(2年)   ΔY₁₈₋₂₀     （主力）
  模块三  2020-2022  宽格式差分  ΔX₂₀₋₂₂(2年)    ΔM₂₀₋₂₂(2年)   ΔY₂₀₋₂₂     （主力）
  模块四  前两期合并  面板差分    组合差分         组合差分        组合差分     （稳健）
  模块五  2018-2022  宽格式差分  ΔX₁₈₋₂₂(4年)    ΔM₁₈₋₂₂(4年)   ΔY₁₈₋₂₂     （敏感）
  模块六  2018-2020-2022 三期宽  X₂₀₁₈(水平)     M₂₀₂₀(水平)    Y₂₀₂₂(水平)  【本模块】

  核心差异：模块六不使用差分，而是利用三个时间点天然分离实现
           "前瞻性中介"（Prospective Mediation）：X在M之前，M在Y之前。

【设计逻辑】
  前瞻中介链：X₂₀₁₈ → M₂₀₂₀ → Y₂₀₂₂
  每个节点独立测量，时序可信，符合VanderWeele因果中介的序贯可忽略性假设。
  与差分模型（组内变化效应）互补：本模块识别的是跨期"水平效应"路径。

【VanderWeele因果中介可行性评估——四个识别条件】
  条件Ⅰ（X₂₀₁₈→Y₂₀₂₂无未测量混杂）：
    ✓  基线协变量（covar2018）大量控制；主要残余威胁：早期家庭结构因素
  条件Ⅱ（M₂₀₂₀→Y₂₀₂₂无未测量混杂）：
    ✓  covar2020纳入，时序保证优于横截面设计
  条件Ⅲ（X₂₀₁₈→M₂₀₂₀无未测量混杂）：
    ✓  同基线控制
  条件Ⅳ（不存在"处理后混杂" Z）：
    ⚠  存在，需通过CMAverse的postc参数处理。

    【关键定义】处理后混杂因子Z满足：
      (a) Z被处理变量X₂₀₁₈所影响（A→Z，即Z在处理之后被触发）
      (b) Z同时影响中介M₂₀₂₀和结局Y₂₀₂₂（Z→M 且 Z→Y）
    注意：Z不是"不被X影响"的变量，而恰恰相反——Z必须是被X影响的变量。
          这是"处理后混杂"（post-treatment confounding）的命名来源。

    可能的Z候选（2020年测量）：
      aincc_2020    → 收入升高可促进就业/升职，进而影响满意度和代际支持
      actor_siops_2020 → 职业地位受收入影响，影响婚姻互动和代际行为
      ahw_2020      → 收入升高可外包家务，减少家务矛盾，影响满意度
      child_2020    → 收入可能影响生育决策，子女数量影响代际关系
      （不适合的例子：父母突发疾病等外生冲击，若不受X₂₀₁₈影响则不是Z）

    处理方式：
      ✗ 控制Z → 过控偏误（overcontrol bias）
      ✗ 忽略Z → 中间混杂偏误（intermediate confounding bias）
      ✓ 在CMAverse中通过 postc 参数指定，
        使用 model="gcomp"（G-computation）或 model="msm"（IPW）正确处理

【与差分模型的互补定位】
  差分模型（模块二/三/四）：
    → 识别组内变化路径，排除时不变个体异质性（within效应）
    → 适合检验"当收入变化时，婚满是否作为中介/调节"
    → 条件Ⅳ理论上不完全满足，中介分解为探索性估计
  前瞻中介（模块六）：
    → 利用天然时序，各识别条件最优满足
    → VanderWeele四分解（CDE/PNDE/TNIE/PNIE）的主模型数据来源
    → postc参数正确处理处理后混杂，避免过控和遗漏
    → 发表策略：模块六为主表，模块二/三/四为附表稳健性检验

【当前状态】
  本块代码完成三期数据清理和宽格式reshape，
  数据保存至：$pre_data\causal_mediation_18&20&22_bal_new.dta
  Stata中med4way仅用于探索性验证，
  正式VanderWeele四分解迁移至R/CMAverse（详见文件末CMAverse迁移方案）。
============================================================ */
***** 2018 & 2020 & 2022 三期平衡面板(放弃)
{
use "$pre_data\causal_mediation_18_22_unbal.dta",clear

tab1 year_n,miss

*2020-2022 两期平衡面板
tab1 year_n,miss


***** Declare data to be panel data *****
xtset id year  // 非完全平衡面板
sort id year

****   New variables needed below       **********
*bysort id: egen treat = max(marry)        //indicator for treatment group = which id's marry state is marry==1 
bysort id (year): gen pynr    = _n        //person-year ID (within person): 人年ID, 1、2、3循环
bysort id:        gen pycount = _N        // of person-years (within person): 人年ID总量

order id fid_ pynr pycount

keep if pycount==3
count
codebook id

keep ///
id fid_ ///
inc_a msat_c12_c_ ///
year clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ //


reshape wide fid_ ///
inc_a msat_c12_c_ ///
clos_ esup_ isup_ opp_ inc_ incc_ inccb_ hw_ hwb_ child_ dw_ childm_ dwm_ dwm2_ gender_ agegap_ aage_ actor_edu1_ actor_edu2_ actor_siops_ sibling_ childborn_ aincc_ ainccr_ ahw_ ahk_ atrust_ prtage_ prtmarr_ prtcor_ fmlincc_ hwc1_ ajc_ pjc_ lifetime_ housewc_16_22_ jobclass_ jobclass1_ jobclass3_ jobclassa_ jobclassp_ fself_ fself1_ actor_fself_ partner_fself_ fq3pid_ resp1pid_ qf706_a__ qf705_a__ oppor5_ count_final totalcount_final msat_c1_ msateco_c1_ msathw_c1_ msat_c2_ msateco_c2_ msathw_c2_ ///
prtedu_ ///
prthk_ ///
prtparty_ ///
prtchildn_ ///
prtgender_ ///
,i(id) j(year) 

global covar2022 ///
dwm_2022 gender_2022 aage_2022 actor_edu2_2022 actor_siops_2022 child_2022 childborn_2022 aincc_2022 ahw_2022 ahk_2022  /// agegap_ sibling_ atrust_
 prtmarr_2022 prtcor_2022 prtgender_2022 /// prtchildn_ prtparty_ prtage_ prtedu_ prthk_
lifetime_2022 // fmlincc_

* 模块六自定义covar2020，确保模块独立可运行（不依赖模块三的全局定义）
global covar2020 ///
dwm_2020 gender_2020 aage_2020 actor_edu2_2020 actor_siops_2020 child_2020 childborn_2020 aincc_2020 ahw_2020 ahk_2020  /// agegap_ sibling_ atrust_
 prtmarr_2020 prtcor_2020 prtgender_2020 prtage_2020 prtedu_2020 /// prtchildn_2020 prtparty_2020 prthk_2020  ///
lifetime_2020 fmlincc_2020 //

tabstat aincc_2020 msat_c1_2020 msat_c2_2020
dis 5.733915-0.5
dis 5.733915+0.5

* 不显著
med4way esup_2022 aincc_2020 msat_c1_2020 $covar2022 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.5379)
med4way esup_2022 aincc_2020 msat_c2_2020 $covar2022 , yreg(linear) mreg(linear) a0(5.233915) a1(6.233915) m(4.55492)
med4way esup_2022 inc_a2020 msat_c1_2020 $covar2022 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.5379)
med4way esup_2022 inc_a2020 msat_c2_2020 $covar2022 , yreg(linear) mreg(linear) a0(0) a1(1) m(4.55492)

* 只有这个显著
med4way esup_2022 inc_a2018 msat_c12_c_2020 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2018 msat_c12_c_2020 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2018 msat_c12_c_2020 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2020 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2022 inc_a2020 msat_c12_c_2022 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2022 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2020 msat_c12_c_2022 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2022 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2020 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2020 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2022 inc_a2022 msat_c12_c_2022 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2022 msat_c12_c_2022 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2022 msat_c12_c_2022 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2022 msat_c12_c_2022 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a2022 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a2022 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

med4way esup_2020 inc_a2020 msat_c12_c_2020 $covar2020 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a2020 msat_c12_c_2020 $covar2020 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2020 inc_a2020 msat_c12_c_2020 $covar2020 if gender_2020 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a2020 msat_c12_c_2020 $covar2020 if gender_2020 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2020 inc_a2020 msat_c12_c_2020 $covar2020 if gender_2020 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2020 inc_a2020 msat_c12_c_2020 $covar2020 if gender_2020 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)

gen inc_a202022 = 0 
replace inc_a202022 = 1 if inc_a2020==1 & inc_a2022==1

* 不显著
med4way esup_2022 inc_a202022 msat_c12_c_2022 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a202022 msat_c12_c_2020 $covar2022 , yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a202022 msat_c12_c_2022 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a202022 msat_c12_c_2020 $covar2022 if gender_2022 ==0, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
med4way esup_2022 inc_a202022 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(0)
med4way esup_2022 inc_a202022 msat_c12_c_2022 $covar2022 if gender_2022 ==1, yreg(linear) mreg(logistic) a0(0) a1(1) m(1)
}
* 注意：save在{...}块之外，数据已在keep if pycount==3后reshape为宽格式
save "$pre_data\causal_mediation_18&20&22_bal_new.dta",replace


/* ================================================================================
【CMAverse迁移方案】Stata数据清理完成后，导入R执行因果中介分析
================================================================================

【分析生态分工】
  Stata（本文件）：数据清理、变量构建、差分变量生成、宽格式reshape、导出CSV/dta
  R / CMAverse  ：VanderWeele四分解（CDE / PNDE / TNIE / PNIE / INTref / INTmed）
  CMAverse文档  ：https://github.com/BS1125/CMAverse/

【研究问题】
  在家庭系统理论框架下，检验"婚姻满意度"如何（中介 and/or 调节）
  干预"子代收入"对"代际经济支持"的影响。

  假设路径一——绝对收入：
    A = inc_a2018（子代高/低绝对收入，二值）
    M = msat_c1_2020（本人婚姻满意度）/ msat_c2_2020（配偶）/
        msat_c12_c_2020（夫妻相对婚姻满意度，高于配偶与否，二值）
    Y = esup_2022（代际经济支持）

  假设路径二——相对收入：
    A = inc_a2018（子代收入高于配偶与否 / 高于父母与否，二值）
    M = 同上
    Y = esup_2022

  六组M变量：本人满意度(c1) / 配偶满意度(c2) / 相对满意度(c12)
              × 三类满意度维度：总体(msat) / 经济(msateco) / 家务(msathw)

【R核心框架——模块六前瞻中介（主模型）】

  # 读入数据（Stata导出）
  library(CMAverse)
  library(haven)
  dat6 <- read_dta("causal_mediation_18&20&22_bal_new.dta")

  # 主模型：相对婚姻满意度（二值）中介，G-computation
  res_main <- cmest(
    data     = dat6,
    model    = "gcomp",            # G-computation，首选
    outcome  = "esup_2022",        # 代际经济支持（连续用linear，二值用logistic）
    exposure = "inc_a2018",        # 子代绝对收入（二值）
    mediator = "msat_c12_c_2020",  # 夫妻相对婚姻满意度（二值）
    basec    = c("dwm_2018","gender_2018","aage_2018",
                 "actor_edu2_2018","actor_siops_2018",
                 "child_2018","aincc_2018","lifetime_2018","fmlincc_2018"),
    postc    = c("aincc_2020","actor_siops_2020","ahw_2020","child_2020"),
    # postc：被X₂₀₁₈影响 且 影响M₂₀₂₀和Y₂₀₂₂ 的2020年中间混杂变量
    # 正确处理方式：既不控制（过控偏误）也不忽略（中间混杂偏误），由gcomp/msm识别
    EMint    = TRUE,               # 允许暴露-中介交互（检验调节性中介）
    yreg     = "linear",           # Y连续时用linear；二值时改logistic
    mreg     = list("logistic"),   # M二值时用logistic；连续时改linear
    astar    = 0,                  # 对照：低收入
    a        = 1,                  # 处理：高收入
    mval     = list(0),            # M参考值（相对满意度"未超配偶"）
    estimation = "imputation",
    inference  = "bootstrap",
    nboot    = 500
  )
  summary(res_main)
  # 输出：CDE / PNDE / TNIE / PNIE / INTref / INTmed / PM（中介比例）

  # 稳健性验证：MSM/IPW模型
  res_msm <- cmest(
    data     = dat6,
    model    = "msm",              # 逆概率加权
    outcome  = "esup_2022",
    exposure = "inc_a2018",
    mediator = "msat_c12_c_2020",
    basec    = c("dwm_2018","gender_2018","aage_2018",
                 "actor_edu2_2018","actor_siops_2018",
                 "child_2018","aincc_2018","lifetime_2018","fmlincc_2018"),
    postc    = c("aincc_2020","actor_siops_2020","ahw_2020","child_2020"),
    EMint    = TRUE,
    yreg     = "linear",
    mreg     = list("logistic"),
    astar    = 0, a = 1, mval = list(0),
    estimation = "imputation",
    inference  = "bootstrap",
    nboot    = 500
  )

【R核心框架——差分数据稳健性检验（模块二/三/四）】

  # 读入差分数据（以模块二2018-2020为例）
  dat2 <- read.csv("causal_mediation_18&20_bal.csv")
  # A = inc_2（绝对收入升级，二值差分）
  # M = msat_c12_2（相对婚姻满意度改善，二值差分）
  # Y = esup_2（代际经济支持升级，二值差分）

  res_diff <- cmest(
    data     = dat2,
    model    = "gcomp",
    outcome  = "esup_2",
    exposure = "inc_2",
    mediator = "msat_c12_2",
    basec    = c("dwm_2018","gender_2018","aage_2018",
                 "actor_edu2_2018","aincc_2018","lifetime_2018"),
    # 差分模型：理论上postc不可完全满足（条件Ⅳ受损），
    # 此处不设postc，报告时注明局限性，作为探索性估计
    EMint    = TRUE,
    yreg     = "logistic",
    mreg     = list("logistic"),
    astar    = 0, a = 1, mval = list(0),
    estimation = "imputation",
    inference  = "bootstrap",
    nboot    = 500
  )

【差分模型与前瞻中介的互补定位】
  差分模型（模块二/三/四）：
    识别目标  → 组内变化效应（within effect），排除时不变异质性
    优势      → 有效控制个体固定效应；可比较"2年差"与"4年差"结果
    局限      → 条件Ⅳ（处理后混杂）不可完全满足；差分量无基准水平意义
    定位      → 附表稳健性检验；绝对/相对收入变化效应的总效应/调节验证

  前瞻中介（模块六）：
    识别目标  → 跨期水平效应（cross-wave level effect），三时点天然分离
    优势      → 识别条件Ⅰ-Ⅳ最优满足；postc可正确处理处理后混杂
    局限      → 三期平衡面板样本量小；识别水平效应，不能与差分效应直接比较
    定位      → 主表VanderWeele四分解（CDE/PNDE/TNIE/PNIE）

  发表策略：
    主表  → 模块六（CMAverse gcomp + msm），前瞻中介因果分解
    附表A → 模块二/三（差分调节回归/CMAverse探索），稳健性
    附表B → 模块五（4年差分），新冠冲击敏感性分析

================================================================================
*/



