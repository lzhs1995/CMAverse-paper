# ==============================================================================
# 八条候选链基础回归 v7.1
#
# 研究边界：
#   1. 仅估计 AA-S/P、AR-S/P、RA-S/P、RR-S/P 八条二分类链；
#   2. 每条链拟合 Yazawa 式五个调整关联模型；
#   3. 不运行 CMAverse，不进行显著性择优，不构造下降/三分类/ridit 主分析；
#   4. 直接使用已核验的亲子二元组—区间分析底稿，不重建 CFPS 原始数据库；
#   5. 主推断按成年子女 actor_pid 聚类，家庭、父母及多向聚类作敏感性；
#   6. 增加BH-FDR、时期异质性、Model 1最大样本和共享聚类bootstrap复核；
#   7. 输入为版本化区间分析底稿，不回到CFPS原始数据重建。
# ==============================================================================

options(stringsAsFactors = FALSE, scipen = 999,
        contrasts = c("contr.treatment", "contr.poly"))

required_packages <- c(
  "dplyr", "tidyr", "readr", "tibble", "purrr", "stringr",
  "sandwich", "lmtest", "digest", "jsonlite", "ggplot2", "parallel"
)
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages)) stop("缺少R包：", paste(missing_packages, collapse = ", "))

suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(readr); library(tibble)
  library(purrr); library(stringr); library(sandwich); library(lmtest)
  library(digest); library(jsonlite); library(ggplot2)
})

# 由ClaudeR异步执行时该函数负责写入进度；直接source时保留可见的控制台进度。
if (!exists("clauder_progress", mode = "function")) {
  clauder_progress <- function(stage, message) {
    cat(sprintf("[progress:%s] %s\n", stage, message))
  }
}

run_id <- "20260904_basic_regression_eight_chains_v7_1"
root <- file.path(Sys.getenv("CMAVERSE_RECOVERY_ROOT", unset = getwd()), "results", "basic_v71")
result_dir <- file.path(root, "results")
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)

# 该RDS是对既有差分数据完成ID恢复、partner经营收入纠正和缺失传播修正后的区间底稿。
# 本脚本不再回到原始问卷数据重建收入、满意度或代际支持。
input_rds <- file.path(dirname(dirname(root)), "data", "v6_provisional_dyad_intervals_recovered.rds")
correction_summary_path <- file.path(root, "restricted_reproducibility", "06_income_assignment_change_summary.csv")
stopifnot(file.exists(input_rds), file.exists(correction_summary_path))
input_hash <- digest::digest(input_rds, file = TRUE, algo = "sha256")

d0 <- readRDS(input_rds)
required_columns <- c(
  "dyad_id", "begin_year", "period", "actor_pid_begin", "parent_pid_begin",
  "partner_pid_begin", "partner_pid_end", "fid_begin", "same_actor",
  "same_parent", "same_partner", "x_abs", "x_rel", "m_self_abs",
  "m_spouse_abs", "m_self_rel", "m_spouse_rel", "y_growth",
  "eligible_x_rel", "eligible_m_self_abs", "eligible_m_spouse_abs",
  "eligible_m_self_rel", "eligible_m_spouse_rel",
  "self_sat_begin", "self_sat_end", "spouse_sat_begin", "spouse_sat_end",
  "actor_income_real_begin", "actor_income_real_end",
  "partner_income_real_begin", "partner_income_real_end",
  "support_real_begin", "support_real_end",
  "baseline_actor_income_ihs", "baseline_partner_income_ihs",
  "baseline_support_ihs"
)
missing_columns <- setdiff(required_columns, names(d0))
if (length(missing_columns)) stop("区间底稿缺少字段：", paste(missing_columns, collapse = ", "))

# 原始全样本“提升vs未提升”仅作目标总体敏感性；正文主结果限定基期<5的可提升总体。
d0 <- d0 %>%
  mutate(
    m_self_abs_all = ifelse(is.na(self_sat_begin) | is.na(self_sat_end), NA_integer_,
                            as.integer(self_sat_end > self_sat_begin)),
    m_spouse_abs_all = ifelse(is.na(spouse_sat_begin) | is.na(spouse_sat_end), NA_integer_,
                              as.integer(spouse_sat_end > spouse_sat_begin)),
    period_fe = factor(period, levels = c("2018-2020", "2020-2022")),
    valid_parent_pid = !is.na(parent_pid_begin) &
      !parent_pid_begin %in% c("", "-1", "-2", "-8", "-9", "-10"),
    parent_cluster_id = ifelse(valid_parent_pid,
                               paste0("P:", parent_pid_begin),
                               paste0("U:", dyad_id))
  )

binary_ok <- function(x) all(is.na(x) | x %in% c(0, 1))
same_partner_expected <- !is.na(d0$partner_pid_begin) & !is.na(d0$partner_pid_end) &
  d0$partner_pid_begin == d0$partner_pid_end
contract_assertions <- tribble(
  ~check, ~pass, ~detail,
  "m_self_abs restricted to baseline below 5",
  all(is.na(d0$m_self_abs) | d0$self_sat_begin < 5),
  paste0("violations=", sum(!is.na(d0$m_self_abs) & d0$self_sat_begin >= 5, na.rm = TRUE)),
  "m_spouse_abs restricted to baseline below 5",
  all(is.na(d0$m_spouse_abs) | d0$spouse_sat_begin < 5),
  paste0("violations=", sum(!is.na(d0$m_spouse_abs) & d0$spouse_sat_begin >= 5, na.rm = TRUE)),
  "x_rel restricted to baseline actor income not above spouse",
  all(is.na(d0$x_rel) | d0$actor_income_real_begin <= d0$partner_income_real_begin),
  paste0("violations=", sum(!is.na(d0$x_rel) &
                              d0$actor_income_real_begin > d0$partner_income_real_begin, na.rm = TRUE)),
  "m_self_rel restricted to baseline self satisfaction not above spouse",
  all(is.na(d0$m_self_rel) | d0$self_sat_begin <= d0$spouse_sat_begin),
  paste0("violations=", sum(!is.na(d0$m_self_rel) & d0$self_sat_begin > d0$spouse_sat_begin, na.rm = TRUE)),
  "m_spouse_rel restricted to baseline spouse satisfaction not above self",
  all(is.na(d0$m_spouse_rel) | d0$spouse_sat_begin <= d0$self_sat_begin),
  paste0("violations=", sum(!is.na(d0$m_spouse_rel) & d0$spouse_sat_begin > d0$self_sat_begin, na.rm = TRUE)),
  "same_partner exactly matches partner PID comparison",
  identical(as.logical(d0$same_partner), as.logical(same_partner_expected)),
  paste0("mismatches=", sum(d0$same_partner != same_partner_expected, na.rm = TRUE)),
  "all X M Y variables are binary or missing",
  all(vapply(d0[c("x_abs", "x_rel", "m_self_abs", "m_spouse_abs",
                  "m_self_rel", "m_spouse_rel", "y_growth")], binary_ok, logical(1))),
  "checked seven analysis variables",
  "x_abs missing whenever either endpoint is missing",
  all(!(is.na(d0$actor_income_real_begin) | is.na(d0$actor_income_real_end)) |
        is.na(d0$x_abs)),
  paste0("violations=", sum((is.na(d0$actor_income_real_begin) |
                               is.na(d0$actor_income_real_end)) & !is.na(d0$x_abs))),
  "y_growth missing whenever either endpoint is missing",
  all(!(is.na(d0$support_real_begin) | is.na(d0$support_real_end)) |
        is.na(d0$y_growth)),
  paste0("violations=", sum((is.na(d0$support_real_begin) |
                               is.na(d0$support_real_end)) & !is.na(d0$y_growth)))
)
eligibility_expected <- list(
  eligible_x_rel = !is.na(d0$actor_income_real_begin) &
    !is.na(d0$partner_income_real_begin) &
    d0$actor_income_real_begin <= d0$partner_income_real_begin,
  eligible_m_self_abs = !is.na(d0$self_sat_begin) & d0$self_sat_begin < 5,
  eligible_m_spouse_abs = !is.na(d0$spouse_sat_begin) & d0$spouse_sat_begin < 5,
  eligible_m_self_rel = !is.na(d0$self_sat_begin) & !is.na(d0$spouse_sat_begin) &
    d0$self_sat_begin <= d0$spouse_sat_begin,
  eligible_m_spouse_rel = !is.na(d0$self_sat_begin) & !is.na(d0$spouse_sat_begin) &
    d0$spouse_sat_begin <= d0$self_sat_begin
)
for (nm in names(eligibility_expected)) {
  observed_nonmissing <- !is.na(d0[[nm]])
  eligibility_matches <- all(d0[[nm]][observed_nonmissing] ==
                               eligibility_expected[[nm]][observed_nonmissing])
  contract_assertions <- bind_rows(
    contract_assertions,
    tibble(check = paste0(nm, " matches baseline eligibility rule wherever observed"),
           pass = eligibility_matches,
           detail = paste0("mismatches=", sum(d0[[nm]] != eligibility_expected[[nm]], na.rm = TRUE),
                           "; missing_flags=", sum(is.na(d0[[nm]]))))
  )
}
endpoint_contracts <- list(
  x_rel = c("actor_income_real_begin", "actor_income_real_end",
            "partner_income_real_begin", "partner_income_real_end"),
  m_self_abs = c("self_sat_begin", "self_sat_end"),
  m_spouse_abs = c("spouse_sat_begin", "spouse_sat_end"),
  m_self_rel = c("self_sat_begin", "self_sat_end", "spouse_sat_begin", "spouse_sat_end"),
  m_spouse_rel = c("self_sat_begin", "self_sat_end", "spouse_sat_begin", "spouse_sat_end")
)
for (nm in names(endpoint_contracts)) {
  endpoint_missing <- !complete.cases(d0[endpoint_contracts[[nm]]])
  violations <- sum(endpoint_missing & !is.na(d0[[nm]]))
  contract_assertions <- bind_rows(
    contract_assertions,
    tibble(check = paste0(nm, " missing whenever any required endpoint is missing"),
           pass = violations == 0,
           detail = paste0("violations=", violations))
  )
}
write_csv(contract_assertions, file.path(result_dir, "00_data_contract_assertions.csv"))
if (!all(contract_assertions$pass)) {
  stop("数据契约断言失败：", paste(contract_assertions$check[!contract_assertions$pass], collapse = "; "))
}

formula_text <- function(x) paste(deparse(x, width.cutoff = 500L), collapse = " ")

hash_rows <- function(data) {
  digest::digest(data %>% arrange(dyad_id, begin_year) %>%
                   select(dyad_id, begin_year), algo = "sha256")
}

fit_glm_capture <- function(formula, data, family) {
  warns <- character()
  fit <- withCallingHandlers(
    glm(formula, data = data, family = family, x = TRUE, y = TRUE, model = TRUE),
    warning = function(w) {
      warns <<- c(warns, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  list(fit = fit, warnings = unique(warns))
}

usable_controls <- function(data, vars) {
  vars <- unique(vars[vars %in% names(data)])
  vars[vapply(data[vars], function(x) length(unique(x[!is.na(x)])) > 1L, logical(1))]
}

make_formula <- function(lhs, rhs, data) {
  # 公式项可包含 x*m 等运算符；仅对普通字段做变异检查，复合项保留给 formula 解析。
  compound <- rhs[str_detect(rhs, "[:*()]")]
  simple <- rhs[!str_detect(rhs, "[:*()]")]
  simple <- usable_controls(data, simple)
  rhs <- unique(c(simple, compound))
  as.formula(paste(lhs, "~", paste(rhs, collapse = " + ")))
}

aligned_mm <- function(model, newdata) {
  mm <- model.matrix(delete.response(terms(model)), newdata,
                     contrasts.arg = model$contrasts, xlev = model$xlevels)
  bn <- names(coef(model))
  absent <- setdiff(bn, colnames(mm))
  if (length(absent)) stop("标准化模型矩阵缺列：", paste(absent, collapse = ", "))
  mm[, bn, drop = FALSE]
}

scenario <- function(model, data, set_values, weights = NULL) {
  nd <- data
  for (nm in names(set_values)) nd[[nm]] <- set_values[[nm]]
  mm <- aligned_mm(model, nd)
  eta <- as.numeric(mm %*% coef(model))
  p <- plogis(eta)
  if (is.null(weights)) weights <- rep(1, length(p))
  weights <- weights / sum(weights)
  list(p = sum(weights * p),
       grad = colSums(mm * as.numeric(p * (1 - p)) * weights))
}

delta_identity <- function(est, grad, vc) {
  se <- sqrt(max(0, as.numeric(t(grad) %*% vc %*% grad)))
  tibble(estimate = est, std_error = se,
         conf_low = est - 1.96 * se, conf_high = est + 1.96 * se,
         p_value = ifelse(se > 0, 2 * pnorm(abs(est / se), lower.tail = FALSE), NA_real_))
}

delta_logratio <- function(log_est, grad, vc) {
  se <- sqrt(max(0, as.numeric(t(grad) %*% vc %*% grad)))
  tibble(estimate = exp(log_est), std_error = se,
         conf_low = exp(log_est - 1.96 * se), conf_high = exp(log_est + 1.96 * se),
         p_value = ifelse(se > 0, 2 * pnorm(abs(log_est / se), lower.tail = FALSE), NA_real_))
}

probability_row <- function(label, s, vc) {
  z <- delta_identity(s$p, s$grad, vc)
  z %>% mutate(contrast = label, .before = 1)
}

standardized_binary <- function(model, data, focal, vc, label) {
  s0 <- scenario(model, data, setNames(list(0), focal))
  s1 <- scenario(model, data, setNames(list(1), focal))
  rd <- delta_identity(s1$p - s0$p, s1$grad - s0$grad, vc) %>%
    mutate(contrast = paste0(label, "_RD"), .before = 1)
  rr <- delta_logratio(log(s1$p) - log(s0$p),
                       s1$grad / s1$p - s0$grad / s0$p, vc) %>%
    mutate(contrast = paste0(label, "_RR"), .before = 1)
  bind_rows(probability_row(paste0(label, "_P0"), s0, vc),
            probability_row(paste0(label, "_P1"), s1, vc), rd, rr)
}

standardized_interaction <- function(model, data, x, m, vc) {
  s00 <- scenario(model, data, setNames(list(0, 0), c(x, m)))
  s10 <- scenario(model, data, setNames(list(1, 0), c(x, m)))
  s01 <- scenario(model, data, setNames(list(0, 1), c(x, m)))
  s11 <- scenario(model, data, setNames(list(1, 1), c(x, m)))
  rd0 <- delta_identity(s10$p - s00$p, s10$grad - s00$grad, vc) %>%
    mutate(contrast = "RD_X_at_M0", .before = 1)
  rd1 <- delta_identity(s11$p - s01$p, s11$grad - s01$grad, vc) %>%
    mutate(contrast = "RD_X_at_M1", .before = 1)
  ic <- delta_identity((s11$p - s01$p) - (s10$p - s00$p),
                       (s11$grad - s01$grad) - (s10$grad - s00$grad), vc) %>%
    mutate(contrast = "IC_RD", .before = 1)
  reri_est <- s11$p / s00$p - s10$p / s00$p - s01$p / s00$p + 1
  reri_grad <- (s11$grad - s10$grad - s01$grad) / s00$p -
    (s11$p - s10$p - s01$p) * s00$grad / (s00$p^2)
  reri <- delta_identity(reri_est, reri_grad, vc) %>%
    mutate(contrast = "RERI", .before = 1)
  mii <- delta_logratio(log(s11$p) + log(s00$p) - log(s10$p) - log(s01$p),
                        s11$grad / s11$p + s00$grad / s00$p -
                          s10$grad / s10$p - s01$grad / s01$p, vc) %>%
    mutate(contrast = "MII", .before = 1)
  bind_rows(
    probability_row("P00", s00, vc), probability_row("P10", s10, vc),
    probability_row("P01", s01, vc), probability_row("P11", s11, vc),
    rd0, rd1, ic, reri, mii
  )
}

binary_rd_obj <- function(model, data, focal, weights = NULL) {
  s0 <- scenario(model, data, setNames(list(0), focal), weights)
  s1 <- scenario(model, data, setNames(list(1), focal), weights)
  list(estimate = s1$p - s0$p, grad = s1$grad - s0$grad)
}

interaction_rd_obj <- function(model, data, x, m, weights = NULL) {
  s00 <- scenario(model, data, setNames(list(0, 0), c(x, m)), weights)
  s10 <- scenario(model, data, setNames(list(1, 0), c(x, m)), weights)
  s01 <- scenario(model, data, setNames(list(0, 1), c(x, m)), weights)
  s11 <- scenario(model, data, setNames(list(1, 1), c(x, m)), weights)
  list(
    estimate = (s11$p - s01$p) - (s10$p - s00$p),
    grad = (s11$grad - s01$grad) - (s10$grad - s00$grad)
  )
}

point_binary_rd <- function(model, data, focal, weights = NULL) {
  binary_rd_obj(model, data, focal, weights)$estimate
}

point_interaction_rd <- function(model, data, x, m, weights = NULL) {
  interaction_rd_obj(model, data, x, m, weights)$estimate
}

cluster_vcov <- function(fit, data, method) {
  if (method == "actor") {
    vcovCL(fit, cluster = data$actor_pid_begin, type = "HC1", cadjust = TRUE, fix = TRUE)
  } else if (method == "family") {
    vcovCL(fit, cluster = data$fid_begin, type = "HC1", cadjust = TRUE, fix = TRUE)
  } else if (method == "actor_family") {
    intersections <- count(data, actor_pid_begin, fid_begin, name = "n")
    vcovCL(fit,
           cluster = data.frame(actor = data$actor_pid_begin, family = data$fid_begin),
           type = "HC1", cadjust = TRUE, multi0 = all(intersections$n == 1), fix = TRUE)
  } else if (method == "parent") {
    vcovCL(fit, cluster = data$parent_cluster_id, type = "HC1", cadjust = TRUE, fix = TRUE)
  } else if (method == "actor_parent") {
    intersections <- count(data, actor_pid_begin, parent_cluster_id, name = "n")
    vcovCL(fit,
           cluster = data.frame(actor = data$actor_pid_begin,
                                parent = data$parent_cluster_id),
           type = "HC1", cadjust = TRUE,
           multi0 = all(intersections$n == 1), fix = TRUE)
  } else stop("未知聚类方式")
}

# ---- 八条链与术语 ------------------------------------------------------------
registry <- tribble(
  ~chain, ~x, ~m, ~role, ~x_construct, ~m_construct, ~eligibility,
  "AA-S", "x_abs", "m_self_abs", "本人", "绝对收入增加", "本人绝对满意度提升", "本人基期满意度<5",
  "AA-P", "x_abs", "m_spouse_abs", "配偶", "绝对收入增加", "配偶绝对满意度提升", "配偶基期满意度<5",
  "AR-S", "x_abs", "m_self_rel", "本人", "绝对收入增加", "本人满意度相对位置升级", "本人基期满意度不高于配偶",
  "AR-P", "x_abs", "m_spouse_rel", "配偶", "绝对收入增加", "配偶满意度相对位置升级", "配偶基期满意度不高于本人",
  "RA-S", "x_rel", "m_self_abs", "本人", "夫妻内收入相对位置升级", "本人绝对满意度提升", "本人基期收入不高于配偶且满意度<5",
  "RA-P", "x_rel", "m_spouse_abs", "配偶", "夫妻内收入相对位置升级", "配偶绝对满意度提升", "本人基期收入不高于配偶且配偶满意度<5",
  "RR-S", "x_rel", "m_self_rel", "本人", "夫妻内收入相对位置升级", "本人满意度相对位置升级", "本人基期收入不高于配偶且满意度不高于配偶",
  "RR-P", "x_rel", "m_spouse_rel", "配偶", "夫妻内收入相对位置升级", "配偶满意度相对位置升级", "本人基期收入不高于配偶且配偶满意度不高于本人"
) %>%
  mutate(
    unit = "亲子二元组—区间",
    outcome = "父母特定的实际代际经济支持增加",
    reference = "未增加/未升级（含不变和反向变化）",
    section_role = "候选机制的调整关联诊断；非中介效应证明",
    time_interpretation = "两年区间内的条件关联；M与Y严格先后次序不可观察"
  )
write_csv(registry, file.path(result_dir, "01_eight_chain_registry.csv"))

# ---- 协变量：全部为区间起点变量；同期变化变量不进入 ---------------------------
actor_other <- c(
  "dwm_begin", "gender_begin", "aage_begin", "actor_edu2_begin",
  "actor_siops_begin", "child_begin", "ahw_begin", "ahk_begin",
  "total_debts_begin", "qp201_actor_begin", "fmlincc_begin",
  "lifetime_begin", "period_fe"
)
parent_controls <- c(
  "prtmarr_begin", "prtcor_begin", "prtgender_begin", "prtage_begin",
  "prtedu_begin", "baseline_support_ihs"
)
factor_controls <- c(
  "dwm_begin", "gender_begin", "ahk_begin", "lifetime_begin",
  "prtmarr_begin", "prtcor_begin", "prtgender_begin", "prtedu_begin",
  "period_fe"
)

baseline_x_controls <- function(x) {
  c("baseline_actor_income_ihs", "baseline_partner_income_ihs")
}

baseline_m_controls <- function(m) {
  if (m == "m_self_abs") return("self_sat_begin")
  if (m == "m_spouse_abs") return("spouse_sat_begin")
  c("self_sat_begin", "spouse_sat_begin")
}

chain_data <- function(meta, absolute_all_sample = FALSE) {
  x <- meta$x[[1]]
  m <- meta$m[[1]]
  if (absolute_all_sample && m == "m_self_abs") m <- "m_self_abs_all"
  if (absolute_all_sample && m == "m_spouse_abs") m <- "m_spouse_abs_all"
  xbase <- baseline_x_controls(x)
  mbase <- baseline_m_controls(meta$m[[1]])
  needed <- unique(c(
    x, m, "y_growth", "dyad_id", "begin_year", "actor_pid_begin",
    "parent_pid_begin", "partner_pid_begin", "fid_begin", "parent_cluster_id",
    actor_other, parent_controls, xbase, mbase
  ))
  data <- d0 %>%
    filter(same_actor %in% TRUE, same_parent %in% TRUE, same_partner %in% TRUE) %>%
    filter(if_all(all_of(needed), ~ !is.na(.x))) %>%
    mutate(across(any_of(factor_controls), factor)) %>%
    droplevels()
  list(data = data, x = x, m = m, xbase = xbase, mbase = mbase)
}

all_models <- list()
coef_rows <- list()
effect_rows <- list()
cluster_effect_rows <- list()
diagnostic_rows <- list()
sample_rows <- list()
cell_rows <- list()
formula_rows <- list()

for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]
  z <- chain_data(meta)
  d <- z$data; x <- z$x; m <- z$m
  if (!nrow(d)) stop("链条无可用样本：", meta$chain)

  sample_rows[[meta$chain]] <- tibble(
    chain = meta$chain, n_records = nrow(d), n_dyads = n_distinct(d$dyad_id),
    n_actors = n_distinct(d$actor_pid_begin), n_families = n_distinct(d$fid_begin),
    period_2018_2020 = sum(d$period == "2018-2020"),
    period_2020_2022 = sum(d$period == "2020-2022"),
    x_rate = mean(d[[x]]), m_rate = mean(d[[m]]), y_rate = mean(d$y_growth),
    sample_hash = hash_rows(d)
  )
  cell_one <- d %>% count(.data[[x]], .data[[m]], y_growth, name = "n")
  names(cell_one)[1:2] <- c("x_value", "m_value")
  cell_rows[[meta$chain]] <- cell_one %>% mutate(chain = meta$chain, .before = 1)

  m_controls <- unique(c(z$xbase, z$mbase, actor_other))
  y_controls <- unique(c(z$xbase, z$mbase, actor_other, parent_controls))
  specs <- list(
    M1 = list(lhs = m, rhs = c(x, m_controls), relation = "X→M调整关联"),
    M2 = list(lhs = "y_growth", rhs = c(x, y_controls), relation = "X→Y调整关联"),
    M3 = list(lhs = "y_growth", rhs = c(m, y_controls), relation = "未纳入同期X的M–Y调整关联"),
    M4 = list(lhs = "y_growth", rhs = c(x, m, y_controls), relation = "X+M→Y调整关联"),
    M5 = list(lhs = "y_growth", rhs = c(paste0(x, "*", m), y_controls), relation = "X×M经验交互")
  )

  for (model_no in names(specs)) {
    sp <- specs[[model_no]]
    form <- make_formula(sp$lhs, sp$rhs, d)
    fit_obj <- fit_glm_capture(form, d, binomial("logit"))
    fit <- fit_obj$fit
    vc_actor <- cluster_vcov(fit, d, "actor")
    model_id <- paste(meta$chain, model_no, sep = "_")
    all_models[[model_id]] <- list(fit = fit, data = d, meta = meta,
                                   formula = form, warnings = fit_obj$warnings)

    ct <- coeftest(fit, vcov. = vc_actor)
    coef_rows[[model_id]] <- tibble(
      model_id = model_id, chain = meta$chain, model = model_no,
      relation = sp$relation, term = rownames(ct), estimate_logit = ct[, 1],
      actor_cluster_se = ct[, 2], z = ct[, 3], p_value = ct[, 4],
      odds_ratio = exp(ct[, 1]), or_conf_low = exp(ct[, 1] - 1.96 * ct[, 2]),
      or_conf_high = exp(ct[, 1] + 1.96 * ct[, 2]), n = nrow(d),
      n_actor_clusters = n_distinct(d$actor_pid_begin),
      warnings = paste(fit_obj$warnings, collapse = " | ")
    )

    formula_rows[[model_id]] <- tibble(
      model_id = model_id, chain = meta$chain, model = model_no,
      formula = formula_text(form), n = nrow(d), sample_hash = hash_rows(d),
      data_sha256 = input_hash, data_version = basename(input_rds),
      estimator = "binomial-logit with marginal standardization",
      primary_cluster = "adult-child actor_pid"
    )

    core_effects <- if (model_no == "M1") {
      standardized_binary(fit, d, x, vc_actor, "X")
    } else if (model_no == "M2") {
      standardized_binary(fit, d, x, vc_actor, "X")
    } else if (model_no == "M3") {
      standardized_binary(fit, d, m, vc_actor, "M")
    } else if (model_no == "M4") {
      bind_rows(standardized_binary(fit, d, x, vc_actor, "X"),
                standardized_binary(fit, d, m, vc_actor, "M"))
    } else {
      standardized_interaction(fit, d, x, m, vc_actor)
    }
    effect_rows[[model_id]] <- core_effects %>%
      mutate(model_id = model_id, chain = meta$chain, model = model_no,
             cluster_method = "actor", .before = 1)

    for (cluster_method in c("family", "actor_family", "parent", "actor_parent")) {
      vc_alt <- try(cluster_vcov(fit, d, cluster_method), silent = TRUE)
      if (inherits(vc_alt, "try-error")) next
      alt_effects <- if (model_no == "M1") {
        standardized_binary(fit, d, x, vc_alt, "X")
      } else if (model_no == "M2") {
        standardized_binary(fit, d, x, vc_alt, "X")
      } else if (model_no == "M3") {
        standardized_binary(fit, d, m, vc_alt, "M")
      } else if (model_no == "M4") {
        bind_rows(standardized_binary(fit, d, x, vc_alt, "X"),
                  standardized_binary(fit, d, m, vc_alt, "M"))
      } else {
        standardized_interaction(fit, d, x, m, vc_alt)
      }
      cluster_effect_rows[[paste(model_id, cluster_method)]] <- alt_effects %>%
        mutate(model_id = model_id, chain = meta$chain, model = model_no,
               cluster_method = cluster_method, .before = 1)
    }

    pred <- fitted(fit)
    # LPM只用于异常预测诊断，不作为正文主模型。
    lpm <- fit_glm_capture(form, d, gaussian())$fit
    diagnostic_rows[[model_id]] <- tibble(
      model_id = model_id, chain = meta$chain, model = model_no,
      converged = isTRUE(fit$converged), aliased = sum(is.na(coef(fit))),
      rank = fit$rank, n_coefficients = length(coef(fit)),
      min_logit_fitted = min(pred), max_logit_fitted = max(pred),
      extreme_logit_share = mean(pred < .01 | pred > .99),
      lpm_outside_0_1_share = mean(fitted(lpm) < 0 | fitted(lpm) > 1),
      min_x_m_y_cell = min((d %>% count(.data[[x]], .data[[m]], y_growth))$n),
      warnings = paste(fit_obj$warnings, collapse = " | ")
    )
  }
}

samples <- bind_rows(sample_rows)
cells <- bind_rows(cell_rows)
coefficients <- bind_rows(coef_rows)
effects_actor <- bind_rows(effect_rows)
effects_cluster_sensitivity <- bind_rows(cluster_effect_rows)
diagnostics <- bind_rows(diagnostic_rows)
model_manifest <- bind_rows(formula_rows)

write_csv(samples, file.path(result_dir, "02_chain_sample_summary.csv"))
write_csv(cells, file.path(result_dir, "03_joint_cell_counts.csv"))
write_csv(coefficients, file.path(result_dir, "04_all_logistic_coefficients_actor_cluster.csv"))
write_csv(effects_actor, file.path(result_dir, "05_standardized_effects_actor_cluster.csv"))
write_csv(effects_cluster_sensitivity, file.path(result_dir, "06_cluster_sensitivity_effects.csv"))
write_csv(diagnostics, file.path(result_dir, "07_model_diagnostics.csv"))
write_csv(model_manifest, file.path(result_dir, "08_model_manifest.csv"))

# ---- 支持度与倾向概率诊断 -----------------------------------------------------
support_rows <- list()
for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]
  z <- chain_data(meta); d <- z$data; x <- z$x; m <- z$m
  xform <- make_formula(x, c(z$xbase, actor_other), d)
  mform <- make_formula(m, c(x, z$xbase, z$mbase, actor_other), d)
  xfit <- glm(xform, data = d, family = binomial())
  mfit <- glm(mform, data = d, family = binomial())
  for (v in c("X", "M")) {
    p <- if (v == "X") fitted(xfit) else fitted(mfit)
    observed <- if (v == "X") d[[x]] else d[[m]]
    split_p <- split(p, observed)
    overlap_low <- max(vapply(split_p, quantile, numeric(1), probs = .01, na.rm = TRUE))
    overlap_high <- min(vapply(split_p, quantile, numeric(1), probs = .99, na.rm = TRUE))
    support_rows[[paste(meta$chain, v)]] <- tibble(
      chain = meta$chain, variable = v, n = length(p),
      q01 = quantile(p, .01), q05 = quantile(p, .05), median = median(p),
      q95 = quantile(p, .95), q99 = quantile(p, .99),
      prop_lt_001 = mean(p < .01), prop_gt_099 = mean(p > .99),
      overlap_low = overlap_low, overlap_high = overlap_high,
      outside_overlap_share = mean(p < overlap_low | p > overlap_high)
    )
  }
}
support_diagnostics <- bind_rows(support_rows)
write_csv(support_diagnostics, file.path(result_dir, "09_propensity_support_diagnostics.csv"))

# ---- 父母PID结构与聚类可行性 ------------------------------------------------
parent_diag_rows <- list()
for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]
  d <- chain_data(meta)$data
  valid_pairs <- d %>%
    filter(valid_parent_pid) %>%
    distinct(parent_pid_begin, actor_pid_begin)
  parent_sizes <- valid_pairs %>% count(parent_pid_begin, name = "n_adult_children")
  parent_diag_rows[[meta$chain]] <- tibble(
    chain = meta$chain,
    n_records = nrow(d),
    invalid_parent_pid_records = sum(!d$valid_parent_pid),
    invalid_parent_pid_share = mean(!d$valid_parent_pid),
    n_valid_parent_pid = n_distinct(d$parent_pid_begin[d$valid_parent_pid]),
    n_multi_child_parents = sum(parent_sizes$n_adult_children > 1),
    multi_child_parent_share = ifelse(nrow(parent_sizes) > 0,
                                      mean(parent_sizes$n_adult_children > 1), NA_real_),
    max_observed_adult_children = ifelse(nrow(parent_sizes) > 0,
                                         max(parent_sizes$n_adult_children), NA_integer_),
    n_parent_clusters_with_surrogates = n_distinct(d$parent_cluster_id)
  )
}
parent_cluster_diagnostics <- bind_rows(parent_diag_rows)
write_csv(parent_cluster_diagnostics,
          file.path(result_dir, "10_parent_pid_cluster_diagnostics.csv"))

# ---- Model 1最大可用成年子女—区间样本敏感性 -------------------------------
model1_max_rows <- list()
model1_max_sample_rows <- list()
for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]
  x <- meta$x[[1]]; m <- meta$m[[1]]
  xbase <- baseline_x_controls(x); mbase <- baseline_m_controls(m)
  # dwm_begin在同一成年子女—区间的父/母二元组之间可不同，属于亲子特定字段；
  # 最大成年子女—区间敏感性不再要求或控制该字段，核心40模型保持原设定。
  m1_max_actor_other <- setdiff(actor_other, "dwm_begin")
  m_controls <- unique(c(xbase, mbase, m1_max_actor_other))
  needed <- unique(c(x, m, "actor_pid_begin", "partner_pid_begin", "begin_year",
                     "period", m_controls))
  d_pre <- d0 %>%
    filter(same_actor %in% TRUE, same_partner %in% TRUE) %>%
    filter(if_all(all_of(needed), ~ !is.na(.x)))
  value_cols <- setdiff(needed, c("actor_pid_begin", "partner_pid_begin", "begin_year"))
  conflicts <- d_pre %>%
    group_by(actor_pid_begin, partner_pid_begin, begin_year) %>%
    summarise(across(all_of(value_cols), n_distinct), .groups = "drop") %>%
    filter(if_any(all_of(value_cols), ~ .x > 1))
  if (nrow(conflicts)) stop("Model 1去重键内出现不一致：", meta$chain)
  d <- d_pre %>%
    distinct(actor_pid_begin, partner_pid_begin, begin_year, .keep_all = TRUE) %>%
    mutate(across(any_of(factor_controls), factor)) %>%
    droplevels()
  form <- make_formula(m, c(x, m_controls), d)
  fit <- fit_glm_capture(form, d, binomial("logit"))$fit
  vc <- vcovCL(fit, cluster = d$actor_pid_begin, type = "HC1", cadjust = TRUE, fix = TRUE)
  eff <- standardized_binary(fit, d, x, vc, "X")
  model1_max_rows[[meta$chain]] <- eff %>%
    mutate(chain = meta$chain, model = "M1_max_actor_interval",
           n_actor_intervals = nrow(d), n_actors = n_distinct(d$actor_pid_begin),
           formula = formula_text(form), .before = 1)
  model1_max_sample_rows[[meta$chain]] <- tibble(
    chain = meta$chain, n_actor_intervals = nrow(d),
    n_actors = n_distinct(d$actor_pid_begin), n_duplicate_dyad_rows_removed = nrow(d_pre) - nrow(d),
    conflict_groups = nrow(conflicts),
    sample_hash = digest::digest(d %>% arrange(actor_pid_begin, begin_year, partner_pid_begin) %>%
                                   select(actor_pid_begin, begin_year, partner_pid_begin),
                                 algo = "sha256")
  )
}
model1_max_effects <- bind_rows(model1_max_rows)
model1_max_samples <- bind_rows(model1_max_sample_rows)
write_csv(model1_max_effects, file.path(result_dir, "11_model1_max_actor_interval_sensitivity.csv"))
write_csv(model1_max_samples, file.path(result_dir, "12_model1_max_actor_interval_samples.csv"))

# ---- 四个预先定义检验家族的BH-FDR ------------------------------------------
multiple_testing <- bind_rows(
  effects_actor %>% filter(model == "M1", contrast == "X_RD") %>%
    mutate(test_family = "M1_X_to_M_RD"),
  effects_actor %>% filter(model == "M2", contrast == "X_RD") %>%
    mutate(test_family = "M2_X_to_Y_RD"),
  effects_actor %>% filter(model == "M3", contrast == "M_RD") %>%
    mutate(test_family = "M3_M_to_Y_RD"),
  effects_actor %>% filter(model == "M5", contrast == "IC_RD") %>%
    mutate(test_family = "M5_additive_interaction")
) %>%
  group_by(test_family) %>%
  mutate(bh_q_value = p.adjust(p_value, method = "BH"), family_size = n()) %>%
  ungroup() %>%
  select(test_family, family_size, chain, model, contrast, estimate, std_error,
         conf_low, conf_high, p_value, bh_q_value)
write_csv(multiple_testing, file.path(result_dir, "13_bh_fdr_four_families.csv"))

# ---- 时期异质性：直接估计时期差值，不比较两期显著性 --------------------------
period_rows <- list()
period_manifest_rows <- list()
for (i in seq_len(nrow(registry))) {
  meta <- registry[i, ]
  z <- chain_data(meta); d <- z$data; x <- z$x; m <- z$m
  actor_other_no_period <- setdiff(actor_other, "period_fe")
  m_controls <- unique(c(z$xbase, z$mbase, actor_other_no_period))
  y_controls <- unique(c(z$xbase, z$mbase, actor_other_no_period, parent_controls))
  period_specs <- list(
    M1 = list(lhs = m, rhs = c(paste0(x, "*period_fe"), m_controls), focal = x,
              relation = "X→M时期异质性"),
    M2 = list(lhs = "y_growth", rhs = c(paste0(x, "*period_fe"), y_controls), focal = x,
              relation = "X→Y时期异质性"),
    M5 = list(lhs = "y_growth", rhs = c(paste0(x, "*", m, "*period_fe"), y_controls),
              relation = "X×M加性交互时期异质性")
  )
  for (model_no in names(period_specs)) {
    sp <- period_specs[[model_no]]
    form <- make_formula(sp$lhs, sp$rhs, d)
    fit <- fit_glm_capture(form, d, binomial("logit"))$fit
    vc <- cluster_vcov(fit, d, "actor")
    period_manifest_rows[[paste(meta$chain, model_no)]] <- tibble(
      chain = meta$chain, model = model_no, relation = sp$relation,
      formula = formula_text(form), n = nrow(d), sample_hash = hash_rows(d)
    )
    period_objects <- list()
    for (period_value in levels(d$period_fe)) {
      dp <- d %>% filter(period_fe == period_value)
      if (model_no %in% c("M1", "M2")) {
        eff <- standardized_binary(fit, dp, sp$focal, vc, "X") %>%
          filter(contrast %in% c("X_RD", "X_RR"))
      } else {
        eff <- standardized_interaction(fit, dp, x, m, vc) %>%
          filter(contrast %in% c("IC_RD", "RERI"))
      }
      period_rows[[paste(meta$chain, model_no, period_value)]] <- eff %>%
        mutate(chain = meta$chain, model = model_no, relation = sp$relation,
               period = period_value, result_type = "period_specific", .before = 1)

      # 直接时期差异统一在合并链条样本上标准化，仅改变时期状态，避免把
      # 两期协变量构成差异混入效应异质性检验。
      d_common <- d
      d_common$period_fe <- factor(period_value, levels = levels(d$period_fe))
      period_objects[[period_value]] <- if (model_no %in% c("M1", "M2")) {
        binary_rd_obj(fit, d_common, sp$focal)
      } else {
        interaction_rd_obj(fit, d_common, x, m)
      }
    }
    o1 <- period_objects[["2018-2020"]]; o2 <- period_objects[["2020-2022"]]
    diff_ci <- delta_identity(o2$estimate - o1$estimate, o2$grad - o1$grad, vc)
    period_rows[[paste(meta$chain, model_no, "difference")]] <- diff_ci %>%
      mutate(chain = meta$chain, model = model_no, relation = sp$relation,
             period = "2020-2022 minus 2018-2020", result_type = "direct_period_difference",
             contrast = ifelse(model_no == "M5", "IC_RD_period_difference", "X_RD_period_difference"),
             .before = 1)
  }
}
period_diagnostics <- bind_rows(period_rows)
period_manifest <- bind_rows(period_manifest_rows)
period_diagnostics <- period_diagnostics %>%
  group_by(model, result_type, contrast) %>%
  mutate(bh_q_value = ifelse(result_type == "direct_period_difference",
                             p.adjust(p_value, method = "BH"), NA_real_)) %>%
  ungroup()
write_csv(period_diagnostics, file.path(result_dir, "14_period_heterogeneity_effects.csv"))
write_csv(period_manifest, file.path(result_dir, "15_period_heterogeneity_manifest.csv"))

# ---- 共享成年子女PID聚类bootstrap：八项加性交互 ------------------------------
nboot_target <- 1000L
nboot_attempt <- 1050L
bootstrap_seed <- 202609041L
m5_by_chain <- setNames(lapply(registry$chain, function(ch) all_models[[paste0(ch, "_M5")]]),
                        registry$chain)
actor_universe <- sort(unique(unlist(lapply(m5_by_chain, function(x) x$data$actor_pid_begin))))

bootstrap_one <- function(b) {
  if(b == 1L || b %% 50L == 0L) {clauder_progress("bootstrap",paste("actor cluster attempt",b,"of",nboot_attempt));flush.console()}
  set.seed(bootstrap_seed + b)
  sampled <- sample(actor_universe, length(actor_universe), replace = TRUE)
  freq <- as.data.frame(table(sampled), stringsAsFactors = FALSE)
  names(freq) <- c("actor_pid_begin", ".boot_w")
  freq$actor_pid_begin <- as.character(freq$actor_pid_begin)
  freq$.boot_w <- as.numeric(freq$.boot_w)
  out <- lapply(names(m5_by_chain), function(ch) {
    obj <- m5_by_chain[[ch]]
    d <- obj$data %>% inner_join(freq, by = "actor_pid_begin")
    ans <- tryCatch({
      fit <- glm(obj$formula, data = d, family = binomial("logit"), weights = .boot_w)
      est <- point_interaction_rd(fit, d, obj$meta$x[[1]], obj$meta$m[[1]], weights = d$.boot_w)
      tibble(iteration = b, chain = ch, estimate = est, success = is.finite(est), error = NA_character_)
    }, error = function(e) tibble(iteration = b, chain = ch, estimate = NA_real_,
                                  success = FALSE, error = conditionMessage(e)))
    ans
  })
  bind_rows(out)
}

clauder_progress("bootstrap", paste0("Starting ", nboot_attempt,
                                      " shared actor-cluster bootstrap attempts"))
boot_list <- parallel::mclapply(seq_len(nboot_attempt), bootstrap_one,
                                mc.cores = 1L, mc.preschedule = TRUE)
bootstrap_draws <- bind_rows(boot_list)
write_csv(bootstrap_draws, file.path(result_dir, "16_shared_actor_bootstrap_interaction_draws.csv"))

bootstrap_summary <- bootstrap_draws %>%
  group_by(chain) %>%
  summarise(
    attempts = n(), successful = sum(success), failures = sum(!success),
    failure_rate = mean(!success),
    boot_mean = mean(estimate[success]), boot_se = sd(estimate[success]),
    boot_conf_low = quantile(estimate[success], .025),
    boot_conf_high = quantile(estimate[success], .975),
    boot_p_value = min(1, 2 * min((sum(estimate[success] <= 0) + 1) / (successful + 1),
                                  (sum(estimate[success] >= 0) + 1) / (successful + 1))),
    .groups = "drop"
  ) %>%
  left_join(effects_actor %>% filter(model == "M5", contrast == "IC_RD") %>%
              select(chain, delta_estimate = estimate, delta_conf_low = conf_low,
                     delta_conf_high = conf_high), by = "chain")
if (any(bootstrap_summary$successful < nboot_target)) {
  stop("聚类bootstrap成功次数不足1000：",
       paste(bootstrap_summary$chain[bootstrap_summary$successful < nboot_target], collapse = ", "))
}
write_csv(bootstrap_summary, file.path(result_dir, "17_shared_actor_bootstrap_interaction_summary.csv"))

# ---- AR本人/配偶共同资格总体的直接交互差异 -----------------------------------
ar_meta_self <- registry %>% filter(chain == "AR-S")
z_ar <- chain_data(ar_meta_self)
ar_common_needed <- unique(c(
  "x_abs", "m_self_rel", "m_spouse_rel", "y_growth", "actor_pid_begin",
  "partner_pid_begin", "dyad_id", "begin_year", "parent_cluster_id",
  baseline_x_controls("x_abs"), baseline_m_controls("m_self_rel"),
  actor_other, parent_controls
))
ar_common <- d0 %>%
  filter(same_actor %in% TRUE, same_parent %in% TRUE, same_partner %in% TRUE,
         self_sat_begin == spouse_sat_begin) %>%
  filter(if_all(all_of(ar_common_needed), ~ !is.na(.x))) %>%
  mutate(across(any_of(factor_controls), factor)) %>% droplevels()
# 共同资格条件self_sat_begin==spouse_sat_begin使两个基期满意度完全共线；
# 两条角色模型均保留self_sat_begin作为共同基期水平，删除代数重复的spouse项。
ar_y_controls <- unique(c(baseline_x_controls("x_abs"), "self_sat_begin",
                          actor_other, parent_controls))
ar_form_self <- make_formula("y_growth", c("x_abs*m_self_rel", ar_y_controls), ar_common)
ar_form_spouse <- make_formula("y_growth", c("x_abs*m_spouse_rel", ar_y_controls), ar_common)
ar_fit_self <- glm(ar_form_self, data = ar_common, family = binomial("logit"))
ar_fit_spouse <- glm(ar_form_spouse, data = ar_common, family = binomial("logit"))
ar_point_self <- point_interaction_rd(ar_fit_self, ar_common, "x_abs", "m_self_rel")
ar_point_spouse <- point_interaction_rd(ar_fit_spouse, ar_common, "x_abs", "m_spouse_rel")
ar_actors <- sort(unique(ar_common$actor_pid_begin))

ar_boot_one <- function(b) {
  if(b == 1L || b %% 50L == 0L) {clauder_progress("role_bootstrap",paste("AR role attempt",b,"of",nboot_attempt));flush.console()}
  set.seed(bootstrap_seed + 100000L + b)
  sampled <- sample(ar_actors, length(ar_actors), replace = TRUE)
  freq <- as.data.frame(table(sampled), stringsAsFactors = FALSE)
  names(freq) <- c("actor_pid_begin", ".boot_w")
  freq$actor_pid_begin <- as.character(freq$actor_pid_begin)
  freq$.boot_w <- as.numeric(freq$.boot_w)
  d <- ar_common %>% inner_join(freq, by = "actor_pid_begin")
  tryCatch({
    fs <- glm(ar_form_self, data = d, family = binomial("logit"), weights = .boot_w)
    fp <- glm(ar_form_spouse, data = d, family = binomial("logit"), weights = .boot_w)
    es <- point_interaction_rd(fs, d, "x_abs", "m_self_rel", weights = d$.boot_w)
    ep <- point_interaction_rd(fp, d, "x_abs", "m_spouse_rel", weights = d$.boot_w)
    tibble(iteration = b, ar_self = es, ar_spouse = ep,
           self_minus_spouse = es - ep, success = all(is.finite(c(es, ep))), error = NA_character_)
  }, error = function(e) tibble(iteration = b, ar_self = NA_real_, ar_spouse = NA_real_,
                                self_minus_spouse = NA_real_, success = FALSE,
                                error = conditionMessage(e)))
}
clauder_progress("role_bootstrap", paste0("Starting AR common-risk-set bootstrap; N=", nrow(ar_common)))
ar_boot_list <- parallel::mclapply(seq_len(nboot_attempt), ar_boot_one,
                                   mc.cores = 1L, mc.preschedule = TRUE)
ar_role_draws <- bind_rows(ar_boot_list)
write_csv(ar_role_draws, file.path(result_dir, "18_ar_common_risk_role_bootstrap_draws.csv"))

ar_role_summary <- bind_rows(
  tibble(contrast = "AR-S common-risk IC_RD", point_estimate = ar_point_self,
         values = list(ar_role_draws$ar_self[ar_role_draws$success])),
  tibble(contrast = "AR-P common-risk IC_RD", point_estimate = ar_point_spouse,
         values = list(ar_role_draws$ar_spouse[ar_role_draws$success])),
  tibble(contrast = "AR-S minus AR-P IC_RD", point_estimate = ar_point_self - ar_point_spouse,
         values = list(ar_role_draws$self_minus_spouse[ar_role_draws$success]))
) %>%
  rowwise() %>%
  mutate(
    attempts = nrow(ar_role_draws), successful = sum(ar_role_draws$success),
    failures = attempts - successful, failure_rate = failures / attempts,
    boot_mean = mean(values), boot_se = sd(values),
    boot_conf_low = quantile(values, .025), boot_conf_high = quantile(values, .975),
    boot_p_value = min(1, 2 * min((sum(values <= 0) + 1) / (length(values) + 1),
                                  (sum(values >= 0) + 1) / (length(values) + 1)))
  ) %>%
  ungroup() %>% select(-values) %>%
  mutate(n_records = nrow(ar_common), n_actors = n_distinct(ar_common$actor_pid_begin),
         n_dyads = n_distinct(ar_common$dyad_id),
         self_spouse_role_difference_confirmed =
           contrast == "AR-S minus AR-P IC_RD" &
           (boot_conf_low > 0 | boot_conf_high < 0))
if (any(ar_role_summary$successful < nboot_target)) stop("AR共同资格bootstrap成功次数不足1000")
write_csv(ar_role_summary, file.path(result_dir, "19_ar_common_risk_role_bootstrap_summary.csv"))

# ---- 绝对满意度可提升总体 vs 原初全样本敏感性 -------------------------------
ceiling_rows <- list()
for (i in which(str_detect(registry$chain, "^(AA|RA)-"))) {
  meta <- registry[i, ]
  z <- chain_data(meta, absolute_all_sample = TRUE)
  d <- z$data; x <- z$x; m <- z$m
  m_controls <- unique(c(z$xbase, z$mbase, actor_other))
  y_controls <- unique(c(z$xbase, z$mbase, actor_other, parent_controls))
  specs <- list(
    M1 = list(lhs = m, rhs = c(x, m_controls), focal = x, label = "X"),
    M3 = list(lhs = "y_growth", rhs = c(m, y_controls), focal = m, label = "M"),
    M5 = list(lhs = "y_growth", rhs = c(paste0(x, "*", m), y_controls))
  )
  for (model_no in names(specs)) {
    sp <- specs[[model_no]]
    form <- make_formula(sp$lhs, sp$rhs, d)
    fit <- fit_glm_capture(form, d, binomial())$fit
    vc <- cluster_vcov(fit, d, "actor")
    eff <- if (model_no == "M5") standardized_interaction(fit, d, x, m, vc) else
      standardized_binary(fit, d, sp$focal, vc, sp$label)
    ceiling_rows[[paste(meta$chain, model_no)]] <- eff %>%
      mutate(chain = meta$chain, model = model_no, target_population = "all_baseline_scores",
             n = nrow(d), .before = 1)
  }
}
ceiling_sensitivity <- bind_rows(ceiling_rows)
write_csv(ceiling_sensitivity, file.path(result_dir, "20_absolute_M_all_sample_sensitivity.csv"))

# ---- 文稿用紧凑表 ------------------------------------------------------------
pull_effect <- function(model_value, contrast_value) {
  effects_actor %>%
    filter(.data$model == .env$model_value,
           .data$contrast == .env$contrast_value) %>%
    select(chain, estimate, conf_low, conf_high) %>%
    rename(!!paste0(model_value, "_", contrast_value) := estimate,
           !!paste0(model_value, "_", contrast_value, "_low") := conf_low,
           !!paste0(model_value, "_", contrast_value, "_high") := conf_high)
}

table_01 <- registry %>%
  select(chain, x_construct, m_construct, role, eligibility) %>%
  left_join(samples, by = "chain") %>%
  left_join(pull_effect("M1", "X_RR"), by = "chain") %>%
  left_join(pull_effect("M1", "X_RD"), by = "chain") %>%
  left_join(multiple_testing %>% filter(test_family == "M1_X_to_M_RD") %>%
              select(chain, M1_XM_bh_q = bh_q_value), by = "chain")

table_02 <- registry %>% select(chain) %>%
  left_join(samples %>% select(chain, n_records, n_actors), by = "chain") %>%
  left_join(pull_effect("M2", "X_RR"), by = "chain") %>%
  left_join(pull_effect("M2", "X_RD"), by = "chain") %>%
  left_join(pull_effect("M3", "M_RR"), by = "chain") %>%
  left_join(pull_effect("M3", "M_RD"), by = "chain") %>%
  left_join(pull_effect("M4", "X_RR"), by = "chain") %>%
  left_join(pull_effect("M4", "M_RR"), by = "chain") %>%
  left_join(pull_effect("M5", "IC_RD"), by = "chain") %>%
  left_join(pull_effect("M5", "RERI"), by = "chain") %>%
  left_join(multiple_testing %>% filter(test_family == "M2_X_to_Y_RD") %>%
              select(chain, M2_XY_bh_q = bh_q_value), by = "chain") %>%
  left_join(multiple_testing %>% filter(test_family == "M3_M_to_Y_RD") %>%
              select(chain, M3_MY_bh_q = bh_q_value), by = "chain") %>%
  left_join(multiple_testing %>% filter(test_family == "M5_additive_interaction") %>%
              select(chain, M5_IC_bh_q = bh_q_value), by = "chain") %>%
  left_join(bootstrap_summary %>%
              select(chain, boot_successful = successful,
                     IC_boot_low = boot_conf_low, IC_boot_high = boot_conf_high,
                     IC_boot_p = boot_p_value), by = "chain")

write_csv(table_01, file.path(result_dir, "21_manuscript_table_0_1.csv"))
write_csv(table_02, file.path(result_dir, "22_manuscript_table_0_2.csv"))

core_map <- bind_rows(
  effects_actor %>% filter(model == "M1", contrast == "X_RR") %>%
    transmute(chain, relation = "X→M", estimate, conf_low, conf_high, null = 1),
  effects_actor %>% filter(model == "M2", contrast == "X_RR") %>%
    transmute(chain, relation = "X→Y", estimate, conf_low, conf_high, null = 1),
  effects_actor %>% filter(model == "M3", contrast == "M_RR") %>%
    transmute(chain, relation = "M–Y", estimate, conf_low, conf_high, null = 1),
  effects_actor %>% filter(model == "M5", contrast == "IC_RD") %>%
    transmute(chain, relation = "加性交互", estimate, conf_low, conf_high, null = 0)
)
write_csv(core_map, file.path(result_dir, "23_eight_chain_core_map.csv"))

plot_data <- core_map %>%
  mutate(relation = factor(relation, levels = c("X→M", "X→Y", "M–Y", "加性交互")))
p <- ggplot(plot_data, aes(x = estimate, y = chain, xmin = conf_low, xmax = conf_high)) +
  geom_vline(data = distinct(plot_data, relation, null), aes(xintercept = null),
             colour = "grey65", linetype = 2) +
  geom_errorbarh(height = .15, colour = "#2C3E50") +
  geom_point(size = 2, colour = "#0072B2") +
  facet_wrap(~ relation, scales = "free_x", ncol = 2) +
  labs(x = "标准化效应及95%置信区间", y = NULL,
       title = "八条候选机制链的调整关联与经验交互") +
  theme_minimal(base_family = "sans", base_size = 11) +
  theme(panel.grid.minor = element_blank(), strip.text = element_text(face = "bold"))
ggsave(file.path(result_dir, "figure_eight_chain_map_v7_1.png"), p, width = 10, height = 7, dpi = 300)
ggsave(file.path(result_dir, "figure_eight_chain_map_v7_1.pdf"), p, width = 10, height = 7)

# ---- 样本与编码审计 ----------------------------------------------------------
same_partner_flow <- tibble(
  step = c("全部相邻区间", "同一成年子女", "同一父母", "同一配偶"),
  n_records = c(nrow(d0), sum(d0$same_actor, na.rm = TRUE),
                sum(d0$same_actor & d0$same_parent, na.rm = TRUE),
                sum(d0$same_actor & d0$same_parent & d0$same_partner, na.rm = TRUE))
)
write_csv(same_partner_flow, file.path(result_dir, "24_same_partner_sample_flow.csv"))

satisfaction_transitions <- bind_rows(
  d0 %>% filter(same_actor %in% TRUE, same_parent %in% TRUE, same_partner %in% TRUE,
                !is.na(self_sat_begin), !is.na(self_sat_end)) %>%
    count(period, role = "本人", baseline = self_sat_begin,
          improved = self_sat_end > self_sat_begin, name = "n"),
  d0 %>% filter(same_actor %in% TRUE, same_parent %in% TRUE, same_partner %in% TRUE,
                !is.na(spouse_sat_begin), !is.na(spouse_sat_end)) %>%
    count(period, role = "配偶", baseline = spouse_sat_begin,
          improved = spouse_sat_end > spouse_sat_begin, name = "n")
) %>%
  group_by(period, role, baseline) %>%
  mutate(baseline_total = sum(n), improvement_probability = sum(n[improved]) / baseline_total) %>%
  ungroup()
write_csv(satisfaction_transitions, file.path(result_dir, "25_satisfaction_transition_audit.csv"))

correction_summary <- read_csv(correction_summary_path, show_col_types = FALSE)
write_csv(correction_summary, file.path(result_dir, "26_partner_business_assignment_correction_summary.csv"))

time_window_statement <- tribble(
  ~variable, ~question_window, ~permitted_interpretation,
  "X：综合收入", "工资/经营收入主要为过去12个月；养老金为调查时月额年化", "X早于访谈时点M，但与Y过去6个月窗口部分重叠",
  "M：婚姻满意度", "访谈时点的当前总体评价", "不能证明M先于Y发生",
  "Y：父母特定经济支持", "访谈前6个月平均每月支持", "与X存在部分时序信息；与M严格先后次序不可观察"
)
write_csv(time_window_statement, file.path(result_dir, "27_measurement_time_windows.csv"))

# 与八条链口径一致的X/M/Y描述性统计，供替换正文旧ridit尺度条目。
descriptive_base <- d0 %>%
  filter(same_actor %in% TRUE, same_parent %in% TRUE, same_partner %in% TRUE)
desc_binary <- function(data, variable, label, period_label) {
  x <- data[[variable]]
  tibble(period = period_label, variable = variable, label = label,
         scale = "二分类正向转移；分母为该变量非缺失/具资格记录",
         n = sum(!is.na(x)), events = sum(x == 1, na.rm = TRUE),
         mean_or_rate = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE))
}
desc_continuous <- function(data, variable, label, period_label) {
  x <- data[[variable]]
  tibble(period = period_label, variable = variable, label = label,
         scale = "原始1—5分",
         n = sum(!is.na(x)), events = NA_integer_,
         mean_or_rate = mean(x, na.rm = TRUE), sd = sd(x, na.rm = TRUE))
}
desc_rows <- list()
desc_specs_binary <- tribble(
  ~variable, ~label,
  "x_abs", "本人实际综合收入增加",
  "x_rel", "本人夫妻内收入相对位置升级",
  "m_self_abs", "本人婚姻满意度提升",
  "m_spouse_abs", "配偶婚姻满意度提升",
  "m_self_rel", "本人婚姻满意度相对位置升级",
  "m_spouse_rel", "配偶婚姻满意度相对位置升级",
  "y_growth", "父母特定实际代际经济支持增加"
)
desc_specs_cont <- tribble(
  ~variable, ~label,
  "self_sat_begin", "本人基期婚姻满意度",
  "self_sat_end", "本人期末婚姻满意度",
  "spouse_sat_begin", "配偶基期婚姻满意度",
  "spouse_sat_end", "配偶期末婚姻满意度"
)
desc_groups <- c("合并区间", levels(descriptive_base$period_fe))
for (g in desc_groups) {
  dg <- if (g == "合并区间") descriptive_base else descriptive_base %>% filter(period_fe == g)
  for (j in seq_len(nrow(desc_specs_binary))) {
    desc_rows[[paste(g, "b", j)]] <- desc_binary(dg, desc_specs_binary$variable[j],
                                                 desc_specs_binary$label[j], g)
  }
  for (j in seq_len(nrow(desc_specs_cont))) {
    desc_rows[[paste(g, "c", j)]] <- desc_continuous(dg, desc_specs_cont$variable[j],
                                                     desc_specs_cont$label[j], g)
  }
}
descriptive_xmy <- bind_rows(desc_rows)
write_csv(descriptive_xmy, file.path(result_dir, "32_descriptive_xmy_scale_aligned.csv"))

# ---- 验收与会话信息 ----------------------------------------------------------
formula_has_both_income_baselines <- str_detect(model_manifest$formula,
                                                fixed("baseline_actor_income_ihs")) &
  str_detect(model_manifest$formula, fixed("baseline_partner_income_ihs"))
period_direct <- period_diagnostics %>% filter(result_type == "direct_period_difference")
parent_special_isolated <- all(d0$parent_cluster_id[!d0$valid_parent_pid] ==
                                 paste0("U:", d0$dyad_id[!d0$valid_parent_pid]))
validation <- bind_rows(
  contract_assertions %>% transmute(check = paste0("data contract: ", check), pass, detail),
  tibble(check = "eight chains estimated", pass = nrow(samples) == 8,
         detail = paste0("chains=", nrow(samples))),
  tibble(check = "five models per chain", pass = nrow(model_manifest) == 40,
         detail = paste0("models=", nrow(model_manifest))),
  tibble(check = "all logistic models converged", pass = all(diagnostics$converged),
         detail = paste0("failed=", sum(!diagnostics$converged))),
  tibble(check = "no aliased coefficients", pass = all(diagnostics$aliased == 0),
         detail = paste0("aliased_models=", sum(diagnostics$aliased > 0))),
  tibble(check = "all 40 formulas control both baseline incomes",
         pass = all(formula_has_both_income_baselines),
         detail = paste0("missing=", sum(!formula_has_both_income_baselines))),
  tibble(check = "all Model 5 formulas contain X by M interaction",
         pass = all(str_detect(model_manifest$formula[model_manifest$model == "M5"], fixed(" * "))),
         detail = "eight interaction formulas checked"),
  tibble(check = "four BH-FDR families each contain eight tests",
         pass = n_distinct(multiple_testing$test_family) == 4 &&
           all(count(multiple_testing, test_family)$n == 8),
         detail = paste(count(multiple_testing, test_family)$n, collapse = "/")),
  tibble(check = "period models provide 24 direct effect differences",
         pass = nrow(period_direct) == 24,
         detail = paste0("differences=", nrow(period_direct))),
  tibble(check = "shared interaction bootstrap has at least 1000 successes per chain",
         pass = all(bootstrap_summary$successful >= 1000),
         detail = paste(bootstrap_summary$successful, collapse = "/")),
  tibble(check = "AR role contrast uses common nonempty risk set and 1000 successes",
         pass = nrow(ar_common) > 0 && all(ar_role_summary$successful >= 1000) &&
           nrow(ar_role_summary) == 3,
         detail = paste0("records=", nrow(ar_common), "; actors=",
                         n_distinct(ar_common$actor_pid_begin), "; successes=",
                         min(ar_role_summary$successful))),
  tibble(check = "special or missing parent PID never forms a shared pseudo-cluster",
         pass = parent_special_isolated,
         detail = paste0("surrogate_records=", sum(!d0$valid_parent_pid))),
  tibble(check = "all chain samples use same spouse", pass = all(vapply(registry$chain, function(ch) {
    all(all_models[[paste0(ch, "_M1")]]$data$same_partner)
  }, logical(1))), detail = "same_partner=TRUE"),
  tibble(check = "partner business correction audit retained", pass =
           identical(as.integer(correction_summary$changed), c(387L, 375L)),
         detail = paste(correction_summary$changed, collapse = "/")),
  tibble(check = "no CMAverse execution", pass = TRUE,
         detail = "script contains no cmest call")
)
write_csv(validation, file.path(result_dir, "28_validation.csv"))
if (!all(validation$pass)) stop("验收失败：", paste(validation$check[!validation$pass], collapse = "; "))

saveRDS(all_models, file.path(result_dir, "29_model_bundle.rds"), compress = "xz")
capture.output(sessionInfo(), file = file.path(result_dir, "30_sessionInfo.txt"))
write_json(list(
  run_id = run_id,
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  analysis_unit = "parent-adult-child dyad interval",
  input_rds = input_rds,
  input_sha256 = input_hash,
  n_chains = nrow(samples), n_models = nrow(model_manifest),
  primary_cluster = "actor_pid_begin",
  bootstrap_attempts = nboot_attempt,
  minimum_successful_bootstrap_repetitions = min(bootstrap_summary$successful),
  ar_common_records = nrow(ar_common),
  ar_common_actors = n_distinct(ar_common$actor_pid_begin),
  cma_ran = FALSE,
  output_root = root
), file.path(result_dir, "31_run_manifest.json"), pretty = TRUE, auto_unbox = TRUE)

hash_candidates <- list.files(root, recursive = TRUE, full.names = TRUE)
hash_candidates <- hash_candidates[file.info(hash_candidates)$isdir %in% FALSE]
hash_candidates <- hash_candidates[!str_detect(hash_candidates, fixed("33_file_hashes.csv"))]
file_hashes <- tibble(
  file = str_remove(hash_candidates, fixed(paste0(root, "/"))),
  bytes = file.info(hash_candidates)$size,
  sha256 = vapply(hash_candidates, digest::digest, character(1),
                  file = TRUE, algo = "sha256")
)
write_csv(file_hashes, file.path(result_dir, "33_file_hashes.csv"))

cat("V7_1_EIGHT_CHAIN_BASIC_REGRESSION_COMPLETE\n")
cat("chains=", nrow(samples), " models=", nrow(model_manifest),
    " all_validation_pass=", all(validation$pass), "\n", sep = "")
