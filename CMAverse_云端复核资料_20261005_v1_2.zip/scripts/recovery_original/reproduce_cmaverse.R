# 2026-09-27：按冻结输入、公式、抽样及种子复现总体八链和48分组。
# 仅恢复已执行规格，不执行 PLAN11 尚未实施的方法修正。
options(stringsAsFactors=FALSE, contrasts=c('contr.treatment','contr.poly'))
recovery_root <- Sys.getenv('CMAVERSE_RECOVERY_ROOT','/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927')
.libPaths(c(file.path(recovery_root,'runtime/library'),.libPaths()))
suppressPackageStartupMessages(library(CMAverse))
stopifnot('mval_grid'%in%names(formals(CMAverse::cmest)))
reference_root <- file.path(recovery_root,'sources/extracted/v751_empirical/research')
overall_reference <- file.path(reference_root,'20260905_basic_regression_cmaverse_v7_4_1/cma/formal')
group_reference <- file.path(reference_root,'20260908_v751_paper_revision_heterogeneity')
source(file.path(group_reference,'scripts/shared_bootstrap.R'))
chains <- c('AA-S','AA-P','AR-S','AR-P','RA-S','RA-P','RR-S','RR-P')
phase <- Sys.getenv('RECOVERY_PHASE','smoke')
run_label <- Sys.getenv('RECOVERY_RUN_LABEL',if(phase=='smoke')'smoke_corrected' else 'formal')
B <- if(phase=='formal')1000L else 10L
if(!phase%in%c('smoke','formal'))stop('Unknown phase')
run_kind <- Sys.getenv('RECOVERY_KIND','all')
if(phase=='formal') {
  smoke_path<-file.path(recovery_root,'evidence/cmaverse_smoke_corrected_validation.csv')
  if(!file.exists(smoke_path) || !all(read.csv(smoke_path)$pass))stop('Corrected-seed smoke evidence missing or failed')
}
shared_plan <- readRDS(file.path(recovery_root,'data/shared_cluster_plan.rds'))
ram_output_mode <- isTRUE(jsonlite::read_json(file.path(recovery_root,'config/recovery.json'))$use_task_ram_outputs)
ram_root <- file.path(recovery_root,'backup/legacy_ram')
atomic_json <- function(x,path) {
  dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE)
  jsonlite::write_json(x,paste0(path,'.tmp'),auto_unbox=TRUE,pretty=TRUE,null='null',na='null')
  stopifnot(file.rename(paste0(path,'.tmp'),path))
}
report_progress <- function(stage,message,extra=list()) {
  atomic_json(c(list(stage=stage,message=message,updated_at=format(Sys.time(),'%FT%T%z'),pid=Sys.getpid(),phase=phase),extra),
              file.path(recovery_root,'evidence/cmaverse_runtime_status.json'))
  cat(stage,message,'\n');flush.console()
  if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)
}
space_wait <- function(write_bytes=512*1024^2,verification_buffer_bytes=256*1024^2) {
  repeat {
    cmd <- c('-c',shQuote(paste0("import shutil;print(shutil.disk_usage(",encodeString(recovery_root,quote="'"),").free)")))
    available <- as.numeric(system2('/opt/homebrew/bin/python3',cmd,stdout=TRUE))
    # 总体沿用原预算；分组按已完成对象大小留192MiB写入预算，另留两个64MiB验证缓冲。
    # 备份端在写出前按实时空间选择不超过256MiB的分卷并固定边界，始终另保留5GiB。
    if(ram_output_mode) {
      binding<-jsonlite::read_json(file.path(recovery_root,'evidence/legacy_ram_buffer.json'),simplifyVector=TRUE)
      sentinel<-jsonlite::read_json(file.path(ram_root,'sentinel.json'),simplifyVector=TRUE)
      stopifnot(binding$state=='mounted',identical(binding$buffer_id,sentinel$buffer_id),identical(binding$mount_point,ram_root))
      ram_cmd<-c('-c',shQuote(paste0("import os,shutil; p=",encodeString(ram_root,quote="'"),"; assert os.stat(p).st_dev==",binding$device_id,"; print(shutil.disk_usage(p).free)")))
      ram_free<-as.numeric(system2('/opt/homebrew/bin/python3',ram_cmd,stdout=TRUE))
      required<-5*1024^3+16*1024^2
      if(length(available)==1 && is.finite(available) && available>required &&
         length(ram_free)==1 && is.finite(ram_free) && ram_free>write_bytes+2*verification_buffer_bytes+64*1024^2)return(invisible(TRUE))
      report_progress('waiting_for_verified_ram_space','完整模型使用任务RAM，等待云回验释放；系统盘保留5GiB',
                      list(free_bytes=available,required_free_bytes=required,ram_free_bytes=ram_free))
    } else {
      required <- 5*1024^3+write_bytes+2*verification_buffer_bytes
      if(length(available)==1 && is.finite(available) && available>required)return(invisible(TRUE))
      report_progress('waiting_for_disk_space','等待本组写入和云回验空间，保留5GiB安全余量',list(free_bytes=available,required_free_bytes=required))
    }
    Sys.sleep(30)
  }
}
read_args <- function(chain,key=NULL) {
  group <- !is.null(key)
  data <- readRDS(file.path(recovery_root,'data',paste0(if(group)key else paste0('overall_',chain),'.rds')))
  roles <- read.csv(file.path(overall_reference,chain,'variable_role_manifest.csv'),check.names=FALSE)
  basec <- unique(roles$variable[roles$role=='basec'])
  postc <- unique(roles$variable[roles$role=='postc'])
  if(group) {
    fm <- read.csv(file.path(group_reference,'heterogeneity/formal',key,'formulas.csv'),check.names=FALSE)
    parts <- strsplit(key,'__',fixed=TRUE)[[1]];gvar <- parts[2]
    if(gvar%in%basec && length(unique(data[[gvar]]))==1L)basec<-setdiff(basec,gvar)
  } else fm <- read.csv(file.path(overall_reference,chain,'formula_manifest.csv'),check.names=FALSE)
  fit_one <- function(i) {
    formula <- stats::as.formula(fm$formula[i],env=baseenv())
    family <- if(fm$family[i]=='binomial')stats::binomial() else stats::gaussian()
    z <- stats::glm(formula,data=data,family=family)
    z$call$formula<-formula;z$call$data<-quote(data)
    z$call$family<-if(fm$family[i]=='binomial')quote(stats::binomial(link='logit')) else quote(stats::gaussian(link='identity'))
    z
  }
  y <- fit_one(which(fm$model=='yreg'))
  m <- lapply(which(grepl('^mreg',fm$model)),fit_one)
  l <- lapply(which(grepl('^postcreg',fm$model)),fit_one)
  names(l)<-vapply(l,function(z)as.character(formula(z)[[2]]),'')
  stopifnot(identical(names(l),postc))
  models<-c(list(y),m,l)
  stopifnot(all(vapply(models,function(z)isTRUE(z$converged) && z$rank==length(coef(z)) && all(is.finite(coef(z))),logical(1))))
  list(data=data,model='gformula',outcome='Y',exposure='X',mediator='M',basec=basec,postc=postc,
       mreg=m,yreg=y,postcreg=l,EMint=TRUE,a=1,astar=0,mval_grid=list(c(0,1)),
       estimation='imputation',inference='bootstrap',boot.ci.type='per',yval=1,full=TRUE,nboot=B)
}
effects_table <- function(fit) do.call(rbind,lapply(c('0','1'),function(m) {
  z<-fit$mval_results[[m]]
  data.frame(mval=m,effect=names(z$effect.pe),estimate=as.numeric(z$effect.pe),se=as.numeric(z$effect.se),
             conf_low=as.numeric(z$effect.ci.low),conf_high=as.numeric(z$effect.ci.high),p_value=as.numeric(z$effect.pval))
}))
compare_numeric <- function(a,b,label) {
  a<-as.numeric(a);b<-as.numeric(b);stopifnot(length(a)==length(b))
  finite<-is.finite(a)&is.finite(b)
  error<-abs(a[finite]-b[finite]);ok<-error <= 1e-10+1e-8*abs(b[finite])
  nonfinite_ok<-all(is.na(a[!finite])==is.na(b[!finite])) && all(a[!finite][!is.na(a[!finite])]==b[!finite][!is.na(b[!finite])])
  data.frame(check=label,values=length(a),mismatches=sum(!ok)+as.integer(!nonfinite_ok),
             max_abs_error=if(length(error))max(error) else 0,pass=all(ok)&&nonfinite_ok)
}
reference_effects <- function(chain,key) {
  if(is.null(key))return(read.csv(file.path(overall_reference,chain,'effects_full.csv'),check.names=FALSE))
  x<-read.csv(file.path(group_reference,'results/heterogeneity_native_1632_results.csv'),check.names=FALSE)
  p<-strsplit(key,'__',fixed=TRUE)[[1]]
  x<-x[x$chain==chain & x$dimension==p[2] & x$level==as.integer(p[3]),,drop=FALSE]
  names(x)[names(x)=='p_native']<-'p_value';x
}
run_one <- function(chain,key=NULL) {
  id<-if(is.null(key))chain else key;kind<-if(is.null(key))'overall' else 'heterogeneity'
  dest<-file.path(recovery_root,'results',run_label,kind,id)
  dir.create(dest,recursive=TRUE,showWarnings=FALSE)
  validation_path<-file.path(dest,'validation.json')
  if(file.exists(validation_path)) {
    v<-jsonlite::read_json(validation_path,simplifyVector=TRUE)
    if((isTRUE(v$full_object_validated)||isTRUE(v$smoke_structure_valid)) && isTRUE(v$historical_numeric_match) && v$B==B) {
      report_progress('reuse_completed',id)
      return(read.csv(file.path(dest,'comparison.csv'),check.names=FALSE))
    }
    stop('Existing incomplete/discrepant output requires review: ',id)
  }
  if(is.null(key))space_wait() else space_wait(192*1024^2,64*1024^2)
  report_progress('fit_regressions',id)
  args<-read_args(chain,key);diagnostics<-NULL;indices<-NULL;bridge<-NULL
  if(!is.null(key)) {
    map<-split(seq_len(nrow(args$data)),factor(args$data$cluster_id,levels=seq_len(ncol(shared_plan$draws))))
    indices<-lapply(seq_len(B),function(b)unlist(map[shared_plan$draws[b,]],use.names=FALSE))
    progress<-function(b,R,last)report_progress('paired_bootstrap',paste(id,'attempt',b,'of',R),list(key=id,completed=b))
    bridge<-make_shared_cmest(indices,shared_plan$seeds[seq_len(B)],progress)
    fn<-bridge$cmest;set.seed(75112345L)
  } else {
    recorded_state<-jsonlite::read_json(file.path(overall_reference,chain,'state.json'),simplifyVector=TRUE)
    stopifnot(recorded_state$nboot==1000L,recorded_state$status=='complete')
    recorded_seed<-as.integer(recorded_state$seed)
    fn<-CMAverse::cmest;set.seed(recorded_seed)
  }
  report_progress('paired_point_and_bootstrap',paste(id,'B=',B))
  started<-Sys.time()
  fit<-do.call(fn,args)
  elapsed<-as.numeric(difftime(Sys.time(),started,units='secs'))
  if(!is.null(bridge))diagnostics<-do.call(rbind,bridge$state$diagnostics)
  stopifnot(inherits(fit,'cmest_mval_grid'),all(vapply(fit$mval_results,inherits,logical(1),what='cmest')),
            identical(dim(fit$mval_grid$bootstrap_t),c(B,34L)))
  fit$call[[1]]<-quote(CMAverse::cmest)
  for(m in names(fit$mval_results))fit$mval_results[[m]]$call[[1]]<-quote(CMAverse::cmest)
  if(is.null(key)) {
    stopifnot(identical(dim(fit$mval_grid$bootstrap_indices),c(B,nrow(args$data))))
    valid_count<-B
  } else {
    stopifnot(identical(attr(fit$mval_grid$bootstrap_indices,'row_lengths'),lengths(indices)))
    valid_count<-sum(diagnostics$execution_ok & diagnostics$fits_valid & diagnostics$core_finite)
    write.csv(diagnostics,file.path(dest,'repeat_diagnostics.csv'),row.names=FALSE)
  }
  tab<-effects_table(fit);ref<-reference_effects(chain,key)
  ix<-match(paste(tab$mval,tab$effect),paste(ref$mval,ref$effect));stopifnot(!anyNA(ix))
  comparisons<-list(compare_numeric(tab$estimate,ref$estimate[ix],'point_estimates'))
  if(phase=='formal')for(v in c('se','conf_low','conf_high','p_value'))
    comparisons[[length(comparisons)+1L]]<-compare_numeric(tab[[v]],ref[[v]][ix],v)
  # 普通 bootstrap 的随机流随总抽样数改变；小样本 smoke 只核对点估计。
  # 分组使用历史固定逐次 seed，因此 smoke 也能核对前10次实际重复。
  if(phase=='formal' || !is.null(key)) {
    draw_path<-if(is.null(key))file.path(group_reference,'review_export_20260908/overall_draws',paste0(chain,'__stored_scale.csv')) else
      file.path(group_reference,'review_export_20260908/draws',paste0(key,'__stored_scale.csv'))
    rd<-read.csv(draw_path,check.names=FALSE)
    comparisons[[length(comparisons)+1L]]<-compare_numeric(fit$mval_grid$bootstrap_t,as.matrix(rd[seq_len(B),-1,drop=FALSE]),'all_stored_scale_draws')
  }
  if(!is.null(key)) {
    dg<-read.csv(file.path(group_reference,'heterogeneity/formal',key,'repeat_diagnostics.csv'))
    for(v in c('n','execution_ok','fits_valid','core_finite'))
      comparisons[[length(comparisons)+1L]]<-compare_numeric(diagnostics[[v]],dg[[v]][seq_len(B)],paste0('diagnostic_',v))
  }
  cmp<-do.call(rbind,comparisons);cmp$key<-id;cmp$kind<-kind;cmp$phase<-phase
  write.csv(cmp,file.path(dest,'comparison.csv'),row.names=FALSE)
  write.csv(tab,file.path(dest,'effects_full.csv'),row.names=FALSE)
  write.csv(fit$mval_grid$bootstrap_t,file.path(dest,'bootstrap_effect_draws_raw.csv'),row.names=FALSE)
  saveRDS(fit$mval_grid$bootstrap_t0,file.path(dest,'bootstrap_effect_point_raw.rds'))
  saveRDS(fit$mval_grid$bootstrap_rng_state,file.path(dest,'bootstrap_rng_state.rds'))
  delta<-fit$delta_cde
  dt<-data.frame(effect=names(delta$effect.pe),estimate=as.numeric(delta$effect.pe),se=as.numeric(delta$effect.se),
                  conf_low=as.numeric(delta$effect.ci.low),conf_high=as.numeric(delta$effect.ci.high),p_value=as.numeric(delta$effect.pval),scale=delta$scale)
  write.csv(dt,file.path(dest,'delta_cde.csv'),row.names=FALSE)
  if(phase=='smoke') {
    # 小规模检查保留数值与结构证据；正式批次另逐个保存及回读完整对象。
    atomic_json(list(smoke_structure_valid=TRUE,full_object_validated=FALSE,historical_numeric_match=all(cmp$pass),
                    formal_full_object_still_required=TRUE,key=id,kind=kind,B=B,N=nrow(args$data),
                    point_seed=if(is.null(key))recorded_seed else 75112345L,elapsed_seconds=elapsed,
                    validated_at=as.character(Sys.time())),validation_path)
    report_progress('smoke_complete',paste(id,'match=',all(cmp$pass)))
    rm(fit,args,bridge,indices);gc()
    return(cmp)
  }
  fit$execution_provenance<-list(recovery_task='cmaverse-recovery-20260927',statistical_version=if(is.null(key))'v7.4.1' else 'v7.5.1',
    historical_reference=if(is.null(key))file.path(overall_reference,chain) else file.path(group_reference,'heterogeneity/formal',key),
    sampling_unit=if(is.null(key))'dyad-interval record' else 'actor-partner-valid-parent-year-qualified-household connected component',
    point_seed=if(is.null(key))recorded_seed else 75112345L,shared_plan_seed=if(is.null(key))NULL else 7510908L,
    B_attempted=B,B_core_valid=valid_count,dependency_adjusted=!is.null(key),
    inference_status=if(valid_count==B)'complete' else 'blocked_failed_repeats',
    historical_numeric_match=all(cmp$pass),source='CSV + frozen data dictionary; no new variable construction',
    original_script_and_package_sources_retained=TRUE,packaging_only_fix='omitted unavailable cma2020 example export',
    serialization='gzip full cmest_mval_grid, both complete cmest children and actual bootstrap indices retained')
  storage_dest<-if(ram_output_mode)file.path(ram_root,'models',run_label,kind,id) else dest
  dir.create(storage_dest,recursive=TRUE,showWarnings=FALSE)
  full_path<-file.path(storage_dest,if(is.null(key))paste0('cmest_grid_',chain,'_nboot',B,'.rds') else 'cmest_paired_full.rds')
  if(file.exists(full_path))stop('Refusing to overwrite existing model: ',full_path)
  if(ram_output_mode) {if(is.null(key))space_wait() else space_wait(192*1024^2,64*1024^2)}
  report_progress('save_and_readback',id)
  saveRDS(fit,paste0(full_path,'.partial'),compress='gzip')
  stopifnot(file.rename(paste0(full_path,'.partial'),full_path))
  check<-readRDS(full_path)
  stopifnot(inherits(check,'cmest_mval_grid'),inherits(check$mval_results[['0']],'cmest'),inherits(check$mval_results[['1']],'cmest'),
            identical(check$mval_grid$bootstrap_t,fit$mval_grid$bootstrap_t),identical(check$data,fit$data),
            !is.null(check$mval_results[['0']]$reg.output),!is.null(check$mval_results[['1']]$reg.output))
  rm(check)
  sha<-digest::digest(file=full_path,algo='sha256')
  validation<-list(full_object_validated=TRUE,historical_numeric_match=all(cmp$pass),object_path=full_path,object_sha256=sha,
                  key=id,kind=kind,phase=phase,B=B,N=nrow(args$data),valid_repeats=valid_count,
                  bytes=file.info(full_path)$size,elapsed_seconds=elapsed,validated_at=as.character(Sys.time()),comparison_file=file.path(dest,'comparison.csv'))
  atomic_json(validation,validation_path)
  atomic_json(list(status='complete',key=id,B=B,B_valid=valid_count,historical_numeric_match=all(cmp$pass),
                  updated_at=as.character(Sys.time())),file.path(dest,'state.json'))
  if(phase=='formal') {
    # 只有经完整回读且数值对照通过的新正式对象请求云端验收后释放。
    atomic_json(list(source=full_path,validation=validation_path,release=all(cmp$pass),category='new_full_cmest'),
                file.path(recovery_root,'backup/ready',paste0(kind,'_',id,'.json')))
  }
  report_progress('model_complete',paste(id,'B_valid=',valid_count,'match=',all(cmp$pass)),list(key=id,elapsed_seconds=elapsed))
  rm(fit,args,bridge,indices);gc()
  cmp
}

all_comparisons<-list()
tryCatch({
  if(run_kind%in%c('all','overall'))for(chain in chains)all_comparisons[[chain]]<-run_one(chain)
  if(run_kind%in%c('all','heterogeneity')) {
    keys<-if(phase=='smoke')c('AA-S__gender_begin__0','RA-P__gender_begin__0') else
      unlist(lapply(chains,function(ch)unlist(lapply(c('gender_begin','lifetime_begin','urban_begin'),function(v)paste(ch,v,0:1,sep='__')))))
    for(key in keys)all_comparisons[[key]]<-run_one(sub('__.*','',key),key)
  }
  complete<-do.call(rbind,all_comparisons)
  write.csv(complete,file.path(recovery_root,'evidence',paste0('cmaverse_',run_label,'_validation.csv')),row.names=FALSE)
  writeLines(capture.output(sessionInfo()),file.path(recovery_root,'evidence',paste0('cmaverse_',run_label,'_sessionInfo.txt')))
  if(phase=='smoke')stopifnot(all(complete$pass))
  report_progress('complete',paste(phase,'模型批次已保存；数值检查通过',sum(complete$pass),'/',nrow(complete)))
},error=function(e){report_progress('failed',conditionMessage(e));stop(e)})
