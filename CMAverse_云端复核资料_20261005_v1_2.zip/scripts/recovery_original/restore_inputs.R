# 2026-09-27：从审核包的 CSV、类型字典和抽样导出恢复独立运行输入。
# 这些 RDS 是重新序列化的恢复输入，不声称与已丢失 RDS 文件逐字节相同。
local({
  root <- Sys.getenv('CMAVERSE_RECOVERY_ROOT','/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927')
  src <- file.path(root,'sources/extracted/v751_empirical/research')
  review <- file.path(src,'20260908_v751_paper_revision_heterogeneity/review_export_20260908')
  out <- file.path(root,'data')
  dir.create(out, showWarnings=FALSE)
  dict <- read.csv(file.path(review,'data_dictionary.csv'), stringsAsFactors=FALSE, check.names=FALSE)
  all_paths <- list.files(file.path(review,'data'),pattern='[.]csv$',recursive=TRUE,full.names=TRUE)
  checks <- list()
  for(path in all_paths) {
    ds <- sub('[.]csv$','',basename(path))
    if(basename(dirname(path))=='overall' && !startsWith(ds,'overall_')) ds <- paste0('overall_',ds)
    dd <- dict[dict$dataset==ds,,drop=FALSE]
    stopifnot(nrow(dd)>0,!anyDuplicated(dd$variable))
    h <- names(read.csv(path,nrows=0,check.names=FALSE))
    stopifnot(identical(h,dd$variable))
    d <- read.csv(path, colClasses=dd$storage, na.strings='NA', check.names=FALSE, stringsAsFactors=FALSE)
    missing <- vapply(d,function(x)sum(is.na(x)),integer(1))
    stopifnot(all(missing==dd$missing))
    for(j in seq_len(nrow(dd))) {
      if(!is.na(dd$label[j]) && nzchar(dd$label[j])) attr(d[[j]],'label') <- dd$label[j]
    }
    p <- file.path(out,paste0(ds,'.rds'))
    saveRDS(d,p,compress='gzip')
    checks[[ds]] <- data.frame(dataset=ds,rows=nrow(d),columns=ncol(d),types_and_missing_pass=TRUE,
      csv_sha256=digest::digest(file=path,algo='sha256'),restored_rds_sha256=digest::digest(file=p,algo='sha256'))
    cat('INPUT_RESTORED',ds,nrow(d),ncol(d),'\n');flush.console()
  }
  stopifnot(length(checks)==57L)
  draw_df <- read.csv(file.path(review,'sampling/shared_cluster_draws.csv'), check.names=FALSE)
  seed_df <- read.csv(file.path(review,'sampling/repeat_seeds.csv'))
  stopifnot(identical(draw_df$replicate,seq_len(1000L)),identical(seed_df$replicate,seq_len(1000L)))
  draws <- as.matrix(draw_df[,-1,drop=FALSE]);storage.mode(draws)<-'integer'
  set.seed(7510908L)
  regenerated <- matrix(sample.int(ncol(draws),1000L*ncol(draws),replace=TRUE),1000L,byrow=TRUE)
  regenerated_seeds <- sample.int(.Machine$integer.max,1000L)
  stopifnot(identical(unname(draws),regenerated),identical(seed_df$seed,regenerated_seeds))
  saveRDS(list(draws=regenerated,seeds=regenerated_seeds,seed=7510908L),file.path(out,'shared_cluster_plan.rds'))
  write.csv(do.call(rbind,checks),file.path(root,'evidence/input_recovery_checks.csv'),row.names=FALSE)
  write.csv(data.frame(check=c('57_exported_datasets','1000_draw_plan_exact','1000_repeat_seeds_exact'),pass=TRUE),
    file.path(root,'evidence/input_plan_validation.csv'),row.names=FALSE)

  # v7.1 的底稿来自 v6 CSV，禁止将 v7.4.1 的身份筛选底稿替代它。
  v6path <- file.path(src,'20260904_basic_mechanism_v6/data/v6_provisional_dyad_intervals.csv')
  bundle <- readRDS(file.path(root,'sources/extracted/baseline_v7/20260904_basic_regression_eight_chains_v7/results/19_model_bundle.rds'))
  template <- bundle[[1]]$data
  h <- names(read.csv(v6path,nrows=0,check.names=FALSE))
  types <- setNames(rep('numeric',length(h)),h)
  for(n in intersect(h,names(template))) {
    cl <- class(template[[n]])
    if('character'%in%cl)types[n]<-'character'
    else if('logical'%in%cl)types[n]<-'logical'
    else if('integer'%in%cl)types[n]<-'integer'
  }
  types[intersect(c('period','period_fe'),h)] <- 'character'
  d0 <- tibble::as_tibble(read.csv(v6path,colClasses=unname(types),check.names=FALSE,na.strings='NA',stringsAsFactors=FALSE))
  d0$period_fe <- factor(d0$period_fe,levels=c('2018-2020','2020-2022'))
  stopifnot(!anyDuplicated(d0[c('dyad_id','begin_year')]))
  baseline_checks <- list()
  for(n in names(bundle)) {
    d <- bundle[[n]]$data
    ix <- match(paste(d$dyad_id,d$begin_year),paste(d0$dyad_id,d0$begin_year))
    stopifnot(!anyNA(ix))
    cs <- intersect(names(d0),names(d))
    ok <- vapply(cs,function(v){
      a <- d0[[v]][ix];b <- d[[v]]
      if(is.factor(a)||is.factor(b))return(identical(as.character(a),as.character(b)))
      isTRUE(all.equal(a,b,tolerance=1e-12,check.attributes=FALSE))
    },logical(1))
    baseline_checks[[n]]<-data.frame(reference_model=n,rows=nrow(d),columns=length(cs),pass=all(ok),failed=paste(cs[!ok],collapse=';'))
  }
  bc <- do.call(rbind,baseline_checks)
  write.csv(bc,file.path(root,'evidence/v6_recovered_values_vs_v7_reference.csv'),row.names=FALSE)
  stopifnot(all(bc$pass))
  saveRDS(d0,file.path(out,'v6_provisional_dyad_intervals_recovered.rds'),compress='xz')
  jsonlite::write_json(list(status='PASS',date=as.character(Sys.time()),datasets=57,baseline_rows=nrow(d0),
    baseline_columns=ncol(d0),provenance='CSV + dictionary / v7 object type evidence; recreated serialization, not original RDS'),
    file.path(root,'evidence/input_recovery.json'),auto_unbox=TRUE,pretty=TRUE)
  cat('INPUT_RECOVERY_COMPLETE\n');flush.console()
})
