.sanitize_cmest_regressions <- function(value) {
  lean_env <- new.env(parent = baseenv())

  sanitize_terms <- function(terms_obj) {
    if (is.null(terms_obj)) return(terms_obj)
    try(environment(terms_obj) <- lean_env, silent = TRUE)
    try(attr(terms_obj, ".Environment") <- lean_env, silent = TRUE)
    terms_obj
  }

  sanitize_model <- function(model) {
    if (inherits(model, "glm")) {
      family_info <- stats::family(model)
      if (identical(family_info$family, "gaussian")) {
        model$family <- stats::gaussian(link = family_info$link)
      } else if (identical(family_info$family, "binomial")) {
        model$family <- stats::binomial(link = family_info$link)
      }
    }
    if (is.list(model) && !is.null(model$terms)) {
      model$terms <- sanitize_terms(model$terms)
    }
    if (is.list(model) && inherits(model$formula, "formula")) {
      formula_obj <- model$formula
      try(environment(formula_obj) <- lean_env, silent = TRUE)
      model$formula <- formula_obj
    }
    if (is.list(model) && inherits(model$call$formula, "formula")) {
      call_formula <- model$call$formula
      try(environment(call_formula) <- lean_env, silent = TRUE)
      model$call$formula <- call_formula
    }
    if (is.list(model) && is.data.frame(model$model) && !is.null(attr(model$model, "terms"))) {
      attr(model$model, "terms") <- sanitize_terms(attr(model$model, "terms"))
    }
    model
  }

  sanitize_object <- function(x) {
    formula_value <- tryCatch(stats::formula(x), error = function(e) NULL)
    if (!is.null(formula_value) || (is.list(x) && !is.null(x$terms))) {
      return(sanitize_model(x))
    }
    if (is.list(x) && (is.null(class(x)) || identical(class(x), "list"))) {
      return(lapply(x, sanitize_object))
    }
    x
  }

  sanitize_object(value)
}
