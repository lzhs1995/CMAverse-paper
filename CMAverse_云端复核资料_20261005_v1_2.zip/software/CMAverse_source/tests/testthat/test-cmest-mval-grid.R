context("cmest supports paired mval_grid bootstrap")

simulate_mval_grid_data <- function(n = 80, binary_y = FALSE) {
  expit <- function(x) exp(x)/(1 + exp(x))
  C1 <- rnorm(n)
  A <- rbinom(n, 1, expit(-0.1 + 0.4 * C1))
  M <- rbinom(n, 1, expit(-0.2 + 0.8 * A + 0.5 * C1))
  if (binary_y) {
    Y <- rbinom(n, 1, expit(-0.4 + 0.6 * A + 0.4 * M + 0.3 * A * M + 0.2 * C1))
  } else {
    Y <- rnorm(n, 0.2 + 0.6 * A + 0.4 * M + 0.3 * A * M + 0.2 * C1, 1)
  }
  data.frame(A = A, M = M, Y = Y, C1 = C1)
}

test_that("cmest mval_grid returns one cmest child per expanded mval", {
  set.seed(20260527)
  data <- simulate_mval_grid_data()
  
  set.seed(1)
  res <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
               mediator = "M", basec = "C1", EMint = TRUE,
               mreg = list("logistic"), yreg = "linear",
               astar = 0, a = 1, mval_grid = list(c(0, 1)),
               nboot = 3, boot.ci.type = "per")
  
  expect_s3_class(res, "cmest_mval_grid")
  expect_named(res$mval_results, c("0", "1"))
  expect_s3_class(res$mval_results[["0"]], "cmest")
  expect_s3_class(res$mval_results[["1"]], "cmest")
  expect_false("mval_results" %in% names(res$mval_results[["0"]]))
  expect_false("mval_grid" %in% names(res$mval_results[["0"]]))
  expect_false("mval_results" %in% names(res$mval_results[["1"]]))
  expect_false("mval_grid" %in% names(res$mval_results[["1"]]))
  expect_equal(res$mval_results[["0"]]$ref$mval, list(0))
  expect_equal(res$mval_results[["1"]]$ref$mval, list(1))
  expect_equal(names(res$mval_results[["0"]]$effect.pe),
               names(res$mval_results[["1"]]$effect.pe))
  expect_true(is.list(res$delta_cde))
  expect_match(res$mval_grid$bootstrap_provenance$hash, "^[0-9a-f]{64}$")
  expect_identical(res$mval_results[["0"]]$bootstrap_provenance$hash,
                   res$mval_results[["1"]]$bootstrap_provenance$hash)
  expect_identical(res$mval_results[["0"]]$bootstrap_provenance$hash,
                   res$delta_cde$bootstrap_provenance$hash)
  expect_equal(unname(res$delta_cde$effect.pe),
               unname(res$mval_results[["1"]]$effect.pe["cde"] -
                        res$mval_results[["0"]]$effect.pe["cde"]),
               tolerance = 1e-12)
  expect_true(all(c("cde", "pnde", "tnde", "pnie", "tnie", "te") %in%
                    names(res$mval_results[["0"]]$effect.pe)))
  expect_s3_class(summary(res), "summary.cmest_mval_grid")
  expect_error(cmsens(res), "cmest_mval_grid")
})

test_that("paired bootstrap provenance is reproducible and seed-sensitive", {
  set.seed(20260527)
  data <- simulate_mval_grid_data()
  fit <- function(seed) {
    set.seed(seed)
    cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
          mediator = "M", basec = "C1", EMint = TRUE,
          mreg = list("logistic"), yreg = "linear",
          astar = 0, a = 1, mval_grid = list(c(0, 1)),
          nboot = 3, boot.ci.type = "per")
  }
  first <- fit(11)
  second <- fit(11)
  changed <- fit(12)
  expect_identical(first$mval_grid$bootstrap_provenance$hash,
                   second$mval_grid$bootstrap_provenance$hash)
  expect_false(identical(first$mval_grid$bootstrap_provenance$hash,
                         changed$mval_grid$bootstrap_provenance$hash))
})

test_that("paired bootstrap progress callback reports without being serialized", {
  set.seed(20260527)
  data <- simulate_mval_grid_data()
  events <- list()
  callback <- function(event) events[[length(events) + 1L]] <<- event
  set.seed(1)
  res <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
               mediator = "M", basec = "C1", EMint = TRUE,
               mreg = list("logistic"), yreg = "linear",
               astar = 0, a = 1, mval_grid = list(c(0, 1)),
               progress_callback = callback, progress_every = 1L,
               nboot = 3, boot.ci.type = "per")
  expect_equal(vapply(events, `[[`, integer(1), "completed"), 0:3)
  expect_identical(events[[1]]$stage, "point_estimate")
  expect_identical(events[[4]]$stage, "bootstrap")
  expect_null(res$call$progress_callback)
  path <- tempfile(fileext = ".rds")
  saveRDS(res$mval_results[["0"]], path)
  expect_s3_class(readRDS(path), "cmest")
})

test_that("serialized paired results do not retain the global workspace", {
  assign("mval_grid_large_global_fixture", raw(5 * 1024 * 1024), envir = .GlobalEnv)
  on.exit(rm("mval_grid_large_global_fixture", envir = .GlobalEnv), add = TRUE)
  set.seed(20260527)
  data <- simulate_mval_grid_data()
  set.seed(17)
  res <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
               mediator = "M", basec = "C1", EMint = TRUE,
               mreg = list("logistic"), yreg = "linear",
               astar = 0, a = 1, mval_grid = list(c(0, 1)),
               nboot = 3, boot.ci.type = "per")
  path <- tempfile(fileext = ".rds")
  on.exit(unlink(path), add = TRUE)
  saveRDS(res, path, compress = FALSE)
  expect_lt(file.info(path)$size, 5 * 1024 * 1024)
  restored <- readRDS(path)
  expect_s3_class(restored$mval_results[["0"]], "cmest")
  expect_equal(restored$mval_results[["0"]]$effect.pe,
               res$mval_results[["0"]]$effect.pe)
  expect_identical(environmentName(environment(
    restored$mval_results[["0"]]$reg.output$yreg$family$linkfun
  )), "stats")
})

test_that("cmest old single mval gformula interface still returns cmest", {
  set.seed(20260527)
  data <- simulate_mval_grid_data()
  
  set.seed(1)
  res <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
               mediator = "M", basec = "C1", EMint = TRUE,
               mreg = list("logistic"), yreg = "linear",
               astar = 0, a = 1, mval = list(0),
               nboot = 3, boot.ci.type = "per")
  
  expect_s3_class(res, "cmest")
  expect_false(inherits(res, "cmest_mval_grid"))
  expect_true(all(c("cde", "pnde", "tnde", "pnie", "tnie", "te") %in%
                    names(res$effect.pe)))
})

test_that("gaussian identity-link delta_cde equals the outcome-model A:M coefficient", {
  set.seed(20260528)
  data <- simulate_mval_grid_data(n = 160, binary_y = FALSE)
  
  set.seed(1)
  res <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
               mediator = "M", basec = "C1", EMint = TRUE,
               mreg = list("logistic"), yreg = "linear",
               astar = 0, a = 1, mval_grid = list(c(0, 1)),
               nboot = 3, boot.ci.type = "per")
  
  coef_mat <- summary(res$mval_results[["0"]]$reg.output$yreg)$coefficients
  int_name <- rownames(coef_mat)[grepl(":", rownames(coef_mat))][[1]]
  int_est <- unname(coef_mat[int_name, "Estimate"])
  
  expect_equal(unname(res$delta_cde$effect.pe), int_est, tolerance = 1e-10)
  expect_equal(unname(res$delta_cde$effect.pe),
               unname(res$mval_results[["1"]]$effect.pe["cde"] -
                        res$mval_results[["0"]]$effect.pe["cde"]),
               tolerance = 1e-12)
})

test_that("cmest mval_grid results numerically match standalone mval calls", {
  set.seed(20260527)
  data <- simulate_mval_grid_data()
  
  set.seed(1)
  res_grid <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
                    mediator = "M", basec = "C1", EMint = TRUE,
                    mreg = list("logistic"), yreg = "linear",
                    astar = 0, a = 1, mval_grid = list(c(0, 1)),
                    nboot = 3, boot.ci.type = "per")
  
  set.seed(1)
  res_single0 <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
                       mediator = "M", basec = "C1", EMint = TRUE,
                       mreg = list("logistic"), yreg = "linear",
                       astar = 0, a = 1, mval = list(0),
                       nboot = 3, boot.ci.type = "per")
  
  set.seed(1)
  res_single1 <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
                       mediator = "M", basec = "C1", EMint = TRUE,
                       mreg = list("logistic"), yreg = "linear",
                       astar = 0, a = 1, mval = list(1),
                       nboot = 3, boot.ci.type = "per")
  
  expect_equal(res_grid$mval_results[["0"]]$effect.pe, res_single0$effect.pe, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["0"]]$effect.se, res_single0$effect.se, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["0"]]$effect.ci.low, res_single0$effect.ci.low, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["0"]]$effect.ci.high, res_single0$effect.ci.high, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["0"]]$effect.pval, res_single0$effect.pval, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["1"]]$effect.pe, res_single1$effect.pe, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["1"]]$effect.se, res_single1$effect.se, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["1"]]$effect.ci.low, res_single1$effect.ci.low, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["1"]]$effect.ci.high, res_single1$effect.ci.high, tolerance = 1e-12)
  expect_equal(res_grid$mval_results[["1"]]$effect.pval, res_single1$effect.pval, tolerance = 1e-12)
})

test_that("cmest mval_grid supports logistic gformula with 17 effects", {
  set.seed(20260527)
  data <- simulate_mval_grid_data(n = 120, binary_y = TRUE)
  
  set.seed(1)
  res <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
               mediator = "M", basec = "C1", EMint = TRUE,
               mreg = list("logistic"), yreg = "logistic",
               astar = 0, a = 1, mval_grid = list(c(0, 1)),
               nboot = 3, boot.ci.type = "per")
  
  expect_equal(length(res$mval_results[["0"]]$effect.pe), 17)
  expect_equal(length(res$mval_results[["1"]]$effect.pe), 17)
  expect_true(is.list(res$delta_cde))
  expect_equal(unname(res$delta_cde$effect.pe),
               unname(res$mval_results[["1"]]$effect.pe["Rcde"] -
                        res$mval_results[["0"]]$effect.pe["Rcde"]),
               tolerance = 1e-12)
  expect_true(all(c("Rcde", "Rpnde", "Rtnde", "Rpnie", "Rtnie", "Rte",
                    "ERcde", "ERintref", "ERintmed", "ERpnie") %in%
                    names(res$mval_results[["0"]]$effect.pe)))
})

test_that("cmest mval_grid child regression model environments do not retain grid internals", {
  set.seed(20260527)
  data <- simulate_mval_grid_data(n = 120, binary_y = TRUE)
  
  set.seed(1)
  res <- cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
               mediator = "M", basec = "C1", EMint = TRUE,
               mreg = list("logistic"), yreg = "logistic",
               astar = 0, a = 1, mval_grid = list(c(0, 1)),
               nboot = 3, boot.ci.type = "per")
  
  large_names <- c(
    "grid_est", "est_grid", "grid_est_i",
    "boots", "boots_i",
    "mval_grid_results", "mval_grid_combos",
    "out", "data", "data0"
  )
  for (mval in c("0", "1")) {
    yreg <- res$mval_results[[mval]]$reg.output$yreg
    formula_env <- environment(stats::formula(yreg))
    terms_env <- environment(yreg$terms)
    model_terms_env <- environment(attr(yreg$model, "terms"))
    expect_false(any(large_names %in% ls(formula_env, all.names = TRUE)))
    expect_false(any(large_names %in% ls(terms_env, all.names = TRUE)))
    expect_false(any(large_names %in% ls(model_terms_env, all.names = TRUE)))
  }
})

test_that("cmest mval_grid is limited to supported v1 scope", {
  set.seed(20260527)
  data <- simulate_mval_grid_data()
  
  expect_error(
    cmest(data = data, model = "rb", outcome = "Y", exposure = "A",
          mediator = "M", basec = "C1", EMint = TRUE,
          mreg = list("logistic"), yreg = "linear",
          astar = 0, a = 1, mval_grid = list(c(0, 1))),
    "model = 'gformula'"
  )
  
  expect_error(
    cmest(data = data, model = "gformula", outcome = "Y", exposure = "A",
          mediator = "M", basec = "C1", EMint = TRUE,
          mreg = list("logistic"), yreg = "linear",
          astar = 0, a = 1, mval_grid = list(c(0, 1)), multimp = TRUE),
    "multimp = TRUE"
  )
})
