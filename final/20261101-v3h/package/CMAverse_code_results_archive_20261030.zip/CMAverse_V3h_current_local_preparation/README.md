# 收入变化、婚姻满意度与成年子女对父母的经济支持

**V3h 当前本地准备包 · 2026-10-30 · 正式原生验收待完成**

当前候选已合并表格历史和 PAGE 域。请从以下三份文件阅读；接受稿、拒绝稿是离线预期文件。

| 文件 | 当前用途 |
|---|---|
| [累计修订候选](manuscript/CMAverse_V3h_table_history_page_tracked_candidate.docx) | SHA256 d0badcab1d4a784be2d2f62801457a250b79b87b4297f3fd4734d955de1be895 |
| [接受全部修订的离线预期](manuscript/CMAverse_V3h_table_history_page_offline_accepted_expected.docx) | 用于后续原生接受结果对照 |
| [拒绝全部修订的离线预期](manuscript/CMAverse_V3h_table_history_page_offline_rejected_expected.docx) | 用于后续原生拒绝结果对照 |

原有离线证据覆盖9个story的两种视图，每视图34表、478行、2956格、3350段；661条修订包含626条原记录、33条表格历史和2条页码记录。本次仅复制和校验文件。PAGE缓存仍空，实际页码、表10第二列与表11第一列的词界及跨页效果待Word检查。

[后续验收计划](ACCEPTANCE_PLAN.md)列出正式三稿、C3元数据与Refresh、分页和最终PDF、同一PDF六主题连续两轮审查以及正式发布的依赖顺序。[科学边界](SCIENTIFIC_BOUNDARIES.md)保留估计目标、推断口径和历史来源缺口。

| 目录 | 内容 |
|---|---|
| manuscript/ | 当前三份候选/离线预期 |
| evidence/ | 当前表格与PAGE证据、C3差异检查及最终PDF验收范围 |
| review_preparation/nlm/ | 六主题模板与15份冻结CSV的来源册，尚未绑定最终PDF或远端source ID |
| code/ | 已有离线检查程序和本次构包程序；本次未执行科研或原生检查 |
| history/20261025/package/ | 完整保留的旧包、原清单、108份CSV与17份R源码；其旧稿仅作历史 |
| provenance/ | 原件身份、复制映射以及15份CSV在当前包内的位置 |

旧包193项成员及原MANIFEST共194项均保留，内部相对路径保持。439项历史索引仍区分102项已复制核验与337项仅索引，六项历史消费缺口91/98/105/117/118/132保持。当前复制校验不补造历史消费证明；本包也不含原始调查数据或完整模型对象。

包内JSON中的原绝对路径用于追溯冻结来源，不表示跨机自动可执行。当前MANIFEST固定所有成员和来源副本；包外DELIVERY_RESULT.json证明完整性、来源副本一致及ZIP每成员SHA/CRC，SIZE_CHECK.json记录严格小于25,000,000字节。以上回执不替代原生、科学或视觉验收。此阶段未发布GitHub或上传百度。
