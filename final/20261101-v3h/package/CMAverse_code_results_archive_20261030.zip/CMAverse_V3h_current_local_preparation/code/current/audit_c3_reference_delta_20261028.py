"""只读核对C3引用差异；不操作Word、Zotero、票据或共享控制器。"""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
from zipfile import ZipFile

from lxml import etree as ET


E = Path(__file__).resolve().parent
CONTRACT = E / "c3_complete_reference_delta_20261028_v1/C3_REFERENCE_DELTA_CONTRACT.json"
CONTRACT_SHA = "ecf32ca45e67b8f6a6e2371d55aae7f9a998b501837209e2b2d42b9c9a49ff45"
ROLES = ("tracked", "accepted", "rejected")
ITEM = re.compile(r"\s*ADDIN ZOTERO_ITEM CSL_CITATION\s+(.+?)\s*", re.S)
BIBL = re.compile(r"\s*ADDIN ZOTERO_BIBL\s+(.+?)\s+CSL_BIBLIOGRAPHY\s*", re.S)


class AuditError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise AuditError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(path):
    path = Path(path).absolute()
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def read_ref(ref):
    require(set(ref) == {"path", "bytes", "sha256"}, "FILE_PIN_SHAPE")
    path = Path(ref["path"])
    require(path.is_absolute(), "ABSOLUTE_INPUT_REQUIRED")
    raw = path.read_bytes()
    require(len(raw) == ref["bytes"] and sha(raw) == ref["sha256"],
            "FILE_PIN_MISMATCH: " + str(path))
    return raw


def load_dependencies():
    raw = CONTRACT.read_bytes()
    require(sha(raw) == CONTRACT_SHA, "C3_CONTRACT_CHANGED")
    contract = json.loads(raw)
    loaded = []
    for key in ("implementation", "projector"):
        ref = contract[key]
        read_ref(ref)
        spec = importlib.util.spec_from_file_location("cma_c3_audit_" + key, ref["path"])
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        read_ref(ref)
        loaded.append(module)
    return contract, loaded[0], loaded[1]


def expected_view(contract, role, phase):
    """仅两项刊名变化，完整JSON其余值和显示文本仍精确核对。"""
    row = contract["roles"][role]
    citations = []
    entries = (row["target_citation_fields"] + row["unaffected_citation_fields"])
    for item in sorted(entries, key=lambda x: (x["story"], x["ordinal"])):
        target = "expected_json_sha256" in item
        citations.append({
            "story": item["story"], "citation_id": item["citation_id"],
            "json_sha256": item["expected_json_sha256"]
                if target and phase == "after" else item["source_json_sha256"],
            "display": item["display"],
        })
    bibliography = row["bibliography"]
    rows_key = "expected_rows" if phase == "after" else "source_rows"
    return {"citations": citations, "bibliography": [{
        "story": bibliography["story"], "metadata": bibliography["metadata_json"],
        "rows": [x["text"] for x in bibliography[rows_key]],
    }]}


def snapshot(raw, projection, helper, projector):
    citations, bibliography = [], []
    with ZipFile(io.BytesIO(raw)) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "DUPLICATE_DOCX_MEMBER")
        for story in sorted(n for n in names if projector.STORY.fullmatch(n)):
            parser = ET.XMLParser(resolve_entities=False, no_network=True)
            root = ET.fromstring(archive.read(story), parser)
            if projection is not None:
                root = projector.project(root, projection)
            require(not projector.field_audit(root)["errors"], "BROKEN_FIELDS: " + story)
            for field in sorted(helper.fields(root, story), key=lambda x: x["ordinal"]):
                code = field["code"]
                item, bibl = ITEM.fullmatch(code), BIBL.fullmatch(code)
                if not item and not bibl:
                    require("ZOTERO_" not in code, "UNSUPPORTED_ZOTERO_INSTRUCTION: " + story)
                    continue
                require(field["separated"] and not field["nested"], "ZOTERO_NOT_LIVE_COMPLEX_FIELD")
                if item:
                    data = json.loads(item.group(1))
                    require(isinstance(data.get("citationID"), str), "MISSING_CITATION_ID")
                    require(not data.get("properties", {}).get("dontUpdate", False),
                            "FROZEN_ZOTERO_CITATION")
                    citations.append({
                        "story": story, "citation_id": data["citationID"],
                        "json_sha256": helper.digest(data),
                        "display": "".join(field["rows"].values()),
                    })
                else:
                    bibliography.append({
                        "story": story, "metadata": json.loads(bibl.group(1)),
                        "rows": list(field["rows"].values()),
                    })
    identities = [(r["story"], r["citation_id"]) for r in citations]
    require(len(identities) == len(set(identities)), "DUPLICATE_CITATION_ID")
    return {"citations": citations, "bibliography": bibliography}


def compare_view(actual, expected, label):
    issues = []
    akeys = [(x["story"], x["citation_id"]) for x in actual["citations"]]
    ekeys = [(x["story"], x["citation_id"]) for x in expected["citations"]]
    if akeys != ekeys:
        issues.append({"view": label, "code": "CITATION_SET_OR_ORDER_CHANGED",
                       "expected": ekeys, "actual": akeys})
    amap = {(x["story"], x["citation_id"]): x for x in actual["citations"]}
    for e in expected["citations"]:
        a = amap.get((e["story"], e["citation_id"]))
        if a is not None:
            for field in ("json_sha256", "display"):
                if a[field] != e[field]:
                    issues.append({"view": label, "code": "CITATION_VALUE_CHANGED",
                                   "citation_id": e["citation_id"], "field": field,
                                   "expected": e[field], "actual": a[field]})
    if len(actual["bibliography"]) != 1:
        issues.append({"view": label, "code": "BIBLIOGRAPHY_FIELD_COUNT_CHANGED",
                       "expected": 1, "actual": len(actual["bibliography"])})
    else:
        a, e = actual["bibliography"][0], expected["bibliography"][0]
        for field in ("story", "metadata"):
            if a[field] != e[field]:
                issues.append({"view": label, "code": "BIBLIOGRAPHY_METADATA_CHANGED", "field": field})
        if len(a["rows"]) != len(e["rows"]):
            issues.append({"view": label, "code": "BIBLIOGRAPHY_ROW_COUNT_CHANGED",
                           "expected": len(e["rows"]), "actual": len(a["rows"])})
        for i, (left, right) in enumerate(zip(a["rows"], e["rows"])):
            if left != right:
                issues.append({"view": label, "code": "BIBLIOGRAPHY_TEXT_CHANGED", "row": i,
                               "expected": right, "actual": left})
    return issues


def audit_raw_roles(raw_roles, phase, dependencies=None):
    require(phase in ("before", "after"), "UNKNOWN_PHASE")
    require(set(raw_roles) == set(ROLES), "THREE_ROLES_REQUIRED")
    contract, helper, projector = dependencies or load_dependencies()
    issues, views = [], {}
    for role in ROLES:
        # 修订稿两个视图都核，拒绝视图须保留独有的2014脚注。
        projections = (("accepted", True, "tracked"), ("rejected", False, "rejected")) \
            if role == "tracked" else (("stored", None, role),)
        for suffix, projection, expected_role in projections:
            label = role + ":" + suffix
            try:
                current = snapshot(raw_roles[role], projection, helper, projector)
                expected = expected_view(contract, expected_role, phase)
                issues.extend(compare_view(current, expected, label))
                views[label] = {
                    "citation_count": len(current["citations"]),
                    "bibliography_count": len(current["bibliography"]),
                    "bibliography_rows": [len(x["rows"]) for x in current["bibliography"]],
                    "snapshot_sha256": helper.digest(current),
                }
            except (AuditError, AssertionError, ValueError, ET.XMLSyntaxError) as error:
                issues.append({"view": label, "code": "INVALID_REFERENCE_STRUCTURE", "error": str(error)})
    return {"phase": phase, "passed": not issues, "issues": issues, "views": views}


def audit_manifest(manifest, phase):
    require(manifest.get("schema") == "cma-c3-docx-delta-inputs-v1", "MANIFEST_SCHEMA")
    dependencies = load_dependencies()
    require(manifest.get("contract") == pin(CONTRACT), "MANIFEST_CONTRACT_MISMATCH")
    phases = ("before",) if phase == "baseline" else ("before", "after")
    results = []
    for name in phases:
        refs = manifest.get(name, {})
        require(set(refs) == set(ROLES), "THREE_ROLES_REQUIRED: " + name)
        results.append(audit_raw_roles({r: read_ref(refs[r]) for r in ROLES}, name, dependencies))
    # 取证期间发生的文件变化不得当成稳定最终稿。
    for name in phases:
        for ref in manifest[name].values():
            read_ref(ref)
    passed = all(x["passed"] for x in results)
    return {
        "schema": "cma-c3-reference-delta-audit-v1", "at": datetime.now(timezone.utc).isoformat(),
        "phase": phase, "status": ("BASELINE_PASS" if phase == "baseline" else "REFERENCE_DELTA_PASS")
            if passed else "REFERENCE_CHECK_FAILED", "passed": passed,
        "reference_delta_complete": passed and phase == "delta", "results": results,
        "contract": pin(CONTRACT), "implementation": pin(Path(__file__)),
        "dependencies": {k: dependencies[0][k] for k in ("implementation", "projector")},
        "inputs": manifest, "native_refresh_proven": False, "library_cas_proven": False,
        "non_reference_content_checked": False, "revision_history_checked": False,
        "word_calls": 0, "docx_writes": 0, "metadata_writes": 0, "shared_writes": 0,
        "claim_limit": "只证明固定文件的引用差异；真实Refresh、库事务、全文/格式/修订历史须由原执行回执及既有验收单独证明。",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--phase", choices=("baseline", "delta"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = args.manifest.read_bytes()
    require(sha(raw) == args.manifest_sha256, "MANIFEST_SHA_MISMATCH")
    result = audit_manifest(json.loads(raw), args.phase)
    require(args.manifest.read_bytes() == raw, "MANIFEST_CHANGED_DURING_AUDIT")
    result["manifest"] = pin(args.manifest)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"result": pin(args.output), "status": result["status"],
                      "reference_delta_complete": result["reference_delta_complete"],
                      "native_refresh_proven": False}, ensure_ascii=False))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
