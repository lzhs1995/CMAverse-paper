"""合成已核验的表格历史与PAGE候选，固定离线三稿；不调用Word或改现役合同。"""

from collections import Counter
from copy import copy, deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
from zipfile import ZipFile

from lxml import etree as ET

E = Path(__file__).resolve().parent
N = E.parent
C = N / 'v3h_cumulative_format_20261024_v2'
OUT = E / 'combined_table_page_candidate_v1'
SOURCE = C / 'CMAverse_V3h_minimal_format_cumulative_tracked.docx'
ACCEPTED = C / 'CMAverse_V3h_minimal_format_accept_all_validation.docx'
REJECTED = C / 'CMAverse_V3h_minimal_format_reject_all_validation.docx'
TABLE = E / 'table_history_candidate_v1/CMAverse_V3h_table_history_context_candidate.docx'
PAGE = E / 'f2_page_field_candidate_v1/CMAverse_V3h_page_field_tracked_candidate.docx'
TABLE_RESULT = TABLE.parent / 'RESULT.json'
PAGE_RESULT = PAGE.parent / 'RESULT.json'
PROJECTION = N / 'scripts/v3h_revision_projection_v2.py'
CAPACITY = E / 'disk_pressure_20261027_v2/apfs_private_space_v1/apfs_private_space.py'
PINS = {
    SOURCE: 'a623676e8892c37d4053cac583a7821f0fccd0b0eb54470000a724534f603e8f',
    ACCEPTED: '818a75103682bdc2c4d23ab2aec4c850fcc938e43cb26eb55d92b89b610fb1d3',
    REJECTED: '5ec277a8b96ff67a311d0bf392b96c080e36703a2f776806c0df7f7d59ddb979',
    TABLE: 'b968d992b80f29406e64a4a32aa7b551e9f304108031804d2b63a9a413226868',
    PAGE: '588f4d37f557321d87f86131648c19f5c1d20ea55c4a282ae0cd36a640bbba4e',
    TABLE_RESULT: '35d1d479b393c3a3366d35ae9da982905db6688ea8c28de2f8fb9f80fc9a6169',
    PAGE_RESULT: 'de885e114099c2a8f83fd3cd2e352ece8c596593d27094b7ff9192b486c5c7da',
    PROJECTION: '7f6ce94d56088f487729b5e2fe29e167b575ac2a1bac9462cfe378388fe7971b',
    CAPACITY: 'f3962a6fa17158cb326c14ffd51d168e55990e6eefe2d5e326c4bb71a84ea537',
    E / 'MAINTAINER_V127_READBACK.json': '7fee3f474225f4ac1bede3830fe9b3b4277212f13851d3a933be537bceec3893',
}
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
STORY = re.compile(r'^word/(document|footnotes|endnotes|header\d*|footer\d*)\.xml$')


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def package(path):
    with ZipFile(path) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert archive.testzip() is None
        return {name: archive.read(name) for name in archive.namelist()}


def write_zip(template, path, replacements):
    with ZipFile(template) as source, ZipFile(path, 'x') as output:
        output.comment = source.comment
        for info in source.infolist():
            output.writestr(copy(info), replacements.get(info.filename, source.read(info.filename)))
    os.chmod(path, 0o600)
    return pin(path)


def json_new(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8') as stream:
        os.fchmod(stream.fileno(), 0o600)
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(path)


def clean_key(node, projection):
    root = deepcopy(node)
    for item in list(root.iter(W + 'trPr')):
        if not item.attrib and not len(item) and not (item.text or item.tail):
            item.getparent().remove(item)
    return projection.tree_key(root)


def main():
    refs = []
    for path, expected in PINS.items():
        ref = pin(path)
        assert ref['sha256'] == expected, path
        refs.append(ref)
    capacity = load_module('cma_combined_capacity', CAPACITY).capacity(E)
    assert capacity['reserve_20_gib_met'], ('SPACE_MANAGEMENT_REQUIRED_FIRST', capacity)
    OUT.mkdir(mode=0o700, exist_ok=False)
    now = datetime.now(timezone.utc).isoformat()
    json_new('INTENT.json', {'at': now, 'inputs': refs, 'implementation': pin(Path(__file__)),
             'operation': 'OFFLINE_COMBINE_EXISTING_TWO_DISJOINT_CANDIDATES', 'capacity_before': capacity,
             'native_word_calls': 0, 'new_run_authorized': False, 'shared_writes': 0,
             'review_mode': 'solo_self_review'})
    print('阶段：合并固定候选，核对ZIP成员及修订ID。', flush=True)
    projection = load_module('cma_combined_projection', PROJECTION)
    original, table, page = (package(p) for p in (SOURCE, TABLE, PAGE))
    accepted, rejected = (package(p) for p in (ACCEPTED, REJECTED))
    assert list(original) == list(table) == list(page) == list(accepted) == list(rejected)
    assert [n for n in original if original[n] != table[n]] == ['word/document.xml']
    assert [n for n in original if original[n] != page[n]] == ['word/footer2.xml']
    merged = {**original, 'word/document.xml': table['word/document.xml'],
              'word/footer2.xml': page['word/footer2.xml']}
    table_result = json.loads(TABLE_RESULT.read_bytes())
    page_result = json.loads(PAGE_RESULT.read_bytes())
    table_ids = {str(x['revision_id']) for x in table_result['added_records']}
    page_ids = {str(x) for x in page_result['new_revision_ids'].values()}
    assert len(table_ids) == 33 and page_ids == {'100663', '100664'} and not table_ids & page_ids
    stories = [n for n in merged if STORY.fullmatch(n)]
    original_ids, merged_ids, original_counts, merged_counts = set(), set(), Counter(), Counter()
    reversal = []
    for name in stories:
        a, b = (ET.fromstring(data[name]) for data in (original, merged))
        projection.validate_revision_shapes(b)
        old = {x.get(W + 'id'): x for x in a.iter() if x.tag in projection.REVISION_TAGS}
        new = {x.get(W + 'id'): x for x in b.iter() if x.tag in projection.REVISION_TAGS}
        assert not original_ids & old.keys() and not merged_ids & new.keys()
        original_ids.update(old); merged_ids.update(new)
        original_counts.update(ET.QName(x).localname for x in old.values())
        merged_counts.update(ET.QName(x).localname for x in new.values())
        assert old.keys() <= new.keys()
        assert all(projection.tree_key(x) == projection.tree_key(new[rid]) for rid, x in old.items())
        extra = new.keys() - old.keys()
        assert extra == (table_ids if name == 'word/document.xml' else
                         page_ids if name == 'word/footer2.xml' else set())
        restored = deepcopy(b)
        for item in list(restored.iter()):
            if item.tag not in projection.REVISION_TAGS or item.get(W + 'id') not in extra:
                continue
            parent = item.getparent()
            if item.tag == W + 'ins':
                parent.remove(item)
            else:
                assert item.tag in projection.PROPERTY_CHANGES and len(item) == 1
                parent.getparent().replace(parent, deepcopy(item[0]))
        if name == 'word/document.xml':
            tables = restored.findall(W + 'body/' + W + 'tbl')
            for row in table_result['created_empty_row_property_containers']:
                parent = tables[row['table_index']].findall(W + 'tr')[row['row_index']]
                prop = parent.find(W + row['prop'])
                assert not prop.attrib and not len(prop) and not (prop.text or prop.tail)
                parent.remove(prop)
        assert projection.tree_key(restored) == projection.tree_key(a), ('LOCAL_REVERSAL_FAILED', name)
        reversal.append({'story': name, 'full_original_xml_restored': True, 'removed_new_revisions': len(extra)})
    assert len(original_ids) == 626 and len(merged_ids) == 661
    assert merged_ids - original_ids == table_ids | page_ids
    # 新接受预期以原固定接受稿为底，只替换明确F2页脚；拒绝预期逐字节沿用原拒绝稿。
    f2_root = ET.fromstring(page['word/footer2.xml'])
    f2_accepted = projection.resolve(f2_root, True)
    assert projection.tree_key(projection.resolve(f2_root, False)) == projection.tree_key(ET.fromstring(rejected['word/footer2.xml']))
    accepted_footer = ET.tostring(f2_accepted, encoding='UTF-8', xml_declaration=True, standalone=True)
    expected = {'accepted': {**accepted, 'word/footer2.xml': accepted_footer}, 'rejected': rejected}
    comparisons = []
    print('阶段：核对全部9个story的接受/拒绝预期，保留原表格几何与正文。', flush=True)
    for view, take_new in [('accepted', True), ('rejected', False)]:
        for name in stories:
            actual = projection.resolve(ET.fromstring(merged[name]), take_new)
            target = ET.fromstring(expected[view][name])
            key = clean_key(actual, projection)
            assert key == clean_key(target, projection), ('PROJECTED_VIEW_MISMATCH', name, view)
            assert not projection.revisions(actual) and not projection.revisions(target)
            comparisons.append({'story': name, 'view': view, 'full_xml_matches': True,
                'comparison_sha256': hashlib.sha256(json.dumps(key, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()})
    outputs = {
        'tracked': write_zip(SOURCE, OUT / 'CMAverse_V3h_table_history_page_tracked_candidate.docx',
                             {n: merged[n] for n in ['word/document.xml', 'word/footer2.xml']}),
        'accepted': write_zip(ACCEPTED, OUT / 'CMAverse_V3h_table_history_page_offline_accepted_expected.docx',
                              {'word/footer2.xml': accepted_footer}),
    }
    rejected_path = OUT / 'CMAverse_V3h_table_history_page_offline_rejected_expected.docx'
    with rejected_path.open('xb') as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write(REJECTED.read_bytes())
    outputs['rejected'] = pin(rejected_path)
    assert outputs['rejected']['sha256'] == PINS[REJECTED]
    for path, expected_sha in PINS.items():
        assert pin(path)['sha256'] == expected_sha
    report = {'schema': 'cma-combined-table-history-page-offline-triad-v1', 'at': now,
        'state': 'OFFLINE_COMBINED_NATIVE_UNTESTED', 'inputs': refs,
        'implementation': pin(Path(__file__)), 'outputs': outputs,
        'changed_tracked_members': ['word/document.xml', 'word/footer2.xml'],
        'unchanged_tracked_member_payloads': 25,
        'original_revisions': dict(original_counts), 'combined_revisions': dict(merged_counts),
        'original_revision_count': 626, 'combined_revision_count': 661,
        'added_table_history_revision_ids': sorted(map(int, table_ids)),
        'added_page_revision_ids': sorted(map(int, page_ids)),
        'added_revision_ids_disjoint': True, 'all_original_revision_nodes_preserved': True,
        'reverse_added_only': reversal, 'full_story_view_comparisons': comparisons,
        'accepted_delta_from_prior_expected': 'Only default footer2.xml: centered PAGE, both first-line units zero, 9pt inherited.',
        'rejected_expected_identical_to_prior': True,
        'validation_copies_track_revisions_setting': 'Retained from original validation templates; zero revision nodes is checked separately. Not final native clean delivery.',
        'page_cache': '', 'native_pagination_proven': False, 'vertical_page_layout_changed': False,
        'current_word_job_changed': False, 'new_word_run': False, 'statistics_execution': False,
        'shared_writes': 0, 'final_paper_acceptance': False, 'review_mode': 'solo_self_review'}
    result = json_new('RESULT.json', report)
    print(json.dumps({'result': result, 'outputs': outputs, 'revision_count': 661,
                      'story_view_comparisons': len(comparisons), 'native_execution': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
