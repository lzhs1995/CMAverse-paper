"""用冻结真稿的内存变异验证C3验收；不改真实DOCX或调用应用。"""

from copy import deepcopy
import io
import json
from zipfile import ZipFile, ZIP_DEFLATED
import unittest

from lxml import etree as ET

import audit_c3_reference_delta_20261028 as audit


W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
CHANGES = (
    ("Journal of the Royal Statistical Society. Series B, Statistical methodology",
     "Journal of the Royal Statistical Society Series B: Statistical Methodology", 4, 3, "LD33NKPV"),
    ("Epidemiology (Cambridge, Mass.)", "Epidemiology", 2, 1, "MEQZDXNW"),
)


def rewrite(raw, transform):
    out = io.BytesIO()
    with ZipFile(io.BytesIO(raw)) as source, ZipFile(out, "w", ZIP_DEFLATED) as target:
        for name in source.namelist():
            original = source.read(name)
            target.writestr(name, transform(name, original) if name.endswith(".xml") else original)
    return out.getvalue()


def replace_literal(raw, old, new, required_hits):
    hits = 0
    def change(_name, value):
        nonlocal hits
        hits += value.count(old.encode())
        return value.replace(old.encode(), new.encode())
    changed = rewrite(raw, change)
    if hits != required_hits:
        raise AssertionError((old, hits, required_hits))
    return changed


def instruction_groups(root):
    """测试变异按复杂域合并指令碎片，不能把单个run当完整JSON。"""
    stack, groups = [], []
    for node in root.iter():
        if node.tag == W + "fldChar":
            kind = node.get(W + "fldCharType")
            if kind == "begin":
                stack.append([])
            elif kind == "separate":
                if not stack:
                    raise AssertionError("orphan field separator")
                groups.append(stack[-1])
            elif kind == "end":
                if not stack:
                    raise AssertionError("orphan field end")
                stack.pop()
        elif node.tag == W + "instrText" and stack:
            stack[-1].append(node)
    if stack:
        raise AssertionError("unclosed test source field")
    return groups


def write_instruction(nodes, text):
    nodes[0].text = text
    for node in nodes[1:]:
        node.text = ""


def replace_instruction(raw, old, new, required_hits, item_key):
    hits = 0
    def change(_name, value):
        nonlocal hits
        tree = ET.fromstring(value)
        for nodes in instruction_groups(tree):
            text = "".join(n.text or "" for n in nodes)
            if "CSL_CITATION" not in text or item_key not in text:
                continue
            prefix, payload = text.split("CSL_CITATION", 1)
            data = json.loads(payload)
            for item in data["citationItems"]:
                keys = {uri.rstrip("/").rsplit("/", 1)[-1] for uri in item.get("uris", [])}
                if item_key in keys:
                    if item["itemData"]["container-title"] != old:
                        raise AssertionError("unexpected journal before mutation")
                    item["itemData"]["container-title"] = new
                    hits += 1
            write_instruction(nodes, prefix + "CSL_CITATION " + json.dumps(data, ensure_ascii=False))
        return ET.tostring(tree, xml_declaration=True, encoding="UTF-8", standalone=True)
    changed = rewrite(raw, change)
    if hits != required_hits:
        raise AssertionError((old, hits, required_hits))
    return changed


def replace_paragraph(raw, old, new):
    hits = 0
    def change(_name, value):
        nonlocal hits
        tree = ET.fromstring(value)
        for paragraph in tree.iter(W + "p"):
            nodes = list(paragraph.iter(W + "t"))
            if "".join(n.text or "" for n in nodes) == old:
                hits += 1
                nodes[0].text = new
                for node in nodes[1:]:
                    node.text = ""
        return ET.tostring(tree, xml_declaration=True, encoding="UTF-8", standalone=True)
    changed = rewrite(raw, change)
    if hits != 1:
        raise AssertionError(("paragraph_mutation_count", hits))
    return changed


class C3ReferenceDeltaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.deps = audit.load_dependencies()
        cls.contract = cls.deps[0]
        cls.before = {r: audit.read_ref(cls.contract["roles"][r]["document"]) for r in audit.ROLES}
        cls.correct = {}
        for role, raw in cls.before.items():
            for old, new, total, _fields, _key in CHANGES:
                raw = replace_literal(raw, old, new, total)
            cls.correct[role] = raw

    def result(self, raw=None, phase="after"):
        return audit.audit_raw_roles(raw or self.correct, phase, self.deps)

    def reject(self, raw, code=None, view=None):
        result = self.result(raw)
        self.assertFalse(result["passed"])
        if code:
            self.assertTrue(any(i["code"] == code and (view is None or i["view"] == view)
                                for i in result["issues"]), result["issues"])

    def test_original_three_documents_and_both_tracked_views_match_baseline(self):
        result = self.result(self.before, "before")
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual({k: v["citation_count"] for k, v in result["views"].items()}, {
            "tracked:accepted": 22, "tracked:rejected": 23,
            "accepted:stored": 22, "rejected:stored": 23})

    def test_only_two_journal_deltas_pass_in_all_four_views(self):
        result = self.result()
        self.assertTrue(result["passed"], result["issues"])
        self.assertEqual(len(result["views"]), 4)

    def test_unchanged_documents_do_not_count_as_refresh(self):
        self.reject(self.before, "CITATION_VALUE_CHANGED")

    def test_rendered_bibliography_only_is_rejected(self):
        changed = dict(self.correct)
        for old, new, _total, fields, key in CHANGES:
            changed["accepted"] = replace_instruction(changed["accepted"], new, old, fields, key)
        self.reject(changed, "CITATION_VALUE_CHANGED", "accepted:stored")

    def test_live_field_only_with_stale_bibliography_is_rejected(self):
        changed = dict(self.correct)
        changed["accepted"] = self.before["accepted"]
        for old, new, _total, fields, key in CHANGES:
            changed["accepted"] = replace_instruction(changed["accepted"], old, new, fields, key)
        self.reject(changed, "BIBLIOGRAPHY_TEXT_CHANGED", "accepted:stored")

    def test_non_target_citation_metadata_change_is_rejected(self):
        target_id = self.contract["roles"]["accepted"]["unaffected_citation_fields"][0]["citation_id"]
        hits = 0
        def change(_name, raw):
            nonlocal hits
            root = ET.fromstring(raw)
            for nodes in instruction_groups(root):
                text = "".join(n.text or "" for n in nodes)
                if "CSL_CITATION" in text and target_id in text:
                    prefix, data = text.split("CSL_CITATION", 1)
                    obj = json.loads(data.strip())
                    obj["citationItems"][0]["itemData"]["DOI"] = "C3_NEGATIVE_CONTROL"
                    write_instruction(nodes, prefix + "CSL_CITATION " + json.dumps(obj, ensure_ascii=False))
                    hits += 1
            return ET.tostring(root)
        changed = dict(self.correct)
        changed["accepted"] = rewrite(changed["accepted"], change)
        self.assertEqual(hits, 1)
        self.reject(changed, "CITATION_VALUE_CHANGED", "accepted:stored")

    def test_rejected_only_historical_footnote_is_checked_inside_tracked(self):
        changed = dict(self.correct)
        changed["tracked"] = replace_literal(changed["tracked"], "hE2u8elZ", "C3_LOST_HISTORY", 1)
        self.reject(changed, "CITATION_SET_OR_ORDER_CHANGED", "tracked:rejected")

    def test_both_target_bibliography_years_are_preserved(self):
        for target in self.contract["roles"]["accepted"]["bibliography"]["targets"]:
            with self.subTest(item=target["item_key"]):
                before = target["expected_after"]
                year = target["rendered_year_must_remain"]
                after = before.replace(", " + year + ". ", ", 1900. ", 1)
                self.assertNotEqual(before, after)
                changed = dict(self.correct)
                changed["accepted"] = replace_paragraph(changed["accepted"], before, after)
                self.reject(changed, "BIBLIOGRAPHY_TEXT_CHANGED", "accepted:stored")

    def test_non_target_bibliography_row_is_preserved(self):
        b = self.contract["roles"]["accepted"]["bibliography"]
        targets = {x["bibliography_row_index"] for x in b["targets"]}
        before = next(x["text"] for i, x in enumerate(b["expected_rows"]) if i not in targets)
        changed = dict(self.correct)
        changed["accepted"] = replace_paragraph(changed["accepted"], before, before + " C3_NEGATIVE")
        self.reject(changed, "BIBLIOGRAPHY_TEXT_CHANGED", "accepted:stored")

    def test_lost_live_zotero_binding_is_rejected(self):
        changed = dict(self.correct)
        changed["accepted"] = replace_literal(changed["accepted"],
            "ADDIN ZOTERO_ITEM CSL_CITATION", "ADDIN C3_LOST_BINDING", 22)
        self.reject(changed, "CITATION_SET_OR_ORDER_CHANGED", "accepted:stored")

    def test_split_instruction_and_json_whitespace_preserve_semantics(self):
        hits = 0
        def change(_name, raw):
            nonlocal hits
            root = ET.fromstring(raw)
            for nodes in instruction_groups(root):
                text = "".join(n.text or "" for n in nodes)
                if "CSL_CITATION" in text:
                    prefix, data = text.split("CSL_CITATION", 1)
                    text = prefix + "CSL_CITATION " + json.dumps(json.loads(data), ensure_ascii=False, indent=2)
                    node = nodes[0]
                    second = deepcopy(node)
                    split = len(text) // 2
                    write_instruction(nodes, "")
                    node.text, second.text = text[:split], text[split:]
                    node.addnext(second)
                    hits += 1
            return ET.tostring(root)
        changed = dict(self.correct)
        changed["accepted"] = rewrite(changed["accepted"], change)
        self.assertEqual(hits, 22)
        result = self.result(changed)
        self.assertTrue(result["passed"], result["issues"])

    @classmethod
    def tearDownClass(cls):
        # 测试结束仍逐字节核原三稿，所有变异仅在内存。
        for role in audit.ROLES:
            if audit.read_ref(cls.contract["roles"][role]["document"]) != cls.before[role]:
                raise AssertionError("REAL_SOURCE_CHANGED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
