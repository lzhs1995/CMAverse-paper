"""用独立固定XSLT核验合并三稿；不导入合成脚本，不调用Word。"""

from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

from lxml import etree as ET

E = Path(__file__).resolve().parent
N = E.parent
OUT = E / 'combined_table_page_candidate_v1'
VERIFIER = N / 'scripts/verify_v3h_cumulative_independent_20261024.py'
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def sha_value(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def key(node):
    if node is None:
        return None
    return [node.tag, sorted(node.attrib.items()), node.text or '', node.tail or '', [key(x) for x in node]]


def clean_root(node):
    root = deepcopy(node)
    for item in list(root.iter(W + 'trPr')):
        if not item.attrib and not len(item) and not (item.text or item.tail):
            item.getparent().remove(item)
    return root


def geometry(root):
    # 记录全表格属性、网格、逐行和逐格属性；不只核发生过问题的5张表。
    tables = []
    for table in root.iter(W + 'tbl'):
        rows = [{'properties': key(row.find(W + 'trPr')),
                 'cells': [key(cell.find(W + 'tcPr')) for cell in row.findall(W + 'tc')]}
                for row in table.findall(W + 'tr')]
        tables.append({'properties': key(table.find(W + 'tblPr')),
                       'grid': key(table.find(W + 'tblGrid')), 'rows': rows})
    return {'tables': tables, 'sections': [key(x) for x in root.iter(W + 'sectPr')]}


def write(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(path)


def main():
    result_path = OUT / 'RESULT.json'
    result = json.loads(result_path.read_bytes())
    for ref in result['inputs'] + [result['implementation']] + list(result['outputs'].values()):
        assert pin(Path(ref['path'])) == ref
    assert pin(VERIFIER)['sha256'] == 'a8f252af146e2e34be28f7215ee3dd803bd701a7fa7fea85220b4326f2f03a18'
    spec = importlib.util.spec_from_file_location('cma_combined_independent_xslt', VERIFIER)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    source, prior_accepted, prior_rejected, table, page = [Path(r['path']) for r in result['inputs'][:5]]
    old, table_parts, page_parts = [verifier.read_package(p) for p in (source, table, page)]
    triad = {name: verifier.read_package(Path(ref['path'])) for name, ref in result['outputs'].items()}
    prior = {'accepted': verifier.read_package(prior_accepted), 'rejected': verifier.read_package(prior_rejected)}
    tracked = triad['tracked']
    assert list(old) == list(tracked)
    assert [n for n in old if old[n] != tracked[n]] == ['word/document.xml', 'word/footer2.xml']
    assert tracked['word/document.xml'] == table_parts['word/document.xml']
    assert tracked['word/footer2.xml'] == page_parts['word/footer2.xml']
    assert [n for n in prior['accepted'] if prior['accepted'][n] != triad['accepted'][n]] == ['word/footer2.xml']
    assert pin(Path(result['outputs']['rejected']['path']))['sha256'] == pin(prior_rejected)['sha256']
    stories = sorted(n for n in old if verifier.STORY.fullmatch(n))
    originals, combined, preservation = {}, {}, []
    print('独立核验：逐条检查原修订与新增修订ID。', flush=True)
    for name in stories:
        before, after = (ET.fromstring(p[name]) for p in (old, tracked))
        assert not verifier.shapes(after), name
        old_nodes, new_nodes = verifier.revision_nodes(before), verifier.revision_nodes(after)
        for node in old_nodes:
            rid = node.get(W + 'id')
            assert rid not in originals
            originals[rid] = (name, key(node))
        for node in new_nodes:
            rid = node.get(W + 'id')
            assert rid not in combined
            combined[rid] = (name, key(node))
        preservation.append({'story': name, 'original': len(old_nodes), 'combined': len(new_nodes), 'shape_errors': 0})
    assert len(originals) == 626 and len(combined) == 661
    assert all(combined[rid] == value for rid, value in originals.items())
    expected_new = {str(x) for x in result['added_table_history_revision_ids'] + result['added_page_revision_ids']}
    assert len(expected_new) == 35 and combined.keys() - originals.keys() == expected_new
    detail, comparisons, totals = {}, [], {}
    for view, accept in [('accepted', True), ('rejected', False)]:
        print('独立核验：' + view + ' 全部story、表格几何、正文及活域。', flush=True)
        detail[view] = {}
        totals[view] = Counter()
        for name in stories:
            projected = verifier.project(ET.fromstring(tracked[name]), accept)
            target = ET.fromstring(triad[view][name])
            before = ET.fromstring(prior[view][name])
            assert not verifier.revision_nodes(projected) and not verifier.revision_nodes(target)
            a, b = clean_root(projected), clean_root(target)
            assert key(a) == key(b), (view, name, 'FULL_XML_DIFFERENCE')
            # F2只影响接受视图的默认页脚；其余story与原批准预期完全相同。
            if view == 'rejected' or name != 'word/footer2.xml':
                assert key(b) == key(clean_root(before)), (view, name, 'PRIOR_EXPECTED_VIEW_CHANGED')
            field_actual, field_target = verifier.field_audit(projected), verifier.field_audit(target)
            assert not field_actual['errors'] and field_actual == field_target
            prior_fields = verifier.field_audit(before)
            if view == 'accepted' and name == 'word/footer2.xml':
                assert not prior_fields['fields'] and field_target['count'] == 1
                only = field_target['fields'][0]
                assert only['kind'] == 'other' and only['display'] == '' and only['separated']
                assert only['code_sha256'] == hashlib.sha256(b' PAGE ').hexdigest()
                paragraphs = list(target.iter(W + 'p'))
                assert len(paragraphs) == 1
                assert verifier.indent(ET.fromstring(triad[view]['word/styles.xml']), paragraphs[0]) == {'firstLine': '0', 'firstLineChars': '0'}
            else:
                assert field_target == prior_fields, (view, name, 'EXISTING_FIELD_CHANGED')
            shape = geometry(b)
            assert geometry(a) == shape
            assert geometry(clean_root(before)) == shape
            content = [''.join(p.itertext(W + 't')) for p in target.iter(W + 'p')]
            anchor_names = {'drawing', 'object', 'oMath', 'oMathPara', 'footnoteReference', 'endnoteReference'}
            anchors = [key(x) for x in target.iter() if ET.QName(x).localname in anchor_names]
            detail[view][name] = {'geometry': shape, 'fields': field_target,
                                  'paragraph_text': content, 'anchors': anchors,
                                  'full_xml_key_sha256': sha_value(key(b))}
            counts = {'tables': len(shape['tables']),
                      'rows': sum(len(t['rows']) for t in shape['tables']),
                      'cells': sum(len(r['cells']) for t in shape['tables'] for r in t['rows']),
                      'sections': len(shape['sections']), 'paragraphs': len(content),
                      'fields': field_target['count'], 'revision_residue': 0}
            totals[view].update(counts)
            comparisons.append({'story': name, 'view': view, 'all_pass': True,
                                'counts': counts, 'full_xml_key_sha256': sha_value(key(b)),
                                'geometry_sha256': sha_value(shape), 'fields_sha256': sha_value(field_target)})
        # 非story XML/关系、样式和图像亦保持母版；两份清稿全包不得残留修订。
        for name, raw in triad[view].items():
            if not verifier.STORY.fullmatch(name):
                assert raw == old[name], (view, name, 'PROTECTED_NONSTORY_CHANGED')
            if name.endswith(('.xml', '.rels')):
                assert not verifier.revision_nodes(ET.fromstring(raw)), (view, name, 'RESIDUAL_REVISION')
    assert len(comparisons) == 18
    detail_ref = write('SOURCE_BOUND_VIEW_CONTRACT.json', {
        'schema': 'cma-combined-offline-view-contract-evidence-v1', 'outputs': result['outputs'],
        'comparison': 'Full XML, normalizing only truly empty trPr created by unchanged row history.',
        'views': detail, 'native_page_cache_computed': False, 'scientific_estimates_changed': False})
    for ref in result['inputs'] + [result['implementation']] + list(result['outputs'].values()):
        assert pin(Path(ref['path'])) == ref
    report = {'schema': 'cma-combined-table-page-independent-readback-v1',
        'at': datetime.now(timezone.utc).isoformat(), 'generation_result': pin(result_path),
        'outputs': result['outputs'], 'independent_projector': pin(VERIFIER),
        'verification_script': pin(Path(__file__)), 'source_bound_view_contract': detail_ref,
        'original_revisions_preserved': 626, 'new_table_history_revisions': 33,
        'new_page_revisions': 2, 'combined_revision_count': 661,
        'global_ids_unique': True, 'revision_preservation': preservation,
        'full_story_view_comparisons': comparisons, 'coverage_totals': dict(totals),
        'new_page_field_in_accepted_only': True, 'old_live_fields_unchanged': True,
        'rejected_copy_exact_prior_sha': True, 'unchanged_tracked_member_payloads': 25,
        'zero_revision_nodes_in_both_expected_copies': True, 'all_pass': True,
        'native_word_execution': False, 'native_table_fix_proven': False,
        'native_pagination_proven': False, 'source_job_replaced': False,
        'shared_writes': 0, 'new_run_authorized': False, 'final_paper_acceptance': False,
        'review_mode': 'solo_self_review'}
    output = write('INDEPENDENT_READBACK.json', report)
    print(json.dumps({'result': output, 'coverage': dict(totals), 'all_pass': True,
                      'native_execution': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
