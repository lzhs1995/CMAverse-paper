#!/usr/bin/env python3
"""独立离线验收累计修订；不导入生成器、旧合同模块或共享 Word 代码。"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import traceback
from zipfile import ZipFile

from lxml import etree as E

ROOT = Path('/Users/lzhs/Documents/cnm/tasks/01_R_analysis')
N = ROOT / 'handoff/cmaverse-solo-2545-20261023'
C = N / 'v3h_cumulative_format_20261024_v2'
M = N / 'v3h_minimal_format_20261024_v1'
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
STORY = re.compile(r'^word/(document|footnotes|endnotes|header\d*|footer\d*)\.xml$')
PROPS = ('pPr', 'rPr', 'trPr', 'tcPr', 'tblPr', 'sectPr', 'tblGrid')
REVISIONS = set(PROPS[i] + 'Change' for i in range(len(PROPS))) | {'ins', 'del'}
UNSUPPORTED = {'moveFrom', 'moveTo', 'moveFromRangeStart', 'moveFromRangeEnd',
               'moveToRangeStart', 'moveToRangeEnd', 'cellIns', 'cellDel', 'cellMerge',
               'numberingChange', 'customXmlInsRangeStart', 'customXmlInsRangeEnd',
               'customXmlDelRangeStart', 'customXmlDelRangeEnd',
               'customXmlMoveFromRangeStart', 'customXmlMoveFromRangeEnd',
               'customXmlMoveToRangeStart', 'customXmlMoveToRangeEnd'}
EXPECTED_COUNTS = {'ins': 36, 'del': 9, 'rPrChange': 283, 'tcPrChange': 129,
                   'pPrChange': 157, 'trPrChange': 7}
FILES = {
    'mother': (ROOT / 'handoff/cmaverse-codex-solo-20261022/baseline/CMAverse_V3g.docx',
               'ebeec8b75fb6747a4ceb7f672a65f8d64889fa0bca17e32b9b18c110db7aeb91'),
    'old_tracked': (N / 'v3h_offline_v1/CMAverse_V3h_offline_tracked.docx',
                    'b9375c20be8b556765907699dcbcd0f26aeb0e92afde0e9e125350ad87bac66c'),
    'old_accepted': (N / 'v3h_offline_v1/CMAverse_V3h_offline_accepted.docx',
                     'f961f9aadc9516369eeaef26ffcdcf26eba9f3f129bd6a521a3a69ec5a4258c7'),
    'candidate': (M / 'CMAverse_V3h_minimal_format_candidate.docx',
                  '38a9d70f7095d8b063d96e1e95e8bcb41ae7539a35dacc3faa11679c1e6837ab'),
    'tracked': (C / 'CMAverse_V3h_minimal_format_cumulative_tracked.docx',
                'a623676e8892c37d4053cac583a7821f0fccd0b0eb54470000a724534f603e8f'),
    'accepted': (C / 'CMAverse_V3h_minimal_format_accept_all_validation.docx',
                 '818a75103682bdc2c4d23ab2aec4c850fcc938e43cb26eb55d92b89b610fb1d3'),
    'rejected': (C / 'CMAverse_V3h_minimal_format_reject_all_validation.docx',
                 '5ec277a8b96ff67a311d0bf392b96c080e36703a2f776806c0df7f7d59ddb979'),
    'contract': (M / 'SOURCE_CONTRACT.json',
                 '475c3f6e1a92ad7be9b8daf450c112498d837d10ae419b61df60e787f20712e5'),
    'revision_map': (C / 'PROPERTY_REVISION_MAP.json',
                     '30d787bd780854b989c0db0b9f5cbae51db5a91520586d34d2c8404f93e28a0b'),
}


def q(local):
    return '{' + W + '}' + local


def sha(b):
    return hashlib.sha256(b).hexdigest()


def pin(path):
    path = Path(path).resolve()
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': sha(b)}


def write(path, data):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def read_package(path):
    with ZipFile(path) as z:
        require(len(z.namelist()) == len(set(z.namelist())), 'DUPLICATE_ZIP_MEMBER')
        require(z.testzip() is None, 'ZIP_CRC')
        data = {name: z.read(name) for name in z.namelist()}
    # 全部 XML 与关系文件均实际解析，媒体以全成员字节比较覆盖。
    for name, b in data.items():
        if name.endswith(('.xml', '.rels')):
            E.fromstring(b)
    return data


def key(e):
    if e is None:
        return None
    return (e.tag, tuple(sorted(e.attrib.items())), e.text or '', e.tail or '',
            tuple(key(c) for c in e))


def semantic_key(root):
    """仅把同属性相邻纯文字run合并，并去掉确实为空的trPr。"""
    def visit(e):
        items = []
        for child in e:
            if child.tag == q('trPr') and not child.attrib and not len(child) and not (child.text or child.tail):
                continue
            pure = (child.tag == q('r') and len(child) > 0
                    and all(x.tag in {q('rPr'), q('t')} for x in child)
                    and any(x.tag == q('t') for x in child)
                    and not (child.text or child.tail)
                    and all(not (x.tail or '') and set(x.attrib) <= {'{http://www.w3.org/XML/1998/namespace}space'}
                            for x in child if x.tag == q('t')))
            if pure:
                props = (tuple(sorted(child.attrib.items())), tuple(key(x) for x in child if x.tag != q('t')))
                text = ''.join(x.text or '' for x in child if x.tag == q('t'))
                if items and items[-1][0] == '__TEXT_RUN__' and items[-1][1] == props:
                    items[-1] = ('__TEXT_RUN__', props, items[-1][2] + text)
                else:
                    items.append(('__TEXT_RUN__', props, text))
            else:
                items.append(visit(child))
        return (e.tag, tuple(sorted(e.attrib.items())), e.text or '', e.tail or '', tuple(items))
    return visit(root)


def xslt_source(accept):
    # 使用XSLT模板分派，与生成器的原地替换/来源映射算法独立。
    templates = []
    for prop in PROPS:
        if accept:
            templates.append(f'<xsl:template match="w:{prop}Change"/>')
        else:
            templates.append(f'<xsl:template match="w:{prop}[w:{prop}Change]"><xsl:apply-templates select="w:{prop}Change/w:{prop}"/></xsl:template>')
    keep, drop = ('ins', 'del') if accept else ('del', 'ins')
    return (f'''<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:w="{W}">
<xsl:output method="xml" encoding="UTF-8"/>
<xsl:template match="@*|node()"><xsl:copy><xsl:apply-templates select="@*|node()"/></xsl:copy></xsl:template>
<xsl:template match="w:{keep}"><xsl:apply-templates select="node()"/></xsl:template>
<xsl:template match="w:{drop}"/>
<xsl:template match="w:delText"><w:t><xsl:apply-templates select="@*|node()"/></w:t></xsl:template>
<xsl:template match="w:delInstrText"><w:instrText><xsl:apply-templates select="@*|node()"/></w:instrText></xsl:template>
{''.join(templates)}
</xsl:stylesheet>''').encode()


TRANSFORMS = {v: E.XSLT(E.fromstring(xslt_source(v))) for v in (True, False)}


def project(root, accept):
    return TRANSFORMS[accept](root).getroot()


def revision_nodes(root):
    return [e for e in root.iter() if E.QName(e).namespace == W and E.QName(e).localname in REVISIONS]


def shapes(root):
    errors, ids = [], []
    for e in root.iter():
        name = E.QName(e).localname
        if E.QName(e).namespace != W:
            continue
        if name in UNSUPPORTED:
            errors.append('UNSUPPORTED_REVISION')
        if name not in REVISIONS:
            continue
        rid = e.get(q('id'), '')
        ids.append(rid)
        if not rid.isdecimal() or (name != 'tblGridChange' and not all(e.get(q(x)) for x in ('author', 'date'))):
            errors.append('REVISION_METADATA')
        if name in {'ins', 'del'}:
            if e.getparent().tag != q('p') or not len(e) or any(c.tag != q('r') for c in e):
                errors.append('UNSUPPORTED_CONTENT_REVISION_SHAPE')
        else:
            base = q(name[:-6])
            if (e.getparent().tag != base or len(e) != 1 or e[0].tag != base
                    or len(e.getparent().findall(e.tag)) != 1):
                errors.append('PROPERTY_REVISION_SHAPE')
            elif revision_nodes(e[0]):
                errors.append('NESTED_OLD_PROPERTY_REVISION')
    if len(ids) != len(set(ids)):
        errors.append('DUPLICATE_REVISION_ID')
    return errors


def indent(root_styles, p):
    """按docDefaults、默认段落样式、basedOn链和直接属性解析缩进全部单位。"""
    styles = {e.get(q('styleId')): e for e in root_styles.findall(q('style'))}
    default = [s for s in styles.values() if s.get(q('type')) == 'paragraph' and s.get(q('default')) == '1']
    direct = p.find(q('pPr'))
    style_id = direct.find(q('pStyle')).get(q('val')) if direct is not None and direct.find(q('pStyle')) is not None else None
    order = []
    def add(sid, ancestry=()):
        require(sid not in ancestry and sid in styles, 'STYLE_CYCLE_OR_MISSING')
        s = styles[sid]
        parent = s.find(q('basedOn'))
        if parent is not None:
            add(parent.get(q('val')), ancestry + (sid,))
        order.append(s.find(q('pPr')))
    if default:
        add(default[0].get(q('styleId')))
    if style_id:
        add(style_id)
    result = {}
    pr = root_styles.find('w:docDefaults/w:pPrDefault/w:pPr', NS)
    for pr in [pr, *order, direct]:
        if pr is not None:
            ind = pr.find(q('ind'))
            if ind is not None:
                result.update(ind.attrib)
    return {E.QName(k).localname: v for k, v in result.items()}


def field_audit(root):
    stack, results, errors = [], [], []
    for e in root.iter():
        if e.tag == q('fldChar'):
            kind = e.get(q('fldCharType'))
            if kind == 'begin':
                stack.append({'code': '', 'display': '', 'separated': False})
            elif kind == 'separate':
                if not stack or stack[-1]['separated']:
                    errors.append('UNMATCHED_FIELD_SEPARATOR')
                else:
                    stack[-1]['separated'] = True
            elif kind == 'end':
                if not stack:
                    errors.append('UNMATCHED_FIELD_END')
                else:
                    f = stack.pop()
                    code = f.pop('code')
                    f['code_sha256'] = sha(code.encode())
                    f['kind'] = ('zotero_citation' if 'ADDIN ZOTERO_ITEM CSL_CITATION' in code else
                                 'zotero_bibliography' if 'ADDIN ZOTERO_BIBL' in code else 'other')
                    if f['kind'] == 'zotero_citation':
                        try:
                            data = json.loads(code.split('CSL_CITATION', 1)[1].strip())
                            f['citation_id'] = data.get('citationID')
                            if data.get('properties', {}).get('dontUpdate', False):
                                errors.append('CITATION_DONT_UPDATE')
                            if not data.get('citationItems') or not f['citation_id']:
                                errors.append('EMPTY_CITATION')
                        except (ValueError, KeyError):
                            errors.append('CITATION_JSON')
                    results.append(f)
        elif e.tag == q('instrText'):
            if not stack or stack[-1]['separated']:
                errors.append('FIELD_CODE_OUTSIDE_FIELD')
            else:
                stack[-1]['code'] += e.text or ''
        elif e.tag == q('t') and stack and stack[-1]['separated']:
            stack[-1]['display'] += e.text or ''
    if stack:
        errors.append('UNCLOSED_FIELD')
    return {'errors': errors, 'count': len(results), 'kinds': dict(Counter(f['kind'] for f in results)),
            'simple_count': len(list(root.iter(q('fldSimple')))), 'fields': results}


def rewind_and_check(root, original):
    old = {e.get(q('id')): e for e in revision_nodes(original)}
    current = {e.get(q('id')): e for e in revision_nodes(root)}
    errors = []
    if not old.keys() <= current.keys():
        return ['ORIGINAL_REVISION_MISSING']
    for rid, e in old.items():
        if e.tag not in {q('ins'), q('del')} and key(e) != key(current[rid]):
            errors.append('ORIGINAL_OLD_PROPERTY_CHANGED')
    restored = deepcopy(root)
    for e in list(revision_nodes(restored)):
        rid = e.get(q('id'))
        if rid not in old:
            if E.QName(e).localname in {'ins', 'del'} or len(e) != 1:
                errors.append('UNEXPECTED_NEW_CONTENT_REVISION')
                continue
            container = e.getparent()
            container.getparent().replace(container, deepcopy(e[0]))
        elif e.tag not in {q('ins'), q('del')}:
            container = e.getparent()
            container.getparent().replace(container, deepcopy(old[rid].getparent()))
    if key(restored) != key(original):
        errors.append('REWIND_NEW_PROPERTIES_DIFFERS_FROM_OLD_TRACKED')
    return errors


def evaluator(packages):
    old_zip, candidate_zip = packages['old_tracked'], packages['candidate']
    story_names = sorted(n for n in old_zip if STORY.fullmatch(n))
    expected = {n: E.fromstring(candidate_zip[n]) for n in story_names}
    mother = {n: E.fromstring(packages['mother'][n]) for n in story_names}
    old = {n: E.fromstring(old_zip[n]) for n in story_names}
    candidate_styles = E.fromstring(candidate_zip['word/styles.xml'])
    last = expected['word/document.xml'].find(q('body')).findall(q('p'))[311]
    approved_indent = indent(candidate_styles, last)
    require(approved_indent == {'firstLineChars': '0', 'firstLine': '420', 'left': '720', 'hanging': '720'}, 'CANDIDATE_TERMINATOR_INDENT')
    require(not ''.join(last.itertext(q('t'))), 'TERMINATOR_NONEMPTY')
    for k, v in approved_indent.items():
        last.find('w:pPr/w:ind', NS).set(q(k), v)
    expected_keys = {n: key(e) for n, e in expected.items()}
    mother_keys = {n: semantic_key(e) for n, e in mother.items()}
    original_fields = {n: field_audit(e) for n, e in expected.items()}

    def check(data, *, details=False):
        errors, evidence = [], []
        if list(data) != list(old_zip):
            errors.append('ZIP_MEMBERS_CHANGED')
        for n in set(old_zip) & set(data):
            if n != 'word/document.xml' and data[n] != old_zip[n]:
                errors.append('UNEXPECTED_TRACKED_MEMBER_CHANGE:' + n)
        roots = {n: E.fromstring(data[n]) for n in story_names}
        if dict(Counter(E.QName(e).localname for e in revision_nodes(roots['word/document.xml']))) != EXPECTED_COUNTS:
            errors.append('REVISION_COVERAGE')
        for n, r in roots.items():
            shape_errors = shapes(r)
            errors += [n + ':' + x for x in shape_errors]
            if shape_errors:
                continue
            a, b = project(r, True), project(r, False)
            accepted_equal, rejected_equal = key(a) == expected_keys[n], semantic_key(b) == mother_keys[n]
            if not accepted_equal:
                errors.append('ACCEPTED_FULL_XML:' + n)
            if not rejected_equal:
                errors.append('REJECTED_FULL_XML:' + n)
            errors += [n + ':' + x for x in rewind_and_check(r, old[n])]
            fields = field_audit(a)
            errors += [n + ':' + x for x in fields['errors']]
            if fields != original_fields[n]:
                errors.append('FIELD_CONTRACT:' + n)
            if revision_nodes(a) or revision_nodes(b):
                errors.append('PROJECTED_REVISION_RESIDUE:' + n)
            if details:
                evidence.append({'story': n, 'accepted_full_xml_equal': accepted_equal,
                                 'rejected_mother_semantic_equal': rejected_equal,
                                 'paragraphs': len(list(a.iter(q('p')))),
                                 'tables': len(list(a.iter(q('tbl')))),
                                 'revisions': dict(Counter(E.QName(e).localname for e in revision_nodes(r))),
                                 'fields': fields})
        return sorted(set(errors)), evidence
    return check, expected, story_names


def main(out):
    require(not out.exists(), 'OUTPUT_EXISTS_DO_NOT_REPLAY')
    inputs = {k: pin(p) for k, (p, expected) in FILES.items()}
    for k, (_, expected) in FILES.items():
        require(inputs[k]['sha256'] == expected, 'INPUT_CHANGED:' + k)
    out.mkdir(parents=True)
    write(out / 'INTENT.json', {'at': datetime.now(timezone.utc).isoformat(), 'inputs': inputs,
                              'implementation': pin(__file__), 'review_mode': 'solo_self_review',
                              'algorithm': 'independent lxml XSLT projection and whole-tree comparisons',
                              'does_not_import_generator_projection_contract_or_word': True})
    (out / 'independent_accept.xslt').write_bytes(xslt_source(True))
    (out / 'independent_reject.xslt').write_bytes(xslt_source(False))
    print(json.dumps({'stage': 'independent_whole_package_and_story_checks'}), flush=True)
    packages = {k: read_package(p) for k, (p, _) in FILES.items() if p.suffix == '.docx'}
    evaluate, expected, names = evaluator(packages)
    errors, stories = evaluate(packages['tracked'], details=True)
    write(out / 'POSITIVE_CHECKS.json', {'errors': errors, 'stories': stories})
    require(not errors, 'INDEPENDENT_POSITIVE_FAILED:' + repr(errors))

    # 实际验证副本必须逐story等于独立投影；非story成员不得被额外重写。
    view_checks, indent_checks = [], []
    original_styles = E.fromstring(packages['tracked']['word/styles.xml'])
    candidate_styles = E.fromstring(packages['candidate']['word/styles.xml'])
    require(packages['tracked']['word/styles.xml'] == packages['mother']['word/styles.xml'], 'STYLE_MASTER_CHANGED')
    for label, accept in [('accepted', True), ('rejected', False)]:
        data = packages[label]
        require(list(data) == list(packages['tracked']), 'VALIDATION_ZIP_MEMBERS_CHANGED')
        for n in data:
            if n not in names:
                require(data[n] == packages['tracked'][n], 'VALIDATION_NONSTORY_CHANGED:' + n)
        for n in names:
            r = E.fromstring(data[n])
            equal = key(r) == key(project(E.fromstring(packages['tracked'][n]), accept))
            require(equal and not revision_nodes(r), 'SAVED_PROJECTION_DIFFERS:' + label + ':' + n)
            view_checks.append({'view': label, 'story': n, 'full_xml_matches_independent_projection': True, 'no_revisions': True})
    for n in names:
        a = E.fromstring(packages['accepted'][n])
        b = E.fromstring(packages['candidate'][n])
        ap, bp = list(a.iter(q('p'))), list(b.iter(q('p')))
        require(len(ap) == len(bp), 'PARAGRAPH_COUNT')
        for i, (p, source) in enumerate(zip(ap, bp)):
            actual, desired = indent(original_styles, p), indent(candidate_styles, source)
            require(actual == desired, 'RESOLVED_INDENT:' + n + ':' + str(i))
        indent_checks.append({'story': n, 'paragraphs': len(ap), 'all_resolved_indents_equal': True})
    write(out / 'SAVED_VIEWS_AND_INDENTS.json', {'views': view_checks, 'indents': indent_checks,
                                               'p311_firstLine': '420', 'original_styles_byte_identical': True})

    mapping = json.loads(FILES['revision_map'][0].read_text())
    records = mapping['records']
    tracked_root = E.fromstring(packages['tracked']['word/document.xml'])
    old_root = E.fromstring(packages['old_tracked']['word/document.xml'])
    current_ids = {e.get(q('id')): e for e in revision_nodes(tracked_root)}
    original_ids = {e.get(q('id')): e for e in revision_nodes(old_root)}
    inferred_merged = [rid for rid in original_ids if original_ids[rid].tag not in {q('ins'), q('del')}
                       and key(original_ids[rid].getparent()) != key(current_ids[rid].getparent())]
    require(len(records) == 565 and len({r['revision_id'] for r in records}) == 565, 'PROPERTY_MAP_COVERAGE')
    require(len(set(current_ids) - set(original_ids)) == 562 and len(inferred_merged) == 3, 'NEW_MERGED_COUNTS')
    require(set(inferred_merged) == {r['revision_id'] for r in records if r['mode'] == 'MERGED_KEEP_ORIGINAL_OLD_VALUE'}, 'MERGED_MAP')
    require(sum(current_ids[r['revision_id']].tag == q('tcPrChange') for r in records) == 129, 'BORDER_REVISION_COUNT')
    write(out / 'REVISION_PRESERVATION.json', {'original_revision_count': len(original_ids), 'new_revision_count': 562,
                                              'property_operations': 565, 'merged_original_ids': inferred_merged,
                                              'all_original_old_properties_preserved': True,
                                              'whole_tree_rewind_to_old_tracked': True, 'cell_property_revisions': 129})

    print(json.dumps({'stage': 'negative_mutations', 'stories_passed': len(names)}), flush=True)
    fixtures = []
    def negative(name, part, selector, action, required_error):
        changed = dict(packages['tracked'])
        root = E.fromstring(changed[part])
        found = root.xpath(selector, namespaces=NS)
        require(bool(found), 'NEGATIVE_TARGET_MISSING:' + name)
        target = found[0]
        before = E.tostring(target, encoding='unicode')
        after = action(target, root)
        changed[part] = E.tostring(root)
        failures, _ = evaluate(changed)
        require(any(required_error in f for f in failures), 'NEGATIVE_UNDETECTED:' + name + ':' + repr(failures))
        fixtures.append({'name': name, 'source': inputs['tracked'], 'part': part, 'xpath': selector,
                         'before_xml': before, 'after_xml': after, 'mutated_part_sha256': sha(changed[part]),
                         'expected_error_contains': required_error, 'observed_errors': failures, 'detected': True})
    def set_attr(tag, value):
        def change(e, root):
            e.set(q(tag), value)
            return E.tostring(e, encoding='unicode')
        return change
    def remove(e, root):
        e.getparent().remove(e)
        return None
    def text_change(e, root):
        e.text = (e.text or '') + 'NEGATIVE_MUTATION'
        return E.tostring(e, encoding='unicode')
    def add_wrong_old_border(e, root):
        # 原旧属性没有直接边框；只在内存负例里插入一个错误旧边框。
        require(e.find(q('tcBorders')) is None, 'NEGATIVE_OLD_BORDER_ALREADY_PRESENT')
        borders = E.Element(q('tcBorders'))
        E.SubElement(borders, q('top'), {q('val'): 'double', q('sz'): '24', q('color'): 'FF0000'})
        following = {q(x) for x in ('shd', 'noWrap', 'tcMar', 'textDirection', 'tcFitText', 'vAlign', 'hideMark', 'headers')}
        position = next((i for i, child in enumerate(e) if child.tag in following), len(e))
        e.insert(position, borders)
        return E.tostring(e, encoding='unicode')
    negative('old_cell_border_corruption', 'word/document.xml', '//w:tcPrChange/w:tcPr', add_wrong_old_border, 'REJECTED_FULL_XML')
    negative('missing_cell_revision', 'word/document.xml', '//w:tcPrChange', remove, 'REVISION_COVERAGE')
    negative('empty_terminator_firstLine_zero', 'word/document.xml', '/w:document/w:body/w:p[312]/w:pPr/w:ind', set_attr('firstLine', '0'), 'ACCEPTED_FULL_XML')
    duplicate_id = revision_nodes(tracked_root)[1].get(q('id'))
    negative('duplicate_revision_id', 'word/document.xml', '//*[@w:id][self::w:ins or self::w:del or self::w:rPrChange or self::w:pPrChange or self::w:tcPrChange or self::w:trPrChange]', set_attr('id', duplicate_id), 'DUPLICATE_REVISION_ID')
    negative('merged_original_old_value_corruption', 'word/document.xml', '//w:pPrChange[@w:id="100062"]/w:pPr/w:spacing', set_attr('line', '999'), 'ORIGINAL_OLD_PROPERTY_CHANGED')
    negative('body_text_corruption', 'word/document.xml', '(//w:t)[1]', text_change, 'ACCEPTED_FULL_XML')
    negative('field_end_removed', 'word/document.xml', '//w:fldChar[@w:fldCharType="end"]', remove, 'FIELD_CONTRACT')
    negative('footnote_content_corruption', 'word/footnotes.xml', '//w:t', text_change, 'ACCEPTED_FULL_XML:word/footnotes.xml')
    negative('style_master_corruption', 'word/styles.xml', '//w:style[@w:styleId="afc"]/w:pPr/w:ind', set_attr('left', '0'), 'UNEXPECTED_TRACKED_MEMBER_CHANGE:word/styles.xml')
    write(out / 'NEGATIVE_FIXTURES.json', {'fixtures': fixtures, 'all_detected': True,
                                         'mutations_in_memory_only': True, 'input_files_not_written': True})

    for k, (p, _) in FILES.items():
        require(pin(p) == inputs[k], 'INPUT_CHANGED_DURING_CHECK:' + k)
    result = {'at': datetime.now(timezone.utc).isoformat(), 'state': 'PASS_INDEPENDENT_CUMULATIVE_OFFLINE_ONLY',
              'review_mode': 'solo_self_review', 'independent_implementation_not_independent_person': True,
              'inputs': inputs, 'implementation': pin(__file__), 'stories': len(names),
              'paragraphs': sum(x['paragraphs'] for x in stories), 'tables': sum(x['tables'] for x in stories),
              'whole_story_xml_and_fields_pass': True, 'all_archive_members_crc_and_xml_pass': True,
              'resolved_indent_paragraphs': sum(x['paragraphs'] for x in indent_checks),
              'new_property_revisions': 562, 'preserved_merged_revisions': inferred_merged,
              'cell_property_revisions': 129, 'negative_cases': len(fixtures), 'all_negative_detected': True,
              'inputs_unchanged': True, 'native_word_invoked': False, 'zotero_invoked': False,
              'statistics_executed': False, 'final_acceptance': False,
              'limits': ['Word native accept/reject/save/close/reopen pending', 'source-style inheritance is offline evidence, not Word rendering',
                         'C3/F2/F5 pending', 'final same-PDF NLM and publication pending']}
    write(out / 'RESULT.json', result)
    write(out / 'MANIFEST.json', {'files': [pin(p) for p in sorted(out.iterdir()) if p.is_file()]})
    print(json.dumps({'state': result['state'], 'stories': result['stories'], 'paragraphs': result['paragraphs'],
                      'negative_cases': result['negative_cases'], 'result': pin(out / 'RESULT.json')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=N / 'v3h_cumulative_independent_acceptance_20261024_v1')
    args = parser.parse_args()
    try:
        main(args.out.resolve())
    except Exception as exc:
        if args.out.is_dir() and not (args.out / 'FAILURE.json').exists():
            write(args.out / 'FAILURE.json', {'at': datetime.now(timezone.utc).isoformat(), 'error': str(exc),
                                            'traceback': traceback.format_exc(), 'native_calls': 0})
        raise
