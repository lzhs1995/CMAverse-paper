#!/usr/bin/env python3
"""为当前候选创建独立本地交付准备包；不运行论文分析或应用。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
from datetime import datetime, timezone
import zipfile

N = Path(__file__).resolve().parent
BASE = N.parent / 'cmaverse-solo-2545-20261023'
E = BASE / 'continuation_20261027_v1'
B = BASE / 'v3h_release_preparation_20261025_v1'
OUT = N / 'release_preparation_current_v1_r2'
PACKAGE = OUT / 'package'
HISTORY = 'history/20261025/package/'
TOOL = Path('/Users/lzhs/.local/share/thesis-refiner/releases/2026.10.22.1-4e957b3cbda4/source')
STAMP = datetime.now(timezone.utc).isoformat()
PREFIX = 'CMAverse_V3h_current_local_preparation/'
ZIP_NAME = 'CMAverse_V3h_current_local_preparation_20261030_v1_r2.zip'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(path):
    path = Path(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode), 'REGULAR_FILE_REQUIRED:' + str(path))
    data = path.read_bytes()
    after = path.lstat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
         'SOURCE_CHANGED_DURING_READ:' + str(path))
    return data


def ref(path, data=None):
    data = read_regular(path) if data is None else data
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}


def checked(path, sha256, size=None):
    data = read_regular(path)
    need(digest(data) == sha256 and (size is None or len(data) == size),
         'PIN_MISMATCH:' + str(path))
    return data


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def capacity():
    state = os.statvfs(N)
    return {'at': datetime.now(timezone.utc).isoformat(),
            'method': 'statvfs.f_bavail * f_frsize (system available bytes)',
            'available_bytes': state.f_bavail * state.f_frsize,
            'not_reclaimable_space_estimate': True}


def main():
    need(not OUT.exists(), 'NEW_OUTPUT_DIRECTORY_REQUIRED')
    before_space = capacity()
    need(before_space['available_bytes'] >= 22 * 1024**3, 'INSUFFICIENT_CURRENT_HEADROOM')
    # 固定旧清单和原交付工具；不使用可切换的技能别名。
    old_manifest_bytes = checked(B / 'package/MANIFEST.json',
        '2fa436226e5a179171ba0d06900bbe0d19966ee86419862a98df9751905d667e', 154688)
    old = json.loads(old_manifest_bytes)
    tool_pins = []
    for original in old['fixed_toolchain']:
        data = checked(Path(original['path']), original['sha256'], original.get('bytes'))
        tool_pins.append(ref(Path(original['path']), data))
    need(len(old['files']) == 193, 'HISTORICAL_MEMBER_COUNT_CHANGED')
    expected_old = {r['package_path'] for r in old['files']} | {'MANIFEST.json'}
    actual_old = {p.relative_to(B / 'package').as_posix()
                  for p in (B / 'package').rglob('*') if p.is_file() or p.is_symlink()}
    need(actual_old == expected_old, 'HISTORICAL_PACKAGE_MEMBER_SET_CHANGED')

    selected = {}

    def select(path, member, category, expected=None, upstream=None):
        member_path = PurePosixPath(member)
        need(not member_path.is_absolute() and member_path.as_posix() == member
             and '..' not in member_path.parts and member not in selected,
             'INVALID_OR_DUPLICATE_MEMBER:' + member)
        data = read_regular(path)
        pin = ref(path, data)
        if expected:
            need(pin['sha256'] == expected['sha256'] and
                 pin['bytes'] == expected['bytes'], 'EXPECTED_SOURCE_CHANGED:' + str(path))
        row = {'package_path': member, 'bytes': len(data), 'sha256': digest(data),
               'source': pin, 'category': category}
        if upstream:
            row['historical_original_source'] = upstream
            row['historical_source_reverified_this_build'] = False
        selected[member] = (row, data)
        return row

    for row in old['files']:
        select(B / 'package' / row['package_path'], HISTORY + row['package_path'],
               'preserved_20261025_package_member', row, row.get('source'))
    select(B / 'package/MANIFEST.json', HISTORY + 'MANIFEST.json',
           'preserved_20261025_original_manifest', ref(B / 'package/MANIFEST.json', old_manifest_bytes))
    for name in ['DELIVERY_CONTRACT.json', 'BUILD_RESULT.json', 'RELEASE_CLOSEOUT.json',
                 'DELIVERY_RESULT.json', 'SIZE_CHECK.json']:
        select(B / name, 'history/20261025/reports/' + name, 'historical_local_package_report')

    # 三份当前输入只复制，使用已经冻结的精确身份。
    combined = E / 'combined_table_page_candidate_v1'
    generated_bytes = checked(combined / 'RESULT.json',
        'bb75b77f03b87120317ef57cba8ee7db5a2d8755d28ee2456bfaeed0cc98f52d', 11039)
    generated = json.loads(generated_bytes)
    readback = json.loads(read_regular(combined / 'INDEPENDENT_READBACK.json'))
    need(readback['all_pass'] is True and readback['generation_result']['sha256'] == digest(generated_bytes),
         'CURRENT_READBACK_SOURCE_MISMATCH')
    role_members = {}
    for role, pin in generated['outputs'].items():
        need(readback['outputs'][role] == pin, 'CURRENT_ROLE_BINDING_MISMATCH:' + role)
        role_members[role] = 'manuscript/' + Path(pin['path']).name
        select(Path(pin['path']), role_members[role], 'current_offline_candidate_or_expected', pin)
    for name in ['RESULT.json', 'INDEPENDENT_READBACK.json', 'REVIEW.md', 'INTENT.json',
                 'C3_LIVE_FIELD_BINDINGS.json', 'PAGE_FIELD_SCOPE_PROPOSAL.json',
                 'SOURCE_BOUND_VIEW_CONTRACT.json']:
        expected = readback['source_bound_view_contract'] if name == 'SOURCE_BOUND_VIEW_CONTRACT.json' else None
        select(combined / name, 'evidence/current_table_page/' + name, 'current_table_page_evidence', expected)
    for pin in [generated['implementation'], readback['verification_script'], readback['independent_projector']]:
        select(Path(pin['path']), 'code/current/' + Path(pin['path']).name, 'existing_offline_implementation', pin)

    c3_dir = E / 'c3_reference_delta_audit_20261028_v1'
    c3_validation = json.loads(read_regular(c3_dir / 'VALIDATION.json'))
    for path in sorted(c3_dir.iterdir()):
        if path.is_file() and path.name != 'READY_FOR_MAINTAINER.NOT_SUBMITTED.json':
            select(path, 'evidence/c3_delta/' + path.name, 'existing_c3_validator_evidence')
    for field in ['implementation', 'tests']:
        pin = c3_validation[field]
        select(Path(pin['path']), 'code/current/' + Path(pin['path']).name, 'existing_c3_validator_source', pin)
    select(E / 'c3_complete_reference_delta_20261028_v1/C3_REFERENCE_DELTA_CONTRACT.json',
           'evidence/c3_delta/C3_REFERENCE_DELTA_CONTRACT.json', 'current_c3_content_contract')
    select(E / 'pdf_final_scope_preparation_20261028_v1/SOURCE_BOUND_PDF_SCOPE.json',
           'evidence/pdf_scope/SOURCE_BOUND_PDF_SCOPE.json', 'current_pdf_scope_not_pdf_pass')
    nlm = E / 'nlm_final_v3h_preparation_20261028_v1'
    sourcebook_manifest = json.loads(read_regular(nlm / 'SUPPLEMENTAL_FROZEN_RESULTS_MANIFEST.json'))
    for name in ['README.md', 'QUERY_TEMPLATE.json', 'SUPPLEMENTAL_FROZEN_RESULTS.md',
                 'SUPPLEMENTAL_FROZEN_RESULTS_MANIFEST.json', 'READBACK.json']:
        pin = sourcebook_manifest['sourcebook'] if name == 'SUPPLEMENTAL_FROZEN_RESULTS.md' else None
        select(nlm / name, 'review_preparation/nlm/' + name, 'unbound_final_nlm_preparation', pin)
    need(sourcebook_manifest['package_manifest']['sha256'] == digest(old_manifest_bytes),
         'SOURCEBOOK_HISTORICAL_PACKAGE_MISMATCH')
    supplemental = []
    need(len(sourcebook_manifest['entries']) == 15, 'SOURCEBOOK_ENTRY_COUNT_CHANGED')
    book = read_regular(nlm / 'SUPPLEMENTAL_FROZEN_RESULTS.md')
    for item in sourcebook_manifest['entries']:
        member = HISTORY + item['package_member']
        row, original_csv = selected[member]
        need(row['sha256'] == item['source']['sha256'], 'SOURCEBOOK_CSV_PIN_MISMATCH')
        start, size = item['sourcebook_byte_offset'], item['sourcebook_byte_length']
        span = book[start:start + size]
        need(span == original_csv and digest(span) == item['sha256'], 'SOURCEBOOK_BYTE_SPAN_MISMATCH')
        supplemental.append({'id': item['id'], 'current_package_member': member,
                             'original_entry': item, 'csv_and_sourcebook_span_match': True})
    select(Path(__file__).resolve(), 'code/preparation/' + Path(__file__).name,
           'current_package_builder_not_statistics')

    # 所有源文件预检完成后才创建新目录；失败或重复运行不覆盖原件。
    OUT.mkdir()
    authored = OUT / 'authoring'
    authored.mkdir()
    provenance = {'schema': 'cma-current-release-source-index-v1', 'at': STAMP,
                  'scope': 'local_current_preparation_only',
                  'historical_package_manifest': ref(B / 'package/MANIFEST.json', old_manifest_bytes),
                  'historical_original_sources_reverified': False,
                  'historical_index_counts_preserved': old['historical_index_counts'],
                  'historical_gaps_preserved': [91, 98, 105, 117, 118, 132],
                  'source_rows': [row for row, _ in selected.values()],
                  'supplemental_fifteen_csv_mapping': supplemental}
    stage = {'schema': 'cma-current-local-release-preparation-state-v1', 'at': STAMP,
             'status': 'LOCAL_PREPARATION_FINAL_NATIVE_ACCEPTANCE_PENDING',
             'review_mode': 'solo_self_review', 'current_source_roles': generated['outputs'],
             'existing_offline_evidence': {'revision_count': 661, 'original_revisions': 626,
                 'new_table_history': 33, 'new_page_history': 2, 'views': 2,
                 'tables_per_view': 34, 'rows_per_view': 478, 'cells_per_view': 2956,
                 'paragraphs_per_view': 3350, 'reexecuted_this_build': False},
             'native_formal_docx_created': False, 'final_word_pdf_created': False,
             'native_citations': '0/3', 'same_pdf_nlm_rounds': '0/2',
             'frozen_statistical_recovery': '37/37 (prior evidence, not rerun)',
             'frozen_source_count': 288, 'decision_counts': {'offline': 22, 'retained': 9, 'native_pending': 3},
             'v216': 'ONE_READ_CONSUMED_EXIT124_NO_RETRY',
             'maintainer_reply_files_observed': {name: (N / name).exists() for name in
                 ['MAINTAINER_PID_READ_REPLY.json', 'MAINTAINER_NATIVE_ADMISSION_REPLY.json']},
             'statistics_executed': 0, 'word_calls': 0, 'zotero_calls': 0,
             'nlm_calls': 0, 'remote_writes': 0, 'mole_cleanup': 0,
             'final_release': False, 'capacity_before': before_space}
    current_readme = f'''# 收入变化、婚姻满意度与成年子女对父母的经济支持

**V3h 当前本地准备包 · 2026-10-30 · 正式原生验收待完成**

当前候选已合并表格历史和 PAGE 域。请从以下三份文件阅读；接受稿、拒绝稿是离线预期文件。

| 文件 | 当前用途 |
|---|---|
| [累计修订候选]({role_members['tracked']}) | SHA256 d0badcab1d4a784be2d2f62801457a250b79b87b4297f3fd4734d955de1be895 |
| [接受全部修订的离线预期]({role_members['accepted']}) | 用于后续原生接受结果对照 |
| [拒绝全部修订的离线预期]({role_members['rejected']}) | 用于后续原生拒绝结果对照 |

原有离线证据覆盖9个story的两种视图，每视图34表、478行、2956格、3350段；661条修订包含626条原记录、33条表格历史和2条页码记录。本次仅复制和校验文件。PAGE缓存仍空，实际页码、表10第二列与表11第一列的词界及跨页效果待Word检查。

[后续验收计划](ACCEPTANCE_PLAN.md)列出正式三稿、C3元数据与Refresh、分页和最终PDF、同一PDF六主题连续两轮审查以及正式发布的依赖顺序。[科学边界](SCIENTIFIC_BOUNDARIES.md)保留估计目标、推断口径和历史来源缺口。

| 目录 | 内容 |
|---|---|
| manuscript/ | 当前三份候选/离线预期 |
| evidence/ | 当前表格与PAGE证据、C3差异检查及最终PDF验收范围 |
| review_preparation/nlm/ | 六主题模板与15份冻结CSV的来源册，尚未绑定最终PDF或远端source ID |
| code/ | 已有离线检查程序和本次构包程序；本次未执行科研或原生检查 |
| history/20261025/package/ | 完整保留的旧包、原清单、108份CSV与17份R源码；其旧稿仅作历史 |
| provenance/ | 原件身份、复制映射以及15份CSV在当前包内的位置 |

旧包193项成员及原MANIFEST共194项均保留，内部相对路径保持。439项历史索引仍区分102项已复制核验与337项仅索引，六项历史消费缺口91/98/105/117/118/132保持。当前复制校验不补造历史消费证明；本包也不含原始调查数据或完整模型对象。

包内JSON中的原绝对路径用于追溯冻结来源，不表示跨机自动可执行。当前MANIFEST固定所有成员和来源副本；包外DELIVERY_RESULT.json证明完整性、来源副本一致及ZIP每成员SHA/CRC，SIZE_CHECK.json记录严格小于25,000,000字节。以上回执不替代原生、科学或视觉验收。此阶段未发布GitHub或上传百度。
'''
    acceptance = '''# 后续验收与正式交付计划

当前已经完成统计恢复37/37、288项来源冻结、34项裁决（22项离线落实、9项保留、3项原生待办），以及当前表格历史/PAGE候选的离线对照。直接复用这些证据，不重复估计或旧检查。

| 顺序 | 剩余工作 | 具体交付与通过条件 |
|---|---|---|
| 1 | 原Word恢复与当前批准继承 | 全文核原维护对v216实际exit124及两代原生批准链的回件；v216读取额度已消费。按受支持的新范围继续，保留原phase、关闭额度与原资源归属。源码审核、读取结果、关闭、旧票核收分别记录。 |
| 2 | 正式三稿 | 以本包当前d0badcab候选及两份离线预期为固定输入，执行当前exact job。生成tracked.docx、accepted.docx、rejected.docx；分别验证修订事件、9部分双视图全文与34表结构、活域、保存关闭重开。原49项文字与表格/PAGE附加事件按实际语义验收。 |
| 3 | C3元数据与实际Refresh | Zotero条目LD33NKPV刊名改为Journal of the Royal Statistical Society Series B: Statistical Methodology；MEQZDXNW改为Epidemiology。按当前旧值做CAS，保留2017b/2019及2014历史脚注。在Word真实Refresh并保存重开，固定前后三稿SHA，运行既有C3差异验收；每视图只允许4处活域刊名及2条书目刊名变化，其他值保持。原生引文三项门禁须有实际证据。 |
| 4 | PAGE与表格实际版式 | 逐页核PAGE连续性、印刷页序、页脚占位和底部文字；检查表10第二列（物理表14）及表11第一列（物理表15）的词界、遮挡、裁切、行序与跨页。按当前Word/PDF只作必要最小修正，保留改前后页图和文稿身份。 |
| 5 | 最终Word PDF | Word原生导出accepted.pdf；依据SOURCE_BOUND_PDF_SCOPE及原合同完成原生Word/Zotero、格式、PDF字体、全页视觉和实证对应五项验收，冻结最终DOCX/PDF的字节数与SHA。旧PDF和空PAGE缓存不算当前通过。 |
| 6 | 同一PDF六主题两轮 | 固定最终PDF及真实可读的辅助来源；六主题每轮各建独立conversation，共12题。沿原账号、传输和当前真实身份，在发送前核实际预算和容量；完整读取回答并逐项裁决。连续两轮使用同一PDF SHA，若修改稿件产生新PDF则重新计轮。当前仍0/2；来源册的15份CSV不声称覆盖全部288项。 |
| 7 | 正式发布与双回下载 | 前述验收完成后更新正式包与清单，发布至https://github.com/lzhs1995/CMAverse-paper并固定commit/tree。公共端与百度分别独立回下载，核文件SHA/大小和ZIP全成员CRC；每ZIP严格小于25,000,000字节。分别保存发布、上传与回下载证据。 |

每个阶段保存真实日志、输入/输出SHA与明确通过范围。保持CODEX_SOLO / solo_self_review、原模型规格与历史推断边界。旧unknown、pending、他方资源和已经消费的读取额度不能由本地构包改变。Word永久授权继续沿用，无需再次询问。
'''
    authored_data = {
        'README.md': current_readme.encode('utf-8'),
        'SCIENTIFIC_BOUNDARIES.md': read_regular(B / 'package/SCIENTIFIC_BOUNDARIES.md').replace(
            '原始裁决和证据见 decisions/ 与 evidence/source_evidence/。'.encode('utf-8'),
            '原始裁决和证据见 [历史裁决](history/20261025/package/decisions/) 与 [历史来源证据](history/20261025/package/evidence/source_evidence/)。'.encode('utf-8')),
        'ACCEPTANCE_PLAN.md': acceptance.encode('utf-8'),
        'LOCAL_STAGE_STATE.json': encoded(stage),
        'provenance/SOURCE_INDEX.json': encoded(provenance),
        'provenance/SUPPLEMENTAL_CURRENT_MEMBER_MAP.json': encoded({
            'schema': 'cma-fifteen-csv-current-member-map-v1', 'at': STAMP,
            'entries': supplemental, 'sourcebook': sourcebook_manifest['sourcebook'],
            'numerical_transforms': 0, 'remote_uploads': 0}),
    }
    for member, data in authored_data.items():
        write_new(authored / member, data)
        select(authored / member, member, 'authored_current_preparation_document')

    # 每个副本与已读原件逐字节一致；不修订旧包中的任何文件。
    for member, (row, data) in sorted(selected.items()):
        need(read_regular(Path(row['source']['path'])) == data, 'SOURCE_DRIFT_BEFORE_COPY:' + member)
        write_new(PACKAGE / member, data)
        need(read_regular(PACKAGE / member) == data, 'COPY_READBACK_MISMATCH:' + member)
    rows = [row for _, (row, _) in sorted(selected.items())]
    manifest = {'schema': 'cma-current-local-preparation-manifest-v1', 'at': STAMP,
                'scope': 'LOCAL_CURRENT_PREPARATION_NOT_FINAL_ACCEPTANCE',
                'review_mode': 'solo_self_review', 'files': rows,
                'historical_package_manifest': ref(B / 'package/MANIFEST.json', old_manifest_bytes),
                'fixed_toolchain': tool_pins, 'build_script': ref(Path(__file__).resolve()),
                'final_acceptance': False, 'statistics_executed': False}
    write_new(PACKAGE / 'MANIFEST.json', encoded(manifest))
    archive_path = OUT / ZIP_NAME
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PACKAGE.rglob('*')):
            if path.is_file():
                archive.write(path, PREFIX + path.relative_to(PACKAGE).as_posix())
    archive_pin = ref(archive_path)
    size_pass = archive_pin['bytes'] < 25_000_000
    write_new(OUT / 'SIZE_CHECK.json', encoded({'at': STAMP, 'archive': archive_pin,
        'strict_limit_bytes': 25_000_000, 'comparison': '<', 'pass': size_pass}))
    need(size_pass, 'ARCHIVE_NOT_STRICTLY_BELOW_25000000_BYTES')
    roles = [{'id': 'readme', 'member': 'README.md', 'label': '当前准备包说明', 'suffixes': ['.md']}]
    for role, label in [('tracked', '当前累计修订候选'), ('accepted', '接受全部修订的离线预期'),
                        ('rejected', '拒绝全部修订的离线预期')]:
        roles.append({'id': role, 'member': role_members[role], 'label': label, 'suffixes': ['.docx']})
    roles += [{'id': 'remaining_plan', 'member': 'ACCEPTANCE_PLAN.md', 'label': '后续详细验收计划', 'suffixes': ['.md']},
              {'id': 'sources', 'member': 'provenance/SOURCE_INDEX.json', 'label': '当前包来源索引', 'suffixes': ['.json']}]
    contract = {'schema': 'delivery-manifest-v1', 'package_root': str(PACKAGE),
                'manifest': ref(PACKAGE / 'MANIFEST.json'), 'require_sources': True,
                'roles': roles, 'zip': {'file': archive_pin, 'prefix': PREFIX,
                    'label': '当前本地准备包ZIP', 'role': 'archive'}}
    write_new(OUT / 'DELIVERY_CONTRACT.json', encoded(contract))
    after_space = capacity()
    need(after_space['available_bytes'] >= 20 * 1024**3, 'SYSTEM_AVAILABLE_BELOW_RESERVE')
    result = {'schema': 'cma-current-package-build-result-v1', 'at': STAMP,
              'status': 'PREPARED_FOR_FIXED_DELIVERY_VERIFIER',
              'package': str(PACKAGE), 'manifest_files': len(rows), 'zip_members': len(rows) + 1,
              'historical_original_package_members_preserved': len(expected_old),
              'historical_frozen_csv': sum(x.endswith('.csv') for x in expected_old),
              'historical_frozen_R': sum(x.lower().endswith('.r') for x in expected_old),
              'supplemental_byte_spans_matched': len(supplemental),
              'archive': archive_pin, 'manifest': contract['manifest'],
              'contract': ref(OUT / 'DELIVERY_CONTRACT.json'), 'fixed_toolchain': tool_pins,
              'capacity_before': before_space, 'capacity_after': after_space,
              'statistics_or_native_checks_reexecuted': False, 'applications_or_remote_calls': 0,
              'final_paper_acceptance': False}
    write_new(OUT / 'BUILD_RESULT.json', encoded(result))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
