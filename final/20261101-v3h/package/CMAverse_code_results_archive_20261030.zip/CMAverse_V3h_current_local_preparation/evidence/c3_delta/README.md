# C3 引用差异验收程序

状态：本机只读程序已验证；实际 Zotero 库事务和 Word Refresh 尚未执行。

程序：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/handoff/cmaverse-solo-2545-20261023/continuation_20261027_v1/audit_c3_reference_delta_20261028.py

输入采用 cma-c3-docx-delta-inputs-v1 清单，contract 固定原 C3 合同；before 和 after 分别包含 tracked、accepted、rejected 三个文件的绝对路径、字节数和 SHA256。取得真实 Word 输出后重新固定这六个文件，不能把当前离线准备清单当作实际 Refresh 的输入证据。

命令参数为 --manifest、--manifest-sha256、--phase baseline|delta、--output。baseline 只核刷新前引用基线；delta 同时核基线和刷新后差异，失败退出2。输出使用新文件路径，拒绝覆盖旧证据。两次已运行命令及完整输出保存在 BASELINE_INPUTS.CLI.json、NEGATIVE_STALE_INPUTS.CLI.json。

验收修订稿接受/拒绝视图和两份独立稿，共四视图；引用数分别22/23/22/23，每视图25条书目。每视图只允许4处活域 itemData container-title 和2条书目刊名改变，完整JSON其余内容、2017b/2019、23条非目标书目及2014历史脚注保持。允许JSON空白及Word分割指令run的差异。

11项检查通过。完整内存正例通过；未刷新原稿、只更新活域或书目、年份/非目标引用改动、丢失Zotero绑定或拒绝视图历史脚注均被拒绝。变异DOCX未写磁盘。首次测试中变异器把碎片当完整JSON的问题已修正；TEST-r1原失败保留，审计程序未因此放宽。

本程序不证明真实Refresh、Zotero CAS、全文/格式或原修订历史通过；这四项继续由原执行回执和既有验收分别证明。VALIDATION.json、INDEPENDENT_READBACK.json 为本轮程序验证，不是论文完成证明。
