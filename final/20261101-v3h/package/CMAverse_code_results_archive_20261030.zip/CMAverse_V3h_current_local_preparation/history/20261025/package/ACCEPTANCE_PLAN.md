# 后续验收与正式交付计划

顺序：V3h原生入口 → C3/F2/F5 → Word接受/拒绝及保存重开 → 最终Word PDF → 同PDF六主题连续两轮NotebookLM → 固定Git提交与百度独立回下载。

| 阶段 | 具体操作 | 必须保存的验收证据 | 当前状态 |
|---|---|---|---|
| 本地准备包 | 核所有已选原件与副本的SHA/大小、完整目录成员及ZIP全成员CRC；ZIP严格小于25,000,000字节 | 包外DELIVERY_RESULT.json、DELIVERY_LINKS.md和SIZE_CHECK.json | 以包外固定工具回执为准 |
| 合法原生入口 | 沿原维护方完成来源绑定的新job/adapter与真实owner入口；重新绑定累计稿、content_source及工具版本 | 新grant、最终输入pins、原客户端实际采用与资源边界证据 | 尚未取得；v76离线8测试通过不代表放行 |
| C3引文 | 将Smith刊名修正为Epidemiology；VanderWeele刊名修正为Journal of the Royal Statistical Society Series B: Statistical Methodology；保留2017卷期年；在Zotero中更新两条元数据后真实Word Refresh | 元数据前后值、Refresh实际执行、活域读回及保存重开证据；原生引文三项门禁全部通过 | 0/3 |
| F2页码 | 在新原生副本核页脚占位，插入PAGE域并最小调整下边距/页脚距离；284/992是旧缺陷观测值，不能作目标 | 当前Word渲染、页码连续性与页脚不碰撞的页图 | 待处理 |
| F5词界 | 只处理表10第二列、表11第一列；根据当前PDF词界选择最小列宽或软换行修改 | 改前后对应页与表格完整性；同步确认F1题注及跨页断行 | 待处理 |
| 原生往返 | 在受控副本中分别接受、拒绝累计修订，保存、关闭、重新打开；以合同核内容、域与版式 | 原生执行日志、文档SHA、接受/拒绝视图和重开后活域 | 待处理；现有两份验证稿仅离线 |
| 最终PDF | 从原生Word导出最终PDF，固定所有实际PDF工具及执行器；全页视觉、字体、字符及页码核验 | Word/PDF对应SHA、来源绑定的导出记录、工具pins和全页审读记录 | 未生成；旧版PDF不替代 |
| NotebookLM第1轮 | 沿既定六主题清单，以最终PDF及实际已核收的辅助来源为输入；完整读取长答并逐项裁决 | PDF SHA、真实source IDs、六主题原文和完整裁决 | 0/2轮；旧UNCERTAIN不重发或代撤 |
| NotebookLM第2轮 | 在同一最终PDF SHA上连续完成第二轮六主题核验 | 同SHA、同来源范围、六主题完整输出、遗留问题处置 | 若改稿/PDF变化，重新开始该PDF的两轮计数 |
| 正式发布 | 更新最终说明与选材，冻结清单；在既有授权范围按固定commit发布到lzhs1995/CMAverse-paper | commit与tree分别登记、发布清单、公共独立回下载的SHA及ZIP CRC | 待前述验收；当前main历史观测不代表此次发布 |
| 百度备份 | 对最终增量按每ZIP严格小于25,000,000字节上传原指定账号，再独立回下载 | 上传/回下载分开留证，逐件SHA/大小及ZIP全成员CRC | 待最终版本；本地准备ZIP不算云端已备份 |

本阶段原生入口观察来自既有handoff及原回件；本包不授权改写旧Word票、释放他人资源或把foreign saved/Zotero内部idle的UNKNOWN改为成功。保持CODEX_SOLO和统计冻结。

当前恢复任务的正式完成条件是经过审查的Word、其最终PDF与数据/脚本/结果对应关系、固定提交的发布证据和独立云回下载均可追溯；本地压缩包通过仅关闭机械打包阶段。
