# 收入变化、婚姻满意度与成年子女对父母的经济支持

**V3h 本地发布准备包 · 2026-10-25 · 论文最终验收尚未完成**

先读[科学边界](SCIENTIFIC_BOUNDARIES.md)，再查看[34项实施对照](decisions/V3H_STATUS_CROSSWALK.md)和[后续验收计划](ACCEPTANCE_PLAN.md)。

本包包含三份稿件、108份冻结CSV、17份R源码、原裁决及离线验证证据。所选原件逐项核SHA256/字节数后原样复制；未执行统计、Word或Zotero。

| 文件 | 用途 |
|---|---|
| [CMAverse_V3h_minimal_format_cumulative_tracked.docx](manuscript/CMAverse_V3h_minimal_format_cumulative_tracked.docx) | 累计修订稿；后续原生验收的工作基础 |
| [CMAverse_V3h_minimal_format_accept_all_validation.docx](manuscript/CMAverse_V3h_minimal_format_accept_all_validation.docx) | 全接受的离线验证副本，便于通读 |
| [CMAverse_V3h_minimal_format_reject_all_validation.docx](manuscript/CMAverse_V3h_minimal_format_reject_all_validation.docx) | 全拒绝的离线验证副本，用于检查回退语义 |
| [CMAverse_V3h_minimal_format_candidate.docx](reference/content_source/CMAverse_V3h_minimal_format_candidate.docx) | 额外保留的角色合同content_source，独立于三稿；不能换成接受验证稿 |

来源导航见[数据—代码—结果—稿件入口](provenance/PROVENANCE_GUIDE.md)与[机器可读来源索引](provenance/SOURCE_INDEX.json)。439项历史记录中，本包复制核验102项，另337项仅保留历史索引；6项历史消费合同缺口原样保留。MODEL_INDEX不证明完整模型存储当前可用。原始调查数据及完整模型对象不随包分发；此包不等于完整实证重跑环境。

当前裁决为22项离线落实、9项不改、3项原生待处理（C3/F2/F5）。原生引文0/3、同一最终PDF的NotebookLM两轮0/2。旧稿PDF、旧NLM与旧原生回执不能算入当前V3h验收。

包内MANIFEST.json记录每个文件的相对路径、SHA256、大小及原件绝对路径。固定交付工具的机械核验回执放在包外：[/Users/lzhs/Documents/cnm/tasks/01_R_analysis/handoff/cmaverse-solo-2545-20261023/v3h_release_preparation_20261025_v1/DELIVERY_RESULT.json](/Users/lzhs/Documents/cnm/tasks/01_R_analysis/handoff/cmaverse-solo-2545-20261023/v3h_release_preparation_20261025_v1/DELIVERY_RESULT.json)；严格小于25,000,000字节的ZIP大小门禁见[/Users/lzhs/Documents/cnm/tasks/01_R_analysis/handoff/cmaverse-solo-2545-20261023/v3h_release_preparation_20261025_v1/SIZE_CHECK.json](/Users/lzhs/Documents/cnm/tasks/01_R_analysis/handoff/cmaverse-solo-2545-20261023/v3h_release_preparation_20261025_v1/SIZE_CHECK.json)。回执只证明文件完整性与来源副本一致，不替代科学、原生和视觉审查。

本地ZIP与包目录是这一阶段的交付物；本次未发布GitHub、未上传百度，也未完成最终版本的独立回下载。后续按ACCEPTANCE_PLAN.md完成原生收尾和两轮审查后，再冻结正式交付版本。
