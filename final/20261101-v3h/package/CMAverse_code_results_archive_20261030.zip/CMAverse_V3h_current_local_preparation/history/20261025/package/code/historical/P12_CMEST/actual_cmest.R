function (data = NULL, model = "rb", full = TRUE, casecontrol = FALSE, 
    yrare = NULL, yprevalence = NULL, estimation = "imputation", 
    inference = "bootstrap", outcome = NULL, event = NULL, exposure = NULL, 
    mediator = NULL, EMint = NULL, basec = NULL, postc = NULL, 
    yreg = NULL, mreg = NULL, wmnomreg = NULL, wmdenomreg = NULL, 
    ereg = NULL, postcreg = NULL, astar = 0, a = 1, mval = NULL, 
    mval_grid = NULL, max_mval_combinations = 20, progress_callback = NULL, 
    progress_every = 1L, yval = NULL, basecval = NULL, nboot = 200, 
    boot.ci.type = "per", nRep = 5, multimp = FALSE, args_mice = NULL) 
{
    cl <- match.call()
    if ("progress_callback" %in% names(cl)) 
        cl$progress_callback <- NULL
    out <- list(call = cl)
    if (is.null(data)) 
        stop("Unspecified data")
    data <- as.data.frame(data)
    if (sum(is.na(data)) > 0 && !multimp) 
        stop("NAs in the data; delete rows with NAs from the data or set multimp = TRUE")
    out$data <- data
    n <- nrow(data)
    if (!model %in% c("rb", "wb", "iorw", "ne", "gformula", "msm")) 
        stop("Select model from 'rb', 'wb', 'iorw', 'ne', 'gformula', 'msm'")
    out$methods$model <- model
    if (!is.logical(full)) 
        stop("full should be TRUE or FALSE")
    out$methods$full <- full
    if (!is.logical(casecontrol)) 
        stop("casecontrol should be TRUE or FALSE")
    out$methods$casecontrol <- casecontrol
    if (casecontrol) {
        if (length(unique(data[, outcome])) != 2) 
            stop("When casecontrol is TRUE, the outcome must be binary")
        if (is.null(yprevalence) && yrare != TRUE) 
            stop("When casecontrol is TRUE, specify yprevalence or set yrare to be TRUE")
        if (is.null(yprevalence) && !(estimation %in% c("para", 
            "paramfunc"))) 
            stop("When casecontrol is TRUE, specify yprevalence or use estimation = 'paramfunc'")
        if (!is.null(yprevalence)) {
            if (!is.numeric(yprevalence)) 
                stop("yprevalence should be numeric")
            out$methods$yprevalence <- yprevalence
        }
        else out$methods$yrare <- yrare
    }
    if (estimation == "para") 
        estimation <- "paramfunc"
    if (estimation == "impu") 
        estimation <- "imputation"
    if (inference == "delt") 
        inference <- "delta"
    if (inference == "boot") 
        inference <- "bootstrap"
    if (model == "rb" && !estimation %in% c("paramfunc", "imputation")) 
        stop("When model = 'rb', select estimation from 'paramfunc', 'imputation'")
    if (model != "rb" && !estimation == "imputation") 
        stop("Use estimation = 'imputation'")
    if (estimation == "paramfunc") {
        if (!is.character(yreg) | length(yreg) != 1) 
            stop("When estimation = 'paramfunc', select yreg from 'linear', 'logistic', \n                       'loglinear', 'poisson', 'quasipoisson', 'negbin', 'coxph', 'aft_exp', 'aft_weibull'")
        if (!yreg %in% c("linear", "logistic", "loglinear", "poisson", 
            "quasipoisson", "negbin", "coxph", "aft_exp", "aft_weibull")) 
            stop("When estimation = 'paramfunc', select yreg from 'linear', 'logistic', \n                       'loglinear', 'poisson', 'quasipoisson', 'negbin', 'coxph', 'aft_exp', 'aft_weibull'")
        if (length(mediator) > 1) 
            stop("'paramfunc' only supports a single mediator")
        if (!is.character(mreg[[1]]) | length(mreg[[1]]) != 1) 
            stop("When estimation = 'paramfunc', select mreg[[1]] from 'linear', 'logistic', 'multinomial'")
        if (!mreg[[1]] %in% c("linear", "logistic", "multinomial")) 
            stop("When estimation = 'paramfunc', select mreg[[1]] from 'linear', 'logistic', 'multinomial'")
    }
    out$methods$estimation <- estimation
    if (!inference %in% c("delta", "bootstrap")) 
        stop("Select inference from 'delta', 'bootstrap'")
    if (estimation == "imputation" && inference == "delta") 
        stop("Use inference = 'bootstrap' when estimation = 'imputation'")
    out$methods$inference <- inference
    if (inference == "bootstrap") {
        if (!is.numeric(nboot)) 
            stop("nboot should be numeric")
        if (!boot.ci.type %in% c("per", "bca")) 
            stop("Select boot.ci.type from 'per', 'bca'")
        out$methods$nboot <- nboot
        out$methods$boot.ci.type <- boot.ci.type
    }
    if (length(outcome) == 0) 
        stop("Unspecified outcome")
    if (length(outcome) > 1) 
        stop("length(outcome) > 1")
    out$variables$outcome <- outcome
    if (is.character(yreg)) {
        if (yreg %in% c("coxph", "aft_exp", "aft_weibull") && 
            !is.null(event)) 
            out$variables$event <- event
    }
    else {
        if (!is.null(event)) 
            warning("event is ignored when yreg is not character")
    }
    if (length(exposure) == 0) 
        stop("Unspecified exposure")
    if (length(exposure) > 1) 
        stop("length(exposure) > 1")
    out$variables$exposure <- exposure
    if (length(mediator) == 0) 
        stop("Unspecified mediator")
    out$variables$mediator <- mediator
    if (model != "iorw") {
        if (!is.logical(EMint)) 
            stop("EMint should be TRUE or FALSE")
        out$variables$EMint <- EMint
    }
    if (!is.null(basec)) 
        out$variables$basec <- basec
    if (length(postc) != 0) {
        if (!model %in% c("msm", "gformula")) 
            stop("When postc is not empty, select model from 'msm' and 'gformula'")
        out$variables$postc <- postc
    }
    if (model == "rb") 
        out$reg.input <- list(yreg = yreg, mreg = mreg)
    if (model == "wb") 
        out$reg.input <- list(yreg = yreg)
    if (model == "gformula") 
        out$reg.input <- list(yreg = yreg, mreg = mreg)
    if (model == "msm") 
        out$reg.input <- list(yreg = yreg, mreg = mreg, wmnomreg = wmnomreg, 
            wmdenomreg = wmdenomreg)
    if (model == "iorw") 
        out$reg.input <- list(yreg = yreg, ereg = ereg)
    if (model == "ne") 
        out$reg.input <- list(yreg = yreg)
    if (length(basec) != 0 && model %in% c("wb", "msm")) 
        out$reg.input$ereg <- ereg
    if (length(postc) != 0 && model == "gformula") 
        out$reg.input$postcreg <- postcreg
    if (is.null(a) | is.null(astar)) 
        stop("Unspecified a or astar")
    mval_grid_active <- !is.null(mval_grid)
    mval_grid_combos <- NULL
    mval_grid_labels <- NULL
    if (mval_grid_active) {
        if (model != "gformula") 
            stop("mval_grid is currently implemented only for model = 'gformula'")
        if (inference != "bootstrap") 
            stop("mval_grid requires inference = 'bootstrap'")
        if (multimp) 
            stop("mval_grid is currently not implemented with multimp = TRUE")
        if (!is.null(mval)) 
            warning("mval is ignored when mval_grid is specified")
        if (!is.list(mval_grid)) 
            stop("mval_grid should be a list")
        if (length(mval_grid) != length(mediator)) 
            stop("length(mval_grid) != length(mediator)")
        if (!is.numeric(max_mval_combinations) | length(max_mval_combinations) != 
            1 | is.na(max_mval_combinations) | max_mval_combinations < 
            1) {
            stop("max_mval_combinations should be a positive number")
        }
        for (p in 1:length(mval_grid)) {
            if (is.null(mval_grid[[p]])) 
                stop(paste0("Unspecified mval_grid[[", p, "]]"))
            if (is.list(mval_grid[[p]])) {
                stop("Each element of mval_grid should be a vector of candidate values, not a nested list")
            }
            if (length(mval_grid[[p]]) == 0) 
                stop(paste0("Empty mval_grid[[", p, "]]"))
        }
        mval_grid_df <- do.call(expand.grid, c(mval_grid, KEEP.OUT.ATTRS = FALSE, 
            stringsAsFactors = FALSE))
        if (nrow(mval_grid_df) > max_mval_combinations) {
            stop(paste0("mval_grid expands to ", nrow(mval_grid_df), 
                " combinations; increase max_mval_combinations to proceed"))
        }
        mval_grid_combos <- lapply(1:nrow(mval_grid_df), function(i) unname(as.list(mval_grid_df[i, 
            , drop = FALSE])))
        mval_grid_label <- function(vals) {
            vals_chr <- vapply(vals, function(x) paste(x, collapse = ","), 
                character(1))
            if (length(vals_chr) == 1) 
                vals_chr
            else paste(paste0(mediator, "=", vals_chr), collapse = "|")
        }
        mval_grid_labels <- make.unique(vapply(mval_grid_combos, 
            mval_grid_label, character(1)))
        names(mval_grid_combos) <- mval_grid_labels
        mval <- mval_grid_combos[[1]]
        out$methods$mval_grid <- mval_grid
        out$methods$max_mval_combinations <- max_mval_combinations
    }
    if (!is.null(progress_callback) && !is.function(progress_callback)) {
        stop("progress_callback must be NULL or a function")
    }
    if (!is.numeric(progress_every) || length(progress_every) != 
        1L || is.na(progress_every) || progress_every < 1 || 
        progress_every != as.integer(progress_every)) {
        stop("progress_every must be a positive integer")
    }
    progress_every <- as.integer(progress_every)
    if (model != "iorw") {
        if (!is.list(mval)) 
            stop("mval should be a list")
        if (length(mval) != length(mediator)) 
            stop("length(mval) != length(mediator)")
        for (p in 1:length(mval)) if (is.null(mval[[p]])) 
            stop(paste0("Unspecified mval[[", p, "]]"))
    }
    if (!(model == "rb" && estimation == "paramfunc" && length(basec) != 
        0) && !is.null(basecval)) 
        warning("basecval is ignored")
    if (model == "ne") {
        if (!is.numeric(nRep)) 
            stop("nRep should be numeric")
        out$methods$nRep <- nRep
    }
    out$multimp <- list(multimp = multimp)
    if (!is.logical(multimp)) 
        stop("multimp should be TRUE or FALSE")
    if (multimp) {
        if (!is.null(args_mice) && !is.list(args_mice)) 
            stop("args_mice should be a list")
        if (is.null(args_mice)) 
            args_mice <- list()
        args_mice$print <- FALSE
        if (!is.null(args_mice$data)) 
            warning("args_mice$data is overwritten by data")
        args_mice$data <- data
        out$multimp$args_mice <- args_mice
    }
    if (!multimp && model %in% c("wb", "iorw", "ne", "msm")) {
        if (sum(is.na(data)) > 0) 
            stop("Selected model doesn't support missing values; use multimp = TRUE")
    }
    environment(regrun) <- environment()
    regs <- regrun()
    yreg <- regs$yreg
    ereg <- regs$ereg
    mreg <- regs$mreg
    wmnomreg <- regs$wmnomreg
    wmdenomreg <- regs$wmdenomreg
    postcreg <- regs$postcreg
    if (inference == "bootstrap") {
        env <- environment()
        counter <- 0
        progbar <- txtProgressBar(min = 0, max = nboot, style = 3)
    }
    environment(estinf) <- environment()
    out <- c(out, estinf())
    if (mval_grid_active) {
        mval_grid_results <- out$mval_grid_results
        if (is.null(mval_grid_results)) 
            stop("Internal error: mval_grid_results were not returned")
        mval_grid_info <- out$mval_grid
        if (is.null(mval_grid_info)) {
            mval_grid_info <- list(values = mval_grid, combinations = mval_grid_combos, 
                labels = mval_grid_labels)
        }
        out$mval_grid_results <- NULL
        out$mval_grid <- mval_grid_info
        out$reg.input <- .sanitize_cmest_regressions(out$reg.input)
        out$mval_results <- lapply(seq_along(mval_grid_results), 
            function(i) {
                child <- list(call = out$call, data = out$data, 
                  methods = out$methods, variables = out$variables, 
                  reg.input = out$reg.input, multimp = out$multimp, 
                  ref = out$ref, reg.output = mval_grid_results[[i]]$reg.output, 
                  effect.pe = mval_grid_results[[i]]$effect.pe, 
                  effect.se = mval_grid_results[[i]]$effect.se, 
                  effect.ci.low = mval_grid_results[[i]]$effect.ci.low, 
                  effect.ci.high = mval_grid_results[[i]]$effect.ci.high, 
                  effect.pval = mval_grid_results[[i]]$effect.pval, 
                  bootstrap_provenance = mval_grid_results[[i]]$bootstrap_provenance)
                child$methods$mval_grid <- NULL
                child$methods$max_mval_combinations <- NULL
                child$ref$mval <- mval_grid_info$combinations[[i]]
                child$call$mval_grid <- NULL
                child$call$max_mval_combinations <- NULL
                child$call$mval <- mval_grid_info$combinations[[i]]
                if (!is.null(child$variables) && "mval" %in% 
                  names(child$variables)) {
                  child$variables$mval <- mval_grid_info$combinations[[i]]
                }
                if (!is.null(child$reg.input) && "mval" %in% 
                  names(child$reg.input)) {
                  child$reg.input$mval <- mval_grid_info$combinations[[i]]
                }
                class(child) <- "cmest"
                child
            })
        names(out$mval_results) <- names(mval_grid_results)
        first_result <- out$mval_results[[1]]
        out$effect.pe <- first_result$effect.pe
        out$effect.se <- first_result$effect.se
        out$effect.ci.low <- first_result$effect.ci.low
        out$effect.ci.high <- first_result$effect.ci.high
        out$effect.pval <- first_result$effect.pval
        out$reg.output <- first_result$reg.output
        class(out) <- "cmest_mval_grid"
    }
    else {
        class(out) <- "cmest"
    }
    return(out)
}
