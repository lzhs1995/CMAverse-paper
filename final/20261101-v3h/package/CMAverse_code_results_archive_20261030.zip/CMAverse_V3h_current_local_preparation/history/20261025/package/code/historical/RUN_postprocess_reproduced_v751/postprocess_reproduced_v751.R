# 2026-09-27：从已回读验证的完整模型所导出的逐次值重建异质性表；不重新拟合。
local({
 root <- Sys.getenv('CMAVERSE_RECOVERY_ROOT','/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927')
 ref <- file.path(root,'sources/extracted/v751_empirical/research/20260908_v751_paper_revision_heterogeneity')
 out <- file.path(root,'results/derived_v751');dir.create(out,recursive=TRUE,showWarnings=FALSE)
 chains <- c('AA-S','AA-P','AR-S','AR-P','RA-S','RA-P','RR-S','RR-P')
 dimensions <- c('gender_begin','lifetime_begin','urban_begin')
 effects <- unique(read.csv(file.path(dirname(ref),'20260906_cmaverse_manuscript_v7_5_1/results/native_272_results.csv'))$effect)
 stopifnot(length(effects)==17L,identical(effects[1:6],c('Rcde','rRpnde','rRtnde','rRpnie','rRtnie','Rte')))
 native_rows <- list();group_rows <- list();difference_rows <- list();qa <- list()
 for(g in dimensions)for(ch in chains) {
  cat('DERIVE',g,ch,'\n');flush.console();vals<-list()
  for(level in 0:1) {
   key <- paste(ch,g,level,sep='__');dir <- file.path(root,'results/formal/heterogeneity',key)
   v <- jsonlite::read_json(file.path(dir,'validation.json'),simplifyVector=TRUE)
   stopifnot(v$full_object_validated,v$historical_numeric_match,v$B==1000L)
   tab <- read.csv(file.path(dir,'effects_full.csv'),check.names=FALSE)
   draws <- as.matrix(read.csv(file.path(dir,'bootstrap_effect_draws_raw.csv'),check.names=FALSE))
   diag <- read.csv(file.path(dir,'repeat_diagnostics.csv'))
   data <- readRDS(file.path(root,'data',paste0(key,'.rds')))
   stopifnot(identical(dim(draws),c(1000L,34L)),nrow(data)==v$N)
   valid <- diag$execution_ok & diag$fits_valid & diag$core_finite
   display <- exp(draws[,c(1:6,18:23),drop=FALSE]);valid<-valid & rowSums(is.finite(display))==12L
   stopifnot(sum(valid)==v$valid_repeats)
   child <- tab[tab$mval==0,,drop=FALSE];other<-tab[tab$mval==1,,drop=FALSE]
   stopifnot(identical(child$effect,effects),identical(other$effect,effects))
   for(m in 0:1) {
    e<-if(m==0)child else other;block<-draws[,1:17+m*17,drop=FALSE];block[,1:6]<-exp(block[,1:6])
    native_rows[[paste(key,m)]] <- data.frame(chain=ch,dimension=g,level=level,mval=m,effect=effects,
     estimate=e$estimate,se=e$se,conf_low=e$conf_low,conf_high=e$conf_high,p_native=e$p_value,
     N=nrow(data),actors=length(unique(data$actor_pid)),clusters=length(unique(data$cluster_id)),
     B_attempted=1000L,B_valid=sum(valid),B_finite_display_scale=colSums(is.finite(block)),
     source=v$object_path,sha256=v$object_sha256,interpretation_status=ifelse(effects%in%effects[1:6],
      if(all(valid))'exploratory_OR_limited' else 'inference_blocked_failed_repeats','ER_proportion_interpretation_suspended'))
   }
   i<-match('rRtnie',effects);ic<-match('Rcde',effects)
   ie<-draws[,i];delta<-exp(draws[,17L+ic])-exp(draws[,ic])
   iepoint<-log(child$estimate[i]);dpoint<-other$estimate[ic]-child$estimate[ic]
   vals[[level+1L]]<-list(ie=ie,delta=delta,iepoint=iepoint,dpoint=dpoint,valid=valid)
   group_rows[[key]]<-data.frame(chain=ch,dimension=g,level=level,N=nrow(data),actors=length(unique(data$actor_pid)),
    clusters=length(unique(data$cluster_id)),IE_OR=exp(iepoint),IE_low=child$conf_low[i],IE_high=child$conf_high[i],
    delta_OR=dpoint,delta_low=if(all(is.finite(delta)))unname(quantile(delta,.025))else NA_real_,
    delta_high=if(all(is.finite(delta)))unname(quantile(delta,.975))else NA_real_,B_attempted=1000L,B_valid=sum(valid),
    status=if(all(valid))'estimable_limited'else'blocked_failed_repeats')
   qa[[key]]<-data.frame(key=key,full_object_readback_previously_passed=v$full_object_validated,
     all_repeats_valid=all(valid),B_attempted=1000L,B_valid=sum(valid))
  }
  for(what in c('IE_logOR','Delta_OR')) {
   draws<-if(what=='IE_logOR')vals[[2]]$ie-vals[[1]]$ie else vals[[2]]$delta-vals[[1]]$delta
   point<-if(what=='IE_logOR')vals[[2]]$iepoint-vals[[1]]$iepoint else vals[[2]]$dpoint-vals[[1]]$dpoint
   valid<-vals[[1]]$valid & vals[[2]]$valid & is.finite(draws)
   status<-if(all(valid)&&is.finite(point))'estimable_limited'else'blocked_failed_repeats'
   p<-if(status=='estimable_limited')(1+sum(abs(draws-point)>=abs(point)))/(length(draws)+1)else NA_real_
   difference_rows[[paste(ch,g,what)]]<-data.frame(chain=ch,dimension=g,contrast=what,estimate=point,
    conf_low=if(all(valid))unname(quantile(draws,.025))else NA_real_,conf_high=if(all(valid))unname(quantile(draws,.975))else NA_real_,
    p_centered_bootstrap=p,B_attempted=1000L,B_valid=sum(valid),status=status,direction='group1_minus_group0')
   saveRDS(data.frame(replicate=1:1000,draw=draws,valid=valid),file.path(out,paste(ch,g,what,'paired_draws.rds',sep='__')))
  }
 }
 diff<-do.call(rbind,difference_rows);diff$q_BH<-NA_real_
 for(what in unique(diff$contrast)) {
  rows<-which(diff$contrast==what);ok<-rows[is.finite(diff$p_centered_bootstrap[rows])]
  diff$q_BH[ok]<-p.adjust(diff$p_centered_bootstrap[ok],method='BH',n=24L)
 }
 outputs<-list(heterogeneity_native_1632_results=do.call(rbind,native_rows),
  heterogeneity_48_group_estimates=do.call(rbind,group_rows),heterogeneity_48_direct_differences=diff)
 validations<-list()
 for(name in names(outputs)) {
  actual<-outputs[[name]];expected<-read.csv(file.path(ref,'results',paste0(name,'.csv')),check.names=FALSE)
  stopifnot(identical(names(actual),names(expected)),nrow(actual)==nrow(expected))
  for(col in setdiff(names(expected),c('source','sha256'))) {
   a<-actual[[col]];b<-expected[[col]]
   pass<-if(is.numeric(a)&&is.numeric(b))isTRUE(all.equal(a,b,tolerance=1e-10,check.attributes=FALSE))else identical(a,b)
   validations[[paste(name,col)]]<-data.frame(file=name,column=col,values=length(a),pass=pass)
  }
  write.csv(actual,file.path(out,paste0(name,'.csv')),row.names=FALSE)
 }
 check<-do.call(rbind,validations)
 write.csv(check,file.path(root,'evidence/v751_postprocess_comparison.csv'),row.names=FALSE)
 write.csv(do.call(rbind,qa),file.path(out,'group_validation_summary.csv'),row.names=FALSE)
 stopifnot(all(check$pass),sum(diff$status=='estimable_limited')==40L,sum(diff$status=='blocked_failed_repeats')==8L)
 jsonlite::write_json(list(status='PASS',columns_checked=nrow(check),numeric_and_metadata_values=sum(check$values),
  source_paths_and_serialization_hashes_replaced=TRUE,model_fits_performed=0L,groups=48L,differences=48L,
  inferable_differences=40L,blocked_differences=8L,created_at=as.character(Sys.time())),
  file.path(root,'evidence/v751_postprocess_comparison.json'),pretty=TRUE,auto_unbox=TRUE)
 cat('V751_POSTPROCESS_MATCHES_HISTORICAL\n');flush.console()
})
