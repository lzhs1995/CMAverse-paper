# 2026-09-27：恢复云端缺失的60组；为连续RNG重放三个mediator的75组。
recovery_root <- Sys.getenv('CMAVERSE_RECOVERY_ROOT','/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927')
Sys.setenv(CMAVERSE_RECOVERY_ROOT=recovery_root,
 NEW47_PROJECT_ROOT=file.path(recovery_root,'runtime/legacy_new47'),
 NEW47_OUTPUT_ROOT=file.path(recovery_root,'results/legacy_new47/recomputed'),
 NEW47_RUN_ID='recovery_20260927_original_n100',NEW47_NBOOT='100',NEW47_SEED='12345',
 NEW47_ORIGINAL_SCRIPT=file.path(recovery_root,'sources/legacy/scripts/20251202 CMAverse_4_way Decomposition_g_formula_new4.7.R'),
 NEW47_TARGET_SCRIPT=file.path(recovery_root,'sources/legacy/scripts/20251202 CMAverse_4_way Decomposition_g_formula_new4.7_native_mval_grid_delta_cde.R'),
 NEW47_DATA_PATH=file.path(recovery_root,'sources/extracted/v751_empirical/stata_source_snapshot/0_data/causal_mediation_18&20_20&22_bal.csv'),
 NEW47_REQUIRE_SECTION4='true',NEW47_UPLOAD_REQUIRED='false',NEW47_ARCHIVE_WAIT_REQUIRED='false',
 NEW47_FORMAL_RUN='false',NEW47_ARM_FULL_RUN='false')
.libPaths(c(file.path(recovery_root,'runtime/library'),.libPaths()))
source(file.path(recovery_root,'runtime/legacy_new47/R/new47_common.R'))
Sys.setenv(NEW47_GROUPS=paste(NEW47_GROUPS,collapse=','))
recovery_mediators <- c('msat_c21_3','msat_c2_2','msateco_c2_2')
for(recovery_mediator in recovery_mediators) {
 Sys.setenv(NEW47_MEDIATOR=recovery_mediator)
 # 保留异步作业环境注入的clauder_progress；RNG仍由工作器显式读写.GlobalEnv。
 source(file.path(recovery_root,'runtime/legacy_new47/R/worker.R'),local=environment())
}
checks <- do.call(rbind,lapply(recovery_mediators,function(m)
 read.csv(file.path(recovery_root,'results/legacy_new47/recomputed',paste0('validation_',m,'.csv')))))
stopifnot(nrow(checks)==75L,all(checks$pass))
write.csv(checks,file.path(recovery_root,'evidence/legacy_recomputed_75_validation.csv'),row.names=FALSE)
jsonlite::write_json(list(status='PASS',groups_completed=75L,missing_remote_groups=60L,
 additional_groups_for_continuous_rng_replay=15L,completed_at=as.character(Sys.time()),
 historical_full_n1000_not_executed=TRUE),file.path(recovery_root,'evidence/legacy_rebuild_summary.json'),pretty=TRUE,auto_unbox=TRUE)
if(exists('clauder_progress',mode='function'))clauder_progress('complete','new4.7三个mediator的75组连续重放完成，缺失60组已重建')
cat('LEGACY_NEW47_REBUILD_COMPLETE\n');flush.console()
