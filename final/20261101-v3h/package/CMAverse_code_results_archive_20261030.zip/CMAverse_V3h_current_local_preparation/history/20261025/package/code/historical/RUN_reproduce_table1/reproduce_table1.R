# 2026-09-27：在正式CMAverse批次之后串行恢复原描述表；不改研究模型。
local({
  recovery_root <- Sys.getenv('CMAVERSE_RECOVERY_ROOT','/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927')
  .libPaths(c(file.path(recovery_root,'runtime/library'),.libPaths()))
  stopifnot(as.character(utils::packageVersion('compareGroups'))=='4.10.2')
  out <- file.path(recovery_root,'results/table1')
  done <- file.path(recovery_root,'evidence/table1_execution.json')
  if(file.exists(done))stop('描述表已执行；先查证据，不重复覆盖')
  progress <- function(stage,message) {
    cat(stage,message,'\n');flush.console()
    jsonlite::write_json(list(stage=stage,message=message,updated_at=as.character(Sys.time()),pid=Sys.getpid()),
      file.path(recovery_root,'evidence/table1_runtime_status.json'),pretty=TRUE,auto_unbox=TRUE)
    if(exists('clauder_progress',mode='function'))clauder_progress(stage,message)
  }
  progress('table1_prepare','读取冻结DTA标签和CSV，恢复描述表双轨')
  source(file.path(out,'scripts/04_run_comparegroups_dual_track.R'),local=TRUE)
  progress('table1_postprocess','比较原143行和当前106行，核查分母与7组41变量')
  source(file.path(out,'scripts/05_finalize_statistics.R'),local=TRUE)
  source(file.path(out,'scripts/07_statistical_regression_tests.R'),local=TRUE)
  # 原清单还包含首次未恢复factor的诊断对象；显式保留其错误身份，不能用于论文。
  progress('table1_legacy_diagnostic','恢复未转换factor的历史诊断对象，仅用于故障证据')
  raw_env <- new.env(parent=environment())
  raw_env$dat <- read.csv(file.path(out,'data/historical.csv'),check.names=FALSE,na.strings=c('','NA'))
  attrs <- readRDS(file.path(out,'data/historical_attributes.rds'))
  for(n in names(raw_env$dat))attributes(raw_env$dat[[n]])<-attrs[[n]]
  block_contract <- readRDS(file.path(out,'spec/block_contract.rds'))
  raw_env$dat$time_period <- factor(raw_env$dat$time_period,levels=c(0,1),labels=c('2018-2020','2020-2022'))
  attr(raw_env$dat$time_period,'label') <- '变化周期'
  raw_env$my_data.dist <- raw_env$dat[,unique(c(unlist(block_contract$historical),'time_period')),drop=FALSE]
  expressions <- readRDS(file.path(out,'history/historical_objects.rds'))$source_expressions
  for(n in names(expressions))eval(expressions[[n]],envir=raw_env)
  objs <- setNames(lapply(names(block_contract$historical),function(n)list(
    compareGroups=get(n,envir=raw_env),createTable=get(paste0('restab.',n),envir=raw_env))),names(block_contract$historical))
  saveRDS(list(objects=objs,combined=raw_env$restab,source_expressions=expressions,
      recovery_note='Historical diagnostic without categorical factor restoration; NOT a manuscript result'),
      file.path(out,'history/legacy_without_factor_restoration_objects.rds'))
  files <- list.files(out,pattern='\\.rds$',recursive=TRUE,full.names=TRUE)
  checks <- lapply(files,function(p){z<-readRDS(p);list(path=p,bytes=file.info(p)$size,
    sha256=digest::digest(file=p,algo='sha256'),class=class(z),readback=TRUE)})
  jsonlite::write_json(list(executed=TRUE,pid=Sys.getpid(),completed_at=as.character(Sys.time()),
    reconstructed_objects=checks,numeric_comparison_pending=TRUE),done,pretty=TRUE,auto_unbox=TRUE)
  writeLines(capture.output(sessionInfo()),file.path(recovery_root,'evidence/table1_sessionInfo.txt'))
  progress('complete','描述对象和导出已重建；等待独立历史数值比较')
})
