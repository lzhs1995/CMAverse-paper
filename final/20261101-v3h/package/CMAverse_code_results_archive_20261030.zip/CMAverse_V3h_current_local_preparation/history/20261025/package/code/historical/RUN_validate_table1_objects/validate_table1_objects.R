# 2026-09-27：独立读回六个重建描述对象，与DTA标签、历史契约及冻结展示/数值逐项比较。
# 仅在reproduce_table1.R完成后运行；无模型重新拟合。
local({
  project <- Sys.getenv('CMAVERSE_RECOVERY_ROOT','/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927')
  .libPaths(c(file.path(project,'runtime/library'),.libPaths()))
  suppressPackageStartupMessages(library(compareGroups))
  suppressPackageStartupMessages(library(haven))
  suppressPackageStartupMessages(library(jsonlite))
  suppressPackageStartupMessages(library(digest))
  source(file.path(project,'runtime/table1_guide/scripts/comparegroups_common.R'),local=TRUE)
  out <- file.path(project,'results/table1')
  ref <- file.path(project,'sources/extracted/v751_empirical/research/20260907_table1_comparegroups_autofit')
  evidence <- file.path(project,'evidence/table1_objects_independent_validation.json')
  checks <- list()
  check <- function(name,ok,details=NULL) {
    checks[[length(checks)+1L]] <<- list(check=name,pass=isTRUE(ok),details=details)
    if(!isTRUE(ok))stop('描述对象独立核验失败：',name)
  }
  save_proof <- function(status,extra=list()) {
    z<-c(list(status=status,checked_at=format(Sys.time(),'%FT%T%z'),pid=Sys.getpid(),
      check_count=length(checks),checks=checks,model_fits_performed=0L),extra)
    jsonlite::write_json(z,paste0(evidence,'.partial'),pretty=TRUE,auto_unbox=TRUE,null='null')
    stopifnot(file.rename(paste0(evidence,'.partial'),evidence))
  }
  tryCatch({
    stopifnot(file.exists(file.path(project,'evidence/table1_execution.json')))
    for(track in c('current','historical')) {
      original <- haven::read_dta(file.path(out,'data',paste0(track,'.dta')))
      attrs <- readRDS(file.path(out,'data',paste0(track,'_attributes.rds')))
      check(paste0(track,'_all_DTA_attributes'),identical(attrs,lapply(original,attributes)),list(columns=ncol(original)))
    }
    contracts <- readRDS(file.path(out,'spec/block_contract.rds'))
    historical_spec <- jsonlite::read_json(file.path(ref,'spec/historical-table-spec.json'),simplifyVector=TRUE)
    check('historical_block_contract',identical(contracts$historical,historical_spec$blocks))
    check('current_7_blocks_41_variables',length(contracts$current)==7L && length(unlist(contracts$current))==41L &&
      !anyDuplicated(unlist(contracts$current)))
    historical <- readRDS(file.path(out,'history/historical_objects.rds'))
    check('historical_all_compareGroups_and_createTable',setequal(names(historical$objects),names(contracts$historical)) &&
      all(vapply(historical$objects,function(x)inherits(x$compareGroups,'compareGroups') && inherits(x$createTable,'createTable'),logical(1))))
    display <- cg_display_frame(historical$combined,'combined','历史七组','historical')
    numeric <- do.call(rbind,lapply(names(historical$objects),function(n)cg_numeric_frame(
      historical$objects[[n]]$compareGroups,historical$objects[[n]]$createTable,n,'historical')))
    check('historical_RDS_to_frozen_display',cg_csv_matches(file.path(ref,'history/historical_display.csv'),display))
    check('historical_RDS_to_frozen_numeric',cg_csv_matches(file.path(ref,'history/historical_numeric_long.csv'),numeric,TRUE))
    current <- readRDS(file.path(out,'current/results/Table1_current_objects.rds'))
    replay <- cg_replay_objects(current)
    check('current_RDS_to_frozen_display',cg_csv_matches(file.path(ref,'current/results/Table1_current_display.csv'),replay$display))
    check('current_RDS_to_frozen_numeric',cg_csv_matches(file.path(ref,'current/results/Table1_current_numeric_long.csv'),replay$numeric,TRUE))
    current_validation <- cg_validate_outputs(file.path(out,'current/results'),'Table1_current')
    check('current_full_manifest_and_semantic_checklist',identical(current_validation$decision,'PASS'),current_validation)
    diagnostic <- readRDS(file.path(out,'history/legacy_without_factor_restoration_objects.rds'))
    check('unrestored_factor_diagnostic_explicitly_labelled',grepl('NOT a manuscript result',diagnostic$recovery_note,fixed=TRUE))
    check('diagnostic_has_7_complete_blocks',setequal(names(diagnostic$objects),names(contracts$historical)) &&
      all(vapply(diagnostic$objects,function(x)inherits(x$compareGroups,'compareGroups') && inherits(x$createTable,'createTable'),logical(1))))
    check('diagnostic_uses_original_extracted_expressions',identical(diagnostic$source_expressions,historical$source_expressions))
    missing <- jsonlite::read_json(file.path(project,'evidence/manuscript/original_manifest_recovery.json'))$missing
    objects <- lapply(missing,function(item) {
      relative <- substring(item$path,nchar(ref)+2L)
      path <- file.path(out,relative);z <- readRDS(path);sha <- digest::digest(file=path,algo='sha256')
      list(path=path,relative_path=relative,bytes=file.info(path)$size,sha256=sha,class=class(z),
           original_sha256=item$original_sha256,original_bytes_match=identical(sha,item$original_sha256),
           diagnostic_only=grepl('without_factor',relative,fixed=TRUE))
    })
    check('six_missing_objects_readable',length(objects)==6L)
    save_proof('PASS',list(objects=objects,original_consumption_hash_gate_unchanged=TRUE,
      unrestored_factor_diagnostic_has_independent_historical_numeric_reference=FALSE,
      original_bytes_matching=sum(vapply(objects,function(x)x$original_bytes_match,logical(1)))))
    cat('TABLE1_OBJECTS_INDEPENDENT_PASS',length(checks),'checks\n');flush.console()
    if(exists('clauder_progress',mode='function'))clauder_progress('complete','六个描述对象独立读回、标签/契约/数值验证完成')
  },error=function(e){save_proof('FAIL',list(error=conditionMessage(e)));stop(e)})
})
