## 从Stata输出恢复完整标签契约；不猜测数字类别，不重新编码协变量。
options(stringsAsFactors=FALSE,scipen=999)
root <- "/Users/lzhs/Desktop/20251202 CMAverse_4_way Decomposition/20260907_table1_comparegroups_autofit"
guide <- "/Users/lzhs/.codex/skills/comparegroups-guide"
source(file.path(guide,"scripts/comparegroups_common.R"),local=TRUE)
blocks <- list(
 dv=c("esup_2","esup_5","esup_1"),
 iv=c("aincc_2","aincc_5","aincc_1","inc_3","inc_6","inc_1"),
 mv=c("msat_c12_3","msat_c12_6","msat_c12_1","msat_c1_2","msat_c1_5","msat_c1_1",
      "msat_c2_2","msat_c2_5","msat_c2_1","msateco_c2_2","msateco_c2_5","msateco_c2_1"),
 cpsn=c("aage_begin","gender_begin","actor_edu2_begin","actor_siops_begin","ahk_begin","urban_begin",
  "child_begin","aincc_begin","ahw_begin","shealth_begin","reside_ind_begin","dwm_begin",
  "actor_siops_cat","child_cat","aincc_cat","ahw_cat","shealth_cat","reside_ind_1"),
 cprt=c("prtgender_begin","prtage_begin","prtedu_begin","prtmarr_begin","prtcor_begin","prtmarr_1","prtcor_1"),
 cfml=c("total_debts_scale_begin","fmlincc_begin","lifetime_begin","total_debts_cat","fmlincc_cat","time_period"),
 celse=c("esup_begin","aincc_begin","inc_begin","msat_c12_begin","msat_c1_begin","msat_c2_begin","msateco_c2_begin"))
labels <- c(dv="被解释变量",iv="解释变量",mv="中介变量",cpsn="个体特征",cprt="父母特征",cfml="家庭特征",celse="必要基期变量")
current <- blocks
current$dv <- "y_target"; current$iv <- c("x_abs_target","x_rel_target")
current$mv <- c("m_self_abs_target","m_spouse_abs_target","m_self_rel_target","m_spouse_rel_target")
## 旧收入三分类属于已退出的X对比，不作为“个体控制变量”混回正文。
## 其原值、全部分类及原统计量仍保留在历史轨；其他协变量类别不变。
current$cpsn <- setdiff(current$cpsn,"aincc_cat")
current$cfml <- setdiff(current$cfml,"time_period")
current$celse <- setdiff(current$celse,c("aincc_begin","msateco_c2_begin"))
stopifnot(!anyDuplicated(unlist(current)))
continuous <- c("esup_1","aincc_1","inc_1","msat_c12_1","msat_c1_1","msat_c2_1","msateco_c2_1",
 "aage_begin","actor_edu2_begin","actor_siops_begin","child_begin","aincc_begin","ahw_begin","shealth_begin","prtage_begin",
 "total_debts_scale_begin","fmlincc_begin","esup_begin","inc_begin","msat_c12_begin","msat_c1_begin","msat_c2_begin","msateco_c2_begin")
contracts<-list()
for(track in c("historical","current")){
 d<-haven::read_dta(file.path(root,"data",paste0(track,".dta")))
 csv<-read.csv(file.path(root,"data",paste0(track,".csv")),check.names=FALSE,na.strings=c("","NA"))
 stopifnot(nrow(d)==nrow(csv),!anyDuplicated(d[c("id","time_period")]),!anyNA(d[c("id","time_period")]))
 fields<-if(track=="historical")unique(c(unlist(blocks),"id","time_period"))else unique(c(unlist(current),"id","time_period",grep("eligible|event_all|identity|same_actor|same_partner|dyad|actor_pid",names(d),value=TRUE)))
 checks<-lapply(fields,function(n){
  a<-as.vector(d[[n]]);b<-csv[[n]]
  same_na<-identical(is.na(a),is.na(b))
  delta<-if(is.numeric(a))max(c(0,abs(a-as.numeric(b))),na.rm=TRUE)else NA_real_
  pass<-same_na && if(is.numeric(a))all(abs(a-as.numeric(b))<=1e-10*pmax(1,abs(a)),na.rm=TRUE)else identical(as.character(a),as.character(b))
  data.frame(track=track,variable=n,missing_equal=same_na,max_abs_difference=delta,passed=pass)
 })
 checks<-do.call(rbind,checks);stopifnot(all(checks$passed))
 write.csv(checks,file.path(root,"qa",paste0(track,"_csv_dta_roundtrip.csv")),row.names=FALSE)
 meta<-lapply(fields,function(n){
  x<-d[[n]];labs<-attr(x,"labels")
  list(name=n,label=attr(x,"label"),class=class(x),
       levels=if(is.null(labs))NULL else lapply(seq_along(labs),function(i)list(value=unname(labs[i]),label=names(labs)[i])),
       observed=if(length(unique(x))<25)sort(unique(as.vector(x)))else NULL)
 });names(meta)<-fields
 jsonlite::write_json(meta,file.path(root,"data",paste0(track,"_labels.json")),pretty=TRUE,auto_unbox=TRUE,na="null")
 saveRDS(lapply(d,attributes),file.path(root,"data",paste0(track,"_attributes.rds")))
 contracts[[track]]<-meta
 if(track=="current"){
  make_var<-function(n){
   catvar<-!n%in%continuous
   m<-meta[[n]];labs<-m$levels
   if(catvar && is.null(labs))stop("类别标签缺失: ",n)
   list(name=n,type=if(catvar)"categorical"else"continuous",
    method=if(catvar)"categorical"else"normal",digits=if(catvar)2L else 3L,
    label=m$label,include_missing=FALSE,levels=if(catvar)labs else NULL,
    reference=if(catvar){
     observed_labs<-Filter(function(z)z$value%in%m$observed,labs)
     if(!length(observed_labs))stop("类别变量没有观察到的参照状态: ",n)
     observed_labs[[1]]$label
    }else NULL)
  }
  spec<-list(spec_version="1.1",analysis_id="table1_current_identity_population",
   input=list(path=file.path(root,"data/current.csv"),format="csv",id="id",time="time_period"),
   defaults=list(continuous_digits=3L,categorical_digits=2L,p_digits=3L,include_missing=FALSE),
   analysis=list(group="time_period",panel_mode="dual",subset=NULL,
    group_reference="2018-2020",group_levels=list(list(value=0,label="2018-2020"),list(value=1,label="2020-2022")),
    note="单位为亲子二元组—区间；same_actor & same_partner & parent_identity_included；未取八链完整案例交集。"),
   blocks=lapply(names(current),function(b)list(id=b,label=labels[[b]],variables=lapply(current[[b]],make_var))),
   display=list(show_all=TRUE,show_n=TRUE,show_p_overall=TRUE,show_p_multiple=TRUE,show_p_trend=FALSE,
    hide_no="no",p_digits=3L,compatibility_export2word=FALSE,
    docx=list(font_family="Times New Roman",font_size=10.5,orientation="landscape",repeat_header=TRUE,
     title="表1 描述性统计",
     footnote="连续变量为均值（标准差），分类变量为n（%）。有效N按变量计算；增长/升级指标仅使用相应资格分母。时期p值未调整成年子女、亲子关系及跨期重复依赖，仅供探索性比较。")),
   outputs=list(stem="Table1_current",formats=list("docx","csv","rds")))
  cg_validate_spec(spec)
  jsonlite::write_json(spec,file.path(root,"spec/table-spec.json"),pretty=TRUE,auto_unbox=TRUE,null="null")
 }
}
saveRDS(list(historical=blocks,current=current,labels=labels,continuous=continuous),file.path(root,"spec/block_contract.rds"))
historical_spec<-list(spec_version="legacy-new4.7-exact",engine="compareGroups",input=file.path(root,"data/historical.csv"),
 labelled_source=file.path(root,"data/historical.dta"),key=c("id","time_period"),blocks=blocks,
 parameter_source=file.path(dirname(root),"20251202 CMAverse_4_way Decomposition_g_formula_new4.7.R"),
 policy="Extract only seven compareGroups, seven createTable assignments and rbind; no source of full script.",
 warning="历史编码只供复现；普通时期p值未调整重复依赖。")
jsonlite::write_json(historical_spec,file.path(root,"spec/historical-table-spec.json"),pretty=TRUE,auto_unbox=TRUE)
cat("SPEC_READY current_variables=",length(unlist(current)),"\n")
