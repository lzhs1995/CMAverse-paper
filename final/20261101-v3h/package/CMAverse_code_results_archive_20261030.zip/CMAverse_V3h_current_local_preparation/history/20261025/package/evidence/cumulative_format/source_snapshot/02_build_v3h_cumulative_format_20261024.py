#!/usr/bin/env python3
"""将批准的最小格式差异叠加到旧修订稿；输入三稿及候选不重写。"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import copy, deepcopy
import json
from pathlib import Path
import sys
import traceback
from zipfile import ZipFile

import v3h_word_contract as c
import v3h_revision_projection_v2 as projection
from docx.oxml import parse_xml
from docx.oxml.ns import qn
from lxml import etree as ET

N = c.HERE
MINIMAL = N / 'v3h_minimal_format_20261024_v1'
CANDIDATE = MINIMAL / 'CMAverse_V3h_minimal_format_candidate.docx'
PINS = {
    CANDIDATE: '38a9d70f7095d8b063d96e1e95e8bcb41ae7539a35dacc3faa11679c1e6837ab',
    MINIMAL / 'SOURCE_CONTRACT.json': '475c3f6e1a92ad7be9b8daf450c112498d837d10ae419b61df60e787f20712e5',
    MINIMAL / 'VALIDATION.json': '379e3d2e908b62c300c7f414a2fe23e6e5142696c9832c472c8c0524905e5b57',
    MINIMAL / 'MANIFEST.json': 'a5b8c8a78665307a65aa800030617292798504e3a49bf541b8984f03fbef381f',
    N / 'v3h_minimal_format_independent_acceptance_20261024_v1/RESULT.json':
        'daafb33648041b6b42ce7152e8c0e6627d6024224d5242bbc905859226b29d3d',
}


def xml_sha(element):
    return c.digest(ET.tostring(element, method='c14n')) if element is not None else None


def member_xml(path, name):
    with ZipFile(path) as archive:
        return parse_xml(archive.read(name))


def write_zip(source, destination, replacements):
    with ZipFile(source) as zin, ZipFile(destination, 'x') as zout:
        zout.comment = zin.comment
        for info in zin.infolist():
            zout.writestr(copy(info), replacements.get(info.filename, zin.read(info.filename)))


def xml_bytes(root):
    return ET.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)


def input_bindings():
    refs = c.frozen_inputs()
    refs.extend(c.verify_binding({'path': str(path), 'sha256': sha}) for path, sha in PINS.items())
    manifest = json.loads((MINIMAL / 'MANIFEST.json').read_text(encoding='utf-8'))
    journal = [x for x in manifest['files'] if x['path'] == str(MINIMAL / 'PROPERTY_PATCH_JOURNAL.json')]
    c.require(len(journal) == 1, 'PATCH_JOURNAL_NOT_BOUND')
    refs.append(c.verify_binding(journal[0]))
    return refs


def implementation_bindings():
    """固定本次实际导入的任务/共享源码，包含间接的journal_layout。"""
    paths = {Path(__file__).resolve()}
    roots = (N / 'scripts', c.WORD / 'scripts')
    for module in tuple(sys.modules.values()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            if path.suffix == '.py' and any(path.is_relative_to(root) for root in roots):
                paths.add(path)
    return [c.binding(path) for path in sorted(paths)]


def materialize_terminator(root, contract):
    """保留原styles.xml时，将空白书目结束段的已批准继承结果显式化。"""
    ps = root.find(qn('w:body')).findall(qn('w:p'))
    c.require(len(ps) == 312 and not ps[311].xpath('.//w:t/text()'), 'EMPTY_TERMINATOR_CHANGED')
    pr = ps[311].find(qn('w:pPr'))
    c.require(pr is not None and pr.find(qn('w:pStyle')).get(qn('w:val')) == 'afc',
              'TERMINATOR_STYLE_CHANGED')
    story_index = list(root.iter(qn('w:p'))).index(ps[311])
    approved = contract['views']['accepted']['stories']['word/document.xml'][story_index]
    effective = c.properties(c.mf.effective_paragraph(c.Document(CANDIDATE), ps[311]))
    c.require(approved['characters'] == 0 and approved['paragraph_properties'] == effective,
              'TERMINATOR_EFFECTIVE_FORMAT_DIFFERS_FROM_FROZEN_CONTRACT')
    approved_indent = approved['paragraph_properties']['ind']
    c.require(approved_indent == {'firstLineChars': '0', 'firstLine': '420',
                                 'left': '720', 'hanging': '720'},
              'TERMINATOR_APPROVED_INDENT_CHANGED')
    ind = pr.find(qn('w:ind'))
    c.require(ind is not None and ind.get(qn('w:firstLine')) == approved_indent['firstLine'],
              'TERMINATOR_DIRECT_FIRST_LINE_CHANGED')
    for name, value in approved_indent.items():
        ind.set(qn('w:' + name), value)
    return ps[311]


def build(out):
    c.require(not out.exists(), 'OUTPUT_EXISTS_DO_NOT_REPLAY: ' + str(out))
    frozen_before = input_bindings()
    dependencies_before = implementation_bindings()
    out.mkdir(parents=True)
    snapshots = []
    for index, ref in enumerate(dependencies_before):
        destination = out / 'source_snapshot' / f'{index:02d}_{Path(ref["path"]).name}'
        destination.parent.mkdir(exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(Path(ref['path']).read_bytes())
        copied = c.binding(destination)
        c.require(copied['sha256'] == ref['sha256'], 'SOURCE_SNAPSHOT_CHANGED')
        snapshots.append({'original': ref, 'snapshot': copied})
    c.write_new(out / 'INTENT.json', {'at': c.now(), 'review_mode': 'solo_self_review',
                'operation': 'offline_cumulative_property_revisions', 'inputs': frozen_before,
                'dependencies': dependencies_before, 'source_snapshots': snapshots,
                'python_executable': c.binding(Path(sys.executable)), 'python_version': sys.version,
                'native_invocation': False, 'statistics_execution': False})
    print(json.dumps({'stage': 'map_accepted_projection', 'at': c.now()}), flush=True)
    old_root = member_xml(c.ACCEPTED, 'word/document.xml')
    tracked = member_xml(c.TRACKED, 'word/document.xml')
    candidate_root = member_xml(CANDIDATE, 'word/document.xml')
    accepted, origins = projection.accepted_projection_with_origins(tracked)
    c.require(projection.tree_key(accepted) == projection.tree_key(old_root), 'OLD_ACCEPTED_TREE_NOT_IDENTICAL')
    with ZipFile(c.TRACKED) as archive, ZipFile(c.BASELINE) as baseline:
        c.require(archive.read('word/styles.xml') == baseline.read('word/styles.xml'), 'STYLE_MASTER_CHANGED')
        story_names = [name for name in archive.namelist() if c.STORY.fullmatch(name)]
        for name in story_names:
            projection.validate_revision_shapes(parse_xml(archive.read(name)))
        maximum_id = max(int(e.get(qn('w:id'))) for name in story_names
                         for e in parse_xml(archive.read(name)).iter()
                         if e.tag in projection.REVISION_TAGS)
    journal = json.loads((MINIMAL / 'PROPERTY_PATCH_JOURNAL.json').read_text(encoding='utf-8'))
    c.require(Counter(row['tag'] for row in journal['properties']) ==
              {'w:rPr': 280, 'w:pPr': 155, 'w:tcPr': 129}, 'APPROVED_PATCH_COVERAGE_CHANGED')
    records = []
    touched = set()
    date = c.now().split('.')[0] + 'Z'
    for row in journal['properties']:
        xpath, tag = row['parent_xpath'], row['tag']
        c.require((xpath, tag) not in touched, 'DUPLICATE_PATCH_TARGET')
        touched.add((xpath, tag))
        old_nodes = accepted.getroottree().xpath(xpath, namespaces=accepted.nsmap)
        new_nodes = candidate_root.getroottree().xpath(xpath, namespaces=candidate_root.nsmap)
        c.require(len(old_nodes) == len(new_nodes) == 1, 'PATCH_TARGET_NOT_UNIQUE')
        old_pr, desired = old_nodes[0].find(qn(tag)), new_nodes[0].find(qn(tag))
        c.require(xml_sha(old_pr) == row['old_sha256'] and xml_sha(desired) == row['new_sha256'],
                  'PATCH_PROPERTY_PIN_CHANGED: ' + xpath)
        target = origins[old_nodes[0]]
        maximum_id += 1
        changed = projection.append_property_revision(target, desired, revision_id=maximum_id,
                                                       author='Codex', date=date)
        records.append({**row, 'tracked_parent_xpath': tracked.getroottree().getpath(target), **changed})

    contract = json.loads((MINIMAL / 'SOURCE_CONTRACT.json').read_text(encoding='utf-8'))
    expected = deepcopy(candidate_root)
    terminator = materialize_terminator(expected, contract)
    old_terminator = accepted.find(qn('w:body')).findall(qn('w:p'))[311]
    maximum_id += 1
    changed = projection.append_property_revision(origins[old_terminator], terminator.find(qn('w:pPr')),
                                                   revision_id=maximum_id, author='Codex', date=date)
    records.append({'parent_xpath': '/w:document/w:body/w:p[312]', 'tag': 'w:pPr',
                    'old_sha256': xml_sha(old_terminator.find(qn('w:pPr'))),
                    'new_sha256': xml_sha(terminator.find(qn('w:pPr'))),
                    'reasons': ['MATERIALIZE_APPROVED_EMPTY_BIBLIOGRAPHY_TERMINATOR_INHERITANCE'],
                    'bibliography_entry': False, **changed})
    new_accepted = projection.resolve(tracked, True)
    c.require(projection.tree_key(new_accepted) == projection.tree_key(expected),
              'NEW_ACCEPTED_TREE_DIFFERS_OUTSIDE_APPROVED_PROPERTY_SET')
    original_rejected = projection.resolve(member_xml(c.TRACKED, 'word/document.xml'), False)
    new_rejected = projection.resolve(tracked, False)
    c.require(projection.tree_key(new_rejected) == projection.tree_key(original_rejected),
              'CUMULATIVE_REJECT_DIFFERS_FROM_PREVIOUS_REJECT')
    c.require(c.compiler.normalized(new_rejected) == c.compiler.normalized(member_xml(c.BASELINE, 'word/document.xml')),
              'CUMULATIVE_REJECT_NOT_MOTHER_EQUIVALENT')
    old_counts = projection.revisions(member_xml(c.TRACKED, 'word/document.xml'))
    new_counts = projection.revisions(tracked)
    new_ids = [e.get(qn('w:id')) for e in tracked.iter() if e.tag in projection.REVISION_TAGS]
    c.require(len(new_ids) == len(set(new_ids)), 'DUPLICATE_REVISION_IDS')
    c.write_new(out / 'PROPERTY_REVISION_MAP.json', {'at': c.now(), 'records': records,
                'original_patch_count': 564, 'materialized_empty_terminator_count': 1,
                'modes': dict(Counter(row['mode'] for row in records)),
                'old_document_counts': old_counts, 'new_document_counts': new_counts})
    paths = {label: out / ('CMAverse_V3h_minimal_format_' + label + '.docx')
             for label in ('cumulative_tracked', 'accept_all_validation', 'reject_all_validation')}
    write_zip(c.TRACKED, paths['cumulative_tracked'], {'word/document.xml': xml_bytes(tracked)})
    with ZipFile(paths['cumulative_tracked']) as archive:
        roots = {name: parse_xml(archive.read(name)) for name in story_names}
    for label, accept_view in [('accept_all_validation', True), ('reject_all_validation', False)]:
        write_zip(paths['cumulative_tracked'], paths[label],
                  {name: xml_bytes(projection.resolve(root, accept_view)) for name, root in roots.items()})

    print(json.dumps({'stage': 'validate_new_cumulative_views', 'at': c.now(),
                      'properties': len(records), 'counts': new_counts}), flush=True)
    checks = {}
    for label, view in [('accept_all_validation', 'accepted'), ('reject_all_validation', 'rejected')]:
        path = paths[label]
        checks[label] = {
            'format': c.check_source_contract(path, contract, view=view),
            'content': c.check_content_contract(path, contract, view=view),
            'no_revisions': not any(c.revision_counts(path).values()),
        }
        c.write_new(out / ('VIEW_CONTRACT_' + label.upper() + '.json'), checks[label])
        c.require(checks[label]['format']['all_pass'] and checks[label]['content']['all_pass']
                  and checks[label]['no_revisions'], 'NEW_CUMULATIVE_CONTRACT_FAILED: ' + label)
    member_records = []
    with ZipFile(c.TRACKED) as old_zip, ZipFile(paths['cumulative_tracked']) as new_zip:
        c.require(old_zip.namelist() == new_zip.namelist() and new_zip.testzip() is None, 'ZIP_INVALID')
        for name in old_zip.namelist():
            old_bytes, new_bytes = old_zip.read(name), new_zip.read(name)
            c.require(name == 'word/document.xml' or old_bytes == new_bytes, 'UNEXPECTED_TRACKED_ZIP_CHANGE: ' + name)
            member_records.append({'name': name, 'before_sha256': c.digest(old_bytes),
                                   'after_sha256': c.digest(new_bytes), 'unchanged': old_bytes == new_bytes})
    story_evidence = []
    for name in story_names:
        after = member_xml(paths['reject_all_validation'], name)
        mother = member_xml(c.BASELINE, name)
        same = c.compiler.normalized(after) == c.compiler.normalized(mother)
        c.require(same, 'REJECT_STORY_DIFFERS_FROM_MOTHER: ' + name)
        story_evidence.append({'story': name, 'reject_mother_normalized_equal': same,
                               'tracked_revision_counts': projection.revisions(roots[name])})
    before = c.frozen_inputs()
    c.require(before == frozen_before[:len(before)] and input_bindings() == frozen_before, 'FROZEN_INPUT_CHANGED')
    c.require(implementation_bindings() == dependencies_before, 'EXECUTION_SOURCE_CHANGED')
    deps = dependencies_before
    c.write_new(out / 'ZIP_MEMBER_READBACK.json', {'members': member_records, 'crc_pass': True})
    c.write_new(out / 'VIEW_CONTRACT_CHECKS.json', checks)
    result = {'schema': 'cmaverse-v3h-cumulative-format-validation-v1', 'at': c.now(),
              'state': 'PASS_CUMULATIVE_REVISIONS_OFFLINE_ONLY', 'review_mode': 'solo_self_review',
              'candidate': c.binding(CANDIDATE), 'source_contract': c.binding(MINIMAL / 'SOURCE_CONTRACT.json'),
              'outputs': {key: c.binding(path) for key, path in paths.items()},
              'inputs': frozen_before, 'dependencies': deps,
              'all_564_approved_property_changes_tracked': True,
              'style_strategy': 'preserve original styles.xml and track equivalent direct bibliography indents',
              'bibliography_entries': 25, 'empty_terminator_direct_materialization': True,
              'property_operations': len(records), 'modes': dict(Counter(row['mode'] for row in records)),
              'accepted_document_equals_candidate_except_explicit_empty_terminator_indent': True,
              'all_story_accepted_format_and_content_match_candidate': True,
              'all_story_rejected_format_and_content_match_mother': True,
              'stories': story_evidence, 'tracked_changed_zip_parts': ['word/document.xml'],
              'frozen_inputs_unchanged': True, 'word_invoked': False, 'zotero_invoked': False,
              'statistics_executed': False, 'shared_format_gate': 'FAIL_63_PENDING_PUBLISHED_ROLE_IMPLEMENTATION',
              'native_accept_reject_save_close_reopen': 'PENDING', 'final_paper_acceptance': False}
    c.write_new(out / 'RESULT.json', result)
    merged_count = result['modes'].get('MERGED_KEEP_ORIGINAL_OLD_VALUE', 0)
    report = f'''# V3h 累计格式修订稿（离线核验）

原有文字修订之上已叠加564项批准属性修改，并将空白书目结束段的继承缩进落实为可拒绝的直接属性。
25条书目保持同一文字和域；空白结束段不计为第26条。累计稿保留V3g的styles.xml，
避免“拒绝全部”后遗留不可撤回的书目样式修改。{merged_count}个已有属性修订保留最初旧值及原修订ID。

接受投影：9个story的全文、域、表格、图片及实际段落/字符格式与最小候选一致。
拒绝投影：9个story与V3g母稿等价。表格边框的tcPrChange已纳入投影与完整结构比较。
原稿、旧三稿和最小候选均未修改；只生成本目录累计稿及接受/拒绝验证副本。

这不是Word原生验收。共享角色实现、C3/F2/F5、原生接受/拒绝保存重开、最终PDF和后续NLM/发布仍待完成。
自审方式为solo_self_review，统计未执行。
'''
    (out / 'REPORT.md').write_text(report, encoding='utf-8')
    c.write_new(out / 'MANIFEST.json', {'at': c.now(), 'files': [c.binding(p) for p in sorted(out.rglob('*')) if p.is_file()]})
    print(json.dumps({'state': result['state'], 'outputs': result['outputs'],
                      'property_operations': len(records), 'modes': result['modes']}, ensure_ascii=False), flush=True)
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=N / 'v3h_cumulative_format_20261024_v1')
    args = parser.parse_args()
    try:
        raise SystemExit(build(args.out.resolve()))
    except Exception as exc:
        if args.out.is_dir() and not (args.out / 'RESULT.json').exists() and not (args.out / 'FAILURE.json').exists():
            c.write_new(args.out / 'FAILURE.json', {'at': c.now(), 'error': str(exc),
                        'traceback': traceback.format_exc(), 'native_invoked': False})
        raise
