#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Codex：从冻结母稿实施已裁定的文稿修订；不调用 Word、Zotero 或统计程序。

默认仅在内存中预演；--write 独占创建新目录。自审类型为 solo_self_review。
文字、格式与完整引文域的接受／拒绝均验证，原始母稿永不覆盖。
"""
from __future__ import annotations

import argparse
import copy
import difflib
import hashlib
import io
import json
import re
import sys
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from lxml import etree as ET

BASE = Path(__file__).resolve().parents[1]
ROOT = BASE.parents[1]
SOURCE = ROOT / 'handoff/cmaverse-codex-solo-20261022/baseline/CMAverse_V3g.docx'
PACK = ROOT / 'handoff/cmaverse-dual-claude-20261012/C41/wip/offline_six_topic_review_v3g_20261022/WORDING_PACK_MERGED_v3g_c41_c2596_v3.json'
DECISIONS = BASE / 'V3H_ADJUDICATION_V1.json'
DEST = BASE / 'v3h_offline_v1'
PINS = {
    SOURCE: 'ebeec8b75fb6747a4ceb7f672a65f8d64889fa0bca17e32b9b18c110db7aeb91',
    PACK: '3da0026eb604f66ccb1ce69adb372bfe595454cf2918aeca5fcee40be7bc973d',
    DECISIONS: '8af55e5e3875d284a23bdfe63654b3eab925f6d7214db035dbe40066943080cb',
}
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}
Q = lambda name: '{' + W + '}' + name
SPACE = '{http://www.w3.org/XML/1998/namespace}space'
DATE = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
AUTHOR = 'Codex'
REVISION_NAMES = ('ins', 'del', 'moveFrom', 'moveTo', 'pPrChange', 'rPrChange',
                  'trPrChange', 'tcPrChange', 'tblPrChange', 'sectPrChange', 'tblGridChange')
NEXT_ID = 100000


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}


def plain(p):
    return ''.join(p.itertext()) if False else ''.join(p.xpath('.//w:t/text()', namespaces=NS))


def unspace(s):
    return re.sub(r'\s+', '', s)


def locate(full, old):
    norm = unspace(full)
    target = unspace(old)
    assert target and norm.count(target) == 1, ('不唯一的文字定位', old, full)
    positions = [i for i, ch in enumerate(full) if not ch.isspace()]
    off = norm.index(target)
    return positions[off], positions[off + len(target) - 1] + 1


def fresh_revision(tag):
    global NEXT_ID
    NEXT_ID += 1
    return ET.Element(Q(tag), {Q('id'): str(NEXT_ID), Q('author'): AUTHOR, Q('date'): DATE})


def run_text(run):
    return ''.join(x.text or '' for x in run if x.tag == Q('t'))


def own_runs(p):
    for r in p.iter(Q('r')):
        parent = r.getparent()
        while parent is not None and parent.tag != Q('p'):
            parent = parent.getparent()
        if parent is p:
            yield r


def offsets(p):
    cursor = 0
    for run in own_runs(p):
        end = cursor + len(run_text(run))
        yield run, cursor, end
        cursor = end


def pure_run(r):
    return r.tag == Q('r') and all(c.tag in (Q('rPr'), Q('t')) for c in r)


def set_run_text(run, value):
    assert pure_run(run), '不能拆分含域标记或其他对象的 run'
    for c in list(run):
        if c.tag == Q('t'):
            run.remove(c)
    t = ET.SubElement(run, Q('t'))
    t.text = value
    t.set(SPACE, 'preserve')


def split_at(p, offset):
    for run, a, b in offsets(p):
        if a < offset < b:
            assert run.getparent() is p and pure_run(run), '禁止拆分域、超链接或嵌套修订'
            text = run_text(run)
            right = copy.deepcopy(run)
            set_run_text(run, text[:offset - a])
            set_run_text(right, text[offset - a:])
            run.addnext(right)
            return


def field_runs(root):
    """保护域结果，不只保护 instrText。"""
    result = set()
    depth = 0
    for run in root.iter(Q('r')):
        before = depth
        for fc in run.iter(Q('fldChar')):
            k = fc.get(Q('fldCharType'))
            if k == 'begin':
                depth += 1
            elif k == 'end':
                depth -= 1
                assert depth >= 0
        if before or depth or any(a.tag == Q('fldSimple') for a in run.iterancestors()):
            result.add(run)
    assert depth == 0
    return result


def splice(p, a, b, value, tracked, protected):
    """在从右到左的互不重叠区间内操作，保留原 run 的格式与属性。"""
    assert 0 <= a <= b <= len(plain(p))
    for run, ra, rb in offsets(p):
        touched = (ra < b and rb > a) if b > a else (ra < a <= rb)
        if touched:
            assert pure_run(run) and run.getparent() is p and run not in protected
    split_at(p, b)
    split_at(p, a)
    selected = [(r, ra, rb) for r, ra, rb in offsets(p) if rb > ra and ra >= a and rb <= b]
    if b > a:
        assert selected and sum(rb - ra for _, ra, rb in selected) == b - a
        runs = [r for r, _, _ in selected]
        first = p.index(runs[0])
        assert list(p)[first:first + len(runs)] == runs, '不能跨越不可见对象作普通删改'
        template = copy.deepcopy(runs[0])
        if tracked:
            deleted = fresh_revision('del')
            p.insert(first, deleted)
            for run in runs:
                deleted.append(run)
                for t in run.iter(Q('t')):
                    t.tag = Q('delText')
            insert_at = first + 1
        else:
            for run in runs:
                p.remove(run)
            insert_at = first
    else:
        left = [(r, ra, rb) for r, ra, rb in offsets(p) if rb == a and rb > ra and r.getparent() is p]
        if left:
            anchor = left[-1][0]
            template = copy.deepcopy(anchor)
            insert_at = p.index(anchor) + 1
        else:
            right = [(r, ra, rb) for r, ra, rb in offsets(p) if ra == a and rb > ra and r.getparent() is p]
            assert right
            anchor = right[0][0]
            template = copy.deepcopy(anchor)
            insert_at = p.index(anchor)
    if value:
        set_run_text(template, value)
        if tracked:
            inserted = fresh_revision('ins')
            inserted.append(template)
            p.insert(insert_at, inserted)
        else:
            p.insert(insert_at, template)


ORDER = {
    'pPr': 'pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle rPr sectPr pPrChange'.split(),
    'rPr': 'rStyle rFonts b bCs i iCs caps smallCaps strike dstrike outline shadow emboss imprint noProof snapToGrid vanish webHidden color spacing w kern position sz szCs highlight u effect bdr shd fitText vertAlign rtl cs em lang eastAsianLayout specVanish oMath rPrChange'.split(),
    'trPr': 'cnfStyle divId gridBefore gridAfter wBefore wAfter cantSplit trHeight tblHeader tblCellSpacing jc hidden ins del trPrChange'.split(),
}


def ordered_put(pr, name, value):
    existing = pr.find(Q(name))
    if value is None:
        if existing is not None:
            pr.remove(existing)
        return
    if existing is not None:
        existing.set(Q('val'), value)
        return
    item = ET.Element(Q(name), {Q('val'): value})
    order = ORDER[ET.QName(pr).localname]
    slot = order.index(name)
    index = next((i for i, c in enumerate(pr)
                  if ET.QName(c).localname in order and order.index(ET.QName(c).localname) > slot), len(pr))
    pr.insert(index, item)


def change_property(owner, tag, changes, tracked):
    pr = owner.find(Q(tag))
    old = copy.deepcopy(pr) if pr is not None else ET.Element(Q(tag))
    if pr is None:
        pr = ET.Element(Q(tag))
        owner.insert(0, pr)
    for name, val in changes.items():
        ordered_put(pr, name, val)
    if tracked:
        rev = fresh_revision(tag + 'Change')
        rev.append(old)
        pr.append(rev)


def resolve(root, accept):
    root = copy.deepcopy(root)
    for item in list(root.iter()):
        name = ET.QName(item).localname
        if name not in ('pPrChange', 'rPrChange', 'trPrChange'):
            continue
        parent = item.getparent()
        if accept:
            parent.remove(item)
        else:
            assert len(item) == 1
            old = copy.deepcopy(item[0])
            parent.getparent().replace(parent, old)
    for item in list(root.iter()):
        if item.tag not in (Q('ins'), Q('del')):
            continue
        parent = item.getparent()
        if parent is None:
            continue
        keep = (item.tag == Q('ins')) == accept
        if keep:
            where = parent.index(item)
            for child in list(item):
                for t in child.iter(Q('delText')):
                    t.tag = Q('t')
                for t in child.iter(Q('delInstrText')):
                    t.tag = Q('instrText')
                parent.insert(where, child)
                where += 1
        parent.remove(item)
    return root


def tree_key(element):
    """全结构比较；命名空间声明和可合并的同格式 run 切片不构成语义变化。"""
    return (element.tag, tuple(sorted(element.attrib.items())), element.text or '',
            tuple(tree_key(c) for c in element))


def normalized(root):
    root = copy.deepcopy(root)
    # 新增行属性的旧状态按 OOXML 表示为空 trPr。拒绝后保留空容器与
    # 母稿中没有 trPr 等价；只规范化真正无属性、无子项、无文字的空容器。
    # cantSplit=0、trHeight 等任何显式属性仍完整参与比较。
    for pr in list(root.iter(Q('trPr'))):
        if not pr.attrib and len(pr) == 0 and not (pr.text or '').strip():
            pr.getparent().remove(pr)
    for parent in root.iter():
        previous = None
        previous_key = None
        for child in list(parent):
            if pure_run(child) and any(c.tag == Q('t') for c in child):
                text = run_text(child)
                key = (tuple(sorted(child.attrib.items())),
                       tuple(tree_key(c) for c in child if c.tag != Q('t')))
                if previous is not None and key == previous_key:
                    set_run_text(previous, run_text(previous) + text)
                    parent.remove(child)
                    continue
                set_run_text(child, text)
                previous, previous_key = child, key
            else:
                previous, previous_key = None, None
    return tree_key(root)


def audit_fields(root):
    stack, fields, errors = [], [], []
    for e in root.iter():
        if e.tag == Q('fldChar'):
            kind = e.get(Q('fldCharType'))
            if kind == 'begin':
                stack.append({'instruction': '', 'display': '', 'separate': False})
            elif kind == 'separate':
                if not stack or stack[-1]['separate']:
                    errors.append('unmatched_or_duplicate_separate')
                else:
                    stack[-1]['separate'] = True
            elif kind == 'end':
                if not stack:
                    errors.append('unmatched_end')
                else:
                    fields.append(stack.pop())
        elif e.tag == Q('instrText'):
            if not stack or stack[-1]['separate']:
                errors.append('instruction_outside_code')
            else:
                stack[-1]['instruction'] += e.text or ''
        elif e.tag == Q('t') and stack and stack[-1]['separate']:
            stack[-1]['display'] += e.text or ''
    if stack:
        errors.append('unclosed_fields')
    for f in fields:
        code = f.pop('instruction')
        f['instruction_sha256'] = sha_bytes(code.encode())
        f['kind'] = 'zotero_citation' if 'ADDIN ZOTERO_ITEM CSL_CITATION' in code else ('zotero_bibliography' if 'ADDIN ZOTERO_BIBL' in code else 'other')
        if f['kind'] == 'zotero_citation':
            data = json.loads(code.split('CSL_CITATION', 1)[1].strip())
            f['citation_id'] = data.get('citationID')
            f['dont_update'] = data.get('properties', {}).get('dontUpdate', False)
            f['items'] = [{
                'id': x.get('id'), 'uris': x.get('uris'),
                'doi': x.get('itemData', {}).get('DOI'),
                'title': x.get('itemData', {}).get('title'),
            } for x in data.get('citationItems', [])]
            if f['dont_update']:
                errors.append('dontUpdate')
            if 'TEMP' in code[:80]:
                errors.append('TEMP')
            uris = [u for x in f['items'] for u in (x['uris'] or [])]
            if len(set(uris)) != len(uris):
                errors.append('duplicate_uri_in_field')
    assert not errors, errors
    return {'pass': True, 'field_count': len(fields),
            'kind_counts': dict(Counter(f['kind'] for f in fields)), 'fields': fields,
            'simple_field_count': len(list(root.iter(Q('fldSimple'))))}


def revisions(root):
    return {n: len(list(root.iter(Q(n)))) for n in REVISION_NAMES
            if len(list(root.iter(Q(n))))}


def xml_bytes(root):
    return ET.tostring(root, encoding='UTF-8', xml_declaration=True, standalone=True)


def make_archive(source_zip, replacements):
    buff = io.BytesIO()
    with zipfile.ZipFile(buff, 'w', compression=zipfile.ZIP_DEFLATED) as dest:
        for info in source_zip.infolist():
            # writestr 会回写 ZipInfo 的 CRC、压缩长度与偏移，不能把母稿的
            # 同一 ZipInfo 实例交给目标 ZIP，否则后续母稿读取会误判重叠成员。
            dest.writestr(copy.copy(info), replacements.get(info.filename, source_zip.read(info.filename)))
    result = buff.getvalue()
    with zipfile.ZipFile(io.BytesIO(result)) as check:
        assert check.testzip() is None
    return result


def main(write=False):
    for path, digest in PINS.items():
        assert binding(path)['sha256'] == digest, ('输入SHA改变', str(path))
    decision_data = json.loads(DECISIONS.read_text())
    assert decision_data['decision_count'] == 34
    for item in decision_data['records']:
        for ev in item.get('evidence', []):
            if 'sha256' in ev:
                assert binding(Path(ev['path']))['sha256'] == ev['sha256']
    pack = {r['id']: r for r in json.loads(PACK.read_text())['records']}
    zin = zipfile.ZipFile(SOURCE)
    stories = [n for n in zin.namelist()
               if re.fullmatch(r'word/(document|footnotes|endnotes|header\d+|footer\d+)\.xml', n)]
    original = {n: ET.fromstring(zin.read(n)) for n in stories}
    assert all(not revisions(r) for r in original.values()), '母稿含未结修订'
    clean = {n: copy.deepcopy(r) for n, r in original.items()}
    tracked = {n: copy.deepcopy(r) for n, r in original.items()}
    pars = {n: list(r.iter(Q('p'))) for n, r in original.items()}
    expected = {}
    changes = []
    body = 'word/document.xml'
    feet = 'word/footnotes.xml'

    def edit(record_id, paragraph, new=None, old=None, part=body):
        rec = pack[record_id]
        p = pars[part][paragraph]
        key = (part, paragraph)
        current = expected.get(key, plain(p))
        start, end = locate(current, old if old is not None else rec['old_text'])
        # 母稿中英文间距保持原习惯；英文脚注翻译也不依赖 PDF 抽取空格。
        replacement = new if new is not None else unspace(rec['new'])
        before = current[start:end]
        expected[key] = current[:start] + replacement + current[end:]
        changes.append({'id': record_id, 'finding': rec['finding'], 'part': part,
                        'paragraph_index': paragraph, 'old': before, 'new': replacement,
                        'kind': 'text', 'status': 'OFFLINE_IMPLEMENTED_NATIVE_PENDING'})

    edit('DF-6a', 1)
    edit('DF-6a', 1355)
    edit('ST-2', 210)
    edit('TM-2', 210, new='保持各自原完整案例样本、共享整簇抽样索引与种子（统一亲属—家庭连通簇按区间两端本人、配偶和父母的有效正PERSON标识及有效正FID连边构建，无效标识不建边）')
    edit('TM-1a', 211)
    edit('TM-4', 212)
    edit('DF-2', 818, old='不统一删除全表缺失。', new='不统一删除全表缺失。个体特征中的“同住情况”与父母特征中的“父母同住”分别从本人侧和父母侧列示同一亲子二元组的同住状态；本表基期及末期指标逐条一致，此说明不适用于同住变化指标。')
    edit('DF-3', 1099, new='其区间来自成年子女聚类bootstrap（预设尝试1,050次，至少需成功1,000次；实际1,050次全部成功）。')
    edit('DF-5a', 1099)
    edit('TM-6', 1102)
    edit('X-3', 1104, new='分时期估计见补充文件14_period_heterogeneity_effects.csv，模型与抽样信息见15_period_heterogeneity_manifest.csv。')
    edit('DF-5b', 1199)
    edit('ST-3', 1209)
    tbl10 = original[body].xpath('//w:tbl', namespaces=NS)[13]
    cell10 = tbl10.findall(Q('tr'))[3].findall(Q('tc'))[2]
    # 实际列：RQ、预期、现有证据、结论；不把 trPr 当作表格单元格。
    p10 = cell10.find(Q('p'))
    assert '031／041' in plain(p10)
    idx10 = pars[body].index(p10)
    edit('DF-6b', idx10)
    edit('TM-1c', idx10)
    edit('TM-3a', 1280)
    edit('TM-3b', 1303)
    edit('TM-1b', 1351)
    edit('X-1', 2203, new='B1的195/200有效抽样未达到98%门槛，诊断p=0.214286不作正常主推断。全14项BH/BY校正的分母固定为m=14，仅对合格规格的初筛p值进行调整；B1不合格，其BH/BY q值记为NA。')
    edit('DF-7', 2772)
    edit('ST-4', 3043)
    edit('TM-3c', 3256)
    edit('DF-1', 3263, new='敏感性R1_B1（486/500，表D.5）、R4_B1、R3_B1、R9_C1、R9_C3、R9_D1、R9_D2未达98%有效比例')
    table11 = original[body].xpath('//w:tbl', namespaces=NS)[14]
    for rid, ci in [('F3a', 1), ('F3b', 2)]:
        cell = table11.findall(Q('tr'))[4].findall(Q('tc'))[ci]
        p = cell.find(Q('p'))
        edit(rid, pars[body].index(p))
    fn4 = original[feet].xpath('./w:footnote[@w:id="4"]/w:p', namespaces=NS)[0]
    url = 'https://www.mca.gov.cn/n152/n165/c1662004999980001877/part/19971.pdf'
    c4_note = '《第五次中国城乡老年人生活状况抽样调查基本数据公报》，2024年10月；调查标准时点为2021年8月1日零时（第1页），居住安排见第5—6页，收入构成见第18页，代际经济支持见第20页，家庭转移性收入定义见第33页（均为公报印刷页码）。'
    edit('C4', pars[feet].index(fn4), old=url, new=c4_note + url, part=feet)
    fn5 = original[feet].xpath('./w:footnote[@w:id="5"]/w:p', namespaces=NS)[0]
    edit('L4', pars[feet].index(fn5), part=feet)

    # 按最终段落差异编译，避免同一段多项操作嵌套或相互覆盖。
    for (part, idx), target in expected.items():
        source_text = plain(pars[part][idx])
        opcodes = difflib.SequenceMatcher(None, source_text, target, autojunk=False).get_opcodes()
        for roots, is_tracked in ((clean, False), (tracked, True)):
            p = list(roots[part].iter(Q('p')))[idx]
            protected = field_runs(roots[part])
            for tag, a, b, c, d in reversed(opcodes):
                if tag != 'equal':
                    splice(p, a, b, target[c:d], is_tracked, protected)
            assert plain(p) == target

    # C1：删除重复句时覆盖完整 begin/instruction/separate/result/end 域。
    deletion_sentence = '四项分解区分直接、中介和交互部分，其理论依据见（VanderWeele, 2014）。'
    removed_field = None
    for roots, is_tracked in ((clean, False), (tracked, True)):
        fn = roots[feet].xpath('./w:footnote[@w:id="6"]', namespaces=NS)[0]
        p2, p4 = fn.findall(Q('p'))[1], fn.findall(Q('p'))[3]
        assert p2.find('./' + Q('pPr') + '/' + Q('numPr')) is not None
        change_property(p2, 'pPr', {'numPr': None}, is_tracked)
        assert plain(p4).startswith(deletion_sentence)
        fields = audit_fields(p4)
        assert fields['kind_counts'] == {'zotero_citation': 1}
        removed_field = fields['fields'][0]
        split_at(p4, len(deletion_sentence))
        following = next(r for r, a, b in offsets(p4) if a == len(deletion_sentence) and b > a)
        selected = [c for c in list(p4)[:p4.index(following)] if c.tag != Q('pPr')]
        assert sum(len(run_text(r)) for r in selected) == len(deletion_sentence)
        assert len([e for r in selected for e in r.iter(Q('fldChar'))]) == 3
        if is_tracked:
            deletion = fresh_revision('del')
            p4.insert(p4.index(selected[0]), deletion)
            for r in selected:
                deletion.append(r)
                for e in r.iter():
                    if e.tag == Q('t'):
                        e.tag = Q('delText')
                    elif e.tag == Q('instrText'):
                        e.tag = Q('delInstrText')
        else:
            for r in selected:
                p4.remove(r)
        assert plain(p4).startswith('固定M下的比例解释')
    changes += [
        {'id': 'C1-numbering', 'finding': 'C1', 'part': feet, 'footnote_id': 6, 'paragraph_in_footnote': 1,
         'kind': 'format', 'old': 'w:numPr', 'new': '移除列表编号；脚注锚点保留', 'status': 'OFFLINE_IMPLEMENTED_NATIVE_PENDING'},
        {'id': 'C1-field', 'finding': 'C1', 'part': feet, 'footnote_id': 6, 'paragraph_in_footnote': 3,
         'kind': 'whole_field_deletion', 'old': deletion_sentence, 'new': '', 'removed_field': removed_field,
         'status': 'OFFLINE_IMPLEMENTED_NATIVE_PENDING'},
    ]

    # C2：只改有效粗体，完整 Zotero 指令保持原字节内容。
    for roots, is_tracked in ((clean, False), (tracked, True)):
        p = list(roots[body].iter(Q('p')))[137]
        targets = [r for r in own_runs(p) if run_text(r) in ('（', '2014', '）')]
        assert ''.join(run_text(r) for r in targets) == '（2014）'
        for r in targets:
            change_property(r, 'rPr', {'b': '0', 'bCs': '0'}, is_tracked)
    changes.append({'id': 'C2', 'finding': 'C2', 'part': body, 'paragraph_index': 137,
                    'kind': 'format', 'old': '（2014）有效粗体', 'new': 'w:b=0、w:bCs=0；引文指令不变',
                    'status': 'OFFLINE_IMPLEMENTED_NATIVE_PENDING'})

    # F1：题注和表头与后文相连；所有数据行不跨页拆分。原生分页另验。
    for roots, is_tracked in ((clean, False), (tracked, True)):
        ps = list(roots[body].iter(Q('p')))
        assert plain(ps[1281]).startswith('表11')
        change_property(ps[1281], 'pPr', {'keepNext': '1'}, is_tracked)
        tbl = roots[body].xpath('//w:tbl', namespaces=NS)[14]
        for row in tbl.findall(Q('tr')):
            change_property(row, 'trPr', {'cantSplit': '1'}, is_tracked)
        for p in tbl.findall(Q('tr'))[0].iter(Q('p')):
            change_property(p, 'pPr', {'keepNext': '1'}, is_tracked)
    changes.append({'id': 'F1', 'finding': 'F1', 'part': body, 'table_index': 14, 'kind': 'format',
                    'old': '原表11分页属性', 'new': '题注/表头keepNext=1，各行cantSplit=1',
                    'status': 'OFFLINE_IMPLEMENTED_VISUAL_PENDING'})

    # 全 story 的字段、文字与全部格式结构等价，不仅核正文可见文字。
    validation = {'review_mode': 'solo_self_review', 'at': DATE, 'scope': 'OFFLINE_OOXML_ONLY',
                  'native_word': 'NOT_RUN', 'zotero_refresh': 'NOT_RUN', 'statistics': 'NOT_RUN',
                  'notebooklm': 'NOT_RUN', 'story_checks': {}, 'table_checks': [],
                  'equivalence_normalization': ['同格式相邻文字run切片合并', '无属性、无子项、无文字的空trPr与缺省行属性等价']}
    rejected = {}
    for part in stories:
        av, rv = resolve(tracked[part], True), resolve(tracked[part], False)
        assert normalized(av) == normalized(clean[part]), ('接受不等价', part)
        assert normalized(rv) == normalized(original[part]), ('拒绝不等价', part)
        assert not revisions(clean[part]) and not revisions(rv)
        rejected[part] = rv
        baseline_fields = audit_fields(original[part])
        accepted_fields = audit_fields(clean[part])
        rejected_fields = audit_fields(rv)
        old_hashes = Counter(f['instruction_sha256'] for f in baseline_fields['fields'])
        new_hashes = Counter(f['instruction_sha256'] for f in accepted_fields['fields'])
        if part == feet:
            assert old_hashes - new_hashes == Counter([removed_field['instruction_sha256']])
        else:
            assert old_hashes == new_hashes
        assert not new_hashes - old_hashes
        assert Counter(f['instruction_sha256'] for f in rejected_fields['fields']) == old_hashes
        validation['story_checks'][part] = {'accept_equivalent': True, 'reject_equivalent': True,
            'baseline': baseline_fields, 'accepted': accepted_fields, 'rejected': rejected_fields,
            'revisions': revisions(tracked[part]), 'clean_revisions': {},
            'changed': normalized(original[part]) != normalized(clean[part])}

    # 所有34个表对象的每格数字逐一核；表10措辞与表11千分位属于已登记变化。
    nums = lambda text: [s.replace(',', '').replace('−', '-') for s in
                        re.findall(r'[-−]?\d[\d,]*(?:\.\d+)?(?:[eE][+-]?\d+)?', text)]
    old_tables = original[body].xpath('//w:tbl', namespaces=NS)
    new_tables = clean[body].xpath('//w:tbl', namespaces=NS)
    assert len(old_tables) == len(new_tables) == 34
    numerical_cells = 0
    for ti, (ot, nt) in enumerate(zip(old_tables, new_tables)):
        oc, nc = ot.findall('.//' + Q('tc')), nt.findall('.//' + Q('tc'))
        assert len(oc) == len(nc)
        changed_cells = []
        for ci, (a, b) in enumerate(zip(oc, nc)):
            assert nums(plain(a)) == nums(plain(b)), ('表内数值变化', ti, ci, plain(a), plain(b))
            numerical_cells += bool(nums(plain(a)))
            if plain(a) != plain(b):
                assert ti in (13, 14), ('未登记的单元格文字变化', ti, ci)
                changed_cells.append(ci)
        validation['table_checks'].append({'table_index': ti, 'cells': len(oc),
            'all_numeric_tokens_unchanged': True, 'changed_text_cells': changed_cells})
    validation['numeric_cells_checked'] = numerical_cells
    for (part, idx), target in expected.items():
        assert plain(list(clean[part].iter(Q('p')))[idx]) == target
    for part in stories:
        for tag in ('drawing', 'pict', 'object', 'footnoteReference', 'endnoteReference'):
            assert [tree_key(e) for e in original[part].iter(Q(tag))] == [tree_key(e) for e in clean[part].iter(Q(tag))]
    validation['objects_and_note_anchors_unchanged'] = True
    validation['removed_citation'] = removed_field
    validation['pass'] = True

    files = {}
    for name, roots in [('accepted', clean), ('tracked', tracked), ('reject_all_validation', rejected)]:
        replacements = {p: xml_bytes(r) for p, r in roots.items() if tree_key(r) != tree_key(original[p])}
        if name == 'tracked':
            settings = ET.fromstring(zin.read('word/settings.xml'))
            tr = settings.find(Q('trackRevisions'))
            if tr is None:
                tr = ET.Element(Q('trackRevisions'))
                # trackRevisions 在 proofState 后、doNotTrackMoves 等设置之前。
                slot = next((i for i, c in enumerate(settings) if ET.QName(c).localname in
                             ('doNotTrackMoves', 'doNotTrackFormatting', 'documentProtection', 'autoFormatOverride', 'styleLockTheme', 'styleLockQFSet', 'defaultTabStop')), len(settings))
                settings.insert(slot, tr)
            tr.set(Q('val'), 'true')
            replacements['word/settings.xml'] = xml_bytes(settings)
        fname = f'CMAverse_V3h_offline_{name}.docx'
        files[fname] = make_archive(zin, replacements)
        with zipfile.ZipFile(io.BytesIO(files[fname])) as check:
            changed_members = [n for n in zin.namelist() if zin.read(n) != check.read(n)]
            assert set(changed_members) <= {body, feet, 'word/settings.xml'}
            validation.setdefault('package_checks', {})[name] = {'crc': 'PASS', 'changed_members': changed_members,
                'media_styles_relationships_other_members': 'BYTE_IDENTICAL'}

    implemented = {c['finding'] for c in changes}
    implementation = []
    for r in decision_data['records']:
        item = {k: r[k] for k in ('id', 'severity', 'decision', 'rationale', 'planned_stage', 'wording_record_ids', 'evidence')}
        if r['id'] in implemented:
            item['implementation_status'] = 'OFFLINE_IMPLEMENTED_NATIVE_VERIFICATION_PENDING'
        elif r['id'] in ('C3', 'F2', 'F5'):
            item['implementation_status'] = 'NATIVE_IMPLEMENTATION_PENDING'
        else:
            assert r['id'] in ('TM-5', 'DF-4', 'DF-8', 'ST-1', 'ST-5', 'ST-6', 'X-2', 'F4', 'F6')
            item['implementation_status'] = 'NO_CHANGE_DECISION_RECORDED'
        item['operations'] = [c['id'] for c in changes if c['finding'] == r['id']]
        implementation.append(item)
    report = {'schema': 'cmaverse-v3h-offline-build-v1', 'at': DATE, 'author': AUTHOR,
        'review_mode': 'solo_self_review', 'inputs': [binding(p) for p in PINS],
        'generator': binding(Path(__file__).resolve()), 'changes': changes,
        'decisions': implementation, 'outputs': [{'path': str(DEST / name), 'bytes': len(data),
                       'sha256': sha_bytes(data)} for name, data in files.items()],
        'pending': ['C3真实Zotero元数据更新和Refresh', 'F2页码及最小页脚版式调整', 'F5表10/11词界原生检查',
                    '真实Word接受/拒绝与导出', '全页视觉/数值/字符验收', '同PDF两轮六主题NLM', '正式发布与整包回验'],
        'validation': validation}
    md = ['# CMAverse V3h 离线修订对照', '',
          '审查者：Codex（solo_self_review）。本目录为离线候选，尚未完成真实 Word/Zotero、PDF 和 NLM 终验。', '',
          '母稿：' + str(SOURCE), '', '## 已实施操作', '']
    for c in changes:
        locator = c['part'] + (f"，段落{c['paragraph_index']}（0起）" if 'paragraph_index' in c else '')
        md += [f"### {c['id']} · {locator}", '', '- 原：' + (c['old'] or '（无）'),
               '- 改：' + (c['new'] or '（完整删除）'), '']
    md += ['## 尚待实施与验证', ''] + ['- ' + x for x in report['pending']]
    md += ['', '全部34个表对象的每格数字已核对；表11两格千分位显示允许变化。全部story的接受/拒绝后文字、格式、对象与完整域结构已核对。此项不等于全稿统计复现。', '']
    summary = {'write': write, 'pass': True, 'operation_count': len(changes), 'decision_count': len(implementation),
               'decision_status_counts': dict(Counter(r['implementation_status'] for r in implementation)),
               'stories': len(stories), 'tables': len(old_tables), 'numeric_cells': numerical_cells,
               'outputs': report['outputs'], 'pending': report['pending']}
    if write:
        DEST.mkdir(exist_ok=False)
        for name, data in files.items():
            with (DEST / name).open('xb') as f:
                f.write(data)
        for name, obj in [('BUILD_AND_VALIDATION.json', report), ('IMPLEMENTATION_STATUS.json', implementation)]:
            with (DEST / name).open('x', encoding='utf-8') as f:
                json.dump(obj, f, ensure_ascii=False, indent=2)
                f.write('\n')
        with (DEST / 'REVISION_COMPARISON.md').open('x', encoding='utf-8') as f:
            f.write('\n'.join(md))
        with (DEST / 'RUN_LOG.json').open('x', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
            f.write('\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--write', action='store_true')
    args = parser.parse_args()
    main(args.write)
