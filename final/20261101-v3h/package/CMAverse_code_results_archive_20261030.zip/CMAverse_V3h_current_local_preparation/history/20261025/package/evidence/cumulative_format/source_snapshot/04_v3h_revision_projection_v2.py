"""V3h 累计修订的只读投影；支持单元格属性修订，不改历史编译器。"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from lxml import etree as ET

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}


def q(name):
    return '{' + W + '}' + name


PROPERTY_CHANGES = {q(name + 'Change'): q(name) for name in
                    ('pPr', 'rPr', 'trPr', 'tcPr', 'tblPr', 'sectPr', 'tblGrid')}
WRAPPERS = {q('ins'), q('del')}
UNSUPPORTED = {q(name) for name in (
    'moveFrom', 'moveTo', 'moveFromRangeStart', 'moveFromRangeEnd',
    'moveToRangeStart', 'moveToRangeEnd', 'cellIns', 'cellDel', 'cellMerge',
    'numberingChange', 'customXmlInsRangeStart', 'customXmlInsRangeEnd',
    'customXmlDelRangeStart', 'customXmlDelRangeEnd',
    'customXmlMoveFromRangeStart', 'customXmlMoveFromRangeEnd',
    'customXmlMoveToRangeStart', 'customXmlMoveToRangeEnd')}
REVISION_TAGS = set(PROPERTY_CHANGES) | WRAPPERS | UNSUPPORTED


def require(value, message):
    if not value:
        raise RuntimeError(message)


def tree_key(element):
    """比较完整XML结构；命名空间前缀本身不参与，属性与文本均保留。"""
    return (element.tag, tuple(sorted(element.attrib.items())), element.text or '', element.tail or '',
            tuple(tree_key(child) for child in element))


def revisions(root):
    return dict(Counter(ET.QName(e).localname for e in root.iter() if e.tag in REVISION_TAGS))


def validate_revision_shapes(root):
    for element in root.iter():
        require(element.tag not in UNSUPPORTED,
                'UNSUPPORTED_REVISION: ' + ET.QName(element).localname)
        if element.tag in PROPERTY_CHANGES:
            expected = PROPERTY_CHANGES[element.tag]
            require(element.getparent() is not None and element.getparent().tag == expected
                    and len(element) == 1 and element[0].tag == expected,
                    'INVALID_PROPERTY_REVISION_SHAPE')
            require(len(element.getparent().findall(element.tag)) == 1,
                    'DUPLICATE_PROPERTY_REVISION')
            require(not any(e.tag in REVISION_TAGS for e in element[0].iter()),
                    'NESTED_OLD_PROPERTY_REVISIONS_NOT_SUPPORTED')
        elif element.tag in WRAPPERS:
            # 本次冻结输入的插入/删除均为段落内run；不把行/段落删除标记当包装。
            require(element.getparent() is not None and element.getparent().tag == q('p')
                    and len(element) > 0 and all(e.tag == q('r') for e in element),
                    'STRUCTURAL_REVISION_NOT_SUPPORTED')


def _resolve_in_place(root, accept):
    validate_revision_shapes(root)
    for element in list(root.iter()):
        if element.tag not in PROPERTY_CHANGES:
            continue
        parent = element.getparent()
        # 外层属性被旧值替换后，不再处理已脱离当前文档的后代。
        if parent is None or element.getroottree().getroot() is not root:
            continue
        if accept:
            parent.remove(element)
        else:
            parent.getparent().replace(parent, deepcopy(element[0]))
    for element in list(root.iter()):
        if element.tag not in WRAPPERS:
            continue
        parent = element.getparent()
        if parent is None:
            continue
        if (element.tag == q('ins')) == accept:
            position = parent.index(element)
            for child in list(element):
                for text in child.iter():
                    if text.tag == q('delText'):
                        text.tag = q('t')
                    elif text.tag == q('delInstrText'):
                        text.tag = q('instrText')
                parent.insert(position, child)
                position += 1
        parent.remove(element)
    require(not revisions(root), 'REVISION_RESIDUE_AFTER_PROJECTION')
    return root


def resolve(root, accept=True):
    return _resolve_in_place(deepcopy(root), accept)


def accepted_projection_with_origins(root):
    """投影仍保存每个节点的原始对象身份，避免修订包装导致XPath错位。"""
    projected = deepcopy(root)
    origins = dict(zip(projected.iter(), root.iter(), strict=True))
    _resolve_in_place(projected, True)
    return projected, {node: origins[node] for node in projected.iter()}


def append_property_revision(parent, desired, *, revision_id, author, date):
    """叠加本次属性，已有同类修订保留最初旧值及原ID，不嵌套修订。"""
    old = parent.find(desired.tag)
    require(old is not None, 'EXPECTED_EXISTING_PROPERTY')
    revision_tag = q(ET.QName(desired).localname + 'Change')
    require(revision_tag in PROPERTY_CHANGES, 'UNSUPPORTED_PROPERTY')
    prior = old.find(revision_tag)
    other_revisions = [e for e in old.iter() if e.tag in REVISION_TAGS and e is not prior]
    require(not other_revisions, 'NESTED_PROPERTY_REQUIRES_EXPLICIT_MAPPING')
    require(not any(e.tag in REVISION_TAGS for e in desired.iter()), 'DESIRED_PROPERTY_NOT_CLEAN')
    replacement = deepcopy(desired)
    if prior is not None:
        require(len(prior) == 1 and prior[0].tag == desired.tag, 'INVALID_PRIOR_PROPERTY')
        change = deepcopy(prior)
        mode = 'MERGED_KEEP_ORIGINAL_OLD_VALUE'
    else:
        attrs = {q('id'): str(revision_id)}
        if revision_tag != q('tblGridChange'):
            attrs.update({q('author'): author, q('date'): date})
        change = ET.Element(revision_tag, attrs)
        change.append(deepcopy(old))
        mode = 'NEW_PROPERTY_REVISION'
    replacement.append(change)
    parent.replace(old, replacement)
    return {'mode': mode, 'revision_id': change.get(q('id')),
            'revision_type': ET.QName(change).localname}
