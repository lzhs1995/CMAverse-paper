"""V3h 专用来源合同；只读 OOXML，不执行 Word、NLM 或统计。"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
from zipfile import ZipFile

ROOT = Path('/Users/lzhs/Documents/cnm/tasks/01_R_analysis')
HERE = ROOT / 'handoff/cmaverse-solo-2545-20261023'
WORD = Path('/Users/lzhs/.local/share/officecli-word-revision/releases/0.1.0.dev3-7b740493869c/source/skills/officecli-word-revision')
BASELINE = ROOT / 'handoff/cmaverse-codex-solo-20261022/baseline/CMAverse_V3g.docx'
ACCEPTED = HERE / 'v3h_offline_v1/CMAverse_V3h_offline_accepted.docx'
TRACKED = HERE / 'v3h_offline_v1/CMAverse_V3h_offline_tracked.docx'
REJECTED = HERE / 'v3h_offline_v1/CMAverse_V3h_offline_reject_all_validation.docx'
DECISIONS = HERE / 'V3H_ADJUDICATION_V1.json'
WORK = HERE / 'wordrev_v3h_v1'
PINS = {
    str(BASELINE): 'ebeec8b75fb6747a4ceb7f672a65f8d64889fa0bca17e32b9b18c110db7aeb91',
    str(ACCEPTED): 'f961f9aadc9516369eeaef26ffcdcf26eba9f3f129bd6a521a3a69ec5a4258c7',
    str(TRACKED): 'b9375c20be8b556765907699dcbcd0f26aeb0e92afde0e9e125350ad87bac66c',
    str(REJECTED): '3fc82461e92d475e86a5718b43e0282c32709dc1bd1784f7d958239afb056194',
    str(DECISIONS): '8af55e5e3875d284a23bdfe63654b3eab925f6d7214db035dbe40066943080cb',
    str(HERE / 'format_audit_v1/DIFFERENTIAL_ADJUDICATION.json'): '9a4fe469f364e329ab8542f7f2135c53ba5af092c3c4684057479331faf33abd',
}
STORY = re.compile(r'^word/(document|footnotes|endnotes|header\d*|footer\d*)\.xml$')
sys.path.insert(0, str(WORD / 'scripts'))
import manuscript_format as mf
from docx import Document
from docx.oxml import parse_xml
from docx.oxml.ns import qn
from lxml import etree as ET


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


compiler = module('cmaverse_v3h_frozen_compiler', HERE / 'scripts/build_v3h_offline.py')


def now():
    return datetime.now(timezone.utc).isoformat()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def verify_binding(ref):
    actual = binding(ref['path'])
    require(actual['sha256'] == ref['sha256'], 'BOUND_INPUT_CHANGED: ' + ref['path'])
    if 'bytes' in ref:
        require(actual['bytes'] == ref['bytes'], 'BOUND_SIZE_CHANGED: ' + ref['path'])
    return actual


def load_bound(ref):
    verify_binding(ref)
    return json.loads(Path(ref['path']).read_text())


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return binding(path)


def frozen_inputs():
    return [verify_binding({'path': p, 'sha256': sha}) for p, sha in PINS.items()]


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def properties(value):
    # 只归一化具有同一 OOXML 布尔语义的显式真/假；不抹除缩进或字号差异。
    value = json.loads(json.dumps(value))
    for name in ('keepNext', 'keepLines', 'widowControl', 'snapToGrid', 'pageBreakBefore'):
        if name in value:
            raw = value[name].get('val', '1')
            value[name] = {'val': raw not in ('0', 'false', 'off')}
    return value


def stories(path, accept=True):
    with ZipFile(path) as archive:
        return {name: parse_xml(ET.tostring(compiler.resolve(parse_xml(archive.read(name)), accept)))
                for name in sorted(archive.namelist()) if STORY.fullmatch(name)}


def format_snapshot(path, accept=True):
    """逐 story/段落/字符位置核实际格式，能发现同数量字体被挪到别处。"""
    doc = Document(path)
    result = {}
    for part, root in stories(path, accept).items():
        rows = []
        for index, p in enumerate(root.iter(qn('w:p'))):
            segments, position, fulltext = [], 0, []
            for run in p.xpath('.//w:r'):
                # 嵌套文本框段落自行枚举，避免父段落重复覆盖。
                if next(run.iterancestors(qn('w:p')), None) is not p:
                    continue
                # 制表符、显式换行与不间断连字符也占字符位置，不能在合同中丢失。
                controls = {'tab': '\t', 'br': '\n', 'cr': '\n',
                            'noBreakHyphen': '\u2011', 'softHyphen': '\u00ad'}
                text = ''.join((e.text or '') if e.tag == qn('w:t')
                               else controls.get(ET.QName(e).localname, '') for e in run)
                if not text:
                    continue
                profile = mf.effective_run(doc, p, run)
                end = position + len(text)
                if segments and segments[-1]['profile'] == profile:
                    segments[-1]['end'] = end
                else:
                    segments.append({'start': position, 'end': end, 'profile': profile})
                position = end
                fulltext.append(text)
            rows.append({'paragraph': index, 'text_sha256': digest(''.join(fulltext).encode()),
                         'characters': position, 'paragraph_properties': properties(mf.effective_paragraph(doc, p)),
                         'segments': segments})
        result[part] = rows
    return result


def content_snapshot(path, accept=True):
    """文本、域、数值表、锚点与图片；与渲染/统计复现证据严格分开。"""
    roots = stories(path, accept)
    content, fields, tables, anchors = {}, {}, {}, {}
    anchor_names = {'drawing', 'object', 'oMath', 'oMathPara', 'footnoteReference', 'endnoteReference'}
    for part, root in roots.items():
        content[part] = [''.join(p.itertext(qn('w:t'))) for p in root.iter(qn('w:p'))]
        fields[part] = compiler.audit_fields(root)
        tables[part] = [[[''.join(t.text or '' for t in cell.iter(qn('w:t')))
                          for cell in row.findall(qn('w:tc'))]
                         for row in table.findall(qn('w:tr'))]
                        for table in root.iter(qn('w:tbl'))]
        anchors[part] = [(ET.QName(e).localname, e.get(qn('w:id')))
                         for e in root.iter() if ET.QName(e).localname in anchor_names]
    with ZipFile(path) as archive:
        media = {n: digest(archive.read(n)) for n in archive.namelist() if n.startswith('word/media/')}
    return {'content': content, 'fields': fields, 'tables': tables, 'anchors': anchors, 'media': media}


def revision_counts(path):
    with ZipFile(path) as archive:
        return {name: compiler.revisions(parse_xml(archive.read(name)))
                for name in sorted(archive.namelist()) if STORY.fullmatch(name)}


def check_source_contract(path, contract, *, accept=True, view='accepted'):
    expected = contract['views'][view]
    profile = format_snapshot(path, accept)
    errors = []
    if set(profile) != set(expected['stories']):
        errors.append({'rule': 'story_set', 'expected': list(expected['stories']), 'actual': list(profile)})
    for story in sorted(set(profile) & set(expected['stories'])):
        old, new = expected['stories'][story], profile[story]
        if len(old) != len(new):
            errors.append({'story': story, 'rule': 'paragraph_count', 'expected': len(old), 'actual': len(new)})
        for i, (a, b) in enumerate(zip(old, new)):
            if a != b:
                errors.append({'story': story, 'paragraph': i, 'rule': 'bound_paragraph_or_character_format',
                               'changed': [k for k in a if a[k] != b[k]]})
    return {'all_pass': not errors, 'scope': 'source_bound_all_story_paragraph_and_character_profiles',
            'file': binding(path), 'view': view, 'stories': len(profile),
            'paragraphs': sum(map(len, profile.values())), 'errors': errors,
            'shared_uniform_gate_replaced': False, 'native_rendering_proven': False}


def check_content_contract(path, contract, *, accept=True, view='accepted'):
    actual = content_snapshot(path, accept)
    expected = contract['views'][view]['content']
    changed = [key for key in expected if canonical(expected[key]) != canonical(actual[key])]
    return {'all_pass': not changed, 'file': binding(path), 'view': view,
            'changed': changed, 'scope': 'all_stories_fields_tables_anchors_media',
            'native_rendering_proven': False, 'statistical_reexecution_proven': False}


def inspect_resources():
    """只读本地账本；不核收、释放或延长任何人的资源票。"""
    import shutil
    import sqlite3
    queue = Path('/Users/lzhs/.local/state/multi-agent-collaboration/resources/queue.sqlite3')
    with sqlite3.connect(queue.as_uri() + '?mode=ro', uri=True) as db:
        db.row_factory = sqlite3.Row
        tickets = [dict(row) for row in db.execute(
            "SELECT * FROM tickets WHERE resource='word-zotero' AND status IN ('ACTIVE','WAITING')")]
    free = shutil.disk_usage(ROOT).free
    pending = Path('/Users/lzhs/.cache/wordrev/word-automation.pending.json')
    return {'at': now(), 'free_bytes': free, 'word_required_bytes': 23622320128,
            'word_disk_ready': free >= 23622320128, 'word_tickets': tickets,
            'pending_file_exists': pending.exists(), 'native_state': 'NOT_QUERIED',
            'no_pending_file_is_not_idle_proof': True}
