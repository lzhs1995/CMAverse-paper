<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<xsl:output method="xml" encoding="UTF-8"/>
<xsl:template match="@*|node()"><xsl:copy><xsl:apply-templates select="@*|node()"/></xsl:copy></xsl:template>
<xsl:template match="w:ins"><xsl:apply-templates select="node()"/></xsl:template>
<xsl:template match="w:del"/>
<xsl:template match="w:delText"><w:t><xsl:apply-templates select="@*|node()"/></w:t></xsl:template>
<xsl:template match="w:delInstrText"><w:instrText><xsl:apply-templates select="@*|node()"/></w:instrText></xsl:template>
<xsl:template match="w:pPrChange"/><xsl:template match="w:rPrChange"/><xsl:template match="w:trPrChange"/><xsl:template match="w:tcPrChange"/><xsl:template match="w:tblPrChange"/><xsl:template match="w:sectPrChange"/><xsl:template match="w:tblGridChange"/>
</xsl:stylesheet>