<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<xsl:output method="xml" encoding="UTF-8"/>
<xsl:template match="@*|node()"><xsl:copy><xsl:apply-templates select="@*|node()"/></xsl:copy></xsl:template>
<xsl:template match="w:del"><xsl:apply-templates select="node()"/></xsl:template>
<xsl:template match="w:ins"/>
<xsl:template match="w:delText"><w:t><xsl:apply-templates select="@*|node()"/></w:t></xsl:template>
<xsl:template match="w:delInstrText"><w:instrText><xsl:apply-templates select="@*|node()"/></w:instrText></xsl:template>
<xsl:template match="w:pPr[w:pPrChange]"><xsl:apply-templates select="w:pPrChange/w:pPr"/></xsl:template><xsl:template match="w:rPr[w:rPrChange]"><xsl:apply-templates select="w:rPrChange/w:rPr"/></xsl:template><xsl:template match="w:trPr[w:trPrChange]"><xsl:apply-templates select="w:trPrChange/w:trPr"/></xsl:template><xsl:template match="w:tcPr[w:tcPrChange]"><xsl:apply-templates select="w:tcPrChange/w:tcPr"/></xsl:template><xsl:template match="w:tblPr[w:tblPrChange]"><xsl:apply-templates select="w:tblPrChange/w:tblPr"/></xsl:template><xsl:template match="w:sectPr[w:sectPrChange]"><xsl:apply-templates select="w:sectPrChange/w:sectPr"/></xsl:template><xsl:template match="w:tblGrid[w:tblGridChange]"><xsl:apply-templates select="w:tblGridChange/w:tblGrid"/></xsl:template>
</xsl:stylesheet>