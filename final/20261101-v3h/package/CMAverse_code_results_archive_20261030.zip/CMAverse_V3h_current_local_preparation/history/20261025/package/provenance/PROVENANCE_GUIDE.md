# 数据—代码—结果—稿件来源入口

SOURCE_INDEX.json保留439项历史记录，明确区分本次已复制核验与仅保留索引；原文件路径、SHA、字节数、用途及6项缺口均保留。

| 来源组 | 稿件与结果用途 | 包内入口 |
|---|---|---|
| 基础回归 | B00–B33中的合同、公式、样本、效应与诊断；B14/B15含时期差补表 | results/historical/；code/historical/RUN_reproduce_baseline_v71/ |
| CMAverse及异质性 | F系列、八链EFFECT/DELTA及D系列冻结结果；原恢复比对回执 | results/historical/；code/historical/ |
| PLAN12 | 适用性诊断、固定M结构冲突及实际分支源码 | results/historical/P12_*；code/historical/P12_* |
| 限定复核 | FEAS_031/041原区间、ALL_ESTIMANDS及D.2筛选原表 | results/supplemental/LIMITED_FOLLOWUP/ 与 D2/ |
| P3及数值收尾 | 9份稿件消费表与2份P3上游审计表各保留原清单 | results/supplemental/NUMERICAL_CLOSEOUT/ 与 P3_UPSTREAM/ |
| V3h措辞和格式 | 34项裁决、离线实施状态、累计修订、独立实现接受/拒绝核验、dev4角色格式审计 | decisions/、manuscript/、evidence/ |
| 原始数据与模型对象 | 原始调查输入不随包分发；MODEL_INDEX仅历史快照；不据文件存在填补历史链 | provenance/ 中的历史索引和缺口记录 |

以下逐件列出冻结R源代码。它们包含入口脚本和函数源码，仍引用原项目数据/路径；本包不声称是可脱离原环境直接重跑的完整环境。本次没有执行其中任何R代码。

| R文件 | 包内副本 | 原始来源 |
|---|---|---|
| actual_cmest.R | `code/historical/P12_CMEST/actual_cmest.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN12_八链适用性评估_20260928/evidence/actual_cmest.R` |
| actual_est.gformula.R | `code/historical/P12_GFORM/actual_est.gformula.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN12_八链适用性评估_20260928/evidence/actual_est.gformula.R` |
| actual_estinf.R | `code/historical/P12_ESTINF/actual_estinf.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN12_八链适用性评估_20260928/evidence/actual_estinf.R` |
| reproduce_baseline_v71.R | `code/historical/RUN_reproduce_baseline_v71/reproduce_baseline_v71.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/scripts/reproduce_baseline_v71.R` |
| reproduce_cmaverse.R | `code/historical/RUN_reproduce_cmaverse/reproduce_cmaverse.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/scripts/reproduce_cmaverse.R` |
| reproduce_table1.R | `code/historical/RUN_reproduce_table1/reproduce_table1.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/scripts/reproduce_table1.R` |
| validate_table1_objects.R | `code/historical/RUN_validate_table1_objects/validate_table1_objects.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/scripts/validate_table1_objects.R` |
| postprocess_reproduced_v751.R | `code/historical/RUN_postprocess_reproduced_v751/postprocess_reproduced_v751.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/scripts/postprocess_reproduced_v751.R` |
| reproduce_legacy_new47.R | `code/historical/RUN_reproduce_legacy_new47/reproduce_legacy_new47.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/scripts/reproduce_legacy_new47.R` |
| cluster_audit.R | `code/supplemental/CODE_01/cluster_audit.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/cluster_audit.R` |
| register_feasible_population.R | `code/supplemental/CODE_02/register_feasible_population.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/register_feasible_population.R` |
| bind_feasible_sampling.R | `code/supplemental/CODE_03/bind_feasible_sampling.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/bind_feasible_sampling.R` |
| 20261005_astra_v4_functions.R | `code/supplemental/CODE_04/20261005_astra_v4_functions.R` | `/Users/lzhs/Downloads/20261005_astra_v4_functions.R` |
| limited_n1_n2_functions.R | `code/supplemental/CODE_05/limited_n1_n2_functions.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/n1_n2/limited_n1_n2_functions.R` |
| build_n1_actor_wave_v2.R | `code/supplemental/CODE_06/build_n1_actor_wave_v2.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/n1_n2/build_n1_actor_wave_v2.R` |
| 03_prepare_specs.R | `code/supplemental/CODE_08/03_prepare_specs.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/sources/extracted/v751_empirical/research/20260907_table1_comparegroups_autofit/scripts/03_prepare_specs.R` |
| recover_probability_draws_v1.R | `code/supplemental/D2/recover_probability_draws_v1.R` | `/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1/recover_probability_draws_v1.R` |

详细数值与字节身份见FROZEN_CSV_R_INVENTORY.json；本次未重新建立全稿每个数字单元格的源显示绑定。
