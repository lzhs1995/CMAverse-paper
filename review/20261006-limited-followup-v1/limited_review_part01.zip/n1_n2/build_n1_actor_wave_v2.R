# 仅定义函数，由supervisor原生R会话执行。保持来源文件只读。
build_n1_actor_wave_v2 <- function(analysis_path, predata_path, out_dir=NULL) {
  neg_na <- function(x) {x<-as.numeric(x);x[x<0]<-NA_real_;x}
  id <- function(x) as.character(x)
  same <- function(x) length(unique(x))==1L
  equal_num <- function(a,b) all((is.na(a)&is.na(b)) | (!is.na(a)&!is.na(b)&abs(a-b)<1e-6))
  d <- if(grepl("[.]rds$",analysis_path)) readRDS(analysis_path) else
    utils::read.csv(analysis_path,stringsAsFactors=FALSE,na.strings=c("NA",""))
  if(!is.data.frame(d)) stop("analysis_path必须直接保存分析data.frame")
  ep <- do.call(rbind,lapply(c("begin","end"),function(t) {
    data.frame(dyad=id(d$dyad_id),wave=d[[paste0(t,"_year")]],
      actor=id(d[[paste0("actor_pid_",t)]]),role=id(d$parent_role),
      parent=id(d[[paste0("parent_pid_",t)]]),cl=id(d$unified_component),
      support=d[[paste0("support_real_",t)]],s=d[[paste0("self_sat_",t)]],
      sp=d[[paste0("spouse_sat_",t)]],inc=d[[paste0("actor_income_real_",t)]],
      stringsAsFactors=FALSE)
  }))
  stopifnot(all(ep$wave %in% c(2018,2020,2022)))
  # 2020取已入选二元组端点的并集，不随意保留第一段；同一二元组重叠必须完全一致。
  ky <- paste(ep$dyad,ep$wave,sep="|")
  groups <- split(seq_len(nrow(ep)),ky)
  check <- names(ep)
  for(ii in groups) if(length(ii)>1L && !all(vapply(ep[ii,check,drop=FALSE],same,logical(1))))
    stop("同一dyad-wave端点冲突: ",ky[ii[1]])
  ep <- ep[!duplicated(ky),,drop=FALSE]
  cols <- c("pid","year","pid_","qf602_a__","msat_c1_","msat_c2_","gender_","aage_","actor_edu2_","ahk_")
  raw <- haven::read_dta(predata_path,col_select=tidyselect::all_of(cols))
  raw <- as.data.frame(raw);raw <- raw[raw$year %in% c(2018,2020,2022),,drop=FALSE]
  rk <- paste(id(raw$pid),raw$year,sep="|")
  if(anyDuplicated(rk)) stop("predata dyad-wave不唯一")
  mi <- match(paste(ep$dyad,ep$wave,sep="|"),rk)
  if(anyNA(mi)) stop("predata未完全匹配分析端点")
  z <- raw[mi,,drop=FALSE]
  # 原generator优先temple的actor PID；预处理pid_必须与已验证端点一致，否则保留门禁。
  if(!identical(id(z$pid_),ep$actor)) stop("predata pid_与已核actor身份不一致，需回查temple身份表")
  cpi <- c(`2018`=103.7,`2020`=109.4,`2022`=112.6)
  if(!equal_num(neg_na(z$qf602_a__)*100/cpi[as.character(ep$wave)],ep$support)) stop("支持金额来源核验失败")
  if(!equal_num(neg_na(z$msat_c1_),ep$s)||!equal_num(neg_na(z$msat_c2_),ep$sp)) stop("满意度原始等级核验失败")
  ep$age <- neg_na(z$aage_);ep$edu <- neg_na(z$actor_edu2_);ep$hukou <- neg_na(z$ahk_)
  sex <- neg_na(z$gender_);if(any(!is.na(sex)&!sex %in% 0:1)) stop("gender异常")
  ep$female <- as.integer(sex==0)
  # parent=-8是角色身份不确定，不能用这个特殊码合并父母。
  slot <- paste(ep$actor,ep$wave,ep$role,sep="|")
  if(anyDuplicated(slot)) stop("同一actor-wave-parent_role多个二元组，须独核角色身份")
  ag <- split(seq_len(nrow(ep)),paste(ep$actor,ep$wave,sep="|"))
  av <- c("actor","wave","cl","s","sp","inc","female","age","edu","hukou")
  ans <- lapply(ag,function(ii) {
    u<-ep[ii,,drop=FALSE]
    if(!all(vapply(u[,av,drop=FALSE],same,logical(1)))) stop("actor-wave人口属性或簇不一致")
    # 已知父母ID不可同时占两个角色；-8保留各自角色。
    known<-u$parent[!is.na(u$parent)&suppressWarnings(as.numeric(u$parent))>0]
    if(anyDuplicated(known)) stop("已知相同parent PID重复占角色")
    a<-u[1,av,drop=FALSE];a$n_par<-nrow(u)
    # 严格缺失：任何观测父母槽金额缺失，则本人波次结局缺失；不给钱的结构零仍为0。
    a$y_any<-if(anyNA(u$support)) NA_integer_ else as.integer(any(u$support>0))
    a
  })
  w<-do.call(rbind,ans);rownames(w)<-NULL
  w<-w[order(w$actor,w$wave),,drop=FALSE]
  if(any(vapply(split(w$cl,w$actor),function(x)!same(x),logical(1)))) stop("跨波次簇变动")
  provenance<-list(wave_covariates_observed=TRUE,support_allocation_adjudicated=TRUE,
    overlap_2020_adjudicated=TRUE,parent_identity_adjudicated=TRUE,
    estimand="Any support to observed eligible parent slots, strict missing; actor-wave union of selected dyad endpoints",
    parent_identity_scope="Known PID conflict checked; -8 kept as distinct father/mother roles, not resolved physical identities",
    source_analysis=normalizePath(analysis_path),source_predata=normalizePath(predata_path),
    source_hashes=c(analysis=digest::digest(file=analysis_path,algo="sha256"),predata=digest::digest(file=predata_path,algo="sha256")))
  audit<-list(input_rows=nrow(d),unique_dyad_wave=nrow(ep),actor_wave=nrow(w),actors=length(unique(w$actor)),
    parent_slots_unknown=sum(is.na(ep$parent)|suppressWarnings(as.numeric(ep$parent))<0),
    missing_by_variable=colSums(is.na(w)),wave_counts=table(w$wave),
    covariate_changes=lapply(c("edu","hukou"),function(v) sum(vapply(split(w[[v]],w$actor),function(x)length(unique(x[!is.na(x)]))>1,logical(1)))))
  result<-list(w=w,provenance=provenance,audit=audit,parent_slots=ep)
  if(!is.null(out_dir)) {
    paths<-file.path(out_dir,c("actor_wave_v2.rds","actor_wave_v2.csv","actor_wave_audit_v2.rds"))
    if(any(file.exists(paths))) stop("目标已存在，不覆盖既有产物")
    dir.create(out_dir,recursive=TRUE,showWarnings=FALSE)
    saveRDS(result,paths[1]);utils::write.csv(w,paths[2],row.names=FALSE);saveRDS(audit,paths[3])
  }
  result
}
