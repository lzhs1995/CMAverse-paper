# 限定N1/N2：只定义函数，不读数据、不提交作业、不自动拟合。
# 必须由supervisor在原生R会话中验证后使用。N1不是中介/调节检验。

fit_n1_reviewed_wave <- function(w, provenance) {
  # 调用者必须交付来源核验后的唯一本人—波次表；不推算年龄或沿用期初教育/户口。
  required <- c("wave_covariates_observed", "support_allocation_adjudicated",
                "overlap_2020_adjudicated", "parent_identity_adjudicated")
  if (!all(vapply(required, function(k) identical(provenance[[k]], TRUE), logical(1))))
    stop("N1_NOT_ESTIMABLE: wave/support/identity provenance not adjudicated")
  vars <- c("actor","wave","cl","y_any","s","sp","inc","female","age","edu","hukou","n_par")
  stopifnot(all(vars %in% names(w)), !anyDuplicated(w[c("actor","wave")]),
            all(w$wave %in% c(2018L,2020L,2022L)))
  if (any(vapply(split(w$cl,w$actor), function(x) length(unique(x))!=1L, logical(1))))
    stop("本人跨波次簇身份不一致")
  z <- w[stats::complete.cases(w[,vars]),vars,drop=FALSE]
  # 至少两次观测才进入本轮人内分解；缺失规则及分析样本先固定。
  count <- table(z$actor); z <- z[z$actor %in% names(count[count>=2L]),,drop=FALSE]
  stopifnot(nrow(z)>0L,all(z$y_any %in% 0:1),all(z$s %in% 1:5),all(z$sp %in% 1:5))
  z$inc_ihs <- asinh(z$inc)
  for(v in c("s","sp","inc_ihs")) {
    z[[paste0(v,"_mean")]] <- ave(z[[v]],z$actor,FUN=mean)
    z[[paste0(v,"_dev")]] <- z[[v]]-z[[paste0(v,"_mean")]]
  }
  f <- y_any ~ s_mean+s_dev+sp_mean+sp_dev+inc_ihs_mean+inc_ihs_dev+
    factor(wave)+female+age+I(age^2)+edu+hukou+n_par
  m <- stats::lm(f,data=z)
  if(m$rank != length(stats::coef(m))) stop("N1设计矩阵降秩；不删控制变量")
  V <- sandwich::vcovCL(m,cluster=z$cl,type="HC1")
  terms <- c("s_mean","s_dev","sp_mean","sp_dev")
  b <- stats::coef(m)[terms];se <- sqrt(diag(V)[terms]);p <- 2*stats::pnorm(-abs(b/se))
  stopifnot(all(is.finite(c(b,se,p))),all(se>0))
  out <- data.frame(term=terms,estimate=b,se=se,ci_low=b-1.96*se,ci_high=b+1.96*se,
                    p_raw=p,q_BH4=stats::p.adjust(p,"BH",n=4),q_BY4=stats::p.adjust(p,"BY",n=4))
  # 诊断不另挑p值；若logit失败，保留失败而非替换LPM。
  logit <- tryCatch({
    mg <- stats::glm(f,data=z,family=stats::binomial())
    stopifnot(isTRUE(mg$converged),all(is.finite(stats::coef(mg))))
    pr <- stats::predict(mg,type="response")
    data.frame(term=terms,ame=stats::coef(mg)[terms]*mean(pr*(1-pr)))
  },error=function(e) list(status="FAILED",message=conditionMessage(e)))
  list(status="COMPLETED",primary=out,logit_diagnostic=logit,formula=f,n=nrow(z),
       actors=length(unique(z$actor)),clusters=length(unique(z$cl)),data=z,
       interpretation="Exploratory between/within association; not X-M interaction or mediation",
       global6_adjustment="Apply centrally with both registered P3 omnibus p values")
}

n2_period_points <- function(d,e,original_s2_path) {
  # e必须是实际生产补丁加载环境；复用原S2估计定义，无新增bootstrap。
  old <- readRDS(original_s2_path)
  stopifnot(all(c("est","boot","formula","n","clusters") %in% names(old)))
  cv <- e$covs_for("none",drop=c("gender_begin","period_fe"))
  stopifnot(!"dwm_begin" %in% cv,!"gender_begin" %in% cv,"y0_any" %in% cv)
  f <- e$fml("y1_any",c(cv,"xa"))
  ans <- lapply(c("2018-2020","2020-2022"),function(period) {
    dat <- e$zscale(e$analysis_sample(d[d$period==period,,drop=FALSE],
                   unique(c(all.vars(f),"female"))),cv)
    tryCatch({
      val <- e$stat_S2(dat,f)
      stopifnot(all(is.finite(val)))
      data.frame(period=period,n=nrow(dat),clusters=length(unique(dat[[e$CLUSTER]])),
                 S2=val[["S2"]],T_female=val[["T_female"]],T_male=val[["T_male"]],
                 status="ESTIMATED",message="")
    },error=function(err) data.frame(period=period,n=nrow(dat),clusters=length(unique(dat[[e$CLUSTER]])),
                 S2=NA_real_,T_female=NA_real_,T_male=NA_real_,status="FAILED",message=conditionMessage(err)))
  })
  list(original=old,period_points=do.call(rbind,ans),formula=f,covariates=cv,
       outcome="期末是否支持(y1_any)",new_bootstrap=FALSE,
       actor_period_status="NOT_ESTIMATED_PENDING_PARENT_ALLOCATION_ADJUDICATION")
}
