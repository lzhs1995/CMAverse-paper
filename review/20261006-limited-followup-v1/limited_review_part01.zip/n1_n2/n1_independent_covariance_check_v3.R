# N1独立线性代数验算：source不执行；不调用lm/glm/vcovCL，不改变模型或追加检验。
# 仅供supervisor原生执行。会由原保存样本重建OLS解及整簇HC1，写独立验算JSON。
n1_independent_covariance_check_v3 <- function(out_dir='/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/n1_n2/runtime_v2/N1_formal_v3') {
  stopifnot(requireNamespace('digest',quietly=TRUE),requireNamespace('jsonlite',quietly=TRUE))
  path<-file.path(out_dir,'N1_result.rds')
  stopifnot(identical(digest::digest(file=path,algo='sha256'),'a4db351d1c8c38ac786d272d17a878ff0e405db6285c3077a3e9624bb317a0ec'))
  r<-readRDS(path);z<-r$data;X<-stats::model.matrix(r$formula,data=z);y<-z$y_any
  n<-nrow(X);k<-ncol(X);G<-length(unique(z$cl));stopifnot(n>k,G>1L,qr(X)$rank==k)
  # 缩放仅为线性代数数值稳定性；不改变原X列空间、参数或样本。
  scale<-sqrt(colSums(X^2));stopifnot(all(scale>0),all(is.finite(scale)))
  Z<-sweep(X,2,scale,'/');bread<-chol2inv(chol(crossprod(Z)))
  coef_z<-drop(bread%*%crossprod(Z,y));res<-y-drop(Z%*%coef_z)
  scores<-rowsum(Z*res,group=z$cl,reorder=FALSE)
  # sandwich 3.1-3 的cluster HC1，含默认cadjust=TRUE。
  correction<-(n-1)/(n-k)*G/(G-1)
  Vz<-bread%*%crossprod(scores)%*%bread*correction
  V<-Vz/outer(scale,scale);dimnames(V)<-list(colnames(X),colnames(X))
  b<-coef_z/scale;names(b)<-colnames(X)
  tt<-as.character(r$primary$term);est<-unname(b[tt]);se<-sqrt(diag(V)[tt]);p<-2*stats::pnorm(-abs(est/se))
  maxerr<-c(estimate=max(abs(est-r$primary$estimate)),se=max(abs(se-r$primary$se)),p=max(abs(p-r$primary$p_raw)))
  passed<-all(is.finite(maxerr))&&all(maxerr<1e-7)
  record<-list(passed=passed,method='Scaled normal equations plus cluster score outer products; no lm/glm/vcovCL calls',
    n=n,k=k,clusters=G,HC1_cadjust=correction,max_absolute_error=as.list(maxerr),tolerance=1e-7,
    columns=colnames(X),formula=deparse(r$formula),new_tests=0L,
    boundary='Implementation equivalence only; does not establish causality or validate new significance')
  jsonlite::write_json(record,file.path(out_dir,'INDEPENDENT_COVARIANCE_CHECK_v3.json'),pretty=TRUE,auto_unbox=TRUE)
  stopifnot(passed);invisible(record)
}
