# 只读结果验收，不拟合、不追加检验；唯一写入本次ACCEPTANCE.json。
n1_native_accept_v3 <- function(out_dir,h) {
  for(p in c('digest','jsonlite'))stopifnot(requireNamespace(p,quietly=TRUE))
  r<-readRDS(file.path(out_dir,'N1_result.rds'))
  pin<-'9d90bd91465840d4f07225f8f04bd58a0efecc5ae67fcda97b5b461b4b7b0eff'
  ip<-file.path(h,'runtime_v2/actor_wave_v2.rds')
  stopifnot(identical(digest::digest(file=ip,algo='sha256'),pin),r$status=='COMPLETED',
    identical(environment(r$formula),baseenv()),r$new_primary_tests==4L,r$new_n2_tests==0L)
  w<-readRDS(ip)$w
  vars<-c('actor','wave','cl','y_any','s','sp','inc','female','age','edu','hukou','n_par')
  z<-w[stats::complete.cases(w[,vars]),vars,drop=FALSE]
  count<-table(z$actor);z<-z[z$actor %in% names(count[count>=2L]),,drop=FALSE]
  z$inc_ihs<-asinh(z$inc)
  for(v in c('s','sp','inc_ihs')) {
    z[[paste0(v,'_mean')]]<-ave(z[[v]],z$actor,FUN=mean)
    z[[paste0(v,'_dev')]]<-z[[v]]-z[[paste0(v,'_mean')]]
  }
  stopifnot(identical(r$data,z),r$n==nrow(z),r$actors==length(unique(z$actor)),
    r$clusters==length(unique(z$cl)),all(table(z$actor)>=2L),!anyDuplicated(z[c('actor','wave')]))
  for(v in c('s','sp','inc_ihs'))stopifnot(max(abs(tapply(z[[paste0(v,'_dev')]],z$actor,mean)))<1e-10)
  expected<-stats::as.formula('y_any ~ s_mean + s_dev + sp_mean + sp_dev + inc_ihs_mean + inc_ihs_dev + factor(wave) + female + age + I(age^2) + edu + hukou + n_par',env=baseenv())
  stopifnot(identical(deparse(r$formula),deparse(expected)),r$covariance_contract$type=='HC1',isTRUE(r$covariance_contract$cadjust))
  tt<-c('s_mean','s_dev','sp_mean','sp_dev');p<-r$primary
  stopifnot(nrow(p)==4L,identical(as.character(p$term),tt),all(is.finite(p$estimate)),all(is.finite(p$se)),all(p$se>0))
  near<-function(a,b)isTRUE(all.equal(unname(a),unname(b),tolerance=1e-12))
  stopifnot(near(p$p_raw,2*stats::pnorm(-abs(p$estimate/p$se))),
    near(p$ci_low,p$estimate-1.96*p$se),near(p$ci_high,p$estimate+1.96*p$se),
    near(p$q_BH4,stats::p.adjust(p$p_raw,'BH',n=4)),near(p$q_BY4,stats::p.adjust(p$p_raw,'BY',n=4)),
    all(is.na(p$q_BH6)),all(is.na(p$q_BY6)),all(p$global6_status=='PENDING_TWO_REGISTERED_P3_OMNIBUS'))
  diskp<-utils::read.csv(file.path(out_dir,'N1_primary_four.csv'),stringsAsFactors=FALSE)
  for(k in c('estimate','se','p_raw','q_BH4','q_BY4'))stopifnot(near(diskp[[k]],p[[k]]))
  n2path<-file.path(h,'runtime_v2/N2_period_points.csv')
  stopifnot(identical(digest::digest(file=n2path,algo='sha256'),'e90532a89b52aae80372fe7250458200adb0737cd6bbc092215796fa0a6af6dd'),
    identical(utils::read.csv(n2path),utils::read.csv(file.path(out_dir,'N2_existing_period_points.csv'))))
  files<-file.path(out_dir,c('N1_result.rds','N1_primary_four.csv','N1_analysis_sample.csv','N2_existing_period_points.csv'))
  evidence<-lapply(files,function(p)list(path=p,bytes=unname(file.info(p)$size),sha256=digest::digest(file=p,algo='sha256')))
  stopifnot(all(vapply(evidence,function(x)x$bytes<25e6,logical(1))))
  record<-list(passed=TRUE,n=r$n,actors=r$actors,clusters=r$clusters,new_tests=4L,new_N2_tests=0L,
    sample_rebuilt_without_refitting=TRUE,formula_environment='baseenv',primary_arithmetic_verified=TRUE,
    global6_status='PENDING_TWO_REGISTERED_P3_OMNIBUS',
    limit='Checks sample, formula, stored inference arithmetic and artifacts; does not independently refit covariance',files=evidence)
  jsonlite::write_json(record,file.path(out_dir,'ACCEPTANCE.json'),pretty=TRUE,auto_unbox=TRUE)
  invisible(record)
}
