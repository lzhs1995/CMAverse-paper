# N1原生短执行：source只定义函数；N2只复用已有CSV，不拟合。
n1_native_root_v3 <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/n1_n2'
n1_native_pins_v3 <- c(functions='e39d192a7406009153ea555bbaa0c6ba91509b1b99ffb9ed1cc8c25fa24cc3c9',
 input='9d90bd91465840d4f07225f8f04bd58a0efecc5ae67fcda97b5b461b4b7b0eff',
 n2='e90532a89b52aae80372fe7250458200adb0737cd6bbc092215796fa0a6af6dd')
# v2：使用ps原生磁盘API，避免依赖df文本/环境；未知值一律停止。
n1_native_disk_value_v3 <- function(usage,minimum_bytes=10e9) {
  if(!is.numeric(minimum_bytes)||length(minimum_bytes)!=1L||
     !is.finite(minimum_bytes)||minimum_bytes<=0)stop("DISK_GATE_UNKNOWN: 无效阈值")
  if(!is.data.frame(usage)||nrow(usage)!=1L||!("available"%in%names(usage))||
     !is.numeric(usage$available)||length(usage$available)!=1L||
     !is.finite(usage$available)||usage$available<0)
    stop("DISK_GATE_UNKNOWN: 原生API未返回唯一有效available bytes；停止新增作业")
  available<-as.double(usage$available)
  if(available<minimum_bytes)
    stop(sprintf("DISK_GATE_LOW: available=%.0f bytes < minimum=%.0f bytes；保留原队列，不新增模型/缓存",available,minimum_bytes))
  available
}
n1_native_disk_v3 <- function() {
  if(!requireNamespace("ps",quietly=TRUE))
    stop("DISK_GATE_UNKNOWN: ps不可用；停止新增作业")
  path<-normalizePath(n1_native_root_v3,mustWork=TRUE)
  usage<-tryCatch(ps::ps_disk_usage(path),error=function(err)
    stop("DISK_GATE_UNKNOWN: ps::ps_disk_usage失败：",conditionMessage(err)))
  n1_native_disk_value_v3(usage)
}
n1_native_execute_v3 <- function(out_dir=file.path(n1_native_root_v3,'runtime_v2/N1_formal_v3'),
                                 native_progress=function(...)NULL) {
  stopifnot(is.function(native_progress))
  for(p in c('sandwich','digest','jsonlite'))stopifnot(requireNamespace(p,quietly=TRUE))
  h<-n1_native_root_v3
  paths<-c(functions=file.path(h,'limited_n1_n2_functions.R'),input=file.path(h,'runtime_v2/actor_wave_v2.rds'),
           n2=file.path(h,'runtime_v2/N2_period_points.csv'))
  hashes<-vapply(paths,function(p)digest::digest(file=p,algo='sha256'),character(1))
  stopifnot(identical(hashes,n1_native_pins_v3))
  free<-n1_native_disk_v3() # available bytes；未知或不足10GB均拒绝新增模型
  if(dir.exists(out_dir))stop('目标已存在；禁止自动重跑或覆盖，先核原终态')
  stopifnot(dir.create(out_dir,recursive=TRUE))
  progress<-function(stage,message) {
    record<-list(stage=stage,message=message,updated_at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid())
    tmp<-file.path(out_dir,'PROGRESS.json.tmp');jsonlite::write_json(record,tmp,auto_unbox=TRUE,pretty=TRUE)
    stopifnot(file.rename(tmp,file.path(out_dir,'PROGRESS.json')))
    cat(record$updated_at,stage,message,'\n');flush.console();native_progress(stage,message)
  }
  started<-Sys.time()
  tryCatch({
    progress('n1_read','读取原生已核actor-wave，冻结完整共同样本后做人内分解')
    a<-readRDS(paths['input']);stopifnot(nrow(a$w)==13514L,length(unique(a$w$actor))==5318L)
    e<-new.env(parent=globalenv());sys.source(paths['functions'],e)
    progress('n1_fit','固定LPM + unified_component聚类HC1；四项人际/人内关联，非中介调节')
    r<-e$fit_n1_reviewed_wave(a$w,a$provenance)
    # 返回公式的环境原本捕获整次拟合环境；保存前固定为baseenv，不序列化模型/调用图。
    environment(r$formula)<-baseenv()
    stopifnot(identical(environment(r$formula),baseenv()))
    r$primary$test_id<-c('N1_SELF_BETWEEN','N1_SELF_WITHIN','N1_SPOUSE_BETWEEN','N1_SPOUSE_WITHIN')
    r$primary$q_BH6<-NA_real_;r$primary$q_BY6<-NA_real_
    r$primary$global6_status<-'PENDING_TWO_REGISTERED_P3_OMNIBUS'
    r$covariance_contract<-list(estimator='sandwich::vcovCL',cluster='cl (unified_component)',type='HC1',
                              cadjust=TRUE,p_reference='two-sided standard normal',ci_multiplier=1.96)
    r$input_source<-as.list(paths);r$input_sha256<-as.list(hashes)
    r$provenance<-a$provenance
    r$sample_sha256<-digest::digest(r$data,algo='sha256',serialize=TRUE,serializeVersion=2)
    r$session<-capture.output(utils::sessionInfo())
    r$new_primary_tests<-4L;r$new_n2_tests<-0L
    r$n2_reuse<-list(path=unname(paths['n2']),sha256=unname(hashes['n2']),new_estimation=FALSE)
    progress('n1_save','保存四项及q4；跨六项q等待P3，不将N1关联计作婚姻机制')
    rp<-file.path(out_dir,'N1_result.rds');saveRDS(r,rp)
    stopifnot(identical(r,readRDS(rp)),file.info(rp)$size<25e6)
    utils::write.csv(r$primary,file.path(out_dir,'N1_primary_four.csv'),row.names=FALSE,na='NA')
    utils::write.csv(r$data,file.path(out_dir,'N1_analysis_sample.csv'),row.names=FALSE,na='NA')
    n2<-utils::read.csv(paths['n2'],stringsAsFactors=FALSE)
    utils::write.csv(n2,file.path(out_dir,'N2_existing_period_points.csv'),row.names=FALSE,na='NA')
    capture.output(r$session,file=file.path(out_dir,'SESSION.txt'))
    ae<-new.env(parent=globalenv());sys.source(file.path(h,'n1_native_accept_v3.R'),ae)
    acceptance<-ae$n1_native_accept_v3(out_dir,h)
    stopifnot(isTRUE(acceptance$passed))
    terminal<-list(status='FUNCTION_COMPLETED',at=format(Sys.time(),tz='UTC',usetz=TRUE),pid=Sys.getpid(),
                   seconds=as.numeric(difftime(Sys.time(),started,units='secs')),acceptance=acceptance,
                   boundary='Function return; original native job/process terminal retained by supervisor')
    jsonlite::write_json(terminal,file.path(out_dir,'FUNCTION_TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE)
    progress('n1_complete',paste('N1四项完成；分析记录',r$n,'本人',r$actors,'簇',r$clusters,'；N2零新增拟合'))
    print(r$primary);invisible(terminal)
  },error=function(err){
    try(jsonlite::write_json(list(status='FAILED',pid=Sys.getpid(),at=as.character(Sys.time()),error=conditionMessage(err)),
        file.path(out_dir,'FUNCTION_TERMINAL.json'),auto_unbox=TRUE,pretty=TRUE),silent=TRUE)
    try(progress('n1_failed',conditionMessage(err)),silent=TRUE);stop(err)
  })
}

# 纯合成门禁边界自检；不访问磁盘、不读真实数据、不拟合。由原生R调用。
n1_native_disk_self_test_v3 <- function() {
  stopifnot(identical(n1_native_disk_value_v3(data.frame(available=10e9)),10e9),
            identical(n1_native_disk_value_v3(data.frame(available=10e9+1)),10e9+1))
  bad<-list(NULL,list(available=10e9),data.frame(),data.frame(available=numeric()),
    data.frame(available=c(10e9,10e9)),data.frame(free=10e9),data.frame(available='10000000000'),
    data.frame(available=NA_real_),data.frame(available=NaN),data.frame(available=Inf),
    data.frame(available=-1),data.frame(available=0),data.frame(available=10e9-1))
  rejected<-vapply(bad,function(x)inherits(try(n1_native_disk_value_v3(x),silent=TRUE),'try-error'),logical(1))
  stopifnot(all(rejected))
  list(passed=TRUE,accepted=2L,rejected=length(bad),scope='synthetic gate values only; no disk/model execution')
}
