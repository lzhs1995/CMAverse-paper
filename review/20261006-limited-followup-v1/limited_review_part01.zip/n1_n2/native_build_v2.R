local({
 h <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/n1_n2"
 pkg <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/delivery/Claude云端分析资料_20261005_v1"
 predata <- "/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/Prepare_data/predata_FE_16_22_unbal.dta"
 stopifnot(all(vapply(c("haven","tidyselect","digest","sandwich"),requireNamespace,logical(1),quietly=TRUE)))
 ne <- new.env(parent=environment())
 sys.source(file.path(h,"build_n1_actor_wave_v2.R"),ne)
 a <- ne$build_n1_actor_wave_v2(file.path(pkg,"data/analysis_13092.csv"),predata,file.path(h,"runtime_v2"))
 capture.output(str(a$audit),file=file.path(h,"runtime_v2/NATIVE_BUILD_AUDIT.txt"))
 print(a$audit)
})
