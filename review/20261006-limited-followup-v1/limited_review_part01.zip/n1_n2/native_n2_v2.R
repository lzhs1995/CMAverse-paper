local({
 root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"; h <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/n1_n2"
 e <- new.env(parent=environment());sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
 for(f in c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","checkpoint_boot_v1.R")) sys.source(file.path(root,f),e)
 e$PKG_DIR <- file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
 e$OUT_DIR <- file.path(root,"production_two_stage_v1");e$load_covariates();e$check_frozen()
 sys.source(file.path(h,"limited_n1_n2_functions.R"),e)
 d <- readRDS(file.path(e$OUT_DIR,"prepared_data.rds"))$d
 r <- e$n2_period_points(d,e,file.path(root,"secondary_S_v1/S2.rds"))
 saveRDS(r,file.path(h,"runtime_v2/N2_period_result.rds"))
 write.csv(r$period_points,file.path(h,"runtime_v2/N2_period_points.csv"),row.names=FALSE)
 print(r$period_points)
})
