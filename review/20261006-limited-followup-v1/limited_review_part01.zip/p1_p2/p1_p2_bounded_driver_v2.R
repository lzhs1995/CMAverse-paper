# 单原生R worker有界驱动；source不执行。仅既有031/041 v5对象，无新规格。
p12d_root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/p1_p2'
p12d_pins <- list(
 worker='3b30a9a4f7300ed44a661011be5cd800a21ac857757c4514210d8a2e263fb298',
 FEAS_031=c(input='14a2e2e629896f3bfe42cc8ece6806cd723228f968f853997ec5816c41d94069',equivalence='15f9d9b2ceb59864e2344f1785c58986ed1c0005a45c0d9467b628893cbb7448'),
 FEAS_041=c(input='30c2b159ce8ed922d394a7848d5b5ea75451c52855d8a501a36ff773b007f180',equivalence='fa0e1fbcb963c59d9d496580061790b5dbc54f2edf928d978a9a3ca8280e9816'))
p12d_sha <- function(p) digest::digest(file=p,algo='sha256')
# v2：使用ps原生磁盘API，避免依赖df文本/环境；未知值一律停止。
p12d_disk_value <- function(usage,minimum_bytes=10e9) {
  if(!is.numeric(minimum_bytes)||length(minimum_bytes)!=1L||
     !is.finite(minimum_bytes)||minimum_bytes<=0)stop("DISK_GATE_UNKNOWN: 无效阈值")
  if(!is.data.frame(usage)||nrow(usage)!=1L||!("available"%in%names(usage))||
     !is.numeric(usage$available)||length(usage$available)!=1L||
     !is.finite(usage$available)||usage$available<0)
    stop("DISK_GATE_UNKNOWN: 原生API未返回唯一有效available bytes；停止新增作业")
  available<-as.double(usage$available)
  if(available<minimum_bytes)
    stop(sprintf("DISK_GATE_LOW: available=%.0f bytes < minimum=%.0f bytes；保留原队列，不新增模型/缓存",available,minimum_bytes))
  available
}
p12d_disk <- function() {
  if(!requireNamespace("ps",quietly=TRUE))
    stop("DISK_GATE_UNKNOWN: ps不可用；停止新增作业")
  path<-normalizePath(p12d_root,mustWork=TRUE)
  usage<-tryCatch(ps::ps_disk_usage(path),error=function(err)
    stop("DISK_GATE_UNKNOWN: ps::ps_disk_usage失败：",conditionMessage(err)))
  p12d_disk_value(usage)
}
p12d_progress <- function(stage,message,id='',native_progress=function(...)NULL) {
  x<-list(stage=stage,message=message,id=id,pid=Sys.getpid(),updated_at=format(Sys.time(),tz='UTC',usetz=TRUE))
  dest<-file.path(p12d_root,'BOUNDED_PROGRESS.json');tmp<-paste0(dest,'.tmp')
  jsonlite::write_json(x,tmp,pretty=TRUE,auto_unbox=TRUE);stopifnot(file.rename(tmp,dest))
  cat(x$updated_at,stage,id,message,'\n');flush.console();native_progress(stage,paste(id,message))
}
p12d_load <- function() {
  stopifnot(requireNamespace('digest'),requireNamespace('jsonlite'))
  p<-file.path(p12d_root,'p1_p2_frozen_worker.R');stopifnot(identical(p12d_sha(p),p12d_pins$worker))
  e<-new.env(parent=globalenv());sys.source(p,e)
  objects<-lapply(c('FEAS_031','FEAS_041'),function(id) {
    dir<-file.path(p12d_root,paste0(id,'_prepare_v5'));ip<-file.path(dir,'INPUTS.rds');eq<-file.path(dir,'EQUIVALENCE.rds')
    stopifnot(identical(p12d_sha(ip),unname(p12d_pins[[id]]['input'])),
              identical(p12d_sha(eq),unname(p12d_pins[[id]]['equivalence'])),isTRUE(readRDS(eq)$passed))
    o<-readRDS(ip);stopifnot(identical(o$id,id),identical(normalizePath(o$destination),normalizePath(dir)))
    e$p12_check_sources(o);o
  });names(objects)<-c('FEAS_031','FEAS_041');list(e=e,objects=objects)
}
p12d_chunk_state <- function(o,first,last) {
  dir<-file.path(o$destination,sprintf('chunk_%04d_%04d',first,last));term<-file.path(dir,'TERMINAL.rds')
  paths<-file.path(o$destination,sprintf('DRAW_%04d.rds',seq.int(first,last)))
  if(!dir.exists(dir)&&!any(file.exists(paths)))return('NOT_STARTED')
  if(!file.exists(term)||!all(file.exists(paths)))stop('PARTIAL_CHUNK_STOP: ',o$id,' ',first,'-',last,'；保留证据，不重跑已有draw')
  z<-readRDS(term);stopifnot(identical(as.integer(z$first),as.integer(first)),identical(as.integer(z$last),as.integer(last)))
  if(!is.null(z$error))stop('FAILED_CHUNK_STOP: ',z$error)
  dg<-z$diagnostics
  if(!is.data.frame(dg))dg<-do.call(rbind,dg)
  stopifnot(nrow(dg)==last-first+1L,all(c('execution_ok','fits_valid','core_finite')%in%names(dg)))
  if(anyNA(dg[,c('execution_ok','fits_valid','core_finite')])||!all(dg$execution_ok & dg$fits_valid & dg$core_finite))stop('INVALID_REPEAT_STOP: ',o$id,' ',first,'-',last)
  for(b in seq.int(first,last)) {
    a<-readRDS(paths[b-first+1L])
    stopifnot(a$b==b,identical(a$index_sha,digest::digest(o$inputs$actual_indices[[b]],algo='sha256')),
      identical(a$seed,o$inputs$replicate_seeds[b]))
    for(g in a$grid)for(m in g$models)stopifnot(isTRUE(m$converged),m$rank==length(m$coefficients),all(is.finite(m$coefficients)))
  }
  'COMPLETE'
}
p12d_review <- function(e,o) {
  for(first in seq.int(1L,151L,50L))stopifnot(p12d_chunk_state(o,first,first+49L)=='COMPLETE')
  # 不计算、不读取p值；仅固定200次的索引、拟合有效性、效应有限性及点值一致。
  firsts<-seq.int(1L,151L,50L);terms<-file.path(o$destination,sprintf('chunk_%04d_%04d/TERMINAL.rds',firsts,firsts+49L))
  points<-lapply(terms,function(p)readRDS(p)$revised_point)
  stopifnot(all(vapply(points,function(v)!is.null(v)&&all(is.finite(v)),logical(1))),
    all(vapply(points,function(v)isTRUE(all.equal(v,points[[1]],tolerance=1e-10)),logical(1))))
  for(b in seq_len(200L))stopifnot(all(is.finite(e$p12_metric(readRDS(file.path(o$destination,sprintf('DRAW_%04d.rds',b)))$grid))))
  record<-list(passed=TRUE,B=200L,technical_only=TRUE,p_value_used=FALSE,
    inputs_sha256=unname(p12d_pins[[o$id]]['input']),terminal_paths=terms,
    terminal_sha256=vapply(terms,p12d_sha,character(1)),fixed_next_B=1000L)
  path<-file.path(o$destination,'TECHNICAL_REVIEW.rds')
  if(file.exists(path))stopifnot(identical(readRDS(path),record)) else e$p12_write(record,path)
  invisible(record)
}
# phase=screen:两候选各1:200；review:无p技术审查；finish:两者通过后固定201:1000；points:全LOO+分期。
# max_units为chunk或50簇批数；max_seconds仅在阶段边界停止，不中断正在运行的原生调用。
p12d_run <- function(phase=c('screen','review','finish','points'),max_units=2L,max_seconds=1800,native_progress=function(...)NULL) {
  phase<-match.arg(phase);stopifnot(max_units>=1,max_seconds>0,is.function(native_progress))
  q<-p12d_load();e<-q$e;objects<-q$objects
  lock<-file.path(p12d_root,'BOUNDED_DRIVER.lock')
  if(!dir.create(lock,showWarnings=FALSE))stop('SINGLE_WORKER_LOCK_BUSY: 不自动接管或删锁')
  on.exit(unlink(lock,recursive=TRUE),add=TRUE)
  jsonlite::write_json(list(pid=Sys.getpid(),phase=phase,at=as.character(Sys.time())),file.path(lock,'OWNER.json'),auto_unbox=TRUE)
  start<-Sys.time();units<-0L
  progress<-function(stage,message,id='')p12d_progress(stage,message,id,native_progress)
  exhausted<-function()units>=max_units||as.numeric(difftime(Sys.time(),start,units='secs'))>=max_seconds
  tryCatch({
    p12d_disk();progress('start',paste('phase',phase))
    if(phase=='review') {
      for(o in objects){p12d_review(e,o);progress('technical_review','200次技术门槛通过；固定推进1000',o$id)}
    } else if(phase%in%c('screen','finish')) {
      if(phase=='finish')for(o in objects)p12d_review(e,o)
      firsts<-if(phase=='screen')seq.int(1L,151L,50L) else seq.int(201L,951L,50L)
      for(o in objects)for(first in firsts) {
        last<-first+49L;state<-p12d_chunk_state(o,first,last)
        if(state=='COMPLETE')next
        if(exhausted()){progress('resumable','本次有界预算到达；下次同phase只执行未开始chunk');return(invisible(list(status='RESUMABLE',units=units)))}
        p12d_disk();progress('chunk_start',paste(first,last),o$id)
        e$p12_run_chunk(o,first,last,function(stage,message)progress(stage,message,o$id))
        stopifnot(p12d_chunk_state(o,first,last)=='COMPLETE');units<-units+1L
        progress('chunk_complete',paste(first,last),o$id)
      }
    } else {
      for(o in objects) {
        for(first in seq.int(1L,951L,50L))stopifnot(p12d_chunk_state(o,first,first+49L)=='COMPLETE')
        # 既有point_batch会跳过已留存LOO（包括FAILED），故不补抽/不换簇。
        period_ids<-sort(unique(o$period))
        period_paths<-file.path(o$destination,paste0('PERIOD_',gsub('[^A-Za-z0-9_-]','_',period_ids),'.rds'))
        if(!all(file.exists(period_paths))) {
          if(exhausted()){progress('resumable','分期阶段预算到达；下次跳过既有分期结果');return(invisible(list(status='RESUMABLE',units=units)))}
          p12d_disk();e$p12_point_batch(o,periods=TRUE,progress=function(stage,message)progress(stage,message,o$id))
          units<-units+1L
        }
        clusters<-sort(unique(o$cluster))
        for(first in seq.int(1L,length(clusters),50L)) {
          ids<-clusters[first:min(length(clusters),first+49L)]
          paths<-file.path(o$destination,paste0('LOO_',gsub('[^A-Za-z0-9_-]','_',ids),'.rds'))
          if(all(file.exists(paths)))next
          if(exhausted()){progress('resumable','LOO阶段预算到达；保留每簇成功/失败');return(invisible(list(status='RESUMABLE',units=units)))}
          p12d_disk();e$p12_point_batch(o,cluster_start=first,cluster_count=50L,periods=FALSE,progress=function(stage,message)progress(stage,message,o$id))
          units<-units+1L
        }
      }
    }
    progress('phase_complete',paste(phase,'阶段完成；函数返回不是进程退出证明'))
    invisible(list(status='PHASE_COMPLETE',phase=phase,units=units,pid=Sys.getpid()))
  },error=function(err){try(progress('STOPPED',conditionMessage(err)),silent=TRUE);stop(err)})
}
