# P1/P2：source仅定义函数。由原生RStudio驱动；不重跑旧B1000。
p12_root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
p12_s <- file.path(p12_root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
p12_write <- function(x,path) {
  stopifnot(!file.exists(path)); tmp<-paste0(path,'.tmp'); stopifnot(!file.exists(tmp)); saveRDS(x,tmp,compress='gzip')
  stopifnot(identical(x,readRDS(tmp)),file.rename(tmp,path));invisible(path)
}
p12_metric <- function(grid) {
  stopifnot(length(grid)==2L,length(grid[[1]]$est)>=6L)
  c(TNIE=exp(grid[[1]]$est[5]),Delta_OR=exp(grid[[2]]$est[1])-exp(grid[[1]]$est[1]))
}
p12_prepare <- function(id,destination) {
  stopifnot(id %in% c('FEAS_031','FEAS_041'),!dir.exists(destination))
  .libPaths(c(file.path(p12_root,'runtime/library'),.libPaths()))
  stopifnot(requireNamespace('CMAverse'),requireNamespace('digest'),requireNamespace('jsonlite'))
  e<-new.env(parent=environment())
  sys.source(file.path(p12_s,'candidate_data.R'),e);sys.source(file.path(p12_s,'baseline_adjustment.R'),e)
  sys.source(file.path(p12_s,'screening_records.R'),e)
  shared<-file.path(p12_root,'next_phase/PLAN12_八链适用性评估_20260928/scripts/shared_bootstrap_diagnostic.R')
  sys.source(shared,e)
  g<-read.csv(file.path(p12_s,'feasible_population_v1/specifications.csv'))
  g<-g[g$spec_id==id,,drop=FALSE];stopifnot(nrow(g)==1L,g$yreg=='logistic')
  outer<-file.path(p12_s,'verify_B1000_v1',id)
  olddir<-file.path(outer,id)
  inp<-readRDS(file.path(olddir,'execution_inputs.rds'));m<-inp$sample
  stopifnot(identical(digest::digest(m$row_index,algo='sha256'),g$sample_sha256),
    identical(inp$spec,g),length(inp$actual_indices)==1000L,length(inp$replicate_seeds)==1000L)
  dat<-data.frame(X=e$X[[g$x]],M=e$M[[g$m]],Y=e$Y[[g$y]],e$C)[m$row_index,,drop=FALSE]
  stopifnot(nrow(dat)==g$n,all(complete.cases(dat)),length(e$covars)==23L,'dwm_begin'%in%e$covars)
  # 原索引逐项重建，确保原23与修订22严格配对。
  plan<-readRDS(file.path(p12_s,'feasible_sampling_v1/verify.rds'))
  map<-split(seq_len(nrow(dat)),factor(m$cluster,levels=plan$clusters))
  idx<-lapply(plan$draws,function(draw)unlist(map[match(draw,plan$clusters)],use.names=FALSE))
  stopifnot(identical(idx,inp$actual_indices),identical(plan$replicate_seeds,inp$replicate_seeds))
  src<-file.path(p12_root,'runtime/CMAverse_source_install/R/est.gformula.R')
  se<-new.env();sys.source(src,se)
  stopifnot(identical(body(se$est.gformula),body(get('est.gformula',asNamespace('CMAverse')))))
  # 原完整对象已不在本地：只读原紧凑grid与独立验收表，不重新估计。
  validation_path<-file.path(outer,'ARTIFACT_VALIDATION.json')
  val<-jsonlite::read_json(validation_path,simplifyVector=TRUE)
  # 原validate.R哈希对象是带属性的右填充整数矩阵，序列化版本固定为2；不是indices list。
  ix<-inp$actual_indices
  pad<-matrix(NA_integer_,1000,max(lengths(ix)))
  for(b in seq_len(1000L))pad[b,seq_along(ix[[b]])]<-ix[[b]]
  attr(pad,'row_lengths')<-lengths(ix)
  attr(pad,'representation')<-'actual indices; right padding is not a sampled observation'
  paired_hash<-digest::digest(pad,algo='sha256',serialize=TRUE,serializeVersion=2)
  rm(pad)

  stopifnot(val$B==1000L,val$valid==1000L,val$spec_id==id,
    isTRUE(val$exact_grid_vs_full_bootstrap),
    identical(paired_hash,val$paired_actual_indices_sha256),
    identical(plan$registry_sha256,digest::digest(file=file.path(p12_s,'feasible_population_v1/specifications.csv'),algo='sha256')),
    identical(plan$membership_sha256,digest::digest(file=file.path(p12_s,'feasible_population_v1/sample_membership.rds'),algo='sha256')))
  gridpaths<-file.path(olddir,'grids',sprintf('bootstrap_%02d.rds',seq_len(1000L)))
  pointpath<-file.path(olddir,'grids','bootstrap_t0.rds')
  stopifnot(all(file.exists(c(gridpaths,pointpath))))
  pointgrid<-readRDS(pointpath);bootstrap_t0_point<-p12_metric(pointgrid)
  effectpath<-file.path(outer,'ALL_NATIVE_EFFECTS.csv');effects<-read.csv(effectpath)
  first<-effects[effects$mval==g$mval0,,drop=FALSE]
  stopifnot(identical(first$effect[1:6],c('Rcde','Rpnde','Rtnde','Rpnie','Rtnie','Rte')))
  # 通过保存的独立表核点值及两个mval，比率差不取对数。
  fetch<-function(m,eff) {v<-effects$estimate[effects$mval==m & effects$effect==eff];stopifnot(length(v)==1L);v}
  tablepoint<-c(TNIE=fetch(g$mval0,'Rtnie'),Delta_OR=fetch(g$mval1,'Rcde')-fetch(g$mval0,'Rcde'))
  # 原estinf先调用est_grid作为最终effect.pe，再推进RNG调用bootstrap t0。
  # 中介模拟量不要求t0与最终点值相等；CDE固定M，不受该模拟影响，仍严格核。
  stopifnot(isTRUE(all.equal(unname(bootstrap_t0_point['Delta_OR']),
    unname(tablepoint['Delta_OR']),tolerance=1e-12)))
  oldpoint<-tablepoint
  old_point_sources<-data.frame(metric=c('TNIE','Delta_OR'),
    original_effect_pe=unname(tablepoint),bootstrap_t0=unname(bootstrap_t0_point),
    source_effect_pe='ALL_NATIVE_EFFECTS.csv: original est_grid effect.pe',
    source_bootstrap_t0='grids/bootstrap_t0.rds: later bootstrap statistic')
  # 与原regrun.R的gformula公式构造完全相同，再核保存的设计系数名。
  oldformula<-as.formula(paste0('Y~',paste(c('X','M','X*M',e$covars),collapse='+')),env=baseenv())
  # 所有公式变量都来自显式dat。固定baseenv避免捕获prepare局部环境/循环对象。
  stopifnot(identical(environment(oldformula),baseenv()))
  mm<-model.matrix(oldformula,data=dat)
  stopifnot(identical(colnames(mm),names(pointgrid[[1]]$models$yreg$coefficients)),
    identical(pointgrid[[1]]$models$yreg$family,'binomial'),
    identical(pointgrid[[1]]$models$yreg$link,'logit'))
  # 直接代入旧系数检查点值，不拟合旧模型。
  cf<-pointgrid[[1]]$models$yreg$coefficients
  means<-vapply(c(g$mval0,g$mval1),function(mv)vapply(c(g$astar,g$a),function(av){
    dd<-dat;dd$M<-mv;dd$X<-av;mean(plogis(model.matrix(oldformula,dd)%*%cf))
  },numeric(1)),numeric(2))
  saved_cde<-diff(exp(qlogis(means[2,])-qlogis(means[1,])))
  stopifnot(abs(unname(saved_cde)-oldpoint['Delta_OR'])<1e-8)
  olddraw<-t(vapply(gridpaths,function(path)p12_metric(readRDS(path)),numeric(2)))
  dir.create(destination,recursive=TRUE)
  paths<-c(src,shared,file.path(p12_root,c('runtime/CMAverse_source_install/R/regrun.R','runtime/CMAverse_source_install/R/estinf.R')),
    file.path(p12_s,c('candidate_data.R','baseline_adjustment.R','screening_records.R','verify_B1000_v1/validate.R',
      'feasible_sampling_v1/verify.rds','feasible_population_v1/specifications.csv','feasible_population_v1/sample_membership.rds')),
    file.path(olddir,'execution_inputs.rds'),validation_path,effectpath,pointpath,gridpaths)
  manifest<-data.frame(path=paths,sha256=vapply(paths,function(p)digest::digest(file=p,algo='sha256'),character(1)))
  obj<-list(id=id,destination=destination,g=g,dat=dat,cluster=m$cluster,period=e$z$period[m$row_index],
    covars=e$covars,revised=setdiff(e$covars,'dwm_begin'),inputs=inp,old_draw=olddraw,
    old_point=oldpoint,old_bootstrap_t0=bootstrap_t0_point,old_point_sources=old_point_sources,
    old_formula=oldformula,manifest=manifest,
    old_source_contract='Original compact grids + native effect table + artifact validation; no full-object regeneration')
  p12_write(obj,file.path(destination,'INPUTS.rds'));obj
}
p12_env <- function() {
  e<-new.env(parent=environment());sys.source(file.path(p12_s,'screening_records.R'),e)
  sys.source(file.path(p12_root,'next_phase/PLAN12_八链适用性评估_20260928/scripts/shared_bootstrap_diagnostic.R'),e);e
}
p12_check_sources <- function(o) {
  stopifnot(all(vapply(seq_len(nrow(o$manifest)),function(i)identical(digest::digest(file=o$manifest$path[i],algo='sha256'),o$manifest$sha256[i]),logical(1))))
}
p12_args <- function(o,dat,controls,B) list(data=dat,model='gformula',outcome='Y',exposure='X',mediator='M',
  basec=controls,yreg=o$g$yreg,mreg=list(o$g$mreg),EMint=TRUE,astar=o$g$astar,a=o$g$a,
  mval_grid=list(c(o$g$mval0,o$g$mval1)),estimation='imputation',inference='bootstrap',nboot=B,boot.ci.type='per',full=TRUE,yval=1)
# 高效CDE只需结果方程；在每个样本自己的协变量分布上标准化。
p12_cde <- function(dat,formula,g) {
  f<-glm(formula,data=dat,family=binomial('logit'))
  stopifnot(isTRUE(f$converged),f$rank==length(coef(f)),all(is.finite(coef(f))))
  means<-vapply(c(g$mval0,g$mval1),function(m) vapply(c(g$astar,g$a),function(a){
    z<-dat;z$M<-m;z$X<-a;mean(predict(f,newdata=z,type='response'))
  },numeric(1)),numeric(2))
  stopifnot(all(is.finite(means)),all(means>0 & means<1))
  or<-exp(qlogis(means[2,])-qlogis(means[1,]))
  c(Delta_OR=unname(or[2]-or[1]),Delta_probability=unname(diff(means[2,]-means[1,])))
}
p12_equivalence <- function(o,progress=function(...)NULL) {
  p12_check_sources(o);path<-file.path(o$destination,'EQUIVALENCE.rds');stopifnot(!file.exists(path))
  revised_formula<-update(o$old_formula,.~.-dwm_begin)
  # 核原点值与三个固定抽样。不重新拟合旧中介。
  checks<-list();fast<-p12_cde(o$dat,o$old_formula,o$g)
  checks[[1]]<-c(fast=fast[1],native=o$old_point['Delta_OR'])
  for(b in c(1L,17L,200L))checks[[length(checks)+1]]<-c(fast=p12_cde(o$dat[o$inputs$actual_indices[[b]],,drop=FALSE],o$old_formula,o$g)[1],native=o$old_draw[b,'Delta_OR'])
  # 修订模型两个固定删簇样本用完整原生桥对照，失败即禁止LOO。
  for(cl in head(sort(unique(o$cluster)),2L)) {
    dat<-o$dat[o$cluster!=cl,,drop=FALSE];e<-p12_env()
    bridge<-e$make_shared_cmest(rep(list(seq_len(nrow(dat))),2L),o$inputs$replicate_seeds[1:2],function(...)NULL)
    point<-NULL;bridge$state$save_grid<-function(grid,label)if(label=='bootstrap_t0')point<<-p12_metric(grid)
    set.seed(o$inputs$point_seed)
    err<-tryCatch({do.call(bridge$cmest,p12_args(o,dat,o$revised,2L));NULL},error=function(e)conditionMessage(e))
    stopifnot(!is.null(point))
    checks[[length(checks)+1]]<-c(fast=p12_cde(dat,revised_formula,o$g)[1],native=point['Delta_OR'])
    progress('equivalence',paste(o$id,'deleted cluster',cl))
  }
  mat<-do.call(rbind,checks);delta<-abs(mat[,1]-mat[,2]);passed<-all(is.finite(delta))&&all(delta<1e-8)
  p12_write(list(passed=passed,checks=mat,tolerance=1e-8),path);stopifnot(passed);invisible(passed)
}
p12_run_chunk <- function(o,first,last,progress) {
  p12_check_sources(o);stopifnot(is.function(progress),first>=1L,last<=1000L,last>first,last-first<50L,
    isTRUE(readRDS(file.path(o$destination,'EQUIVALENCE.rds'))$passed))
  # 201以后的计算只要求技术审查证据，不检查显著性。
  if(last>200L)stopifnot(isTRUE(readRDS(file.path(o$destination,'TECHNICAL_REVIEW.rds'))$passed))
  bs<-seq.int(first,last);dest<-file.path(o$destination,sprintf('chunk_%04d_%04d',first,last));stopifnot(!dir.exists(dest))
  for(b in bs)stopifnot(!file.exists(file.path(o$destination,sprintf('DRAW_%04d.rds',b))))
  dir.create(dest);e<-p12_env();warnings<-character();points<-list()
  bridge<-e$make_shared_cmest(o$inputs$actual_indices[bs],o$inputs$replicate_seeds[bs],function(b,R,last)progress('revised_bootstrap',paste(o$id,first+b-1L,'/1000')))
  bridge$state$save_grid<-function(grid,label) {
    compact<-e$compact_grid(grid)
    if(grepl('^bootstrap_[0-9]+$',label)) {
      b<-bs[as.integer(sub('bootstrap_','',label))]
      p12_write(list(b=b,index_sha=digest::digest(o$inputs$actual_indices[[b]],algo='sha256'),seed=o$inputs$replicate_seeds[b],grid=compact),file.path(o$destination,sprintf('DRAW_%04d.rds',b)))
    } else points[[label]]<<-compact
  }
  set.seed(o$inputs$point_seed);started<-Sys.time()
  fit<-tryCatch(withCallingHandlers(do.call(bridge$cmest,p12_args(o,o$dat,o$revised,length(bs))),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e)e)
  # 不写庞大完整环境；逐次原生效应/模型诊断均已留存。
  p12_write(list(points=points,diagnostics=bridge$state$diagnostics,warnings=unique(warnings),
    error=if(inherits(fit,'error'))conditionMessage(fit) else NULL,first=first,last=last,
    revised_point=if(!inherits(fit,'error'))c(TNIE=unname(fit$effect.pe['Rtnie']),Delta_OR=unname(fit$delta_cde$effect.pe)) else NULL,
    seconds=as.numeric(difftime(Sys.time(),started,units='secs')),pid=Sys.getpid()),file.path(dest,'TERMINAL.rds'))
  invisible(dest)
}
p12_point_batch <- function(o,cluster_start=1L,cluster_count=50L,periods=FALSE,progress) {
  p12_check_sources(o);stopifnot(isTRUE(readRDS(file.path(o$destination,'EQUIVALENCE.rds'))$passed))
  f<-update(o$old_formula,.~.-dwm_begin);clusters<-sort(unique(o$cluster))
  ids<-if(periods)sort(unique(o$period)) else clusters[seq.int(cluster_start,min(length(clusters),cluster_start+cluster_count-1L))]
  for(id in ids) {
    dest<-file.path(o$destination,paste0(if(periods)'PERIOD_' else 'LOO_',gsub('[^A-Za-z0-9_-]','_',id),'.rds'))
    if(file.exists(dest))next
    keep<-if(periods)o$period==id else o$cluster!=id;dat<-o$dat[keep,,drop=FALSE]
    ff<-if(periods)update(f,.~.-period_fe) else f
    started<-Sys.time();warnings<-character()
    v<-tryCatch(withCallingHandlers(p12_cde(dat,ff,o$g),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e)e)
    p12_write(list(id=id,n=nrow(dat),clusters=length(unique(o$cluster[keep])),formula=deparse(ff),
      effect=if(!inherits(v,'error'))v else NULL,error=if(inherits(v,'error'))conditionMessage(v) else NULL,
      warnings=unique(warnings),seconds=as.numeric(difftime(Sys.time(),started,units='secs'))),dest)
    progress(if(periods)'period' else 'leave_one_cluster_out',paste(o$id,id))
  };invisible(NULL)
}
p12_self_test <- function() {
  g<-data.frame(mval0=0,mval1=1,a=1,astar=0)
  toy<-list(list(est=c(log(2),0,0,0,log(1.1),0)),list(est=c(log(1.5),0,0,0,log(1.1),0)))
  stopifnot(isTRUE(all.equal(unname(p12_metric(toy)),c(1.1,-.5))))
  # 重复抽中同簇必须重复包含所有成员。
  m<-split(1:5,c('a','a','b','b','b'));idx<-unlist(m[c('a','a','b')],use.names=FALSE)
  stopifnot(identical(idx,c(1L,2L,1L,2L,3L,4L,5L)))
  set.seed(91827);d<-data.frame(X=rbinom(400,1,.5),M=rbinom(400,1,.5),C=rnorm(400))
  d$Y<-rbinom(400,1,plogis(-.5+.4*d$X+.2*d$M-.3*d$X*d$M+.1*d$C))
  z<-p12_cde(d,Y~X*M+C,g);stopifnot(length(z)==2L,all(is.finite(z)))
  list(passed=TRUE,scope='synthetic scale/cluster repetition/finite deterministic CDE; native equivalence separate')
}

p12_collect <- function(o,B=1000L) {
  stopifnot(B%in%c(200L,1000L));rows<-vector('list',B)
  terminals<-list.files(o$destination,pattern='TERMINAL.rds$',recursive=TRUE,full.names=TRUE)
  valid<-rep(FALSE,B);point<-NULL
  for(p in terminals) {
    z<-readRDS(p);if(!is.null(z$revised_point)) {
      if(is.null(point))point<-z$revised_point else stopifnot(isTRUE(all.equal(point,z$revised_point,tolerance=1e-10)))
    }
    dg<-z$diagnostics
    if(length(dg))for(j in seq_along(dg)) {
      b<-z$first+j-1L;if(b<=B)valid[b]<-isTRUE(dg[[j]]$execution_ok)&&isTRUE(dg[[j]]$fits_valid)&&isTRUE(dg[[j]]$core_finite)
    }
  }
  for(b in seq_len(B)) {
    path<-file.path(o$destination,sprintf('DRAW_%04d.rds',b));met<-c(TNIE=NA_real_,Delta_OR=NA_real_)
    if(file.exists(path))met<-tryCatch(p12_metric(readRDS(path)$grid),error=function(e)met)
    rows[[b]]<-data.frame(b=b,valid=valid[b]&&all(is.finite(met)),old_TNIE=o$old_draw[b,1],old_Delta_OR=o$old_draw[b,2],
      revised_TNIE=met[1],revised_Delta_OR=met[2],paired_Delta_OR=met[2]-o$old_draw[b,2])
  }
  tab<-do.call(rbind,rows)
  # 完整失败分母保留；不以有效重复筛选换来更小p。
  list(B=B,table=tab,old_point=o$old_point,old_point_sources=o$old_point_sources,revised_point=point,
    all_draws_valid=all(tab$valid),valid_n=sum(tab$valid),
    interpretation='Paired refinement and sensitivity, not independent confirmation. Inference requires separate frozen rule and failure review.')
}

# 原生轻量持久化自测：不拟合模型、不读生产输入。严格identical包含公式环境。
p12_serialization_self_test <- function() {
  f<-as.formula('Y~X+M+X*M+dwm_begin',env=baseenv())
  x<-list(old_formula=f,dat=data.frame(X=c(0,1),M=c(1,0),Y=c(0,1),dwm_begin=c(0,1)),
          inputs=list(actual_indices=list(c(1L,2L,1L)),replicate_seeds=91827L))
  y<-unserialize(serialize(x,NULL))
  stopifnot(identical(x,y),identical(environment(y$old_formula),baseenv()),
            identical(model.matrix(x$old_formula,x$dat),model.matrix(y$old_formula,y$dat)))
  list(passed=TRUE,scope='strict serialization identity of baseenv formula and plain data; no model estimation')
}
