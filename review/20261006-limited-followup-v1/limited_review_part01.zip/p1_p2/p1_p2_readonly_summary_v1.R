# 只读汇总；source不运行，不拟合模型，不修改冻结worker/原始结果。
# 必须由原RStudio作业aca6819f真实终态被supervisor确认后调用。
p12s_diag <- function(x) {
  if(is.data.frame(x)) return(x)
  if(!length(x)) return(data.frame())
  do.call(rbind,lapply(x,as.data.frame))
}
p12s_ci <- function(point,draws,valid=rep(TRUE,length(draws))) {
  # 固定原目标尺度的中心化绝对偏差95%区间；不新增p值。
  # 任何失败均保留并暂缓区间，避免未经审查静默删除失败重复。
  if(!is.finite(point)||!all(valid)||!all(is.finite(draws))) return(c(lower=NA_real_,upper=NA_real_))
  radius<-unname(quantile(abs(draws-point),.95,type=7))
  c(lower=point-radius,upper=point+radius)
}
p12s_collect_draws <- function(o) {
  stopifnot(nrow(o$old_draw)==1000L)
  valid<-rep(FALSE,1000L);point<-NULL;logs<-list();diag<-list()
  for(first in seq.int(1L,951L,50L)) {
    last<-first+49L
    path<-file.path(o$destination,sprintf('chunk_%04d_%04d/TERMINAL.rds',first,last))
    stopifnot(file.exists(path));z<-readRDS(path)
    stopifnot(z$first==first,z$last==last)
    d<-p12s_diag(z$diagnostics)
    stopifnot(nrow(d)==50L,all(c('execution_ok','fits_valid','core_finite')%in%names(d)))
    valid[first:last]<-vapply(seq_len(50L),function(j)
      all(vapply(d[j,c('execution_ok','fits_valid','core_finite'),drop=FALSE],isTRUE,logical(1))) && is.null(z$error),logical(1))
    d$global_b<-first:last;diag[[length(diag)+1L]]<-d
    logs[[length(logs)+1L]]<-list(path=path,error=z$error,warnings=z$warnings,pid=z$pid)
    if(!is.null(z$revised_point)) {
      if(is.null(point))point<-z$revised_point else stopifnot(isTRUE(all.equal(point,z$revised_point,tolerance=1e-10)))
    }
  }
  stopifnot(length(point)==2L)
  rows<-lapply(seq_len(1000L),function(b) {
    path<-file.path(o$destination,sprintf('DRAW_%04d.rds',b));stopifnot(file.exists(path))
    z<-readRDS(path)
    stopifnot(z$b==b,identical(z$index_sha,digest::digest(o$inputs$actual_indices[[b]],algo='sha256')),
              isTRUE(all.equal(z$seed,o$inputs$replicate_seeds[b],tolerance=0)))
    met<-p12_metric(z$grid)
    data.frame(b=b,valid=valid[b]&&all(is.finite(met)),old_TNIE=o$old_draw[b,'TNIE'],old_Delta_OR=o$old_draw[b,'Delta_OR'],
      revised_TNIE=met['TNIE'],revised_Delta_OR=met['Delta_OR'],row.names=NULL)
  })
  tab<-do.call(rbind,rows)
  tab$paired_TNIE<-tab$revised_TNIE-tab$old_TNIE
  tab$paired_Delta_OR<-tab$revised_Delta_OR-tab$old_Delta_OR
  est<-list();for(metric in c('TNIE','Delta_OR'))for(version in c('old','revised','paired')) {
    pt<-switch(version,old=o$old_point[[metric]],revised=point[[metric]],paired=point[[metric]]-o$old_point[[metric]])
    draws<-tab[[paste(version,metric,sep='_')]]
    ok<-if(version=='old')is.finite(draws) else tab$valid & is.finite(draws)
    ci<-p12s_ci(pt,draws,ok)
    est[[length(est)+1L]]<-data.frame(id=o$id,version=version,metric=metric,estimate=pt,lower=ci[1],upper=ci[2],
      planned_B=1000L,valid_B=sum(ok),interval_status=if(all(ok))'ALL_VALID_CENTERED_ABSOLUTE_DEVIATION' else 'WITHHELD_FAILURE_REVIEW_REQUIRED',row.names=NULL)
  }
  list(table=tab,estimates=do.call(rbind,est),revised_point=point,diagnostics=diag,chunks=logs)
}
p12s_points <- function(o,kind,revised_point) {
  ids<-sort(unique(if(kind=='LOO')o$cluster else o$period))
  paths<-file.path(o$destination,paste0(kind,'_',gsub('[^A-Za-z0-9_-]','_',ids),'.rds'))
  stopifnot(!anyDuplicated(paths),all(file.exists(paths)))
  found<-list.files(o$destination,pattern=paste0('^',kind,'_.*[.]rds$'),full.names=TRUE)
  stopifnot(setequal(paths,found))
  rows<-lapply(seq_along(ids),function(j) {
    z<-readRDS(paths[j]);stopifnot(as.character(z$id)==as.character(ids[j]))
    ff<-update(o$old_formula,.~.-dwm_begin)
    if(kind=='PERIOD')ff<-update(ff,.~.-period_fe)
    stopifnot(identical(z$formula,deparse(ff)))
    keep<-if(kind=='LOO')o$cluster!=ids[j] else o$period==ids[j]
    stopifnot(z$n==sum(keep),z$clusters==length(unique(o$cluster[keep])))
    ef<-if(is.null(z$effect))c(Delta_OR=NA_real_,Delta_probability=NA_real_) else z$effect
    ok<-is.null(z$error)&&all(is.finite(ef))
    data.frame(id=o$id,kind=kind,unit=as.character(ids[j]),n=z$n,clusters=z$clusters,Delta_OR=ef[['Delta_OR']],
      Delta_probability=ef[['Delta_probability']],valid=ok,
      change_fraction_revised=if(ok&&revised_point!=0)abs(ef[['Delta_OR']]-revised_point)/abs(revised_point) else NA_real_,
      error=if(is.null(z$error))'' else z$error,warnings=paste(z$warnings,collapse=' | '),
      formula=paste(z$formula,collapse=' '),path=paths[j],row.names=NULL)
  });do.call(rbind,rows)
}
p12s_run <- function(home,points_native_receipt,supervisor_confirmed_terminal=FALSE,output_dir) {
  stopifnot(isTRUE(supervisor_confirmed_terminal),file.exists(points_native_receipt),!dir.exists(output_dir))
  receipt<-jsonlite::fromJSON(points_native_receipt,simplifyVector=FALSE)
  txt<-paste(vapply(receipt$content,function(z)if(is.null(z$text))'' else z$text,character(1)),collapse='\n')
  stopifnot(identical(receipt$isError,FALSE),grepl('aca6819f',txt,fixed=TRUE),grepl('phase_complete|points_return|PHASE_COMPLETE',txt))
  expected<-c(FEAS_031='14a2e2e629896f3bfe42cc8ece6806cd723228f968f853997ec5816c41d94069',FEAS_041='30c2b159ce8ed922d394a7848d5b5ea75451c52855d8a501a36ff773b007f180')
  results<-list()
  for(id in names(expected)) {
    inp<-file.path(home,paste0(id,'_prepare_v5'),'INPUTS.rds')
    stopifnot(identical(digest::digest(file=inp,algo='sha256'),unname(expected[id])))
    o<-readRDS(inp);p12_check_sources(o)
    stopifnot(o$id==id,isTRUE(readRDS(file.path(o$destination,'EQUIVALENCE.rds'))$passed))
    d<-p12s_collect_draws(o);rp<-unname(d$revised_point['Delta_OR']);op<-unname(o$old_point['Delta_OR'])
    loo<-p12s_points(o,'LOO',rp);period<-p12s_points(o,'PERIOD',rp)
    assessable<-all(loo$valid)&&is.finite(rp)&&rp!=0
    stability<-data.frame(id=id,rule=c('no_dwm_same_sign_retains_half','revised_period_same_direction','revised_LOO_max_relative_change_le_25pct'),
      pass=c(if(is.finite(rp)&&is.finite(op))sign(rp)==sign(op)&&abs(rp)>=.5*abs(op) else NA,
        if(all(period$valid))all(sign(period$Delta_OR)==sign(rp)) else NA,
        if(assessable)max(loo$change_fraction_revised)<=.25 else NA),
      failures=c(sum(!d$table$valid),sum(!period$valid),sum(!loo$valid)))
    results[[id]]<-list(draws=d,period=period,loo=loo,stability=stability,old_point_sources=o$old_point_sources,
      maximum_LOO_change=if(assessable)max(loo$change_fraction_revised) else NA_real_)
  }
  dir.create(output_dir,recursive=TRUE)
  for(id in names(results)) {
    r<-results[[id]]
    for(nm in c('period','loo','stability','old_point_sources'))write.csv(r[[nm]],file.path(output_dir,paste0(id,'_',nm,'.csv')),row.names=FALSE)
    write.csv(r$draws$table,file.path(output_dir,paste0(id,'_paired_draws.csv')),row.names=FALSE)
    write.csv(r$draws$estimates,file.path(output_dir,paste0(id,'_intervals.csv')),row.names=FALSE)
  }
  saveRDS(results,file.path(output_dir,'SUMMARY.rds'))
  jsonlite::write_json(list(status='READONLY_SUMMARY_COMPLETE',job_id='aca6819f',native_receipt=points_native_receipt,
    native_receipt_sha256=digest::digest(file=points_native_receipt,algo='sha256'),new_models=0,new_p_values=0,
    interval='point +/- quantile(abs(draw-point), .95, type=7), original target scale; withheld if any invalid draw',
    LOO='Revised no-dwm specification; denominator revised full-sample Delta_OR; differs from cloud v5 old-spec example; supervisor adjudicated',
    inference='Sensitivity after selection, not independent confirmation; remaining covariate timing and OR noncollapsibility unresolved'),
    file.path(output_dir,'ACCEPTANCE.json'),auto_unbox=TRUE,pretty=TRUE)
  invisible(results)
}
p12s_self_test <- function() {
  x<-data.frame(execution_ok=c(TRUE,FALSE),fits_valid=c(TRUE,TRUE),core_finite=c(TRUE,TRUE))
  stopifnot(identical(p12s_diag(x),x),nrow(p12s_diag(list(as.list(x[1,]),as.list(x[2,]))))==2L,
    all(is.na(p12s_ci(0,c(1,NA)))),all(is.na(p12s_ci(0,c(1,2),c(TRUE,FALSE)))),
    isTRUE(all.equal(unname(p12s_ci(0,c(-1,1))),c(-1,1))))
  list(passed=TRUE,scope='pure diagnostics normalization and fixed CI; no production data or models')
}
