# P3最终只读独立验收：source仅定义；严禁在原native作业终态之前调用。
p3a_root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/p3"
p3a_run <- function(native_terminal_evidence, native_terminal_verified=FALSE) {
  stopifnot(isTRUE(native_terminal_verified),length(native_terminal_evidence)==1L,
            file.exists(native_terminal_evidence),
            requireNamespace("digest",quietly=TRUE),requireNamespace("jsonlite",quietly=TRUE))
  dest<-file.path(p3a_root,"production_B2000_v1")
  out<-file.path(p3a_root,"final_audit_v1")
  if(dir.exists(out))stop("审查输出已存在；保留原件，不覆盖")
  d<-new.env(parent=globalenv());sys.source(file.path(p3a_root,"p3_bounded_driver_v1.R"),d)
  q<-d$p3d_load();f<-q$frozen;e<-q$e
  paths<-c(checkpoint=file.path(dest,"CHECKPOINT.rds"),result=file.path(dest,"RESULT.rds"),
    technical=file.path(dest,"TECHNICAL_200.rds"),review=file.path(dest,"TECHNICAL_REVIEW_200.rds"),
    n1=file.path(dirname(p3a_root),"n1_n2/runtime_v2/N1_formal_v3/N1_primary_four.csv"),
    native_terminal=normalizePath(native_terminal_evidence,mustWork=TRUE),
    script=file.path(p3a_root,"p3_final_readonly_audit_v1.R"),
    manifest=file.path(p3a_root,"BOUNDED_INPUT_MANIFEST_v1.json"))
  stopifnot(all(file.exists(paths)),!dir.exists(file.path(p3a_root,"BOUNDED_DRIVER.lock")))
  sha<-function(x)digest::digest(file=x,algo="sha256")
  before<-vapply(paths,sha,character(1))
  s<-readRDS(paths["checkpoint"]);r<-readRDS(paths["result"])
  t<-readRDS(paths["technical"]);review<-readRDS(paths["review"])
  identity<-digest::digest(list(f$data,f$plan,f$fA,f$fB,f$cap,
    f$base_data,f$domain,body(e$p3_domain_check),body(e$p3_one),body(e$p3_gamma),
    body(e$p3_attempt),body(e$p3_run),body(e$p3_omnibus),body(e$p3_validate_plan),
    body(e$p3_draw_rows),body(e$fit_logit),body(e$set_cf)),algo="sha256")
  stopifnot(identical(identity,s$identity),identical(identity,r$identity),
    identical(s$plan,f$plan),length(s$results)==2000L,identical(r$point,s$point),
    identical(r$warm_used_in_primary,FALSE),
    r$status=="FUNCTION_COMPLETED_REQUIRES_NATIVE_TERMINAL",
    identical(t$identity,identity),t$completed==200L,identical(t$results,s$results[1:200]),
    t$status=="TECHNICAL_CHECKPOINT_NOT_PVALUE_GATE",
    identical(review$identity,identity),isTRUE(review$passed),isTRUE(review$technical_only),
    identical(review$p_value_used,FALSE),identical(review$validity_ratio_used_as_promotion_gate,FALSE),
    review$fixed_next_B==2000L,review$primary=="cold",isTRUE(review$warm_diagnostic_only),
    review$final_inference_min_valid==.98)
  near<-function(a,b)stopifnot(isTRUE(all.equal(a,b,tolerance=1e-12,check.attributes=TRUE)))
  scalar<-function(x,default=NA)if(is.null(x)||!length(x))default else x[[1]]
  textval<-function(x)if(is.null(x))"" else paste(as.character(unlist(x)),collapse=" | ")
  tags<-c("probability","original","capped")
  keys<-c("T_le3","T_4","T_5","d_5vle3","d_5v4")
  mats<-setNames(lapply(tags,function(tag)matrix(NA_real_,2000L,5L,
    dimnames=list(as.character(1:2000),keys))),tags)
  gi<-match(f$data[[f$cluster]],f$plan$ids);stopifnot(!anyNA(gi))
  counts<-tabulate(gi,nbins=length(f$plan$ids))
  ledger<-vector("list",6000L);k<-0L
  for(b in seq_len(2000L)) {
    z<-s$results[[b]];draw<-f$plan$draws[,b]
    stopifnot(identical(z$draw,as.integer(b)),
      identical(z$draw_sha256,digest::digest(draw,algo="sha256")),
      z$sampling$rows==sum(counts[draw]),
      z$sampling$zero_contribution_draws==sum(counts[draw]==0L),
      z$sampling$eligible_selections==sum(counts[draw]>0L),
      z$sampling$unique_eligible_clusters==length(unique(draw[counts[draw]>0L])))
    for(tag in tags) {
      value<-z[[tag]];di<-z$diagnostics[[tag]];warm<-di$warm_diagnostic
      valid<-!is.null(value)
      if(valid) {
        stopifnot(is.numeric(value),identical(names(value),keys),all(is.finite(value)))
        near(unname(value["d_5vle3"]),unname(value["T_5"]-value["T_le3"]))
        near(unname(value["d_5v4"]),unname(value["T_5"]-value["T_4"]))
        mats[[tag]][b,]<-value
      }
      if(!is.null(warm))stopifnot(!valid)
      if(valid&&tag!="probability")stopifnot(isTRUE(di$ok),isTRUE(di$converged))
      k<-k+1L
      reason<-if(valid)"VALID_COLD" else if(!is.null(z$diagnostics$sample_error))
        "EMPTY_DRAW" else if(is.null(di))"UPSTREAM_FAILURE" else
        if(identical(di$ok,FALSE))"FIT_OR_PREDICT_ERROR" else
        if(!is.null(di$prediction_error))"PREDICTION_FAILURE" else
        if(identical(di$converged,FALSE))"NONCONVERGED" else "OTHER_UNUSABLE"
      ledger[[k]]<-data.frame(draw=b,draw_sha256=z$draw_sha256,equation=tag,
        primary_valid=valid,reason=reason,
        ok=scalar(di$ok),converged=scalar(di$converged),iterations=scalar(di$iterations),
        rank=scalar(di$rank),columns=scalar(di$columns),positive_rows=scalar(di$n_positive),
        positive_clusters=scalar(di$positive_clusters),max_amount=scalar(di$max_amount),
        error=textval(di$error),warnings=textval(di$warnings),
        prediction_error=textval(di$prediction_error),sample_error=textval(z$diagnostics$sample_error),
        warm_attempted=!is.null(warm),warm_ok=scalar(warm$ok),
        warm_usable=scalar(warm$usable),warm_converged=scalar(warm$converged),
        warm_error=textval(warm$error),warm_warnings=textval(warm$warnings),
        sample_rows=z$sampling$rows,zero_contribution_draws=z$sampling$zero_contribution_draws,
        unique_eligible_clusters=z$sampling$unique_eligible_clusters,stringsAsFactors=FALSE)
    }
  }
  ledger<-do.call(rbind,ledger)
  for(tag in tags)stopifnot(identical(mats[[tag]],r$draws[[tag]]))
  expected200<-setNames(vapply(tags,function(tag)sum(complete.cases(mats[[tag]][1:200,,drop=FALSE])),integer(1)),tags)
  near(review$valid_counts,expected200)
  # 只核原已登记2df统计量与保存p的一致性；不产生新的单对比p或更换推断。
  p3rows<-lapply(c("original","capped"),function(tag) {
    test<-r$tests[[tag]];mat<-mats[[tag]];pt<-s$point[[tag]]
    ok<-complete.cases(mat)&apply(mat,1,function(x)all(is.finite(x)))
    nv<-sum(ok)
    stopifnot(test$B==2000L,test$n_valid==nv,test$valid_ratio==nv/2000L)
    estimable<-nv>=1960L&&!is.null(pt)&&all(is.finite(pt))
    if(estimable) {
      xx<-mat[ok,c("d_5vle3","d_5v4"),drop=FALSE];v<-cov(xx)
      near(test$covariance,v)
      estimable<-all(is.finite(v))&&min(eigen(v,symmetric=TRUE,only.values=TRUE)$values)>max(diag(v))*1e-10
    }
    if(!estimable)stopifnot(test$status=="WITHHELD",is.na(test$p_raw))
    else {
      iv<-solve(v);pp<-pt[c("d_5vle3","d_5v4")]
      statistic<-as.numeric(t(pp)%*%iv%*%pp)
      centered<-sweep(xx,2,pp,"-");bb<-rowSums((centered%*%iv)*centered)
      near(test$statistic,statistic);near(test$bootstrap_statistics,bb)
      near(test$p_raw,(1+sum(bb>=statistic))/(1+nv))
      stopifnot(test$status=="ESTIMATED_POST_SELECTION")
    }
    data.frame(test_id=paste0("P3_",toupper(tag),"_OMNIBUS"),module="P3",
      estimand="Three-state two-contrast omnibus",status=test$status,B=2000L,
      n_valid=nv,valid_ratio=nv/2000,p_raw=test$p_raw,
      statistic=scalar(test$statistic,NA_real_),T_le3=scalar(pt["T_le3"],NA_real_),
      T_4=scalar(pt["T_4"],NA_real_),T_5=scalar(pt["T_5"],NA_real_),
      d_5vle3=scalar(pt["d_5vle3"],NA_real_),d_5v4=scalar(pt["d_5v4"],NA_real_))
  })
  p3table<-do.call(rbind,p3rows)
  n1<-read.csv(paths["n1"],stringsAsFactors=FALSE)
  stopifnot(nrow(n1)==4L,!anyDuplicated(n1$test_id),
    setequal(n1$test_id,c("N1_SELF_BETWEEN","N1_SELF_WITHIN","N1_SPOUSE_BETWEEN","N1_SPOUSE_WITHIN")),
    all(is.finite(n1$p_raw)),all(n1$p_raw>=0&n1$p_raw<=1))
  six<-rbind(data.frame(test_id=n1$test_id,module="N1",status="ESTIMATED_POST_SELECTION",p_raw=n1$p_raw),
    p3table[,c("test_id","module","status","p_raw")])
  stopifnot(nrow(six)==6L,!anyDuplicated(six$test_id))
  six$q_BH6<-p.adjust(six$p_raw,method="BH",n=6L)
  six$q_BY6<-p.adjust(six$p_raw,method="BY",n=6L)
  six$family_n<-6L
  stopifnot(all(is.na(six$q_BH6[is.na(six$p_raw)])),all(is.na(six$q_BY6[is.na(six$p_raw)])))
  six$interpretation<-"Exploratory post-selection; fixed six only, not correction of prior search history"
  diag_summary<-aggregate(list(repeats=rep(1L,nrow(ledger))),
    ledger[,c("equation","primary_valid","reason","warm_attempted")],sum)
  points<-do.call(rbind,lapply(tags,function(tag) {
    pt<-s$point[[tag]]
    data.frame(equation=tag,estimand=keys,estimate=if(is.null(pt))rep(NA_real_,5L)else unname(pt),
      scale=if(tag=="probability")"probability"else"real_monthly_amount",
      descriptive_only=TRUE)
  }))
  after<-vapply(paths,sha,character(1));stopifnot(identical(before,after))
  dir.create(out,recursive=TRUE)
  write.csv(six,file.path(out,"REGISTERED_SIX_BH_BY.csv"),row.names=FALSE,na="NA")
  write.csv(p3table,file.path(out,"P3_TWO_OMNIBUS.csv"),row.names=FALSE,na="NA")
  write.csv(points,file.path(out,"P3_POINT_ESTIMANDS_NO_NEW_P.csv"),row.names=FALSE,na="NA")
  write.csv(ledger,file.path(out,"ALL_6000_EQUATION_DIAGNOSTICS.csv"),row.names=FALSE,na="NA")
  write.csv(ledger[!ledger$primary_valid,],file.path(out,"ALL_PRIMARY_FAILURES.csv"),row.names=FALSE,na="NA")
  write.csv(diag_summary,file.path(out,"DIAGNOSTIC_SUMMARY.csv"),row.names=FALSE,na="NA")
  inputs<-data.frame(name=names(paths),path=unname(paths),sha256=unname(before),
    bytes=unname(file.info(paths)$size))
  write.csv(inputs,file.path(out,"INPUT_MANIFEST.csv"),row.names=FALSE)
  ans<-list(status="FILE_AUDIT_PASS",models_run=0L,identity=identity,B=2000L,
    all_draws_verified=2000L,equations_checked=6000L,global_clusters=length(f$plan$ids),
    eligible_clusters=sum(counts>0L),zero_contribution_clusters=sum(counts==0L),
    eligible_rows=nrow(f$data),cap=f$cap,cap_operation="pmin",
    cold_primary=TRUE,warm_used_in_primary=FALSE,final_min_valid=1960L,
    fixed_family_n=6L,withheld_test_ids=six$test_id[six$status=="WITHHELD"],
    technical200_counts=as.list(expected200),
    no_new_p_values=TRUE,original_omnibus_arithmetic_verified=TRUE,
    native_terminal_verified_by_supervisor=TRUE,
    native_terminal_evidence=normalizePath(native_terminal_evidence),
    native_terminal_sha256=unname(before["native_terminal"]),
    input_sha_unchanged=TRUE,prior_search_correction_claim=FALSE,
    at=format(Sys.time(),tz="UTC",usetz=TRUE))
  jsonlite::write_json(ans,file.path(out,"ACCEPTANCE.json"),auto_unbox=TRUE,pretty=TRUE,na="null")
  jsonlite::write_json(list(acceptance=ans,registered_six=six,p3_tests=p3table,diagnostics=diag_summary),
    file.path(out,"REPORT_DATA.json"),auto_unbox=TRUE,pretty=TRUE,na="null")
  cat("P3 FILE_AUDIT_PASS; models_run=0; 2000 draws; fixed six BH/BY; output:",out,"\n")
  invisible(ans)
}

