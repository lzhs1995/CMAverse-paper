#!/usr/bin/env python3
"""显式清单打包；不运行R、不下载、不提交Git；默认只验证清单。"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, shutil, tempfile, zipfile

LIMIT = 25_000_000
PAYLOAD = 22_000_000
BANNED = {".rds", ".rdata", ".rda", ".zip", ".wbk"}
ROLES = {"report", "results", "scripts", "draws", "audit", "manuscript", "microdata", "dictionary", "provenance"}

def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def read_manifest(path):
    m = json.loads(Path(path).read_text())
    if m.get("status") != "FROZEN_APPROVED_FOR_PACKAGING":
        raise ValueError("清单未冻结；先由supervisor完成真实验收与资料范围核查")
    if not m.get("native_terminal_verified") or not m.get("p3_final_audit_pass"):
        raise ValueError("原P3真实终态/只读验收未通过")
    entries = m["files"]
    if not entries:
        raise ValueError("空清单")
    names = set()
    required = {"report", "results", "scripts", "draws", "audit", "manuscript", "dictionary", "provenance"}
    for e in entries:
        p = Path(e["source"])
        a = PurePosixPath(e["archive"])
        if not p.is_absolute() or not p.is_file() or p.is_symlink():
            raise ValueError("必须为明确的非符号链接文件: "+str(p))
        if a.is_absolute() or ".." in a.parts or a.as_posix() in names or a.as_posix() in {"PACKAGE_MANIFEST.json", "MANIFEST.json", "FROZEN_SOURCE_MANIFEST.json"}:
            raise ValueError("归档路径无效/重复")
        if any(part.startswith(".") for part in a.parts) or any(part == ".git" for part in p.parts):
            raise ValueError("不收隐藏文件/Git内部")
        if p.suffix.lower() in BANNED:
            raise ValueError("不要复制巨大R对象/旧ZIP/备份；导出必要表并保留旧链接: "+str(p))
        if e["role"] not in ROLES:
            raise ValueError("未知角色")
        if p.stat().st_size != e["bytes"] or sha(p) != e["sha256"]:
            raise ValueError("冻结后来源变动: "+str(p))
        if e["bytes"] > PAYLOAD:
            raise ValueError("单来源超22MB；先将CSV按行独立分片并记录原表关系: "+str(p))
        if e["role"] == "microdata" and not e.get("prior_authorized_scope_evidence"):
            raise ValueError("微观表缺少既有授权范围/列映射证据")
        if e.get("web"):
            if p.suffix.lower() not in {".md", ".csv", ".json", ".txt", ".pdf", ".docx"}:
                raise ValueError("网页直读格式不支持")
        names.add(a.as_posix())
        required.discard(e["role"])
    if required:
        raise ValueError("必要交付角色缺失: "+str(sorted(required)))
    return m

def bundle(entries, output, payload=PAYLOAD, limit=LIMIT):
    batches, batch, total = [], [], 0
    for e in entries:
        if e["bytes"] > payload:
            raise ValueError("single member exceeds bounded payload")
        if batch and total + e["bytes"] > payload:
            batches.append(batch); batch, total = [], 0
        batch.append(e); total += e["bytes"]
    if batch:
        batches.append(batch)
    result = []
    for i, members in enumerate(batches, 1):
        target = output / ("limited_review_part%02d.zip" % i)
        with zipfile.ZipFile(target, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for e in members:
                if sha(e["source"]) != e["sha256"]:
                    raise ValueError("source changed before ZIP")
                z.write(e["source"], e["archive"])
            z.writestr("PACKAGE_MANIFEST.json", json.dumps(members, ensure_ascii=False, indent=2))
        if target.stat().st_size >= limit:
            raise ValueError("ZIP exceeds strict byte limit")
        with zipfile.ZipFile(target) as z:
            if z.testzip() is not None:
                raise ValueError("CRC failed")
            for e in members:
                h=hashlib.sha256()
                with z.open(e["archive"]) as f:
                    for b in iter(lambda:f.read(1024*1024), b""):
                        h.update(b)
                if h.hexdigest()!=e["sha256"]:
                    raise ValueError("ZIP readback SHA mismatch")
                if sha(e["source"]) != e["sha256"]:
                    raise ValueError("source changed during ZIP")
        result.append({"file":target.name, "bytes":target.stat().st_size, "sha256":sha(target),
                       "members":len(members), "crc":"PASS", "member_sha_readback":"PASS"})
    return result

def build(manifest_path, output):
    m=read_manifest(manifest_path)
    output=Path(output)
    if output.exists():
        raise ValueError("保留现有产物，不覆盖")
    output.parent.mkdir(parents=True, exist_ok=True)
    total=sum(e["bytes"] for e in m["files"])
    if shutil.disk_usage(output.parent).free < 10_000_000_000 + 3*total:
        raise ValueError("先恢复磁盘预算；打包后保留至少10GB")
    stage=Path(tempfile.mkdtemp(prefix=output.name+".staging-",dir=output.parent))
    # 故障保留staging作证据；禁止静默重建或删除。
    packs=bundle(m["files"],stage)
    web=[]
    for e in m["files"]:
        if not e.get("web"):
            continue
        dst=stage/e["archive"]
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(e["source"],dst)
        if sha(dst)!=e["sha256"]:
            raise ValueError("web copy checksum mismatch")
        web.append({"path":e["archive"],"sha256":e["sha256"],"bytes":e["bytes"]})
    receipt={"status":"LOCAL_PACKAGING_VERIFIED_NOT_PUBLISHED","source_manifest_sha256":sha(manifest_path),
             "zip_limit_bytes_exclusive":LIMIT,"packages":packs,"web_files":web,
             "prior_assets":m.get("prior_assets",[]),"git_push_performed":False}
    (stage/"MANIFEST.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
    shutil.copyfile(manifest_path,stage/"FROZEN_SOURCE_MANIFEST.json")
    for e in m["files"]:
        if sha(e["source"])!=e["sha256"]:
            raise ValueError("source changed before local finalization")
    os.rename(stage,output)
    return receipt

def self_test():
    # 仅随机合成文件；不读工程、不运行R、无网络/Git。
    with tempfile.TemporaryDirectory(prefix="limited-pack-test-") as td:
        root=Path(td); entries=[]
        for i in range(3):
            p=root/("source%d.csv"%i);p.write_bytes(os.urandom(3500))
            entries.append({"source":str(p),"archive":"draws/"+p.name,"bytes":p.stat().st_size,"sha256":sha(p)})
        out=root/"out";out.mkdir()
        got=bundle(entries,out,payload=5000,limit=7000)
        assert len(got)==3 and all(z["bytes"]<7000 for z in got)
        entries[0]["sha256"]="0"*64
        bad=root/"bad";bad.mkdir()
        try: bundle(entries,bad,payload=5000,limit=7000)
        except ValueError: pass
        else: raise AssertionError("tamper not rejected")
    return {"status":"SELF_TEST_PASS","synthetic_only":True,"models_run":0,"network_calls":0}

if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--manifest")
    ap.add_argument("--output")
    ap.add_argument("--build",action="store_true")
    ap.add_argument("--self-test",action="store_true")
    a=ap.parse_args()
    if a.self_test: ans=self_test()
    elif not a.manifest: ap.error("--manifest required")
    elif a.build:
        if not a.output: ap.error("--output required for --build")
        ans=build(a.manifest,a.output)
    else:
        m=read_manifest(a.manifest);ans={"status":"MANIFEST_VALID_NO_BUILD","files":len(m["files"])}
    print(json.dumps(ans,ensure_ascii=False,indent=2))
