# 仅从已验收P3对象导出非微观数值；由supervisor原R会话执行，不拟合。
p3_export_nonmicro <- function() {
  root<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/p3"
  dest<-file.path(root,"production_B2000_v1")
  out<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/limited_followup_20261006_v1/delivery_preparation_v1/nonmicro_exports_v1"
  stopifnot(!dir.exists(out),requireNamespace("digest",quietly=TRUE),requireNamespace("jsonlite",quietly=TRUE))
  acc<-jsonlite::read_json(file.path(root,"final_audit_v1/ACCEPTANCE.json"),simplifyVector=TRUE)
  stopifnot(acc$status=="FILE_AUDIT_PASS",acc$B==2000L,acc$all_draws_verified==2000L,
    isTRUE(acc$native_terminal_verified_by_supervisor))
  rp<-file.path(dest,"RESULT.rds");cp<-file.path(dest,"CHECKPOINT.rds")
  sha<-function(p)digest::digest(file=p,algo="sha256")
  before<-vapply(c(rp,cp),sha,character(1))
  r<-readRDS(rp);s<-readRDS(cp)
  stopifnot(identical(r$identity,s$identity),identical(r$identity,acc$identity),
    ncol(s$plan$draws)==2000L,length(s$results)==2000L)
  dir.create(out,recursive=TRUE)
  all<-do.call(rbind,lapply(names(r$draws),function(tag) {
    mat<-r$draws[[tag]]
    data.frame(draw=seq_len(2000L),equation=tag,
      draw_sha256=vapply(s$results,function(z)z$draw_sha256,character(1)),
      primary_valid=complete.cases(mat),mat,check.names=FALSE)
  }))
  write.csv(all,file.path(out,"P3_ALL_2000_PAIRED_DRAWS.csv"),row.names=FALSE,na="NA")
  # 每行一个draw，列为原全局抽样位置；仅公开1..3212的簇序号，不含人员/家庭ID。
  con<-gzfile(file.path(out,"P3_ORIGINAL_GLOBAL_DRAW_ORDINALS.csv.gz"),"wt")
  tryCatch(write.table(t(s$plan$draws),con,sep=",",quote=FALSE,
    row.names=FALSE,col.names=paste0("selection_",seq_len(nrow(s$plan$draws)))),
    finally=close(con))
  con<-gzfile(file.path(out,"P3_ORIGINAL_GLOBAL_DRAW_ORDINALS.csv.gz"),"rt")
  back<-tryCatch(as.matrix(read.csv(con,check.names=FALSE)),finally=close(con))
  stopifnot(all(dim(back)==rev(dim(s$plan$draws))),all(back==t(s$plan$draws)))
  stopifnot(identical(before,vapply(c(rp,cp),sha,character(1))))
  meta<-list(status="NONMICRO_EXPORT_VERIFIED",models_run=0L,
    source_result_sha256=before[1],source_checkpoint_sha256=before[2],identity=r$identity,
    rows_per_equation=2000L,global_cluster_count=length(s$plan$ids),
    draw_orientation="CSV row b is original draw b; selection_j values index original plan ids",
    draw_values="Ordinal indices only; no raw person/family identifiers",
    original_plan_ids_digest=digest::digest(s$plan$ids,algo="sha256"),
    original_plan_draw_matrix_digest=digest::digest(s$plan$draws,algo="sha256"),
    original_plan_path="/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1/production_two_stage_v1/plan2000.rds",
    reconstruction="Use unchanged prior published plan2000.rds ids order. Gzip CSV ordinals are lossless original columns transposed.",
    all_failed_draws_preserved=TRUE,cold_primary=TRUE,warm_used_in_primary=FALSE)
  jsonlite::write_json(meta,file.path(out,"P3_DRAW_EXPORT_PROVENANCE.json"),auto_unbox=TRUE,pretty=TRUE)
  paths<-list.files(out,full.names=TRUE)
  write.csv(data.frame(file=basename(paths),bytes=file.info(paths)$size,
    sha256=vapply(paths,sha,character(1))),file.path(out,"EXPORT_MANIFEST.csv"),row.names=FALSE)
  cat("NONMICRO_EXPORT_VERIFIED; models_run=0;",out,"\n");invisible(meta)
}

