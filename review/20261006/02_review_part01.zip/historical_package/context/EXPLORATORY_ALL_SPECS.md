# 完整探索筛选结果：150登记，120完成B200，30不适用，0待估计

11项候选已按预定规则冻结待B1000。中介TNIE无原始p<0.05；DeltaCDE三项原始p<0.05（其中041/046镜像），BH/BY均无p<0.05。全部结果保留；不能称发现稳健显著性。B1000尚未执行，NLM尚未认可此设计。

## SELECTION_RULES.md
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/SELECTION_RULES.md

# 核心筛选规则 v1（B200运行前固定）

本规则只覆盖核心150规格；有序、两部分、滞后扩展另登记，不称穷尽全部模型。

1. 主筛选指标为总自然间接效应TNIE，以及配对受控直接效应对比Delta CDE。后者表示预设M对比下的效应修饰，不把M主效应或任一回归系数的显著性替代它。其余四项分解指标全部报告，但不据其最小p增补候选。
2. 每个指标在150个登记检验上构成一个多重比较族。报告BH及任意依赖下更保守的BY调整；无效检验在调整分母中保留，内部按p=1计数，公开表标为不可估。三个Y编码分别展示，禁止跨尺度比较效应绝对大小。
3. 两主指标各按每种Y编码保留最多2个候选，合计最多12个独特规格。按BY、原始双侧p、规格ID依次排序；同一规格入选两个指标只执行一次B1000，不补足空名额。相对分差反号编码属于同一等价组，每个指标/Y单元最多取一项，另一项仍完整报告。选择不设显著性硬门槛。
4. 候选必须通过数据、模型、干预相容性及全部200次重复有效性检查。失效重复不补抽、不伪装缺失；不足200的结果与失败原因仍报告，不能将仅成功子集的p用于主排名。不能在看到结果后更改名额或淘汰理由。
5. p值实现须先核估计量零假设尺度：差值为0，比例为1并在log尺度检验。采用中心化bootstrap偏差的双侧尾部统计，有限模拟加一校正，明确是探索性近似；B200的分辨率与Monte Carlo误差单列。原生CMAverse的p另列，不混用。CI和p可能因计算方式不同而不一致，保留并说明。
6. B1000使用新的固定种子及完整聚类重抽样计划，不挑选旧成功重复，不更改样本、模型、对比。复核失效或不显著均保留，不递补下一模型追显著。
7. B1000并非独立验证。另做保持亲属/家庭依赖的内部选择稳定性评估，报告方向、排名和选中频率；具体重抽样合同在执行前冻结。当前数据已经被查看，不称外部验证。
8. 范围支持不等同条件共同支持；特别是本人相对收入、夫妻相对满意度的干预相容性及同期变化时序须逐项裁决。计算通过不能替代因果识别。

本规则是新增探索的前置决定，不改写历史研究假设；所有结果和规则版本保留。


## candidate_data.R
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/candidate_data.R

# 统一候选数据构造；仅加载与构造，不写输出、不拟合。
options(stringsAsFactors=FALSE)
root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1')
v <- readRDS(file.path(root,'data/v6_provisional_dyad_intervals_recovered.rds'))
d <- readRDS(file.path(root,'data/identity_target_13092.rds'))
j <- match(paste(d$dyad_id,d$period_label),paste(v$dyad_id,v$period)); stopifnot(!anyNA(j))
z <- v[j,]
# 金额使用万元单位；零值可进入log1p，单位作为规格固定，不搜索变换常数。
X <- list(abs_increase=z$x_abs,
 abs_diff_10k=(z$actor_income_real_end-z$actor_income_real_begin)/10000,
 abs_log1p_10k=log1p(z$actor_income_real_end/10000)-log1p(z$actor_income_real_begin/10000),
 rel_transition_eligible=z$x_rel,
 rel_share_diff=z$share_end-z$share_begin)
M <- list(self_increase_eligible=z$m_self_abs,spouse_increase_eligible=z$m_spouse_abs,
 self_increase_all=as.numeric(z$dm_self_abs>0),spouse_increase_all=as.numeric(z$dm_spouse_abs>0),
 self_score_diff=z$dm_self_abs,spouse_score_diff=z$dm_spouse_abs,
 self_relative_transition=z$m_self_rel,spouse_relative_transition=z$m_spouse_rel,
 self_relative_gap_diff=z$dm_self_rel,spouse_relative_gap_diff=z$dm_spouse_rel)
Y <- list(support_increase=z$y_growth,
 support_diff_10k=(z$support_real_end-z$support_real_begin)/10000,
 support_log1p_10k=log1p(z$support_real_end/10000)-log1p(z$support_real_begin/10000))
grid <- expand.grid(x=names(X),m=names(M),y=names(Y),stringsAsFactors=FALSE)


## candidate_data_support.csv
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/candidate_data_support.csv

"spec_id","x","m","y","n","actors","x_unique","m_unique","y_unique","m_zero","y_zero","stage","fit_approved"
"DATA_001","abs_increase","self_increase_eligible","support_increase",4170,2065,2,2,2,2191,2888,"DATA_SUPPORT_ONLY",FALSE
"DATA_002","abs_diff_10k","self_increase_eligible","support_increase",4170,2065,1985,2,2,2191,2888,"DATA_SUPPORT_ONLY",FALSE
"DATA_003","abs_log1p_10k","self_increase_eligible","support_increase",4170,2065,1985,2,2,2191,2888,"DATA_SUPPORT_ONLY",FALSE
"DATA_004","rel_transition_eligible","self_increase_eligible","support_increase",2707,1408,2,2,2,1436,1851,"DATA_SUPPORT_ONLY",FALSE
"DATA_005","rel_share_diff","self_increase_eligible","support_increase",4170,2065,1719,2,2,2191,2888,"DATA_SUPPORT_ONLY",FALSE
"DATA_006","abs_increase","spouse_increase_eligible","support_increase",4111,2015,2,2,2,2158,2895,"DATA_SUPPORT_ONLY",FALSE
"DATA_007","abs_diff_10k","spouse_increase_eligible","support_increase",4111,2015,1958,2,2,2158,2895,"DATA_SUPPORT_ONLY",FALSE
"DATA_008","abs_log1p_10k","spouse_increase_eligible","support_increase",4111,2015,1958,2,2,2158,2895,"DATA_SUPPORT_ONLY",FALSE
"DATA_009","rel_transition_eligible","spouse_increase_eligible","support_increase",2165,1159,2,2,2,1060,1495,"DATA_SUPPORT_ONLY",FALSE
"DATA_010","rel_share_diff","spouse_increase_eligible","support_increase",4111,2015,1688,2,2,2158,2895,"DATA_SUPPORT_ONLY",FALSE
"DATA_011","abs_increase","self_increase_all","support_increase",12854,5236,2,2,2,10875,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_012","abs_diff_10k","self_increase_all","support_increase",12854,5236,5240,2,2,10875,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_013","abs_log1p_10k","self_increase_all","support_increase",12854,5236,5241,2,2,10875,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_014","rel_transition_eligible","self_increase_all","support_increase",7849,3547,2,2,2,6578,5438,"DATA_SUPPORT_ONLY",FALSE
"DATA_015","rel_share_diff","self_increase_all","support_increase",12854,5236,4986,2,2,10875,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_016","abs_increase","spouse_increase_all","support_increase",12851,5235,2,2,2,10898,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_017","abs_diff_10k","spouse_increase_all","support_increase",12851,5235,5241,2,2,10898,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_018","abs_log1p_10k","spouse_increase_all","support_increase",12851,5235,5242,2,2,10898,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_019","rel_transition_eligible","spouse_increase_all","support_increase",7850,3548,2,2,2,6745,5440,"DATA_SUPPORT_ONLY",FALSE
"DATA_020","rel_share_diff","spouse_increase_all","support_increase",12851,5235,4985,2,2,10898,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_021","abs_increase","self_score_diff","support_increase",12854,5236,2,9,2,8429,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_022","abs_diff_10k","self_score_diff","support_increase",12854,5236,5240,9,2,8429,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_023","abs_log1p_10k","self_score_diff","support_increase",12854,5236,5241,9,2,8429,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_024","rel_transition_eligible","self_score_diff","support_increase",7849,3547,2,9,2,4978,5438,"DATA_SUPPORT_ONLY",FALSE
"DATA_025","rel_share_diff","self_score_diff","support_increase",12854,5236,4986,9,2,8429,8948,"DATA_SUPPORT_ONLY",FALSE
"DATA_026","abs_increase","spouse_score_diff","support_increase",12851,5235,2,9,2,8400,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_027","abs_diff_10k","spouse_score_diff","support_increase",12851,5235,5241,9,2,8400,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_028","abs_log1p_10k","spouse_score_diff","support_increase",12851,5235,5242,9,2,8400,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_029","rel_transition_eligible","spouse_score_diff","support_increase",7850,3548,2,9,2,5360,5440,"DATA_SUPPORT_ONLY",FALSE
"DATA_030","rel_share_diff","spouse_score_diff","support_increase",12851,5235,4985,9,2,8400,8946,"DATA_SUPPORT_ONLY",FALSE
"DATA_031","abs_increase","self_relative_transition","support_increase",10047,4416,2,2,2,8456,6968,"DATA_SUPPORT_ONLY",FALSE
"DATA_032","abs_diff_10k","self_relative_transition","support_increase",10047,4416,4277,2,2,8456,6968,"DATA_SUPPORT_ONLY",FALSE
"DATA_033","abs_log1p_10k","self_relative_transition","support_increase",10047,4416,4278,2,2,8456,6968,"DATA_SUPPORT_ONLY",FALSE
"DATA_034","rel_transition_eligible","self_relative_transition","support_increase",6450,3036,2,2,2,5575,4473,"DATA_SUPPORT_ONLY",FALSE
"DATA_035","rel_share_diff","self_relative_transition","support_increase",10047,4416,3946,2,2,8456,6968,"DATA_SUPPORT_ONLY",FALSE
"DATA_036","abs_increase","spouse_relative_transition","support_increase",9974,4371,2,2,2,8434,6974,"DATA_SUPPORT_ONLY",FALSE
"DATA_037","abs_diff_10k","spouse_relative_transition","support_increase",9974,4371,4231,2,2,8434,6974,"DATA_SUPPORT_ONLY",FALSE
"DATA_038","abs_log1p_10k","spouse_relative_transition","support_increase",9974,4371,4232,2,2,8434,6974,"DATA_SUPPORT_ONLY",FALSE
"DATA_039","rel_transition_eligible","spouse_relative_transition","support_increase",5860,2826,2,2,2,4808,4076,"DATA_SUPPORT_ONLY",FALSE
"DATA_040","rel_share_diff","spouse_relative_transition","support_increase",9974,4371,3904,2,2,8434,6974,"DATA_SUPPORT_ONLY",FALSE
"DATA_041","abs_increase","self_relative_gap_diff","support_increase",12843,5231,2,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_042","abs_diff_10k","self_relative_gap_diff","support_increase",12843,5231,5237,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_043","abs_log1p_10k","self_relative_gap_diff","support_increase",12843,5231,5238,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_044","rel_transition_eligible","self_relative_gap_diff","support_increase",7843,3544,2,13,2,3874,5435,"DATA_SUPPORT_ONLY",FALSE
"DATA_045","rel_share_diff","self_relative_gap_diff","support_increase",12843,5231,4983,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_046","abs_increase","spouse_relative_gap_diff","support_increase",12843,5231,2,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_047","abs_diff_10k","spouse_relative_gap_diff","support_increase",12843,5231,5237,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_048","abs_log1p_10k","spouse_relative_gap_diff","support_increase",12843,5231,5238,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_049","rel_transition_eligible","spouse_relative_gap_diff","support_increase",7843,3544,2,13,2,3874,5435,"DATA_SUPPORT_ONLY",FALSE
"DATA_050","rel_share_diff","spouse_relative_gap_diff","support_increase",12843,5231,4983,13,2,6329,8940,"DATA_SUPPORT_ONLY",FALSE
"DATA_051","abs_increase","self_increase_eligible","support_diff_10k",4170,2065,2,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_052","abs_diff_10k","self_increase_eligible","support_diff_10k",4170,2065,1985,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_053","abs_log1p_10k","self_increase_eligible","support_diff_10k",4170,2065,1985,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_054","rel_transition_eligible","self_increase_eligible","support_diff_10k",2707,1408,2,2,416,1436,1163,"DATA_SUPPORT_ONLY",FALSE
"DATA_055","rel_share_diff","self_increase_eligible","support_diff_10k",4170,2065,1719,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_056","abs_increase","spouse_increase_eligible","support_diff_10k",4111,2015,2,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_057","abs_diff_10k","spouse_increase_eligible","support_diff_10k",4111,2015,1958,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_058","abs_log1p_10k","spouse_increase_eligible","support_diff_10k",4111,2015,1958,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_059","rel_transition_eligible","spouse_increase_eligible","support_diff_10k",2165,1159,2,2,366,1060,882,"DATA_SUPPORT_ONLY",FALSE
"DATA_060","rel_share_diff","spouse_increase_eligible","support_diff_10k",4111,2015,1688,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_061","abs_increase","self_increase_all","support_diff_10k",12854,5236,2,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_062","abs_diff_10k","self_increase_all","support_diff_10k",12854,5236,5240,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_063","abs_log1p_10k","self_increase_all","support_diff_10k",12854,5236,5241,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_064","rel_transition_eligible","self_increase_all","support_diff_10k",7849,3547,2,2,771,6578,3177,"DATA_SUPPORT_ONLY",FALSE
"DATA_065","rel_share_diff","self_increase_all","support_diff_10k",12854,5236,4986,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_066","abs_increase","spouse_increase_all","support_diff_10k",12851,5235,2,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_067","abs_diff_10k","spouse_increase_all","support_diff_10k",12851,5235,5241,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_068","abs_log1p_10k","spouse_increase_all","support_diff_10k",12851,5235,5242,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_069","rel_transition_eligible","spouse_increase_all","support_diff_10k",7850,3548,2,2,772,6745,3179,"DATA_SUPPORT_ONLY",FALSE
"DATA_070","rel_share_diff","spouse_increase_all","support_diff_10k",12851,5235,4985,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_071","abs_increase","self_score_diff","support_diff_10k",12854,5236,2,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_072","abs_diff_10k","self_score_diff","support_diff_10k",12854,5236,5240,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_073","abs_log1p_10k","self_score_diff","support_diff_10k",12854,5236,5241,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_074","rel_transition_eligible","self_score_diff","support_diff_10k",7849,3547,2,9,771,4978,3177,"DATA_SUPPORT_ONLY",FALSE
"DATA_075","rel_share_diff","self_score_diff","support_diff_10k",12854,5236,4986,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_076","abs_increase","spouse_score_diff","support_diff_10k",12851,5235,2,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_077","abs_diff_10k","spouse_score_diff","support_diff_10k",12851,5235,5241,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_078","abs_log1p_10k","spouse_score_diff","support_diff_10k",12851,5235,5242,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_079","rel_transition_eligible","spouse_score_diff","support_diff_10k",7850,3548,2,9,772,5360,3179,"DATA_SUPPORT_ONLY",FALSE
"DATA_080","rel_share_diff","spouse_score_diff","support_diff_10k",12851,5235,4985,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_081","abs_increase","self_relative_transition","support_diff_10k",10047,4416,2,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_082","abs_diff_10k","self_relative_transition","support_diff_10k",10047,4416,4277,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_083","abs_log1p_10k","self_relative_transition","support_diff_10k",10047,4416,4278,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_084","rel_transition_eligible","self_relative_transition","support_diff_10k",6450,3036,2,2,677,5575,2640,"DATA_SUPPORT_ONLY",FALSE
"DATA_085","rel_share_diff","self_relative_transition","support_diff_10k",10047,4416,3946,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_086","abs_increase","spouse_relative_transition","support_diff_10k",9974,4371,2,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_087","abs_diff_10k","spouse_relative_transition","support_diff_10k",9974,4371,4231,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_088","abs_log1p_10k","spouse_relative_transition","support_diff_10k",9974,4371,4232,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_089","rel_transition_eligible","spouse_relative_transition","support_diff_10k",5860,2826,2,2,646,4808,2321,"DATA_SUPPORT_ONLY",FALSE
"DATA_090","rel_share_diff","spouse_relative_transition","support_diff_10k",9974,4371,3904,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_091","abs_increase","self_relative_gap_diff","support_diff_10k",12843,5231,2,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_092","abs_diff_10k","self_relative_gap_diff","support_diff_10k",12843,5231,5237,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_093","abs_log1p_10k","self_relative_gap_diff","support_diff_10k",12843,5231,5238,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_094","rel_transition_eligible","self_relative_gap_diff","support_diff_10k",7843,3544,2,13,770,3874,3176,"DATA_SUPPORT_ONLY",FALSE
"DATA_095","rel_share_diff","self_relative_gap_diff","support_diff_10k",12843,5231,4983,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_096","abs_increase","spouse_relative_gap_diff","support_diff_10k",12843,5231,2,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_097","abs_diff_10k","spouse_relative_gap_diff","support_diff_10k",12843,5231,5237,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_098","abs_log1p_10k","spouse_relative_gap_diff","support_diff_10k",12843,5231,5238,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_099","rel_transition_eligible","spouse_relative_gap_diff","support_diff_10k",7843,3544,2,13,770,3874,3176,"DATA_SUPPORT_ONLY",FALSE
"DATA_100","rel_share_diff","spouse_relative_gap_diff","support_diff_10k",12843,5231,4983,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_101","abs_increase","self_increase_eligible","support_log1p_10k",4170,2065,2,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_102","abs_diff_10k","self_increase_eligible","support_log1p_10k",4170,2065,1985,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_103","abs_log1p_10k","self_increase_eligible","support_log1p_10k",4170,2065,1985,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_104","rel_transition_eligible","self_increase_eligible","support_log1p_10k",2707,1408,2,2,416,1436,1163,"DATA_SUPPORT_ONLY",FALSE
"DATA_105","rel_share_diff","self_increase_eligible","support_log1p_10k",4170,2065,1719,2,566,2191,1708,"DATA_SUPPORT_ONLY",FALSE
"DATA_106","abs_increase","spouse_increase_eligible","support_log1p_10k",4111,2015,2,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_107","abs_diff_10k","spouse_increase_eligible","support_log1p_10k",4111,2015,1958,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_108","abs_log1p_10k","spouse_increase_eligible","support_log1p_10k",4111,2015,1958,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_109","rel_transition_eligible","spouse_increase_eligible","support_log1p_10k",2165,1159,2,2,366,1060,882,"DATA_SUPPORT_ONLY",FALSE
"DATA_110","rel_share_diff","spouse_increase_eligible","support_log1p_10k",4111,2015,1688,2,538,2158,1671,"DATA_SUPPORT_ONLY",FALSE
"DATA_111","abs_increase","self_increase_all","support_log1p_10k",12854,5236,2,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_112","abs_diff_10k","self_increase_all","support_log1p_10k",12854,5236,5240,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_113","abs_log1p_10k","self_increase_all","support_log1p_10k",12854,5236,5241,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_114","rel_transition_eligible","self_increase_all","support_log1p_10k",7849,3547,2,2,771,6578,3177,"DATA_SUPPORT_ONLY",FALSE
"DATA_115","rel_share_diff","self_increase_all","support_log1p_10k",12854,5236,4986,2,1082,10875,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_116","abs_increase","spouse_increase_all","support_log1p_10k",12851,5235,2,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_117","abs_diff_10k","spouse_increase_all","support_log1p_10k",12851,5235,5241,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_118","abs_log1p_10k","spouse_increase_all","support_log1p_10k",12851,5235,5242,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_119","rel_transition_eligible","spouse_increase_all","support_log1p_10k",7850,3548,2,2,772,6745,3179,"DATA_SUPPORT_ONLY",FALSE
"DATA_120","rel_share_diff","spouse_increase_all","support_log1p_10k",12851,5235,4985,2,1084,10898,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_121","abs_increase","self_score_diff","support_log1p_10k",12854,5236,2,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_122","abs_diff_10k","self_score_diff","support_log1p_10k",12854,5236,5240,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_123","abs_log1p_10k","self_score_diff","support_log1p_10k",12854,5236,5241,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_124","rel_transition_eligible","self_score_diff","support_log1p_10k",7849,3547,2,9,771,4978,3177,"DATA_SUPPORT_ONLY",FALSE
"DATA_125","rel_share_diff","self_score_diff","support_log1p_10k",12854,5236,4986,9,1082,8429,5041,"DATA_SUPPORT_ONLY",FALSE
"DATA_126","abs_increase","spouse_score_diff","support_log1p_10k",12851,5235,2,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_127","abs_diff_10k","spouse_score_diff","support_log1p_10k",12851,5235,5241,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_128","abs_log1p_10k","spouse_score_diff","support_log1p_10k",12851,5235,5242,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_129","rel_transition_eligible","spouse_score_diff","support_log1p_10k",7850,3548,2,9,772,5360,3179,"DATA_SUPPORT_ONLY",FALSE
"DATA_130","rel_share_diff","spouse_score_diff","support_log1p_10k",12851,5235,4985,9,1084,8400,5039,"DATA_SUPPORT_ONLY",FALSE
"DATA_131","abs_increase","self_relative_transition","support_log1p_10k",10047,4416,2,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_132","abs_diff_10k","self_relative_transition","support_log1p_10k",10047,4416,4277,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_133","abs_log1p_10k","self_relative_transition","support_log1p_10k",10047,4416,4278,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_134","rel_transition_eligible","self_relative_transition","support_log1p_10k",6450,3036,2,2,677,5575,2640,"DATA_SUPPORT_ONLY",FALSE
"DATA_135","rel_share_diff","self_relative_transition","support_log1p_10k",10047,4416,3946,2,930,8456,3918,"DATA_SUPPORT_ONLY",FALSE
"DATA_136","abs_increase","spouse_relative_transition","support_log1p_10k",9974,4371,2,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_137","abs_diff_10k","spouse_relative_transition","support_log1p_10k",9974,4371,4231,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_138","abs_log1p_10k","spouse_relative_transition","support_log1p_10k",9974,4371,4232,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_139","rel_transition_eligible","spouse_relative_transition","support_log1p_10k",5860,2826,2,2,646,4808,2321,"DATA_SUPPORT_ONLY",FALSE
"DATA_140","rel_share_diff","spouse_relative_transition","support_log1p_10k",9974,4371,3904,2,914,8434,3863,"DATA_SUPPORT_ONLY",FALSE
"DATA_141","abs_increase","self_relative_gap_diff","support_log1p_10k",12843,5231,2,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_142","abs_diff_10k","self_relative_gap_diff","support_log1p_10k",12843,5231,5237,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_143","abs_log1p_10k","self_relative_gap_diff","support_log1p_10k",12843,5231,5238,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_144","rel_transition_eligible","self_relative_gap_diff","support_log1p_10k",7843,3544,2,13,770,3874,3176,"DATA_SUPPORT_ONLY",FALSE
"DATA_145","rel_share_diff","self_relative_gap_diff","support_log1p_10k",12843,5231,4983,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_146","abs_increase","spouse_relative_gap_diff","support_log1p_10k",12843,5231,2,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_147","abs_diff_10k","spouse_relative_gap_diff","support_log1p_10k",12843,5231,5237,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_148","abs_log1p_10k","spouse_relative_gap_diff","support_log1p_10k",12843,5231,5238,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE
"DATA_149","rel_transition_eligible","spouse_relative_gap_diff","support_log1p_10k",7843,3544,2,13,770,3874,3176,"DATA_SUPPORT_ONLY",FALSE
"DATA_150","rel_share_diff","spouse_relative_gap_diff","support_log1p_10k",12843,5231,4983,13,1082,6329,5035,"DATA_SUPPORT_ONLY",FALSE


## RESULT.json
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/continuousM_adjudication_v2/RESULT.json

{
  "at": "2026-10-05T02:45:35.199341+00:00",
  "status": "EXPLORATORY_SCIENTIFIC_ADJUDICATION_COMPLETE",
  "review_mode": "solo_self_review_with_prior_Claude_report",
  "specifications": [
    "FEAS_041",
    "FEAS_042",
    "FEAS_043",
    "FEAS_044",
    "FEAS_045",
    "FEAS_046",
    "FEAS_047",
    "FEAS_048",
    "FEAS_049",
    "FEAS_050",
    "FEAS_091",
    "FEAS_092",
    "FEAS_093",
    "FEAS_094",
    "FEAS_095",
    "FEAS_096",
    "FEAS_097",
    "FEAS_098",
    "FEAS_099",
    "FEAS_100",
    "FEAS_141",
    "FEAS_142",
    "FEAS_143",
    "FEAS_144",
    "FEAS_145",
    "FEAS_146",
    "FEAS_147",
    "FEAS_148",
    "FEAS_149",
    "FEAS_150"
  ],
  "sample_sha256": {
    "FEAS_041": "fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732",
    "FEAS_042": "b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c",
    "FEAS_043": "06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889",
    "FEAS_044": "f0410895c82da97a909b4ab42327e2d2fa01c9b142ab2992ac2380cb96bd3bbe",
    "FEAS_045": "341f3244465857cefc228058a5e54c01a18ca9a2e9d0114795dffddb6f48f049",
    "FEAS_046": "fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732",
    "FEAS_047": "b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c",
    "FEAS_048": "06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889",
    "FEAS_049": "f0410895c82da97a909b4ab42327e2d2fa01c9b142ab2992ac2380cb96bd3bbe",
    "FEAS_050": "341f3244465857cefc228058a5e54c01a18ca9a2e9d0114795dffddb6f48f049",
    "FEAS_091": "fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732",
    "FEAS_092": "b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c",
    "FEAS_093": "06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889",
    "FEAS_094": "f0410895c82da97a909b4ab42327e2d2fa01c9b142ab2992ac2380cb96bd3bbe",
    "FEAS_095": "341f3244465857cefc228058a5e54c01a18ca9a2e9d0114795dffddb6f48f049",
    "FEAS_096": "fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732",
    "FEAS_097": "b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c",
    "FEAS_098": "06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889",
    "FEAS_099": "f0410895c82da97a909b4ab42327e2d2fa01c9b142ab2992ac2380cb96bd3bbe",
    "FEAS_100": "341f3244465857cefc228058a5e54c01a18ca9a2e9d0114795dffddb6f48f049",
    "FEAS_141": "fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732",
    "FEAS_142": "b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c",
    "FEAS_143": "06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889",
    "FEAS_144": "f0410895c82da97a909b4ab42327e2d2fa01c9b142ab2992ac2380cb96bd3bbe",
    "FEAS_145": "341f3244465857cefc228058a5e54c01a18ca9a2e9d0114795dffddb6f48f049",
    "FEAS_146": "fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732",
    "FEAS_147": "b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c",
    "FEAS_148": "06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889",
    "FEAS_149": "f0410895c82da97a909b4ab42327e2d2fa01c9b142ab2992ac2380cb96bd3bbe",
    "FEAS_150": "341f3244465857cefc228058a5e54c01a18ca9a2e9d0114795dffddb6f48f049"
  },
  "relative_admitted": 30,
  "absolute_unsuitable": 30,
  "effect_estimates_added": 0,
  "p_values_read_by_this_adjudication": false,
  "prior_binary_results_known": true,
  "preregistered_threshold": false,
  "causal_identification_verified": false,
  "max_mean_tail": 0.000662139671811243,
  "max_individual_tail": 0.0270459311436912,
  "restrictions": [
    "Admission is to exploratory model computation only, not proof of a valid causal intervention.",
    "Relative-gap versions can have different outcome effects; gap alone does not identify a unique joint-couple intervention.",
    "The same version and concurrent-time limitations apply to relative binary specifications; do not selectively claim identification for them.",
    "No clipping, sample changes, altered contrasts or p-driven recoding; preserve original frozen estimands and resampling.",
    "Nonzero Gaussian leakage remains. Small probability does not bound its effect on nonlinear outcome estimates.",
    "Rankings are exploratory and sample-specific; retain full 150-test families and paired-mirror equivalence deduplication.",
    "B1000 is precision refinement, not independent confirmation; bounded/ordinal or temporally ordered alternatives require separate registration.",
    "Worker must bind this continuous-specific evidence explicitly; do not fake binary probability gates.",
    "Native readiness, frozen worker identity and current storage budget remain required before execution."
  ],
  "evidence": [
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_bootstrap_support_v1/INDEPENDENT_VALIDATION.json",
      "sha256": "471e4159d2ea12a0ffb6c61b300bbc592e037168b00047401c7d7d7919c21380",
      "bytes": 1683
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_bootstrap_support_v1/ALL_REPLICATES.csv",
      "sha256": "4283bf3b59dd1fd2d1ec87142d25c8ade77d3e0a67f2d1f2803a8fc4f46b3169",
      "bytes": 1031169
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/feasible_population_v1/specifications.csv",
      "sha256": "9ed331391d5359a707692e9ff5ce849ef63e11f87d926368c889ca347a79ddd3",
      "bytes": 80519
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/continuousM_adjudication_v1/SPECIFICATION_DECISIONS.csv",
      "sha256": "9315e7aa24ac401ecc532aacc6ccf5497df30be5706d02a3a8cff8fea6b3d9fe",
      "bytes": 15465
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/claude_gaussian_review_v1/executor-report.md",
      "sha256": "267cf3a2bb2327797a13c7bca9b8b62a3ab7bd0d9cab3c2ac3ee28b9099d7e8c",
      "bytes": 6063
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/claude_math_correction_adjudication_v1/RESULT.json",
      "sha256": "c303810edf059ffee48248e1cea6f9ab8e94cd2e01984035d544a0e6c002f74a",
      "bytes": 2423
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_worker_support_v1/RESULT.json",
      "sha256": "c232cdb27d5f1eb1225dd4516dc6008e0ea89fe8b980c2d05138c93daef8d6d5",
      "bytes": 6675
    }
  ]
}


## executor-report.md
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/claude_coding_audit_v2/executor-report.md

# 编码与估计量独立审查报告

task_id: cmaverse-coding-audit-20261005
executor: surface:2596 (claude, ordinal 1)
范围: 仅离线只读源码审查；零次模型运行，零次 p 值读取，未改任何共享文件。

## 1. 输入身份核验

INPUT_PINS.json 中 6 项全部与现盘一致（读前读后各核一次，未变）：

| 文件 | sha256 前缀 | bytes |
|---|---|---|
| candidate_data.R | 802a91bb456de0a1 | 1629 |
| screening_worker_continuous_v3.R | ec63bdc8845d5094 | 7434 |
| ADJUSTMENT_AND_ESTIMANDS.md | 5223e0edcb9bb931 | 3745 |
| PRE_RESULT_AMENDMENT_v2.md | 77244eb0e65d3b03 | 2767 |
| SELECTION_RULES.md | d0e0210b6f277361 | 2436 |
| CURRENT_PLAN.md | 90b4c503ca67e855 | 47390 |

ALL_PINS_MATCH: True

## 2. 缺陷（BUG，需属主裁决）

**B1 — 四个实际依赖未进入 INPUT_PINS，钉选不完整。**

`screening_worker_continuous_v3.R` 在运行时 source／读取以下文件，它们直接决定调整族、诊断记录与规格参数，但均不在 pins 中：

| 行号 | 依赖 | 当前 sha256 前缀 | 作用 |
|---|---|---|---|
| 43 | baseline_adjustment.R | 0d9f91af5036ca29 | 定义 23 项固定调整族 `covars` 与 `factors` |
| 56 | screening_records.R | 3738309998390d96 | `make_grid_recorder` 等记录器 |
| 57 | shared_bootstrap_diagnostic.R | feaba1da5e407bb9 | `make_shared_cmest`，bootstrap 诊断桥 |
| 33 | feasible_population_v1/specifications.csv | 9ed331391d5359a7 | 逐规格 x/m/y/astar/a/mval/n/sample_sha256 |

后果：审查声明「输入身份已冻结」时，实际有四个可变更的上游未被该声明覆盖。`specifications.csv` 在 worker 内部确有自洽校验（第 39 行把它的 sha 与 `plan$registry_sha256` 对照），但 `baseline_adjustment.R` 无任何哈希校验——改动它会静默改变全部 150 规格的调整族而不触发任何 stopifnot。

建议：把上述四项加入 INPUT_PINS，或在 worker 内对 `baseline_adjustment.R` 增加与 `source_manifest` 同级的 digest 校验。我未修改任何文件。

## 3. 已证事实（VERIFIED，附行号）

**V1 — X 的五种编码互不等价，且混用两种度量语义。**
`candidate_data.R:10-14`：`abs_increase`（二值 `z$x_abs`）、`abs_diff_10k`（万元差分）、`abs_log1p_10k`（log1p 差分）、`rel_transition_eligible`（二值 `z$x_rel`）、`rel_share_diff`（份额差分）。前三项为绝对收入，后两项为相对（份额）口径。二值项与连续项的对比尺度不同，`SELECTION_RULES.md` 第 2 条禁止跨尺度比较效应绝对大小，此禁令对 X 维度同样必要。

**V2 — M 的十种编码中，relative_gap 一族为「本人减配偶」的差分，自带符号约定。**
`candidate_data.R:19`：`self_relative_gap_diff=z$dm_self_rel`，`spouse_relative_gap_diff=z$dm_spouse_rel`。`ADJUSTMENT_AND_ESTIMANDS.md`「对比与分解」明确要求说明相对分差是本人减配偶的变化。

**V3 — 镜像等价为代数恒等，非实证不变性。**
在 `gap_self = −gap_spouse` 恒等下，同时把 M 映为 −M 且 mval 映为 −mval，描述的是同一个受控对比；受控直接效应的对比两端逐一对应，效应方向无需反向。只有「每固定正单位的回归系数」反号，那是参数化记账方向。此结论已由前序任务从 SIMULATOR_SUPPORT.csv 独立复核：15 对 self/spouse 规格在 astar 与 a 两处的 n、σ、exact_tail、max_individual_tail、sample_sha256 逐项相同。本次审查不重复该数值核算，亦不据此声称效应不变。

**V4 — 本轮 B200 worker 只接受 relative_gap 两族，不接受 score_diff。**
`screening_worker_continuous_v3.R:35-36`：`stopifnot(g$mreg == "linear", g$m %in% c("self_relative_gap_diff","spouse_relative_gap_diff"))`。这与 Gaussian 支持裁决一致——`*_score_diff` 两族被判 `UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN`，其模拟 M 有 12%–17% 落在 `[1−基线, 5−基线]` 外。worker 用硬 stopifnot 实现该裁决，不依赖调用方自觉。

**V5 — 中介与调节在代码层是分开的两个量，未混淆。**
`:80-83` 传入 `EMint=TRUE` 与 `mval_grid=list(c(g$mval0,g$mval1))`。自然间接效应（TNIE）与配对受控直接效应对比（Delta CDE）由此分别可得；后者表示预设 M 对比下的效应修饰。`SELECTION_RULES.md` 第 1 条与 `ADJUSTMENT_AND_ESTIMANDS.md`「首先检验自然间接效应与受控效应差/交互」均要求 M 回归系数不得当作中介效应，代码未把系数当作效应。

**V6 — 失效重复不补抽，失败保留。**
`:105-108` 记录 `status`、`repeats`、`valid=sum(dg$fits_valid & dg$core_finite)`，失败时写 `error` 并以 `FAILED` 终态落盘；`:90-92` 无条件写出 `repeat_diagnostics.csv` 与 `warnings.txt`。符合 `PRE_RESULT_AMENDMENT_v2.md`「200 次任一不可估不补抽、不换种子，所有失败输出保留」。

**V7 — 终态语义自限，不冒称进程退出码。**
`:108` 显式写入 `interpretation='Function terminal only; driver must separately collect child process exit'`。函数终态与子进程退出是两个事实，代码未混淆。

**V8 — 23 项固定调整族不按 p 值增删，双方满意度对称进入。**
`baseline_adjustment.R:2-7` 列出固定 23 项，含 `self_sat_begin` 与 `spouse_sat_begin` 同时进入，使本人／配偶规格对称；`:10` 以 `stopifnot(all(covars %in% names(z)))` 硬校验存在性。符合 `ADJUSTMENT_AND_ESTIMANDS.md`「沿用已保存基础回归的区间起点调整变量，不按 p 值增删」。

**V9 — 同期变化不支持中介时序，代码未声称支持。**
`candidate_data.R:10-22` 的 X／M／Y 全部为同一两年区间内的变化量（end 减 begin）。`ADJUSTMENT_AND_ESTIMANDS.md`「当前两年区间变化不能证明 X 先于 M、M 先于 Y」。worker 无任何时序断言；`:22-24` 反而强制 `identical(support$causal_identification_verified, FALSE)`，即准入证据必须自称未验证因果识别。这是把「未识别」写进硬校验，方向正确。

## 4. 可为科学辩护的主张 vs 未解决问题

可辩护（在强假设下的探索性分解）：
- X／M／Y 各编码的构造口径明确、单位固定、不搜索变换常数（`candidate_data.R:9` 注释与 `:11-12`、`:21-22` 实现一致）。
- 镜像对的等价组处理有规则依据（`SELECTION_RULES.md` 第 3 条），且代码层以同一拟合实现。
- 中介效应与效应修饰分离，不以回归系数替代中介效应。
- 失败与不显著结果保留，多重比较分母保留 150。

未解决（不得在正文写成已识别）：
- **时序**：全部为同期两年变化，X→M→Y 顺序无证据（V9）。
- **夫妻联合干预版本**：`gap_self = −gap_spouse` 下固定一方即固定另一方，「谁的满意度被改变、如何改变」仍未定义。`ADJUSTMENT_AND_ESTIMANDS.md` 与 `SELECTION_RULES.md` 第 8 条均列为未决。
- **条件共同支持**：诊断只核过 M 模拟值的边界兼容，未核 `astar/a` 对比处的条件共同支持；`SELECTION_RULES.md` 第 8 条明确「范围支持不等同条件共同支持」。
- **bootstrap refit 尾部**：零次 bootstrap 执行，现有 σ 来自单次全样本拟合，对 B200 的越界次数无预测力。
- **越界非零**：`*_relative_gap_diff` 的 `exact_expected_tail` 区间为 0.00016–0.00026，从不为 0。低均值不等于排除，措辞不得写成「已排除越界」。
- **钉选不完整**：见 B1。

## 5. 未测项（UNMEASURED，不得当作通过）

- 未运行任何 R 模型、未读取任何 p 值、未执行 bootstrap。
- 未读取 RDS 实体数据（`v6_provisional_dyad_intervals_recovered.rds`、`identity_target_13092.rds`、`sample_membership.rds`、`screen.rds`），故 `z` 各字段的实际取值域、缺失结构、`cluster_id` 的亲属／家庭连通性均未核。
- 未核 `make_shared_cmest` 与 `make_grid_recorder` 的内部实现（文件存在且已记哈希，未逐行审）。
- 未核安装版 CMAverse 的 `mval_grid` 分解语义是否与 `yreg='logistic'` 组合下的 `yval=1`（`:84`）在所有分量上自洽。
- 未对 126 规格人口变化与效应同行显示的要求做落实核查。

## 6. 产出

- `review_output/coding_audit_matrix.json`（sha256 d1204929cd68ed7b，7960 B）：主张到代码行的紧凑映射矩阵。
- 本报告。

未改任何共享代码、skill、仓库或数据；未删除文件；未提交 RStudio；未调用任何 UI／外部服务；未替换会话或切换模型。原有报告与回执全部保留。


## executor-report.md
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/claude_gaussian_review_v1/executor-report.md

# 连续M适用性独立审查报告

task_id: cmaverse-gaussian-review-20261005
reviewer: claude:executor (独立审查，非准入决定)
范围: 60个连续中介规格（mreg=linear）、120个干预行

## 结论摘要

60个规格按中介族清晰二分，**不存在中间地带**：

| M族 | 规格数 | 期望域外概率 | 最坏个体行 | 裁决 |
|---|---|---|---|---|
| self_relative_gap_diff | 15 | 0.016%–0.026% | ≤1.08% | 适用（须附条件说明） |
| spouse_relative_gap_diff | 15 | 0.016%–0.026% | ≤1.08% | 适用（须附条件说明） |
| self_score_diff | 15 | 12.0%–14.2% | 39.0%–43.6% | 不适用，需有界替代 |
| spouse_score_diff | 15 | 13.2%–16.7% | 34.4%–39.7% | 不适用，需有界替代 |

30个适用、30个不适用、0个待补证。`RESULT.json` 报告的 2e-4–0.1675 全域范围由我独立复算确认（实测 0.000160–0.167485）。

## 为何域外概率在此是硬缺陷

已读安装版估计器源码（`installed_est_gformula_body.R`，与源码 body 恒等已由生产者 `stopifnot` 核过）：

```r
error <- rnorm(n_full, mean = 0, sd = sigma(mreg[[p]]))
mid_a     <- mpred_a[full_index]     + error
mid_astar <- mpred_astar[full_index] + error
```

**无截断**。a 与 astar 共享同一 error（配对规则）。这意味着落在合法域外的概率质量不是纸面警告，而是真实生成不可能的中介值并喂入结果模型。满意度差分的合法域是 `[1-基线, 5-基线]`，相对分差是 `[-4-基线差, 4-基线差]`。

score_diff 族期望 12%–17% 的抽样落在域外、最坏个体行高达 44%，等于把一个 5 点离散量的变化当连续无界量处理；relative_gap_diff 族因基线差分布居中、sigma 相对域宽更小，泄漏降至万分之二量级。

## 不依赖 p 值的准入规则（结果前冻结）

```
rule_id: gaussian_support_admission_v1
输入: exact_expected_tail, max_individual_tail  (均为分布量，非显著性)

附条件准入: exact_expected_tail < 0.01 且 max_individual_tail < 0.05
需有界模型: exact_expected_tail >= 0.05 或 max_individual_tail >= 0.20
中间带:    0.01 <= tail < 0.05 -> 暂缓，待有界模型对照；禁止用显著性裁决
```

明确禁止：以 p 值/显著性作准入依据、事后调阈值以保留某族、静默截断模拟中介。

应用结果：30 附条件准入、30 需有界模型、0 落入中间带。阈值与数据的分离度很大（0.00026 vs 0.1199，差约 460 倍），所以结论对阈值选择不敏感。

## 诊断自身的可信度

闭式条件尾概率与实际抽样越界比例的一致性：中位差 0.0004、最大差 0.0139。这说明诊断测的正是它声称的量。但这只支持"模拟越界量化正确"，**不支持因果识别**。

## 中介时序与调整估计必须分开报告

全部 60 个规格 `time_structure = concurrent_two_year_changes`。没有任何一个能建立 X→M→Y 的时间顺序。**这与高斯支持域问题正交**：换成有界中介模型可以修复支持域，但修不了时序。两者必须分列为独立缺陷，不能因为其中一个解决就宣称规格可用。

## 等价组

`spouse_relative_gap_diff` 用 mval1=−1，`self_relative_gap_diff` 用 mval1=+1 —— 这 30 行是**一个反号等价组**，不是两个独立的角色发现。按现行规则每指标/Y单元最多取一项。

## 替代方案（仅建议，不扩充冻结规格）

针对 score_diff 两族：

- 有序（polr）中介模型，直接按离散变化尺度建模
- 有界变换 + 结果阶段显式逆变换
- 两部分模型，分离"无变化"与"变化幅度"

状态：`RECOMMENDATION_ONLY_REQUIRES_SEPARATE_CONTRACT`。**不得**并入已冻结的 150 规格族，也不得计入其分母。

## 人口损失（与效果同行披露）

| M族 | n 范围 | 排除比例中位数 |
|---|---|---|
| relative_gap_diff（两族） | 7668–12564 | 26.4% |
| self_score_diff | 2654–4096 | 76.3% |
| spouse_score_diff | 2121–4028 | 75.3% |

score_diff 族在支持域失败之外还损失约四分之三母体。跨人口排序属探索候选比较，不能证明编码方式改善了同一总体上的真实效应。

## 证据 vs 推断 vs 未测

**证据（读自已验证输入）**：安装版模拟器无截断且 a/astar 共享误差；120 行闭式尾概率与抽样越界比例；逐规格 n、聚类数、排除比例；全部 60 规格为同期变化。

**推断（我的判断，非测量）**：12%–17% 域外质量使高斯近似对 score_diff 族失效；万分之二量级对 relative_gap_diff 族可接受但须披露；不存在中间地带因此无需逐例裁量。

**未测**：实际 cmest bootstrap 的 RNG 轨迹（诊断用自有种子）；连续暴露对比的条件共同支持/positivity；相对分差中介的夫妻联合干预版本；域外中介抽样对结果阶段估计的实际影响量级；有界替代是否会改变任何效应估计。

## 合规声明

未修改原数据、冻结规格、已有结果、共享 skill/代理/配置；未运行正式 R 模型；未读取或使用任何 p 值/显著性；未截断模拟 M；未重写或重发旧效率任务的报告与回调。仅在 `review_output/` 下写入 `suitability.json`，无大文件复制。

## 读取输入哈希回读

| 文件 | pack 固定(前16) | 实测(前16) | 结果 |
|---|---|---|---|
| SELECTION_RULES.md | `d0e0210b6f277361` | `d0e0210b6f277361` | OK |
| ADJUSTMENT_AND_ESTIMANDS.md | `5223e0edcb9bb931` | `5223e0edcb9bb931` | OK |
| PRE_RESULT_AMENDMENT_v2.md | `77244eb0e65d3b03` | `77244eb0e65d3b03` | OK |
| RESULT.json | `edf306fbc539a4d6` | `edf306fbc539a4d6` | OK |
| SIMULATOR_SUPPORT.csv | `29894d27f95f9d41` | `29894d27f95f9d41` | OK |
| installed_est_gformula_body.R | `3c459717db2db685` | `3c459717db2db685` | OK |
| candidate_data.R | `802a91bb456de0a1` | `802a91bb456de0a1` | OK |
| diagnose_gaussian_simulator.R | `68671d4eb8c7f8a3` | `68671d4eb8c7f8a3` | OK |

全部 8/8 匹配。

结构化裁决: `review_output/suitability.json`


## ALL_300_STATUS.csv
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/status_120_specs_v1/ALL_300_STATUS.csv

spec_id,x,m,y,metric,n,clusters,excluded_fraction,status,status_reason,estimate,ci_low,ci_high,p_exploratory,valid,adjusted_p,ranking,evidence
FEAS_001,abs_increase,self_increase_eligible,support_increase,TNIE,4096,1641,0,VALIDATED_B200,,0.999308690324634,0.993381793921412,1.00984260645185,0.741293532338308,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/first_B200_v1/ARTIFACT_VALIDATION.json
FEAS_001,abs_increase,self_increase_eligible,support_increase,Delta_CDE,4096,1641,0,VALIDATED_B200,,-0.0215270991146883,-0.383430227316747,0.355238111971901,0.900497512437811,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/first_B200_v1/ARTIFACT_VALIDATION.json
FEAS_002,abs_diff_10k,self_increase_eligible,support_increase,TNIE,2733,1175,0.332763671875,VALIDATED_B200,,1.00024178724036,0.996551785675091,1.00344763180151,0.786069651741294,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_002/ARTIFACT_VALIDATION.json
FEAS_002,abs_diff_10k,self_increase_eligible,support_increase,Delta_CDE,2733,1175,0.332763671875,VALIDATED_B200,,-0.0243789304446611,-0.11257165498549,0.100259212689735,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_002/ARTIFACT_VALIDATION.json
FEAS_003,abs_log1p_10k,self_increase_eligible,support_increase,TNIE,2991,1277,0.269775390625,VALIDATED_B200,,1.00219444759239,0.993516657293029,1.00586622355411,0.572139303482587,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_003/ARTIFACT_VALIDATION.json
FEAS_003,abs_log1p_10k,self_increase_eligible,support_increase,Delta_CDE,2991,1277,0.269775390625,VALIDATED_B200,,0.0536997203831739,-0.0838378018341638,0.235916720913273,0.527363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_003/ARTIFACT_VALIDATION.json
FEAS_004,rel_transition_eligible,self_increase_eligible,support_increase,TNIE,2654,1248,0,VALIDATED_B200,,0.981917194359635,0.942313158153619,1.01283193333877,0.278606965174129,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_004/ARTIFACT_VALIDATION.json
FEAS_004,rel_transition_eligible,self_increase_eligible,support_increase,Delta_CDE,2654,1248,0,VALIDATED_B200,,0.412124516598985,-0.0548407012454932,1.20348703789105,0.174129353233831,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_004/ARTIFACT_VALIDATION.json
FEAS_005,rel_share_diff,self_increase_eligible,support_increase,TNIE,2725,1177,0.334716796875,VALIDATED_B200,,0.998765819035745,0.990555433715851,1.00693209037754,0.646766169154229,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_005/ARTIFACT_VALIDATION.json
FEAS_005,rel_share_diff,self_increase_eligible,support_increase,Delta_CDE,2725,1177,0.334716796875,VALIDATED_B200,,0.110344184501018,-0.0510887753423906,0.274457694463669,0.134328358208955,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_005/ARTIFACT_VALIDATION.json
FEAS_006,abs_increase,spouse_increase_eligible,support_increase,TNIE,4028,1573,0,VALIDATED_B200,,1.00040622152255,0.991241716693616,1.01550429565576,0.930348258706468,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_006/ARTIFACT_VALIDATION.json
FEAS_006,abs_increase,spouse_increase_eligible,support_increase,Delta_CDE,4028,1573,0,VALIDATED_B200,,0.332464591814602,-0.0426395440520153,0.720726812050526,0.0995024875621891,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_006/ARTIFACT_VALIDATION.json
FEAS_007,abs_diff_10k,spouse_increase_eligible,support_increase,TNIE,2875,1211,0.286246276067527,VALIDATED_B200,,0.999378964694429,0.994924963397027,1.00382530309272,0.686567164179104,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_007/ARTIFACT_VALIDATION.json
FEAS_007,abs_diff_10k,spouse_increase_eligible,support_increase,Delta_CDE,2875,1211,0.286246276067527,VALIDATED_B200,,-0.0444022525040978,-0.116206112803838,0.0548697960089451,0.293532338308458,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_007/ARTIFACT_VALIDATION.json
FEAS_008,abs_log1p_10k,spouse_increase_eligible,support_increase,TNIE,3119,1299,0.225670307845084,VALIDATED_B200,,1.00057215980848,0.994762481131904,1.00482462132812,0.72636815920398,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_008/ARTIFACT_VALIDATION.json
FEAS_008,abs_log1p_10k,spouse_increase_eligible,support_increase,Delta_CDE,3119,1299,0.225670307845084,VALIDATED_B200,,0.0164061093010479,-0.1139974885477,0.143643930422807,0.830845771144279,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch01/FEAS_008/ARTIFACT_VALIDATION.json
FEAS_009,rel_transition_eligible,spouse_increase_eligible,support_increase,TNIE,2121,1024,0,VALIDATED_B200,,1.00004011382049,0.979046368406202,1.02725559549734,0.985074626865672,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_009/ARTIFACT_VALIDATION.json
FEAS_009,rel_transition_eligible,spouse_increase_eligible,support_increase,Delta_CDE,2121,1024,0,VALIDATED_B200,,0.191528854125976,-0.237216933599186,0.692970430019721,0.45771144278607,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_009/ARTIFACT_VALIDATION.json
FEAS_010,rel_share_diff,spouse_increase_eligible,support_increase,TNIE,2698,1140,0.330188679245283,VALIDATED_B200,,0.998977412099798,0.995135283116876,1.00380093313731,0.601990049751244,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_010/ARTIFACT_VALIDATION.json
FEAS_010,rel_share_diff,spouse_increase_eligible,support_increase,Delta_CDE,2698,1140,0.330188679245283,VALIDATED_B200,,0.0753080679106958,-0.0456151481358623,0.230233004499962,0.283582089552239,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch01/FEAS_010/ARTIFACT_VALIDATION.json
FEAS_011,abs_increase,self_increase_all,support_increase,TNIE,4096,1641,0.675667115369388,VALIDATED_B200,,0.999308690324634,0.993381793921412,1.00984260645185,0.741293532338308,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_011/ARTIFACT_VALIDATION.json
FEAS_011,abs_increase,self_increase_all,support_increase,Delta_CDE,4096,1641,0.675667115369388,VALIDATED_B200,,-0.0215270991146883,-0.383430227316747,0.355238111971901,0.900497512437811,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_011/ARTIFACT_VALIDATION.json
FEAS_012,abs_diff_10k,self_increase_all,support_increase,TNIE,2733,1175,0.783593316968881,VALIDATED_B200,,1.00024178724036,0.996551785675091,1.00344763180151,0.786069651741294,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_012/ARTIFACT_VALIDATION.json
FEAS_012,abs_diff_10k,self_increase_all,support_increase,Delta_CDE,2733,1175,0.783593316968881,VALIDATED_B200,,-0.0243789304446611,-0.11257165498549,0.100259212689735,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_012/ARTIFACT_VALIDATION.json
FEAS_013,abs_log1p_10k,self_increase_all,support_increase,TNIE,2991,1277,0.763164146013144,VALIDATED_B200,,1.00219444759239,0.993516657293029,1.00586622355411,0.572139303482587,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_013/ARTIFACT_VALIDATION.json
FEAS_013,abs_log1p_10k,self_increase_all,support_increase,Delta_CDE,2991,1277,0.763164146013144,VALIDATED_B200,,0.0536997203831739,-0.0838378018341638,0.235916720913273,0.527363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_013/ARTIFACT_VALIDATION.json
FEAS_014,rel_transition_eligible,self_increase_all,support_increase,TNIE,2654,1248,0.655503634475597,VALIDATED_B200,,0.981917194359635,0.942313158153619,1.01283193333877,0.278606965174129,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_014/ARTIFACT_VALIDATION.json
FEAS_014,rel_transition_eligible,self_increase_all,support_increase,Delta_CDE,2654,1248,0.655503634475597,VALIDATED_B200,,0.412124516598985,-0.0548407012454932,1.20348703789105,0.174129353233831,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_014/ARTIFACT_VALIDATION.json
FEAS_015,rel_share_diff,self_increase_all,support_increase,TNIE,2725,1177,0.784226779634175,VALIDATED_B200,,0.998765819035745,0.990555433715851,1.00693209037754,0.646766169154229,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_015/ARTIFACT_VALIDATION.json
FEAS_015,rel_share_diff,self_increase_all,support_increase,Delta_CDE,2725,1177,0.784226779634175,VALIDATED_B200,,0.110344184501018,-0.0510887753423906,0.274457694463669,0.134328358208955,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_015/ARTIFACT_VALIDATION.json
FEAS_016,abs_increase,spouse_increase_all,support_increase,TNIE,4028,1573,0.681076801266825,VALIDATED_B200,,1.00040622152255,0.991241716693616,1.01550429565576,0.930348258706468,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_016/ARTIFACT_VALIDATION.json
FEAS_016,abs_increase,spouse_increase_all,support_increase,Delta_CDE,4028,1573,0.681076801266825,VALIDATED_B200,,0.332464591814602,-0.0426395440520153,0.720726812050526,0.0995024875621891,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_016/ARTIFACT_VALIDATION.json
FEAS_017,abs_diff_10k,spouse_increase_all,support_increase,TNIE,2875,1211,0.77236737925574,VALIDATED_B200,,0.999378964694429,0.994924963397027,1.00382530309272,0.686567164179104,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_017/ARTIFACT_VALIDATION.json
FEAS_017,abs_diff_10k,spouse_increase_all,support_increase,Delta_CDE,2875,1211,0.77236737925574,VALIDATED_B200,,-0.0444022525040978,-0.116206112803838,0.0548697960089451,0.293532338308458,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_017/ARTIFACT_VALIDATION.json
FEAS_018,abs_log1p_10k,spouse_increase_all,support_increase,TNIE,3119,1299,0.75304829770388,VALIDATED_B200,,1.00057215980848,0.994762481131904,1.00482462132812,0.72636815920398,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_018/ARTIFACT_VALIDATION.json
FEAS_018,abs_log1p_10k,spouse_increase_all,support_increase,Delta_CDE,3119,1299,0.75304829770388,VALIDATED_B200,,0.0164061093010479,-0.1139974885477,0.143643930422807,0.830845771144279,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_018/ARTIFACT_VALIDATION.json
FEAS_019,rel_transition_eligible,spouse_increase_all,support_increase,TNIE,2121,1024,0.724724205061648,VALIDATED_B200,,1.00004011382049,0.979046368406202,1.02725559549734,0.985074626865672,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_019/ARTIFACT_VALIDATION.json
FEAS_019,rel_transition_eligible,spouse_increase_all,support_increase,Delta_CDE,2121,1024,0.724724205061648,VALIDATED_B200,,0.191528854125976,-0.237216933599186,0.692970430019721,0.45771144278607,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_019/ARTIFACT_VALIDATION.json
FEAS_020,rel_share_diff,spouse_increase_all,support_increase,TNIE,2698,1140,0.786381631037213,VALIDATED_B200,,0.998977412099798,0.995135283116876,1.00380093313731,0.601990049751244,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_020/ARTIFACT_VALIDATION.json
FEAS_020,rel_share_diff,spouse_increase_all,support_increase,Delta_CDE,2698,1140,0.786381631037213,VALIDATED_B200,,0.0753080679106958,-0.0456151481358623,0.230233004499962,0.283582089552239,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch02/FEAS_020/ARTIFACT_VALIDATION.json
FEAS_021,abs_increase,self_score_diff,support_increase,TNIE,4096,1641,0.675667115369388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_021,abs_increase,self_score_diff,support_increase,Delta_CDE,4096,1641,0.675667115369388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_022,abs_diff_10k,self_score_diff,support_increase,TNIE,2733,1175,0.783593316968881,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_022,abs_diff_10k,self_score_diff,support_increase,Delta_CDE,2733,1175,0.783593316968881,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_023,abs_log1p_10k,self_score_diff,support_increase,TNIE,2991,1277,0.763164146013144,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_023,abs_log1p_10k,self_score_diff,support_increase,Delta_CDE,2991,1277,0.763164146013144,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_024,rel_transition_eligible,self_score_diff,support_increase,TNIE,2654,1248,0.655503634475597,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_024,rel_transition_eligible,self_score_diff,support_increase,Delta_CDE,2654,1248,0.655503634475597,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_025,rel_share_diff,self_score_diff,support_increase,TNIE,2725,1177,0.784226779634175,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_025,rel_share_diff,self_score_diff,support_increase,Delta_CDE,2725,1177,0.784226779634175,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_026,abs_increase,spouse_score_diff,support_increase,TNIE,4028,1573,0.681076801266825,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_026,abs_increase,spouse_score_diff,support_increase,Delta_CDE,4028,1573,0.681076801266825,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_027,abs_diff_10k,spouse_score_diff,support_increase,TNIE,2875,1211,0.77236737925574,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_027,abs_diff_10k,spouse_score_diff,support_increase,Delta_CDE,2875,1211,0.77236737925574,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_028,abs_log1p_10k,spouse_score_diff,support_increase,TNIE,3119,1299,0.75304829770388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_028,abs_log1p_10k,spouse_score_diff,support_increase,Delta_CDE,3119,1299,0.75304829770388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_029,rel_transition_eligible,spouse_score_diff,support_increase,TNIE,2121,1024,0.724724205061648,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_029,rel_transition_eligible,spouse_score_diff,support_increase,Delta_CDE,2121,1024,0.724724205061648,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_030,rel_share_diff,spouse_score_diff,support_increase,TNIE,2698,1140,0.786381631037213,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_030,rel_share_diff,spouse_score_diff,support_increase,Delta_CDE,2698,1140,0.786381631037213,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_031,abs_increase,self_relative_transition,support_increase,TNIE,9879,2939,0,VALIDATED_B200,,0.999897340128608,0.994503219043267,1.00490568225602,0.945273631840796,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_031/ARTIFACT_VALIDATION.json
FEAS_031,abs_increase,self_relative_transition,support_increase,Delta_CDE,9879,2939,0,VALIDATED_B200,,-0.407543877675273,-0.650163593466548,-0.111230655651275,0.00497512437810945,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_031/ARTIFACT_VALIDATION.json
FEAS_032,abs_diff_10k,self_relative_transition,support_increase,TNIE,6477,2244,0.344366838748861,VALIDATED_B200,,1.00009567381561,0.997103421496641,1.00123991661925,0.781094527363184,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_032/ARTIFACT_VALIDATION.json
FEAS_032,abs_diff_10k,self_relative_transition,support_increase,Delta_CDE,6477,2244,0.344366838748861,VALIDATED_B200,,-0.021738152806251,-0.128680043529867,0.0297820853773862,0.567164179104478,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_032/ARTIFACT_VALIDATION.json
FEAS_033,abs_log1p_10k,self_relative_transition,support_increase,TNIE,7202,2424,0.270978844012552,VALIDATED_B200,,1.00031615194595,0.99659788470919,1.00146692872346,0.72636815920398,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_033/ARTIFACT_VALIDATION.json
FEAS_033,abs_log1p_10k,self_relative_transition,support_increase,Delta_CDE,7202,2424,0.270978844012552,VALIDATED_B200,,-0.0748871091459815,-0.216076715941036,0.0768545691147093,0.318407960199005,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_033/ARTIFACT_VALIDATION.json
FEAS_034,rel_transition_eligible,self_relative_transition,support_increase,TNIE,6331,2397,0,VALIDATED_B200,,0.998859226145322,0.988963256922449,1.00451038818492,0.671641791044776,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_034/ARTIFACT_VALIDATION.json
FEAS_034,rel_transition_eligible,self_relative_transition,support_increase,Delta_CDE,6331,2397,0,VALIDATED_B200,,-0.274214712007085,-0.673338202449183,0.277295228644705,0.174129353233831,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_034/ARTIFACT_VALIDATION.json
FEAS_035,rel_share_diff,self_relative_transition,support_increase,TNIE,6766,2235,0.315112865674663,VALIDATED_B200,,1.00011574725557,0.998419355167071,1.00154057097561,0.711442786069652,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_035/ARTIFACT_VALIDATION.json
FEAS_035,rel_share_diff,self_relative_transition,support_increase,Delta_CDE,6766,2235,0.315112865674663,VALIDATED_B200,,-0.0292938736578965,-0.163689450405845,0.122283963908696,0.616915422885572,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_035/ARTIFACT_VALIDATION.json
FEAS_036,abs_increase,spouse_relative_transition,support_increase,TNIE,9804,2895,0,VALIDATED_B200,,0.999901112956538,0.994814856442338,1.00805423039935,0.970149253731343,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_036/ARTIFACT_VALIDATION.json
FEAS_036,abs_increase,spouse_relative_transition,support_increase,Delta_CDE,9804,2895,0,VALIDATED_B200,,0.393272551770349,0.0533009442100788,0.919340801437653,0.0746268656716418,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_recovery_v1/FEAS_036/ARTIFACT_VALIDATION.json
FEAS_037,abs_diff_10k,spouse_relative_transition,support_increase,TNIE,6654,2276,0.321297429620563,VALIDATED_B200,,0.999667582381046,0.997941394472432,1.00158518438154,0.686567164179104,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_037/ARTIFACT_VALIDATION.json
FEAS_037,abs_diff_10k,spouse_relative_transition,support_increase,Delta_CDE,6654,2276,0.321297429620563,VALIDATED_B200,,0.0220880253272766,-0.0483913249343684,0.129434103541189,0.641791044776119,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_037/ARTIFACT_VALIDATION.json
FEAS_038,abs_log1p_10k,spouse_relative_transition,support_increase,TNIE,7342,2439,0.251121991024072,VALIDATED_B200,,0.999751027109599,0.998138683404013,1.00256167802796,0.661691542288557,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_038/ARTIFACT_VALIDATION.json
FEAS_038,abs_log1p_10k,spouse_relative_transition,support_increase,Delta_CDE,7342,2439,0.251121991024072,VALIDATED_B200,,-0.00350956629416177,-0.138880808333529,0.216239793815378,0.960199004975124,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch02/FEAS_038/ARTIFACT_VALIDATION.json
FEAS_039,rel_transition_eligible,spouse_relative_transition,support_increase,TNIE,5757,2221,0,VALIDATED_B200,,1.0017913696009,0.992999636673526,1.02574720210841,0.671641791044776,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_039/ARTIFACT_VALIDATION.json
FEAS_039,rel_transition_eligible,spouse_relative_transition,support_increase,Delta_CDE,5757,2221,0,VALIDATED_B200,,0.0521795734818999,-0.35102866228703,0.79859631617692,0.81592039800995,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_039/ARTIFACT_VALIDATION.json
FEAS_040,rel_share_diff,spouse_relative_transition,support_increase,TNIE,6735,2212,0.313035495716034,VALIDATED_B200,,1.00003272565871,0.998480021770101,1.00189756153659,0.90547263681592,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_040/ARTIFACT_VALIDATION.json
FEAS_040,rel_share_diff,spouse_relative_transition,support_increase,Delta_CDE,6735,2212,0.313035495716034,VALIDATED_B200,,-0.002952264580661,-0.112096027269637,0.145576207848121,0.975124378109453,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch03_recovery_v1/FEAS_040/ARTIFACT_VALIDATION.json
FEAS_041,abs_increase,self_relative_gap_diff,support_increase,TNIE,12564,3149,0.00483168316831683,VALIDATED_B200,,1.00039757007382,0.998363047116144,1.00304492613615,0.671641791044776,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_041/ARTIFACT_VALIDATION.json
FEAS_041,abs_increase,self_relative_gap_diff,support_increase,Delta_CDE,12564,3149,0.00483168316831683,VALIDATED_B200,,-0.0858683431318368,-0.172048351550989,-0.0184003563091187,0.0398009950248756,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_041/ARTIFACT_VALIDATION.json
FEAS_042,abs_diff_10k,self_relative_gap_diff,support_increase,TNIE,8417,2538,0.333306930693069,VALIDATED_B200,,0.999912724184133,0.99945299871742,1.00027408272071,0.587064676616915,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_042/ARTIFACT_VALIDATION.json
FEAS_042,abs_diff_10k,self_relative_gap_diff,support_increase,Delta_CDE,8417,2538,0.333306930693069,VALIDATED_B200,,0.00781539497032946,-0.0151166330409588,0.0284560280053812,0.512437810945274,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_042/ARTIFACT_VALIDATION.json
FEAS_043,abs_log1p_10k,self_relative_gap_diff,support_increase,TNIE,9295,2701,0.263762376237624,VALIDATED_B200,,0.999953946036928,0.999100370994302,1.0007312181633,0.825870646766169,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_043/ARTIFACT_VALIDATION.json
FEAS_043,abs_log1p_10k,self_relative_gap_diff,support_increase,Delta_CDE,9295,2701,0.263762376237624,VALIDATED_B200,,0.0131005058216935,-0.0329427956825387,0.0473400692631412,0.517412935323383,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_043/ARTIFACT_VALIDATION.json
FEAS_044,rel_transition_eligible,self_relative_gap_diff,support_increase,TNIE,7668,2658,0.00428515777171796,VALIDATED_B200,,1.00036130701672,0.995326318281655,1.01015465214452,0.796019900497512,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_044/ARTIFACT_VALIDATION.json
FEAS_044,rel_transition_eligible,self_relative_gap_diff,support_increase,Delta_CDE,7668,2658,0.00428515777171796,VALIDATED_B200,,-0.0228178770088907,-0.151968268039254,0.0931421195833785,0.736318407960199,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch01/FEAS_044/ARTIFACT_VALIDATION.json
FEAS_045,rel_share_diff,self_relative_gap_diff,support_increase,TNIE,8589,2433,0.319683168316832,VALIDATED_B200,,0.999803438204307,0.998217656958779,1.00089535003501,0.706467661691542,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_045/ARTIFACT_VALIDATION.json
FEAS_045,rel_share_diff,self_relative_gap_diff,support_increase,Delta_CDE,8589,2433,0.319683168316832,VALIDATED_B200,,0.0111281739045919,-0.0282709553890356,0.0485703208597417,0.601990049751244,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_045/ARTIFACT_VALIDATION.json
FEAS_046,abs_increase,spouse_relative_gap_diff,support_increase,TNIE,12564,3149,0.00483168316831683,VALIDATED_B200,,1.00039760423648,0.998363088539944,1.00304519811154,0.671641791044776,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_046/ARTIFACT_VALIDATION.json
FEAS_046,abs_increase,spouse_relative_gap_diff,support_increase,Delta_CDE,12564,3149,0.00483168316831683,VALIDATED_B200,,-0.0858683431318368,-0.172048351550989,-0.0184003563091187,0.0398009950248756,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_046/ARTIFACT_VALIDATION.json
FEAS_047,abs_diff_10k,spouse_relative_gap_diff,support_increase,TNIE,8417,2538,0.333306930693069,VALIDATED_B200,,0.999912732127567,0.99945291497052,1.00027410677879,0.587064676616915,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_047/ARTIFACT_VALIDATION.json
FEAS_047,abs_diff_10k,spouse_relative_gap_diff,support_increase,Delta_CDE,8417,2538,0.333306930693069,VALIDATED_B200,,0.00781539497032946,-0.0151166330409588,0.0284560280053812,0.512437810945274,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_047/ARTIFACT_VALIDATION.json
FEAS_048,abs_log1p_10k,spouse_relative_gap_diff,support_increase,TNIE,9295,2701,0.263762376237624,VALIDATED_B200,,0.9999539450726,0.999100504699076,1.00073101179434,0.825870646766169,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_048/ARTIFACT_VALIDATION.json
FEAS_048,abs_log1p_10k,spouse_relative_gap_diff,support_increase,Delta_CDE,9295,2701,0.263762376237624,VALIDATED_B200,,0.0131005058216935,-0.0329427956825387,0.0473400692631412,0.517412935323383,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch02/FEAS_048/ARTIFACT_VALIDATION.json
FEAS_049,rel_transition_eligible,spouse_relative_gap_diff,support_increase,TNIE,7668,2658,0.00428515777171796,VALIDATED_B200,,1.00036130774652,0.995326844491501,1.01015478092626,0.796019900497512,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_049/ARTIFACT_VALIDATION.json
FEAS_049,rel_transition_eligible,spouse_relative_gap_diff,support_increase,Delta_CDE,7668,2658,0.00428515777171796,VALIDATED_B200,,-0.0228178770088907,-0.151968268039254,0.0931421195833785,0.736318407960199,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_049/ARTIFACT_VALIDATION.json
FEAS_050,rel_share_diff,spouse_relative_gap_diff,support_increase,TNIE,8589,2433,0.319683168316832,VALIDATED_B200,,0.999803446398291,0.998217377548458,1.00089537219037,0.706467661691542,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_050/ARTIFACT_VALIDATION.json
FEAS_050,rel_share_diff,spouse_relative_gap_diff,support_increase,Delta_CDE,8589,2433,0.319683168316832,VALIDATED_B200,,0.0111281739045919,-0.0282709553890356,0.0485703208597417,0.601990049751244,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_050/ARTIFACT_VALIDATION.json
FEAS_051,abs_increase,self_increase_eligible,support_diff_10k,TNIE,4096,1641,0,VALIDATED_B200,,-1.49571422991069e-05,-0.000117740066340064,0.000190439903227241,0.766169154228856,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_051/ARTIFACT_VALIDATION.json
FEAS_051,abs_increase,self_increase_eligible,support_diff_10k,Delta_CDE,4096,1641,0,VALIDATED_B200,,0.00164584545683975,-0.00678302170735751,0.00899173803919628,0.681592039800995,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_051/ARTIFACT_VALIDATION.json
FEAS_052,abs_diff_10k,self_increase_eligible,support_diff_10k,TNIE,2733,1175,0.332763671875,VALIDATED_B200,,-2.65723616737539e-05,-0.000140795754265537,0.000117171277734059,0.616915422885572,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_052/ARTIFACT_VALIDATION.json
FEAS_052,abs_diff_10k,self_increase_eligible,support_diff_10k,Delta_CDE,2733,1175,0.332763671875,VALIDATED_B200,,-0.00731737607794317,-0.0132526392752558,0.00280272682930895,0.27363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_052/ARTIFACT_VALIDATION.json
FEAS_053,abs_log1p_10k,self_increase_eligible,support_diff_10k,TNIE,2991,1277,0.269775390625,VALIDATED_B200,,1.62786723787562e-05,-6.96250516212974e-05,8.8459987541607e-05,0.691542288557214,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_053/ARTIFACT_VALIDATION.json
FEAS_053,abs_log1p_10k,self_increase_eligible,support_diff_10k,Delta_CDE,2991,1277,0.269775390625,VALIDATED_B200,,0.000119889368053935,-0.00472658841238002,0.00421886843858436,0.955223880597015,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_053/ARTIFACT_VALIDATION.json
FEAS_054,rel_transition_eligible,self_increase_eligible,support_diff_10k,TNIE,2654,1248,0,VALIDATED_B200,,-7.960114133397e-05,-0.000441412182090075,0.000421045693778187,0.671641791044776,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_054/ARTIFACT_VALIDATION.json
FEAS_054,rel_transition_eligible,self_increase_eligible,support_diff_10k,Delta_CDE,2654,1248,0,VALIDATED_B200,,0.00276417248132148,-0.00575071876877407,0.0108954881484454,0.562189054726368,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_054/ARTIFACT_VALIDATION.json
FEAS_055,rel_share_diff,self_increase_eligible,support_diff_10k,TNIE,2725,1177,0.334716796875,VALIDATED_B200,,-4.38308413513002e-06,-7.52608061625338e-05,6.75289138047097e-05,0.781094527363184,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_055/ARTIFACT_VALIDATION.json
FEAS_055,rel_share_diff,self_increase_eligible,support_diff_10k,Delta_CDE,2725,1177,0.334716796875,VALIDATED_B200,,0.00164333530037554,-0.00111521624160425,0.00420456224569934,0.258706467661692,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_055/ARTIFACT_VALIDATION.json
FEAS_056,abs_increase,spouse_increase_eligible,support_diff_10k,TNIE,4028,1573,0,VALIDATED_B200,,8.09266334726288e-06,-0.000145852604698334,0.00026951968741977,0.885572139303483,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_056/ARTIFACT_VALIDATION.json
FEAS_056,abs_increase,spouse_increase_eligible,support_diff_10k,Delta_CDE,4028,1573,0,VALIDATED_B200,,0.00682185654310922,-0.0024121484985904,0.0160895540818869,0.208955223880597,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_056/ARTIFACT_VALIDATION.json
FEAS_057,abs_diff_10k,spouse_increase_eligible,support_diff_10k,TNIE,2875,1211,0.286246276067527,VALIDATED_B200,,3.14640073503186e-05,-0.000133987683160027,0.000205531812588911,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_057/ARTIFACT_VALIDATION.json
FEAS_057,abs_diff_10k,spouse_increase_eligible,support_diff_10k,Delta_CDE,2875,1211,0.286246276067527,VALIDATED_B200,,-0.00638975929086576,-0.0135146433017593,0.00317040992670297,0.189054726368159,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_057/ARTIFACT_VALIDATION.json
FEAS_058,abs_log1p_10k,spouse_increase_eligible,support_diff_10k,TNIE,3119,1299,0.225670307845084,VALIDATED_B200,,1.98273379487142e-06,-0.000106262742332824,0.0001304985617695,0.920398009950249,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_058/ARTIFACT_VALIDATION.json
FEAS_058,abs_log1p_10k,spouse_increase_eligible,support_diff_10k,Delta_CDE,3119,1299,0.225670307845084,VALIDATED_B200,,-0.000374007243310152,-0.00646014377198255,0.00549075258354061,0.91044776119403,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_058/ARTIFACT_VALIDATION.json
FEAS_059,rel_transition_eligible,spouse_increase_eligible,support_diff_10k,TNIE,2121,1024,0,VALIDATED_B200,,1.73472347597681e-18,-0.000526430329499584,0.000292921160789596,1,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_059/ARTIFACT_VALIDATION.json
FEAS_059,rel_transition_eligible,spouse_increase_eligible,support_diff_10k,Delta_CDE,2121,1024,0,VALIDATED_B200,,-0.00104936466657083,-0.0136198076843157,0.00937230315376899,0.855721393034826,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_059/ARTIFACT_VALIDATION.json
FEAS_060,rel_share_diff,spouse_increase_eligible,support_diff_10k,TNIE,2698,1140,0.330188679245283,VALIDATED_B200,,2.78492817705515e-05,-0.000155122464104203,0.000116812530741024,0.587064676616915,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_060/ARTIFACT_VALIDATION.json
FEAS_060,rel_share_diff,spouse_increase_eligible,support_diff_10k,Delta_CDE,2698,1140,0.330188679245283,VALIDATED_B200,,-0.00211093093101893,-0.00555788005458585,0.00136887138133393,0.288557213930348,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch04/FEAS_060/ARTIFACT_VALIDATION.json
FEAS_061,abs_increase,self_increase_all,support_diff_10k,TNIE,4096,1641,0.675667115369388,VALIDATED_B200,,-1.49571422991069e-05,-0.000117740066340064,0.000190439903227241,0.766169154228856,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_061/ARTIFACT_VALIDATION.json
FEAS_061,abs_increase,self_increase_all,support_diff_10k,Delta_CDE,4096,1641,0.675667115369388,VALIDATED_B200,,0.00164584545683975,-0.00678302170735751,0.00899173803919628,0.681592039800995,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_061/ARTIFACT_VALIDATION.json
FEAS_062,abs_diff_10k,self_increase_all,support_diff_10k,TNIE,2733,1175,0.783593316968881,VALIDATED_B200,,-2.65723616737539e-05,-0.000140795754265537,0.000117171277734059,0.616915422885572,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_062/ARTIFACT_VALIDATION.json
FEAS_062,abs_diff_10k,self_increase_all,support_diff_10k,Delta_CDE,2733,1175,0.783593316968881,VALIDATED_B200,,-0.00731737607794317,-0.0132526392752558,0.00280272682930895,0.27363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_062/ARTIFACT_VALIDATION.json
FEAS_063,abs_log1p_10k,self_increase_all,support_diff_10k,TNIE,2991,1277,0.763164146013144,VALIDATED_B200,,1.62786723787562e-05,-6.96250516212974e-05,8.8459987541607e-05,0.691542288557214,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_063/ARTIFACT_VALIDATION.json
FEAS_063,abs_log1p_10k,self_increase_all,support_diff_10k,Delta_CDE,2991,1277,0.763164146013144,VALIDATED_B200,,0.000119889368053935,-0.00472658841238002,0.00421886843858436,0.955223880597015,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_063/ARTIFACT_VALIDATION.json
FEAS_064,rel_transition_eligible,self_increase_all,support_diff_10k,TNIE,2654,1248,0.655503634475597,VALIDATED_B200,,-7.960114133397e-05,-0.000441412182090075,0.000421045693778187,0.671641791044776,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_064/ARTIFACT_VALIDATION.json
FEAS_064,rel_transition_eligible,self_increase_all,support_diff_10k,Delta_CDE,2654,1248,0.655503634475597,VALIDATED_B200,,0.00276417248132148,-0.00575071876877407,0.0108954881484454,0.562189054726368,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_064/ARTIFACT_VALIDATION.json
FEAS_065,rel_share_diff,self_increase_all,support_diff_10k,TNIE,2725,1177,0.784226779634175,VALIDATED_B200,,-4.38308413513002e-06,-7.52608061625338e-05,6.75289138047097e-05,0.781094527363184,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_065/ARTIFACT_VALIDATION.json
FEAS_065,rel_share_diff,self_increase_all,support_diff_10k,Delta_CDE,2725,1177,0.784226779634175,VALIDATED_B200,,0.00164333530037554,-0.00111521624160425,0.00420456224569934,0.258706467661692,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_065/ARTIFACT_VALIDATION.json
FEAS_066,abs_increase,spouse_increase_all,support_diff_10k,TNIE,4028,1573,0.681076801266825,VALIDATED_B200,,8.09266334726288e-06,-0.000145852604698334,0.00026951968741977,0.885572139303483,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_066/ARTIFACT_VALIDATION.json
FEAS_066,abs_increase,spouse_increase_all,support_diff_10k,Delta_CDE,4028,1573,0.681076801266825,VALIDATED_B200,,0.00682185654310922,-0.0024121484985904,0.0160895540818869,0.208955223880597,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_066/ARTIFACT_VALIDATION.json
FEAS_067,abs_diff_10k,spouse_increase_all,support_diff_10k,TNIE,2875,1211,0.77236737925574,VALIDATED_B200,,3.14640073503186e-05,-0.000133987683160027,0.000205531812588911,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_067/ARTIFACT_VALIDATION.json
FEAS_067,abs_diff_10k,spouse_increase_all,support_diff_10k,Delta_CDE,2875,1211,0.77236737925574,VALIDATED_B200,,-0.00638975929086576,-0.0135146433017593,0.00317040992670297,0.189054726368159,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_067/ARTIFACT_VALIDATION.json
FEAS_068,abs_log1p_10k,spouse_increase_all,support_diff_10k,TNIE,3119,1299,0.75304829770388,VALIDATED_B200,,1.98273379487142e-06,-0.000106262742332824,0.0001304985617695,0.920398009950249,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_068/ARTIFACT_VALIDATION.json
FEAS_068,abs_log1p_10k,spouse_increase_all,support_diff_10k,Delta_CDE,3119,1299,0.75304829770388,VALIDATED_B200,,-0.000374007243310152,-0.00646014377198255,0.00549075258354061,0.91044776119403,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch03/FEAS_068/ARTIFACT_VALIDATION.json
FEAS_069,rel_transition_eligible,spouse_increase_all,support_diff_10k,TNIE,2121,1024,0.724724205061648,VALIDATED_B200,,1.73472347597681e-18,-0.000526430329499584,0.000292921160789596,1,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_069/ARTIFACT_VALIDATION.json
FEAS_069,rel_transition_eligible,spouse_increase_all,support_diff_10k,Delta_CDE,2121,1024,0.724724205061648,VALIDATED_B200,,-0.00104936466657083,-0.0136198076843157,0.00937230315376899,0.855721393034826,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_069/ARTIFACT_VALIDATION.json
FEAS_070,rel_share_diff,spouse_increase_all,support_diff_10k,TNIE,2698,1140,0.786381631037213,VALIDATED_B200,,2.78492817705515e-05,-0.000155122464104203,0.000116812530741024,0.587064676616915,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_070/ARTIFACT_VALIDATION.json
FEAS_070,rel_share_diff,spouse_increase_all,support_diff_10k,Delta_CDE,2698,1140,0.786381631037213,VALIDATED_B200,,-0.00211093093101893,-0.00555788005458585,0.00136887138133393,0.288557213930348,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch05/FEAS_070/ARTIFACT_VALIDATION.json
FEAS_071,abs_increase,self_score_diff,support_diff_10k,TNIE,4096,1641,0.675667115369388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_071,abs_increase,self_score_diff,support_diff_10k,Delta_CDE,4096,1641,0.675667115369388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_072,abs_diff_10k,self_score_diff,support_diff_10k,TNIE,2733,1175,0.783593316968881,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_072,abs_diff_10k,self_score_diff,support_diff_10k,Delta_CDE,2733,1175,0.783593316968881,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_073,abs_log1p_10k,self_score_diff,support_diff_10k,TNIE,2991,1277,0.763164146013144,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_073,abs_log1p_10k,self_score_diff,support_diff_10k,Delta_CDE,2991,1277,0.763164146013144,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_074,rel_transition_eligible,self_score_diff,support_diff_10k,TNIE,2654,1248,0.655503634475597,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_074,rel_transition_eligible,self_score_diff,support_diff_10k,Delta_CDE,2654,1248,0.655503634475597,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_075,rel_share_diff,self_score_diff,support_diff_10k,TNIE,2725,1177,0.784226779634175,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_075,rel_share_diff,self_score_diff,support_diff_10k,Delta_CDE,2725,1177,0.784226779634175,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_076,abs_increase,spouse_score_diff,support_diff_10k,TNIE,4028,1573,0.681076801266825,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_076,abs_increase,spouse_score_diff,support_diff_10k,Delta_CDE,4028,1573,0.681076801266825,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_077,abs_diff_10k,spouse_score_diff,support_diff_10k,TNIE,2875,1211,0.77236737925574,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_077,abs_diff_10k,spouse_score_diff,support_diff_10k,Delta_CDE,2875,1211,0.77236737925574,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_078,abs_log1p_10k,spouse_score_diff,support_diff_10k,TNIE,3119,1299,0.75304829770388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_078,abs_log1p_10k,spouse_score_diff,support_diff_10k,Delta_CDE,3119,1299,0.75304829770388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_079,rel_transition_eligible,spouse_score_diff,support_diff_10k,TNIE,2121,1024,0.724724205061648,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_079,rel_transition_eligible,spouse_score_diff,support_diff_10k,Delta_CDE,2121,1024,0.724724205061648,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_080,rel_share_diff,spouse_score_diff,support_diff_10k,TNIE,2698,1140,0.786381631037213,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_080,rel_share_diff,spouse_score_diff,support_diff_10k,Delta_CDE,2698,1140,0.786381631037213,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_081,abs_increase,self_relative_transition,support_diff_10k,TNIE,9879,2939,0,VALIDATED_B200,,9.28132553768175e-08,-7.14574701531119e-05,7.70053006927728e-05,1,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_081/ARTIFACT_VALIDATION.json
FEAS_081,abs_increase,self_relative_transition,support_diff_10k,Delta_CDE,9879,2939,0,VALIDATED_B200,,-0.0019589279849601,-0.00974808458210112,0.00620406795455049,0.567164179104478,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_081/ARTIFACT_VALIDATION.json
FEAS_082,abs_diff_10k,self_relative_transition,support_diff_10k,TNIE,6477,2244,0.344366838748861,VALIDATED_B200,,-2.07427488871413e-06,-6.90334997598464e-05,8.41415177882374e-05,0.900497512437811,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_082/ARTIFACT_VALIDATION.json
FEAS_082,abs_diff_10k,self_relative_transition,support_diff_10k,Delta_CDE,6477,2244,0.344366838748861,VALIDATED_B200,,0.000461531251214261,-0.00904358859416265,0.0054878152231261,0.855721393034826,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_082/ARTIFACT_VALIDATION.json
FEAS_083,abs_log1p_10k,self_relative_transition,support_diff_10k,TNIE,7202,2424,0.270978844012552,VALIDATED_B200,,-1.55231947765034e-05,-0.000105246159567314,0.000147956252312714,0.711442786069652,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_083/ARTIFACT_VALIDATION.json
FEAS_083,abs_log1p_10k,self_relative_transition,support_diff_10k,Delta_CDE,7202,2424,0.270978844012552,VALIDATED_B200,,0.000570730063953476,-0.0076787463360293,0.0108635578698843,0.870646766169154,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_083/ARTIFACT_VALIDATION.json
FEAS_084,rel_transition_eligible,self_relative_transition,support_diff_10k,TNIE,6331,2397,0,VALIDATED_B200,,-2.89156269259227e-06,-0.000127493973739028,9.04199213628764e-05,0.860696517412935,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_084/ARTIFACT_VALIDATION.json
FEAS_084,rel_transition_eligible,self_relative_transition,support_diff_10k,Delta_CDE,6331,2397,0,VALIDATED_B200,,0.000519520219443343,-0.00730290023553527,0.00883385996201896,0.900497512437811,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_084/ARTIFACT_VALIDATION.json
FEAS_085,rel_share_diff,self_relative_transition,support_diff_10k,TNIE,6766,2235,0.315112865674663,VALIDATED_B200,,-8.25725028200932e-06,-4.99203557487451e-05,4.59813200164279e-05,0.716417910447761,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_085/ARTIFACT_VALIDATION.json
FEAS_085,rel_share_diff,self_relative_transition,support_diff_10k,Delta_CDE,6766,2235,0.315112865674663,VALIDATED_B200,,-0.000618796514284415,-0.00473218175047854,0.00308617046061908,0.751243781094527,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_085/ARTIFACT_VALIDATION.json
FEAS_086,abs_increase,spouse_relative_transition,support_diff_10k,TNIE,9804,2895,0,VALIDATED_B200,,1.53177854020706e-07,-6.23747616012752e-05,6.16288799605648e-05,0.990049751243781,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_086/ARTIFACT_VALIDATION.json
FEAS_086,abs_increase,spouse_relative_transition,support_diff_10k,Delta_CDE,9804,2895,0,VALIDATED_B200,,-0.00110592650504213,-0.00755673234207533,0.00500893834404055,0.796019900497512,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch02/FEAS_086/ARTIFACT_VALIDATION.json
FEAS_087,abs_diff_10k,spouse_relative_transition,support_diff_10k,TNIE,6654,2276,0.321297429620563,VALIDATED_B200,,-3.56375183488758e-06,-4.83357873090429e-05,6.27612836883999e-05,0.810945273631841,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_087/ARTIFACT_VALIDATION.json
FEAS_087,abs_diff_10k,spouse_relative_transition,support_diff_10k,Delta_CDE,6654,2276,0.321297429620563,VALIDATED_B200,,0.000395548234308586,-0.00475593275062577,0.00783402553670737,0.895522388059702,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_087/ARTIFACT_VALIDATION.json
FEAS_088,abs_log1p_10k,spouse_relative_transition,support_diff_10k,TNIE,7342,2439,0.251121991024072,VALIDATED_B200,,4.0714856435857e-06,-3.98796857411487e-05,5.98365370820659e-05,0.72636815920398,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_088/ARTIFACT_VALIDATION.json
FEAS_088,abs_log1p_10k,spouse_relative_transition,support_diff_10k,Delta_CDE,7342,2439,0.251121991024072,VALIDATED_B200,,-0.00170960664810543,-0.00577001351460685,0.00244602251672305,0.3681592039801,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_088/ARTIFACT_VALIDATION.json
FEAS_089,rel_transition_eligible,spouse_relative_transition,support_diff_10k,TNIE,5757,2221,0,VALIDATED_B200,,4.09025518469976e-07,-0.00020934079464055,0.00023951162739583,0.980099502487562,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_089/ARTIFACT_VALIDATION.json
FEAS_089,rel_transition_eligible,spouse_relative_transition,support_diff_10k,Delta_CDE,5757,2221,0,VALIDATED_B200,,1.1113265862059e-05,-0.00615340451683421,0.00648425174658608,1,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_089/ARTIFACT_VALIDATION.json
FEAS_090,rel_share_diff,spouse_relative_transition,support_diff_10k,TNIE,6735,2212,0.313035495716034,VALIDATED_B200,,-8.94800195419022e-07,-3.53648166839268e-05,3.81209372622648e-05,0.865671641791045,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_090/ARTIFACT_VALIDATION.json
FEAS_090,rel_share_diff,spouse_relative_transition,support_diff_10k,Delta_CDE,6735,2212,0.313035495716034,VALIDATED_B200,,-0.00165546262612514,-0.00392841342887939,0.000943247917882959,0.278606965174129,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch06/FEAS_090/ARTIFACT_VALIDATION.json
FEAS_091,abs_increase,self_relative_gap_diff,support_diff_10k,TNIE,12564,3149,0.00483168316831683,VALIDATED_B200,,-8.63397740420019e-06,-6.76303011360333e-05,3.4780797515467e-05,0.656716417910448,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_091/ARTIFACT_VALIDATION.json
FEAS_091,abs_increase,self_relative_gap_diff,support_diff_10k,Delta_CDE,12564,3149,0.00483168316831683,VALIDATED_B200,,0.00119511094956369,-0.0003936355176407,0.00270146247256952,0.134328358208955,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_091/ARTIFACT_VALIDATION.json
FEAS_092,abs_diff_10k,self_relative_gap_diff,support_diff_10k,TNIE,8417,2538,0.333306930693069,VALIDATED_B200,,8.15149865572898e-06,-4.83174332524064e-06,2.25566913020328e-05,0.333333333333333,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_092/ARTIFACT_VALIDATION.json
FEAS_092,abs_diff_10k,self_relative_gap_diff,support_diff_10k,Delta_CDE,8417,2538,0.333306930693069,VALIDATED_B200,,0.00163978611964366,-0.00091177478240594,0.002954592949426,0.223880597014925,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch03/FEAS_092/ARTIFACT_VALIDATION.json
FEAS_093,abs_log1p_10k,self_relative_gap_diff,support_diff_10k,TNIE,9295,2701,0.263762376237624,VALIDATED_B200,,-6.65048351909756e-06,-4.0340399802402e-05,3.03071987873283e-05,0.626865671641791,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_093/ARTIFACT_VALIDATION.json
FEAS_093,abs_log1p_10k,self_relative_gap_diff,support_diff_10k,Delta_CDE,9295,2701,0.263762376237624,VALIDATED_B200,,0.00106641608536052,-0.000250584999960856,0.00204685816584553,0.104477611940299,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_093/ARTIFACT_VALIDATION.json
FEAS_094,rel_transition_eligible,self_relative_gap_diff,support_diff_10k,TNIE,7668,2658,0.00428515777171796,VALIDATED_B200,,-9.66010798645212e-06,-0.000131332637055524,7.56810440052108e-05,0.791044776119403,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_094/ARTIFACT_VALIDATION.json
FEAS_094,rel_transition_eligible,self_relative_gap_diff,support_diff_10k,Delta_CDE,7668,2658,0.00428515777171796,VALIDATED_B200,,0.000135825141528741,-0.00205888186825451,0.00250077116614314,0.920398009950249,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_094/ARTIFACT_VALIDATION.json
FEAS_095,rel_share_diff,self_relative_gap_diff,support_diff_10k,TNIE,8589,2433,0.319683168316832,VALIDATED_B200,,-2.41238201147131e-06,-2.62624447570071e-05,1.99839634480306e-05,0.736318407960199,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_095/ARTIFACT_VALIDATION.json
FEAS_095,rel_share_diff,self_relative_gap_diff,support_diff_10k,Delta_CDE,8589,2433,0.319683168316832,VALIDATED_B200,,0.000536484605063323,-0.000337325305431354,0.00131052481920675,0.248756218905473,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_095/ARTIFACT_VALIDATION.json
FEAS_096,abs_increase,spouse_relative_gap_diff,support_diff_10k,TNIE,12564,3149,0.00483168316831683,VALIDATED_B200,,-8.63397740419065e-06,-6.76303011360429e-05,3.47807975154721e-05,0.656716417910448,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_096/ARTIFACT_VALIDATION.json
FEAS_096,abs_increase,spouse_relative_gap_diff,support_diff_10k,Delta_CDE,12564,3149,0.00483168316831683,VALIDATED_B200,,0.00119511094956369,-0.0003936355176407,0.00270146247256952,0.134328358208955,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch04/FEAS_096/ARTIFACT_VALIDATION.json
FEAS_097,abs_diff_10k,spouse_relative_gap_diff,support_diff_10k,TNIE,8417,2538,0.333306930693069,VALIDATED_B200,,8.15149865572963e-06,-4.83174332526214e-06,2.25566913020349e-05,0.333333333333333,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_097/ARTIFACT_VALIDATION.json
FEAS_097,abs_diff_10k,spouse_relative_gap_diff,support_diff_10k,Delta_CDE,8417,2538,0.333306930693069,VALIDATED_B200,,0.00163978611964366,-0.00091177478240594,0.002954592949426,0.223880597014925,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_097/ARTIFACT_VALIDATION.json
FEAS_098,abs_log1p_10k,spouse_relative_gap_diff,support_diff_10k,TNIE,9295,2701,0.263762376237624,VALIDATED_B200,,-6.65048351909323e-06,-4.03403998023768e-05,3.030719878731e-05,0.626865671641791,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_098/ARTIFACT_VALIDATION.json
FEAS_098,abs_log1p_10k,spouse_relative_gap_diff,support_diff_10k,Delta_CDE,9295,2701,0.263762376237624,VALIDATED_B200,,0.00106641608536052,-0.000250584999960856,0.00204685816584553,0.104477611940299,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_098/ARTIFACT_VALIDATION.json
FEAS_099,rel_transition_eligible,spouse_relative_gap_diff,support_diff_10k,TNIE,7668,2658,0.00428515777171796,VALIDATED_B200,,-9.66010798642437e-06,-0.000131332637055517,7.5681044005241e-05,0.791044776119403,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_099/ARTIFACT_VALIDATION.json
FEAS_099,rel_transition_eligible,spouse_relative_gap_diff,support_diff_10k,Delta_CDE,7668,2658,0.00428515777171796,VALIDATED_B200,,0.000135825141528741,-0.00205888186825451,0.00250077116614314,0.920398009950249,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_099/ARTIFACT_VALIDATION.json
FEAS_100,rel_share_diff,spouse_relative_gap_diff,support_diff_10k,TNIE,8589,2433,0.319683168316832,VALIDATED_B200,,-2.41238201147066e-06,-2.6262444757002e-05,1.99839634480323e-05,0.736318407960199,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_100/ARTIFACT_VALIDATION.json
FEAS_100,rel_share_diff,spouse_relative_gap_diff,support_diff_10k,Delta_CDE,8589,2433,0.319683168316832,VALIDATED_B200,,0.000536484605063323,-0.000337325305431354,0.00131052481920675,0.248756218905473,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch05/FEAS_100/ARTIFACT_VALIDATION.json
FEAS_101,abs_increase,self_increase_eligible,support_log1p_10k,TNIE,4096,1641,0,VALIDATED_B200,,-1.46409953237234e-05,-0.000109337092783018,0.000173123145625223,0.766169154228856,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_101/ARTIFACT_VALIDATION.json
FEAS_101,abs_increase,self_increase_eligible,support_log1p_10k,Delta_CDE,4096,1641,0,VALIDATED_B200,,0.00219181922864152,-0.00480589184245992,0.00807485261088757,0.45771144278607,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_101/ARTIFACT_VALIDATION.json
FEAS_102,abs_diff_10k,self_increase_eligible,support_log1p_10k,TNIE,2733,1175,0.332763671875,VALIDATED_B200,,-2.17633963733696e-05,-0.000119053465894088,8.54996310166337e-05,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_102/ARTIFACT_VALIDATION.json
FEAS_102,abs_diff_10k,self_increase_eligible,support_log1p_10k,Delta_CDE,2733,1175,0.332763671875,VALIDATED_B200,,-0.0055812817307429,-0.0101989707152627,0.00233717452724886,0.27363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_102/ARTIFACT_VALIDATION.json
FEAS_103,abs_log1p_10k,self_increase_eligible,support_log1p_10k,TNIE,2991,1277,0.269775390625,VALIDATED_B200,,1.34251228091028e-05,-6.12591264287965e-05,8.0698087997825e-05,0.691542288557214,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_103/ARTIFACT_VALIDATION.json
FEAS_103,abs_log1p_10k,self_increase_eligible,support_log1p_10k,Delta_CDE,2991,1277,0.269775390625,VALIDATED_B200,,0.000384261840393235,-0.0033259209392133,0.0038279790517778,0.810945273631841,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_103/ARTIFACT_VALIDATION.json
FEAS_104,rel_transition_eligible,self_increase_eligible,support_log1p_10k,TNIE,2654,1248,0,VALIDATED_B200,,-8.19409065966007e-05,-0.000425630192080791,0.000377938583023779,0.616915422885572,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_104/ARTIFACT_VALIDATION.json
FEAS_104,rel_transition_eligible,self_increase_eligible,support_log1p_10k,Delta_CDE,2654,1248,0,VALIDATED_B200,,0.00266616673917405,-0.00480506590549169,0.00981545802491494,0.527363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_104/ARTIFACT_VALIDATION.json
FEAS_105,rel_share_diff,self_increase_eligible,support_log1p_10k,TNIE,2725,1177,0.334716796875,VALIDATED_B200,,-3.59314352789538e-06,-7.00914734524957e-05,6.9943139437598e-05,0.796019900497512,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_105/ARTIFACT_VALIDATION.json
FEAS_105,rel_share_diff,self_increase_eligible,support_log1p_10k,Delta_CDE,2725,1177,0.334716796875,VALIDATED_B200,,0.00160609796187178,-0.00069455375356325,0.00375264477973718,0.194029850746269,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_105/ARTIFACT_VALIDATION.json
FEAS_106,abs_increase,spouse_increase_eligible,support_log1p_10k,TNIE,4028,1573,0,VALIDATED_B200,,4.71079649374965e-06,-0.0001063981236615,0.000180855345354586,0.875621890547264,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_106/ARTIFACT_VALIDATION.json
FEAS_106,abs_increase,spouse_increase_eligible,support_log1p_10k,Delta_CDE,4028,1573,0,VALIDATED_B200,,0.00456018071586679,-0.00183038871146053,0.01049834610345,0.164179104477612,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_remaining_B200_v1/FEAS_106/ARTIFACT_VALIDATION.json
FEAS_107,abs_diff_10k,spouse_increase_eligible,support_log1p_10k,TNIE,2875,1211,0.286246276067527,VALIDATED_B200,,3.24705892752951e-05,-0.000120032883031423,0.000161865246290744,0.567164179104478,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_107/ARTIFACT_VALIDATION.json
FEAS_107,abs_diff_10k,spouse_increase_eligible,support_log1p_10k,Delta_CDE,2875,1211,0.286246276067527,VALIDATED_B200,,-0.00536692247963753,-0.0109875309664207,0.00111791705992996,0.124378109452736,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_107/ARTIFACT_VALIDATION.json
FEAS_108,abs_log1p_10k,spouse_increase_eligible,support_log1p_10k,TNIE,3119,1299,0.225670307845084,VALIDATED_B200,,-4.68705077018381e-06,-8.73711578870661e-05,8.80948614432273e-05,0.870646766169154,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_108/ARTIFACT_VALIDATION.json
FEAS_108,abs_log1p_10k,spouse_increase_eligible,support_log1p_10k,Delta_CDE,3119,1299,0.225670307845084,VALIDATED_B200,,-0.00114770789866038,-0.00557249430634418,0.00243259981240983,0.552238805970149,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch04/FEAS_108/ARTIFACT_VALIDATION.json
FEAS_109,rel_transition_eligible,spouse_increase_eligible,support_log1p_10k,TNIE,2121,1024,0,VALIDATED_B200,,4.33680868994202e-18,-0.000399189556967431,0.0002771454706784,1,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_109/ARTIFACT_VALIDATION.json
FEAS_109,rel_transition_eligible,spouse_increase_eligible,support_log1p_10k,Delta_CDE,2121,1024,0,VALIDATED_B200,,0.000288457431462536,-0.0101934508864225,0.00893224873025692,0.945273631840796,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_109/ARTIFACT_VALIDATION.json
FEAS_110,rel_share_diff,spouse_increase_eligible,support_log1p_10k,TNIE,2698,1140,0.330188679245283,VALIDATED_B200,,2.209359075214e-05,-0.000126941520557319,9.97652199717014e-05,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_110/ARTIFACT_VALIDATION.json
FEAS_110,rel_share_diff,spouse_increase_eligible,support_log1p_10k,Delta_CDE,2698,1140,0.330188679245283,VALIDATED_B200,,-0.0015794527393999,-0.00468970825805357,0.00126654285779129,0.348258706467662,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch07/FEAS_110/ARTIFACT_VALIDATION.json
FEAS_111,abs_increase,self_increase_all,support_log1p_10k,TNIE,4096,1641,0.675667115369388,VALIDATED_B200,,-1.46409953237234e-05,-0.000109337092783018,0.000173123145625223,0.766169154228856,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_111/ARTIFACT_VALIDATION.json
FEAS_111,abs_increase,self_increase_all,support_log1p_10k,Delta_CDE,4096,1641,0.675667115369388,VALIDATED_B200,,0.00219181922864152,-0.00480589184245992,0.00807485261088757,0.45771144278607,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_111/ARTIFACT_VALIDATION.json
FEAS_112,abs_diff_10k,self_increase_all,support_log1p_10k,TNIE,2733,1175,0.783593316968881,VALIDATED_B200,,-2.17633963733696e-05,-0.000119053465894088,8.54996310166337e-05,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_112/ARTIFACT_VALIDATION.json
FEAS_112,abs_diff_10k,self_increase_all,support_log1p_10k,Delta_CDE,2733,1175,0.783593316968881,VALIDATED_B200,,-0.0055812817307429,-0.0101989707152627,0.00233717452724886,0.27363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_112/ARTIFACT_VALIDATION.json
FEAS_113,abs_log1p_10k,self_increase_all,support_log1p_10k,TNIE,2991,1277,0.763164146013144,VALIDATED_B200,,1.34251228091028e-05,-6.12591264287965e-05,8.0698087997825e-05,0.691542288557214,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_113/ARTIFACT_VALIDATION.json
FEAS_113,abs_log1p_10k,self_increase_all,support_log1p_10k,Delta_CDE,2991,1277,0.763164146013144,VALIDATED_B200,,0.000384261840393235,-0.0033259209392133,0.0038279790517778,0.810945273631841,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_113/ARTIFACT_VALIDATION.json
FEAS_114,rel_transition_eligible,self_increase_all,support_log1p_10k,TNIE,2654,1248,0.655503634475597,VALIDATED_B200,,-8.19409065966007e-05,-0.000425630192080791,0.000377938583023779,0.616915422885572,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_114/ARTIFACT_VALIDATION.json
FEAS_114,rel_transition_eligible,self_increase_all,support_log1p_10k,Delta_CDE,2654,1248,0.655503634475597,VALIDATED_B200,,0.00266616673917405,-0.00480506590549169,0.00981545802491494,0.527363184079602,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_114/ARTIFACT_VALIDATION.json
FEAS_115,rel_share_diff,self_increase_all,support_log1p_10k,TNIE,2725,1177,0.784226779634175,VALIDATED_B200,,-3.59314352789538e-06,-7.00914734524957e-05,6.9943139437598e-05,0.796019900497512,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_115/ARTIFACT_VALIDATION.json
FEAS_115,rel_share_diff,self_increase_all,support_log1p_10k,Delta_CDE,2725,1177,0.784226779634175,VALIDATED_B200,,0.00160609796187178,-0.00069455375356325,0.00375264477973718,0.194029850746269,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_115/ARTIFACT_VALIDATION.json
FEAS_116,abs_increase,spouse_increase_all,support_log1p_10k,TNIE,4028,1573,0.681076801266825,VALIDATED_B200,,4.71079649374965e-06,-0.0001063981236615,0.000180855345354586,0.875621890547264,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_116/ARTIFACT_VALIDATION.json
FEAS_116,abs_increase,spouse_increase_all,support_log1p_10k,Delta_CDE,4028,1573,0.681076801266825,VALIDATED_B200,,0.00456018071586679,-0.00183038871146053,0.01049834610345,0.164179104477612,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_116/ARTIFACT_VALIDATION.json
FEAS_117,abs_diff_10k,spouse_increase_all,support_log1p_10k,TNIE,2875,1211,0.77236737925574,VALIDATED_B200,,3.24705892752951e-05,-0.000120032883031423,0.000161865246290744,0.567164179104478,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_117/ARTIFACT_VALIDATION.json
FEAS_117,abs_diff_10k,spouse_increase_all,support_log1p_10k,Delta_CDE,2875,1211,0.77236737925574,VALIDATED_B200,,-0.00536692247963753,-0.0109875309664207,0.00111791705992996,0.124378109452736,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_117/ARTIFACT_VALIDATION.json
FEAS_118,abs_log1p_10k,spouse_increase_all,support_log1p_10k,TNIE,3119,1299,0.75304829770388,VALIDATED_B200,,-4.68705077018381e-06,-8.73711578870661e-05,8.80948614432273e-05,0.870646766169154,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_118/ARTIFACT_VALIDATION.json
FEAS_118,abs_log1p_10k,spouse_increase_all,support_log1p_10k,Delta_CDE,3119,1299,0.75304829770388,VALIDATED_B200,,-0.00114770789866038,-0.00557249430634418,0.00243259981240983,0.552238805970149,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_118/ARTIFACT_VALIDATION.json
FEAS_119,rel_transition_eligible,spouse_increase_all,support_log1p_10k,TNIE,2121,1024,0.724724205061648,VALIDATED_B200,,4.33680868994202e-18,-0.000399189556967431,0.0002771454706784,1,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_119/ARTIFACT_VALIDATION.json
FEAS_119,rel_transition_eligible,spouse_increase_all,support_log1p_10k,Delta_CDE,2121,1024,0.724724205061648,VALIDATED_B200,,0.000288457431462536,-0.0101934508864225,0.00893224873025692,0.945273631840796,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_119/ARTIFACT_VALIDATION.json
FEAS_120,rel_share_diff,spouse_increase_all,support_log1p_10k,TNIE,2698,1140,0.786381631037213,VALIDATED_B200,,2.209359075214e-05,-0.000126941520557319,9.97652199717014e-05,0.611940298507463,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_120/ARTIFACT_VALIDATION.json
FEAS_120,rel_share_diff,spouse_increase_all,support_log1p_10k,Delta_CDE,2698,1140,0.786381631037213,VALIDATED_B200,,-0.0015794527393999,-0.00468970825805357,0.00126654285779129,0.348258706467662,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch08/FEAS_120/ARTIFACT_VALIDATION.json
FEAS_121,abs_increase,self_score_diff,support_log1p_10k,TNIE,4096,1641,0.675667115369388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_121,abs_increase,self_score_diff,support_log1p_10k,Delta_CDE,4096,1641,0.675667115369388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_122,abs_diff_10k,self_score_diff,support_log1p_10k,TNIE,2733,1175,0.783593316968881,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_122,abs_diff_10k,self_score_diff,support_log1p_10k,Delta_CDE,2733,1175,0.783593316968881,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_123,abs_log1p_10k,self_score_diff,support_log1p_10k,TNIE,2991,1277,0.763164146013144,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_123,abs_log1p_10k,self_score_diff,support_log1p_10k,Delta_CDE,2991,1277,0.763164146013144,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_124,rel_transition_eligible,self_score_diff,support_log1p_10k,TNIE,2654,1248,0.655503634475597,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_124,rel_transition_eligible,self_score_diff,support_log1p_10k,Delta_CDE,2654,1248,0.655503634475597,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_125,rel_share_diff,self_score_diff,support_log1p_10k,TNIE,2725,1177,0.784226779634175,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_125,rel_share_diff,self_score_diff,support_log1p_10k,Delta_CDE,2725,1177,0.784226779634175,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_126,abs_increase,spouse_score_diff,support_log1p_10k,TNIE,4028,1573,0.681076801266825,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_126,abs_increase,spouse_score_diff,support_log1p_10k,Delta_CDE,4028,1573,0.681076801266825,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_127,abs_diff_10k,spouse_score_diff,support_log1p_10k,TNIE,2875,1211,0.77236737925574,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_127,abs_diff_10k,spouse_score_diff,support_log1p_10k,Delta_CDE,2875,1211,0.77236737925574,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_128,abs_log1p_10k,spouse_score_diff,support_log1p_10k,TNIE,3119,1299,0.75304829770388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_128,abs_log1p_10k,spouse_score_diff,support_log1p_10k,Delta_CDE,3119,1299,0.75304829770388,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_129,rel_transition_eligible,spouse_score_diff,support_log1p_10k,TNIE,2121,1024,0.724724205061648,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_129,rel_transition_eligible,spouse_score_diff,support_log1p_10k,Delta_CDE,2121,1024,0.724724205061648,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_130,rel_share_diff,spouse_score_diff,support_log1p_10k,TNIE,2698,1140,0.786381631037213,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_130,rel_share_diff,spouse_score_diff,support_log1p_10k,Delta_CDE,2698,1140,0.786381631037213,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,,,,,,,PENDING_FULL_UNIVERSE,
FEAS_131,abs_increase,self_relative_transition,support_log1p_10k,TNIE,9879,2939,0,VALIDATED_B200,,6.36694972872692e-09,-6.1453270726909e-05,5.91049890450292e-05,1,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_131/ARTIFACT_VALIDATION.json
FEAS_131,abs_increase,self_relative_transition,support_log1p_10k,Delta_CDE,9879,2939,0,VALIDATED_B200,,-0.00138678677977248,-0.00766354532058616,0.00552972363790875,0.616915422885572,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_131/ARTIFACT_VALIDATION.json
FEAS_132,abs_diff_10k,self_relative_transition,support_log1p_10k,TNIE,6477,2244,0.344366838748861,VALIDATED_B200,,-1.26029843953166e-06,-6.20123687099748e-05,5.95593794309257e-05,0.875621890547264,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_132/ARTIFACT_VALIDATION.json
FEAS_132,abs_diff_10k,self_relative_transition,support_log1p_10k,Delta_CDE,6477,2244,0.344366838748861,VALIDATED_B200,,0.000232308624509984,-0.00692513348064152,0.00401618744359578,0.900497512437811,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_132/ARTIFACT_VALIDATION.json
FEAS_133,abs_log1p_10k,self_relative_transition,support_log1p_10k,TNIE,7202,2424,0.270978844012552,VALIDATED_B200,,-1.17571263165569e-05,-7.60541148280504e-05,0.000103355612438658,0.696517412935323,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_133/ARTIFACT_VALIDATION.json
FEAS_133,abs_log1p_10k,self_relative_transition,support_log1p_10k,Delta_CDE,7202,2424,0.270978844012552,VALIDATED_B200,,0.000631934237306353,-0.00570176367673124,0.00837617516123864,0.82089552238806,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_133/ARTIFACT_VALIDATION.json
FEAS_134,rel_transition_eligible,self_relative_transition,support_log1p_10k,TNIE,6331,2397,0,VALIDATED_B200,,-2.75569861452529e-06,-0.000122688696409597,7.12998713379129e-05,0.870646766169154,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_134/ARTIFACT_VALIDATION.json
FEAS_134,rel_transition_eligible,self_relative_transition,support_log1p_10k,Delta_CDE,6331,2397,0,VALIDATED_B200,,0.000392781238552969,-0.00649741535580956,0.00781536986832271,0.915422885572139,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_134/ARTIFACT_VALIDATION.json
FEAS_135,rel_share_diff,self_relative_transition,support_log1p_10k,TNIE,6766,2235,0.315112865674663,VALIDATED_B200,,-5.38587753228827e-06,-4.07000383867835e-05,3.82809161220296e-05,0.73134328358209,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_135/ARTIFACT_VALIDATION.json
FEAS_135,rel_share_diff,self_relative_transition,support_log1p_10k,Delta_CDE,6766,2235,0.315112865674663,VALIDATED_B200,,-0.000420689391960995,-0.00350852093262914,0.00257579641400109,0.81592039800995,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_135/ARTIFACT_VALIDATION.json
FEAS_136,abs_increase,spouse_relative_transition,support_log1p_10k,TNIE,9804,2895,0,VALIDATED_B200,,-1.90327432422928e-07,-5.07812386760461e-05,4.76807454260086e-05,0.965174129353234,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_136/ARTIFACT_VALIDATION.json
FEAS_136,abs_increase,spouse_relative_transition,support_log1p_10k,Delta_CDE,9804,2895,0,VALIDATED_B200,,-0.00026145361835818,-0.00532930285847217,0.00456155149521548,0.950248756218905,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/binary_expanded_B200_batch03/FEAS_136/ARTIFACT_VALIDATION.json
FEAS_137,abs_diff_10k,spouse_relative_transition,support_log1p_10k,TNIE,6654,2276,0.321297429620563,VALIDATED_B200,,-4.02610879084836e-06,-4.00898385415502e-05,5.02561358026812e-05,0.766169154228856,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_137/ARTIFACT_VALIDATION.json
FEAS_137,abs_diff_10k,spouse_relative_transition,support_log1p_10k,Delta_CDE,6654,2276,0.321297429620563,VALIDATED_B200,,0.000450090871980135,-0.00363973431738393,0.00637307976903232,0.855721393034826,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_137/ARTIFACT_VALIDATION.json
FEAS_138,abs_log1p_10k,spouse_relative_transition,support_log1p_10k,TNIE,7342,2439,0.251121991024072,VALIDATED_B200,,2.43752618637322e-06,-3.34036497303417e-05,4.39771729814608e-05,0.751243781094527,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_138/ARTIFACT_VALIDATION.json
FEAS_138,abs_log1p_10k,spouse_relative_transition,support_log1p_10k,Delta_CDE,7342,2439,0.251121991024072,VALIDATED_B200,,-0.00135441493559248,-0.00470088410834391,0.00207809941076714,0.402985074626866,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/absolute_continuousX_binaryM_B200_batch05/FEAS_138/ARTIFACT_VALIDATION.json
FEAS_139,rel_transition_eligible,spouse_relative_transition,support_log1p_10k,TNIE,5757,2221,0,VALIDATED_B200,,2.65082186743076e-06,-0.000176142954152273,0.000223365451777774,0.920398009950249,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_139/ARTIFACT_VALIDATION.json
FEAS_139,rel_transition_eligible,spouse_relative_transition,support_log1p_10k,Delta_CDE,5757,2221,0,VALIDATED_B200,,-5.87790601390462e-05,-0.00547247465662638,0.00564620346237472,0.990049751243781,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_139/ARTIFACT_VALIDATION.json
FEAS_140,rel_share_diff,spouse_relative_transition,support_log1p_10k,TNIE,6735,2212,0.313035495716034,VALIDATED_B200,,-6.64091472477642e-07,-3.01180701492163e-05,3.1885145676585e-05,0.860696517412935,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_140/ARTIFACT_VALIDATION.json
FEAS_140,rel_share_diff,spouse_relative_transition,support_log1p_10k,Delta_CDE,6735,2212,0.313035495716034,VALIDATED_B200,,-0.0014570632967755,-0.00353668845443372,0.000908370400884812,0.283582089552239,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relativeX_binaryM_B200_batch09/FEAS_140/ARTIFACT_VALIDATION.json
FEAS_141,abs_increase,self_relative_gap_diff,support_log1p_10k,TNIE,12564,3149,0.00483168316831683,VALIDATED_B200,,-6.82823615775607e-06,-5.44090724751469e-05,2.88451409612989e-05,0.651741293532338,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_141/ARTIFACT_VALIDATION.json
FEAS_141,abs_increase,self_relative_gap_diff,support_log1p_10k,Delta_CDE,12564,3149,0.00483168316831683,VALIDATED_B200,,0.00100612324189422,-0.000401846739356875,0.00227143284200027,0.159203980099502,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_141/ARTIFACT_VALIDATION.json
FEAS_142,abs_diff_10k,self_relative_gap_diff,support_log1p_10k,TNIE,8417,2538,0.333306930693069,VALIDATED_B200,,5.59197230731029e-06,-4.41167696185635e-06,1.60128308615084e-05,0.358208955223881,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_142/ARTIFACT_VALIDATION.json
FEAS_142,abs_diff_10k,self_relative_gap_diff,support_log1p_10k,Delta_CDE,8417,2538,0.333306930693069,VALIDATED_B200,,0.00123446798971761,-0.000715394092398794,0.00228395993973653,0.208955223880597,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_142/ARTIFACT_VALIDATION.json
FEAS_143,abs_log1p_10k,self_relative_gap_diff,support_log1p_10k,TNIE,9295,2701,0.263762376237624,VALIDATED_B200,,-5.30426836350397e-06,-3.35542113865277e-05,2.4206833499384e-05,0.626865671641791,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_143/ARTIFACT_VALIDATION.json
FEAS_143,abs_log1p_10k,self_relative_gap_diff,support_log1p_10k,Delta_CDE,9295,2701,0.263762376237624,VALIDATED_B200,,0.000931970070741413,-0.000187954459363076,0.00179508628727721,0.0895522388059701,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_143/ARTIFACT_VALIDATION.json
FEAS_144,rel_transition_eligible,self_relative_gap_diff,support_log1p_10k,TNIE,7668,2658,0.00428515777171796,VALIDATED_B200,,-7.19591546850373e-06,-0.000115637630025622,7.0680883393752e-05,0.81592039800995,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_144/ARTIFACT_VALIDATION.json
FEAS_144,rel_transition_eligible,self_relative_gap_diff,support_log1p_10k,Delta_CDE,7668,2658,0.00428515777171796,VALIDATED_B200,,0.000113966663820143,-0.00180690511156529,0.00224415545376961,0.90547263681592,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch06/FEAS_144/ARTIFACT_VALIDATION.json
FEAS_145,rel_share_diff,self_relative_gap_diff,support_log1p_10k,TNIE,8589,2433,0.319683168316832,VALIDATED_B200,,-1.69262553278266e-06,-2.16363929584511e-05,1.87732680385435e-05,0.796019900497512,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_145/ARTIFACT_VALIDATION.json
FEAS_145,rel_share_diff,self_relative_gap_diff,support_log1p_10k,Delta_CDE,8589,2433,0.319683168316832,VALIDATED_B200,,0.000484314019667213,-0.000274640689963972,0.00117375747831916,0.243781094527363,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_145/ARTIFACT_VALIDATION.json
FEAS_146,abs_increase,spouse_relative_gap_diff,support_log1p_10k,TNIE,12564,3149,0.00483168316831683,VALIDATED_B200,,-6.82823615773829e-06,-5.44090724751253e-05,2.88451409613142e-05,0.651741293532338,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_146/ARTIFACT_VALIDATION.json
FEAS_146,abs_increase,spouse_relative_gap_diff,support_log1p_10k,Delta_CDE,12564,3149,0.00483168316831683,VALIDATED_B200,,0.00100612324189422,-0.000401846739356875,0.00227143284200027,0.159203980099502,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_146/ARTIFACT_VALIDATION.json
FEAS_147,abs_diff_10k,spouse_relative_gap_diff,support_log1p_10k,TNIE,8417,2538,0.333306930693069,VALIDATED_B200,,5.5919723073014e-06,-4.41167696184852e-06,1.60128308615103e-05,0.358208955223881,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_147/ARTIFACT_VALIDATION.json
FEAS_147,abs_diff_10k,spouse_relative_gap_diff,support_log1p_10k,Delta_CDE,8417,2538,0.333306930693069,VALIDATED_B200,,0.00123446798971761,-0.000715394092398794,0.00228395993973653,0.208955223880597,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_147/ARTIFACT_VALIDATION.json
FEAS_148,abs_log1p_10k,spouse_relative_gap_diff,support_log1p_10k,TNIE,9295,2701,0.263762376237624,VALIDATED_B200,,-5.30426836350094e-06,-3.35542113865506e-05,2.4206833499381e-05,0.626865671641791,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_148/ARTIFACT_VALIDATION.json
FEAS_148,abs_log1p_10k,spouse_relative_gap_diff,support_log1p_10k,Delta_CDE,9295,2701,0.263762376237624,VALIDATED_B200,,0.000931970070741413,-0.000187954459363076,0.00179508628727721,0.0895522388059701,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch07_recovery_v1/FEAS_148/ARTIFACT_VALIDATION.json
FEAS_149,rel_transition_eligible,spouse_relative_gap_diff,support_log1p_10k,TNIE,7668,2658,0.00428515777171796,VALIDATED_B200,,-7.19591546850069e-06,-0.000115637630025619,7.06808833937282e-05,0.81592039800995,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch08/FEAS_149/ARTIFACT_VALIDATION.json
FEAS_149,rel_transition_eligible,spouse_relative_gap_diff,support_log1p_10k,Delta_CDE,7668,2658,0.00428515777171796,VALIDATED_B200,,0.000113966663820143,-0.00180690511156529,0.00224415545376961,0.90547263681592,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch08/FEAS_149/ARTIFACT_VALIDATION.json
FEAS_150,rel_share_diff,spouse_relative_gap_diff,support_log1p_10k,TNIE,8589,2433,0.319683168316832,VALIDATED_B200,,-1.69262553277399e-06,-2.16363929584517e-05,1.87732680385529e-05,0.796019900497512,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch08/FEAS_150/ARTIFACT_VALIDATION.json
FEAS_150,rel_share_diff,spouse_relative_gap_diff,support_log1p_10k,Delta_CDE,8589,2433,0.319683168316832,VALIDATED_B200,,0.000484314019667213,-0.000274640689963972,0.00117375747831916,0.243781094527363,200,,PENDING_FULL_UNIVERSE,/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/relative_continuousM_B200_batch08/FEAS_150/ARTIFACT_VALIDATION.json


## ALL_300_ADJUSTED.csv
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/ALL_300_ADJUSTED.csv

"spec_id","metric","eligible","test_value","p","BH","BY","selected"
"FEAS_001","TNIE",TRUE,-0.000691548740084604,0.741293532338308,1,1,FALSE
"FEAS_002","TNIE",TRUE,0.000241758014534452,0.786069651741294,1,1,FALSE
"FEAS_003","TNIE",TRUE,0.00219204330901695,0.572139303482587,1,1,TRUE
"FEAS_004","TNIE",TRUE,-0.0182482976457878,0.278606965174129,1,1,TRUE
"FEAS_005","TNIE",TRUE,-0.00123494319279743,0.646766169154229,1,1,FALSE
"FEAS_006","TNIE",TRUE,0.000406139036923499,0.930348258706468,1,1,FALSE
"FEAS_007","TNIE",TRUE,-0.000621228227875342,0.686567164179104,1,1,FALSE
"FEAS_008","TNIE",TRUE,0.000571996187468291,0.72636815920398,1,1,FALSE
"FEAS_009","TNIE",TRUE,4.01130159532904e-05,0.985074626865672,1,1,FALSE
"FEAS_010","TNIE",TRUE,-0.00102311109991807,0.601990049751244,1,1,FALSE
"FEAS_011","TNIE",TRUE,-0.000691548740084604,0.741293532338308,1,1,FALSE
"FEAS_012","TNIE",TRUE,0.000241758014534452,0.786069651741294,1,1,FALSE
"FEAS_013","TNIE",TRUE,0.00219204330901695,0.572139303482587,1,1,FALSE
"FEAS_014","TNIE",TRUE,-0.0182482976457878,0.278606965174129,1,1,FALSE
"FEAS_015","TNIE",TRUE,-0.00123494319279743,0.646766169154229,1,1,FALSE
"FEAS_016","TNIE",TRUE,0.000406139036923499,0.930348258706468,1,1,FALSE
"FEAS_017","TNIE",TRUE,-0.000621228227875342,0.686567164179104,1,1,FALSE
"FEAS_018","TNIE",TRUE,0.000571996187468291,0.72636815920398,1,1,FALSE
"FEAS_019","TNIE",TRUE,4.01130159532904e-05,0.985074626865672,1,1,FALSE
"FEAS_020","TNIE",TRUE,-0.00102311109991807,0.601990049751244,1,1,FALSE
"FEAS_021","TNIE",FALSE,,,,,FALSE
"FEAS_022","TNIE",FALSE,,,,,FALSE
"FEAS_023","TNIE",FALSE,,,,,FALSE
"FEAS_024","TNIE",FALSE,,,,,FALSE
"FEAS_025","TNIE",FALSE,,,,,FALSE
"FEAS_026","TNIE",FALSE,,,,,FALSE
"FEAS_027","TNIE",FALSE,,,,,FALSE
"FEAS_028","TNIE",FALSE,,,,,FALSE
"FEAS_029","TNIE",FALSE,,,,,FALSE
"FEAS_030","TNIE",FALSE,,,,,FALSE
"FEAS_031","TNIE",TRUE,-0.00010266514127729,0.945273631840796,1,1,FALSE
"FEAS_032","TNIE",TRUE,9.56692391621077e-05,0.781094527363184,1,1,FALSE
"FEAS_033","TNIE",TRUE,0.000316101980459295,0.72636815920398,1,1,FALSE
"FEAS_034","TNIE",TRUE,-0.00114142503245006,0.671641791044776,1,1,FALSE
"FEAS_035","TNIE",TRUE,0.000115740557371896,0.711442786069652,1,1,FALSE
"FEAS_036","TNIE",TRUE,-9.88919331083147e-05,0.970149253731343,1,1,FALSE
"FEAS_037","TNIE",TRUE,-0.000332472881937712,0.686567164179104,1,1,FALSE
"FEAS_038","TNIE",TRUE,-0.000249003889296596,0.661691542288557,1,1,FALSE
"FEAS_039","TNIE",TRUE,0.00178976701197421,0.671641791044776,1,1,FALSE
"FEAS_040","TNIE",TRUE,3.27251232331369e-05,0.90547263681592,1,1,FALSE
"FEAS_041","TNIE",TRUE,0.000397491063781653,0.671641791044776,1,1,FALSE
"FEAS_042","TNIE",TRUE,-8.72796246227213e-05,0.587064676616915,1,1,FALSE
"FEAS_043","TNIE",TRUE,-4.60550235880974e-05,0.825870646766169,1,1,FALSE
"FEAS_044","TNIE",TRUE,0.000361241761056573,0.796019900497512,1,1,FALSE
"FEAS_045","TNIE",TRUE,-0.000196581116494343,0.706467661691542,1,1,FALSE
"FEAS_046","TNIE",TRUE,0.000397525212859124,0.671641791044776,1,1,FALSE
"FEAS_047","TNIE",TRUE,-8.72716804957341e-05,0.587064676616915,1,1,FALSE
"FEAS_048","TNIE",TRUE,-4.6055987960795e-05,0.825870646766169,1,1,FALSE
"FEAS_049","TNIE",TRUE,0.000361242490589211,0.796019900497512,1,1,FALSE
"FEAS_050","TNIE",TRUE,-0.0001965729208995,0.706467661691542,1,1,FALSE
"FEAS_051","TNIE",TRUE,-1.49571422991069e-05,0.766169154228856,1,1,FALSE
"FEAS_052","TNIE",TRUE,-2.65723616737539e-05,0.616915422885572,1,1,FALSE
"FEAS_053","TNIE",TRUE,1.62786723787562e-05,0.691542288557214,1,1,FALSE
"FEAS_054","TNIE",TRUE,-7.960114133397e-05,0.671641791044776,1,1,FALSE
"FEAS_055","TNIE",TRUE,-4.38308413513002e-06,0.781094527363184,1,1,FALSE
"FEAS_056","TNIE",TRUE,8.09266334726288e-06,0.885572139303483,1,1,FALSE
"FEAS_057","TNIE",TRUE,3.14640073503186e-05,0.611940298507463,1,1,FALSE
"FEAS_058","TNIE",TRUE,1.98273379487142e-06,0.920398009950249,1,1,FALSE
"FEAS_059","TNIE",TRUE,1.73472347597681e-18,1,1,1,FALSE
"FEAS_060","TNIE",TRUE,2.78492817705515e-05,0.587064676616915,1,1,TRUE
"FEAS_061","TNIE",TRUE,-1.49571422991069e-05,0.766169154228856,1,1,FALSE
"FEAS_062","TNIE",TRUE,-2.65723616737539e-05,0.616915422885572,1,1,FALSE
"FEAS_063","TNIE",TRUE,1.62786723787562e-05,0.691542288557214,1,1,FALSE
"FEAS_064","TNIE",TRUE,-7.960114133397e-05,0.671641791044776,1,1,FALSE
"FEAS_065","TNIE",TRUE,-4.38308413513002e-06,0.781094527363184,1,1,FALSE
"FEAS_066","TNIE",TRUE,8.09266334726288e-06,0.885572139303483,1,1,FALSE
"FEAS_067","TNIE",TRUE,3.14640073503186e-05,0.611940298507463,1,1,FALSE
"FEAS_068","TNIE",TRUE,1.98273379487142e-06,0.920398009950249,1,1,FALSE
"FEAS_069","TNIE",TRUE,1.73472347597681e-18,1,1,1,FALSE
"FEAS_070","TNIE",TRUE,2.78492817705515e-05,0.587064676616915,1,1,FALSE
"FEAS_071","TNIE",FALSE,,,,,FALSE
"FEAS_072","TNIE",FALSE,,,,,FALSE
"FEAS_073","TNIE",FALSE,,,,,FALSE
"FEAS_074","TNIE",FALSE,,,,,FALSE
"FEAS_075","TNIE",FALSE,,,,,FALSE
"FEAS_076","TNIE",FALSE,,,,,FALSE
"FEAS_077","TNIE",FALSE,,,,,FALSE
"FEAS_078","TNIE",FALSE,,,,,FALSE
"FEAS_079","TNIE",FALSE,,,,,FALSE
"FEAS_080","TNIE",FALSE,,,,,FALSE
"FEAS_081","TNIE",TRUE,9.28132553768175e-08,1,1,1,FALSE
"FEAS_082","TNIE",TRUE,-2.07427488871413e-06,0.900497512437811,1,1,FALSE
"FEAS_083","TNIE",TRUE,-1.55231947765034e-05,0.711442786069652,1,1,FALSE
"FEAS_084","TNIE",TRUE,-2.89156269259227e-06,0.860696517412935,1,1,FALSE
"FEAS_085","TNIE",TRUE,-8.25725028200932e-06,0.716417910447761,1,1,FALSE
"FEAS_086","TNIE",TRUE,1.53177854020706e-07,0.990049751243781,1,1,FALSE
"FEAS_087","TNIE",TRUE,-3.56375183488758e-06,0.810945273631841,1,1,FALSE
"FEAS_088","TNIE",TRUE,4.0714856435857e-06,0.72636815920398,1,1,FALSE
"FEAS_089","TNIE",TRUE,4.09025518469976e-07,0.980099502487562,1,1,FALSE
"FEAS_090","TNIE",TRUE,-8.94800195419022e-07,0.865671641791045,1,1,FALSE
"FEAS_091","TNIE",TRUE,-8.63397740420019e-06,0.656716417910448,1,1,FALSE
"FEAS_092","TNIE",TRUE,8.15149865572898e-06,0.333333333333333,1,1,TRUE
"FEAS_093","TNIE",TRUE,-6.65048351909756e-06,0.626865671641791,1,1,FALSE
"FEAS_094","TNIE",TRUE,-9.66010798645212e-06,0.791044776119403,1,1,FALSE
"FEAS_095","TNIE",TRUE,-2.41238201147131e-06,0.736318407960199,1,1,FALSE
"FEAS_096","TNIE",TRUE,-8.63397740419065e-06,0.656716417910448,1,1,FALSE
"FEAS_097","TNIE",TRUE,8.15149865572963e-06,0.333333333333333,1,1,FALSE
"FEAS_098","TNIE",TRUE,-6.65048351909323e-06,0.626865671641791,1,1,FALSE
"FEAS_099","TNIE",TRUE,-9.66010798642437e-06,0.791044776119403,1,1,FALSE
"FEAS_100","TNIE",TRUE,-2.41238201147066e-06,0.736318407960199,1,1,FALSE
"FEAS_101","TNIE",TRUE,-1.46409953237234e-05,0.766169154228856,1,1,FALSE
"FEAS_102","TNIE",TRUE,-2.17633963733696e-05,0.611940298507463,1,1,FALSE
"FEAS_103","TNIE",TRUE,1.34251228091028e-05,0.691542288557214,1,1,FALSE
"FEAS_104","TNIE",TRUE,-8.19409065966007e-05,0.616915422885572,1,1,FALSE
"FEAS_105","TNIE",TRUE,-3.59314352789538e-06,0.796019900497512,1,1,FALSE
"FEAS_106","TNIE",TRUE,4.71079649374965e-06,0.875621890547264,1,1,FALSE
"FEAS_107","TNIE",TRUE,3.24705892752951e-05,0.567164179104478,1,1,TRUE
"FEAS_108","TNIE",TRUE,-4.68705077018381e-06,0.870646766169154,1,1,FALSE
"FEAS_109","TNIE",TRUE,4.33680868994202e-18,1,1,1,FALSE
"FEAS_110","TNIE",TRUE,2.209359075214e-05,0.611940298507463,1,1,FALSE
"FEAS_111","TNIE",TRUE,-1.46409953237234e-05,0.766169154228856,1,1,FALSE
"FEAS_112","TNIE",TRUE,-2.17633963733696e-05,0.611940298507463,1,1,FALSE
"FEAS_113","TNIE",TRUE,1.34251228091028e-05,0.691542288557214,1,1,FALSE
"FEAS_114","TNIE",TRUE,-8.19409065966007e-05,0.616915422885572,1,1,FALSE
"FEAS_115","TNIE",TRUE,-3.59314352789538e-06,0.796019900497512,1,1,FALSE
"FEAS_116","TNIE",TRUE,4.71079649374965e-06,0.875621890547264,1,1,FALSE
"FEAS_117","TNIE",TRUE,3.24705892752951e-05,0.567164179104478,1,1,FALSE
"FEAS_118","TNIE",TRUE,-4.68705077018381e-06,0.870646766169154,1,1,FALSE
"FEAS_119","TNIE",TRUE,4.33680868994202e-18,1,1,1,FALSE
"FEAS_120","TNIE",TRUE,2.209359075214e-05,0.611940298507463,1,1,FALSE
"FEAS_121","TNIE",FALSE,,,,,FALSE
"FEAS_122","TNIE",FALSE,,,,,FALSE
"FEAS_123","TNIE",FALSE,,,,,FALSE
"FEAS_124","TNIE",FALSE,,,,,FALSE
"FEAS_125","TNIE",FALSE,,,,,FALSE
"FEAS_126","TNIE",FALSE,,,,,FALSE
"FEAS_127","TNIE",FALSE,,,,,FALSE
"FEAS_128","TNIE",FALSE,,,,,FALSE
"FEAS_129","TNIE",FALSE,,,,,FALSE
"FEAS_130","TNIE",FALSE,,,,,FALSE
"FEAS_131","TNIE",TRUE,6.36694972872692e-09,1,1,1,FALSE
"FEAS_132","TNIE",TRUE,-1.26029843953166e-06,0.875621890547264,1,1,FALSE
"FEAS_133","TNIE",TRUE,-1.17571263165569e-05,0.696517412935323,1,1,FALSE
"FEAS_134","TNIE",TRUE,-2.75569861452529e-06,0.870646766169154,1,1,FALSE
"FEAS_135","TNIE",TRUE,-5.38587753228827e-06,0.73134328358209,1,1,FALSE
"FEAS_136","TNIE",TRUE,-1.90327432422928e-07,0.965174129353234,1,1,FALSE
"FEAS_137","TNIE",TRUE,-4.02610879084836e-06,0.766169154228856,1,1,FALSE
"FEAS_138","TNIE",TRUE,2.43752618637322e-06,0.751243781094527,1,1,FALSE
"FEAS_139","TNIE",TRUE,2.65082186743076e-06,0.920398009950249,1,1,FALSE
"FEAS_140","TNIE",TRUE,-6.64091472477642e-07,0.860696517412935,1,1,FALSE
"FEAS_141","TNIE",TRUE,-6.82823615775607e-06,0.651741293532338,1,1,FALSE
"FEAS_142","TNIE",TRUE,5.59197230731029e-06,0.358208955223881,1,1,TRUE
"FEAS_143","TNIE",TRUE,-5.30426836350397e-06,0.626865671641791,1,1,FALSE
"FEAS_144","TNIE",TRUE,-7.19591546850373e-06,0.81592039800995,1,1,FALSE
"FEAS_145","TNIE",TRUE,-1.69262553278266e-06,0.796019900497512,1,1,FALSE
"FEAS_146","TNIE",TRUE,-6.82823615773829e-06,0.651741293532338,1,1,FALSE
"FEAS_147","TNIE",TRUE,5.5919723073014e-06,0.358208955223881,1,1,FALSE
"FEAS_148","TNIE",TRUE,-5.30426836350094e-06,0.626865671641791,1,1,FALSE
"FEAS_149","TNIE",TRUE,-7.19591546850069e-06,0.81592039800995,1,1,FALSE
"FEAS_150","TNIE",TRUE,-1.69262553277399e-06,0.796019900497512,1,1,FALSE
"FEAS_001","Delta_CDE",TRUE,-0.0215270991146883,0.900497512437811,1,1,FALSE
"FEAS_002","Delta_CDE",TRUE,-0.0243789304446611,0.611940298507463,1,1,FALSE
"FEAS_003","Delta_CDE",TRUE,0.0536997203831739,0.527363184079602,1,1,FALSE
"FEAS_004","Delta_CDE",TRUE,0.412124516598985,0.174129353233831,0.863330406789582,1,FALSE
"FEAS_005","Delta_CDE",TRUE,0.110344184501018,0.134328358208955,0.863330406789582,1,FALSE
"FEAS_006","Delta_CDE",TRUE,0.332464591814602,0.0995024875621891,0.863330406789582,1,FALSE
"FEAS_007","Delta_CDE",TRUE,-0.0444022525040978,0.293532338308458,0.863330406789582,1,FALSE
"FEAS_008","Delta_CDE",TRUE,0.0164061093010479,0.830845771144279,1,1,FALSE
"FEAS_009","Delta_CDE",TRUE,0.191528854125976,0.45771144278607,1,1,FALSE
"FEAS_010","Delta_CDE",TRUE,0.0753080679106958,0.283582089552239,0.863330406789582,1,FALSE
"FEAS_011","Delta_CDE",TRUE,-0.0215270991146883,0.900497512437811,1,1,FALSE
"FEAS_012","Delta_CDE",TRUE,-0.0243789304446611,0.611940298507463,1,1,FALSE
"FEAS_013","Delta_CDE",TRUE,0.0536997203831739,0.527363184079602,1,1,FALSE
"FEAS_014","Delta_CDE",TRUE,0.412124516598985,0.174129353233831,0.863330406789582,1,FALSE
"FEAS_015","Delta_CDE",TRUE,0.110344184501018,0.134328358208955,0.863330406789582,1,FALSE
"FEAS_016","Delta_CDE",TRUE,0.332464591814602,0.0995024875621891,0.863330406789582,1,FALSE
"FEAS_017","Delta_CDE",TRUE,-0.0444022525040978,0.293532338308458,0.863330406789582,1,FALSE
"FEAS_018","Delta_CDE",TRUE,0.0164061093010479,0.830845771144279,1,1,FALSE
"FEAS_019","Delta_CDE",TRUE,0.191528854125976,0.45771144278607,1,1,FALSE
"FEAS_020","Delta_CDE",TRUE,0.0753080679106958,0.283582089552239,0.863330406789582,1,FALSE
"FEAS_021","Delta_CDE",FALSE,,,,,FALSE
"FEAS_022","Delta_CDE",FALSE,,,,,FALSE
"FEAS_023","Delta_CDE",FALSE,,,,,FALSE
"FEAS_024","Delta_CDE",FALSE,,,,,FALSE
"FEAS_025","Delta_CDE",FALSE,,,,,FALSE
"FEAS_026","Delta_CDE",FALSE,,,,,FALSE
"FEAS_027","Delta_CDE",FALSE,,,,,FALSE
"FEAS_028","Delta_CDE",FALSE,,,,,FALSE
"FEAS_029","Delta_CDE",FALSE,,,,,FALSE
"FEAS_030","Delta_CDE",FALSE,,,,,FALSE
"FEAS_031","Delta_CDE",TRUE,-0.407543877675273,0.00497512437810945,0.746268656716418,1,TRUE
"FEAS_032","Delta_CDE",TRUE,-0.021738152806251,0.567164179104478,1,1,FALSE
"FEAS_033","Delta_CDE",TRUE,-0.0748871091459815,0.318407960199005,0.918484500574053,1,FALSE
"FEAS_034","Delta_CDE",TRUE,-0.274214712007085,0.174129353233831,0.863330406789582,1,FALSE
"FEAS_035","Delta_CDE",TRUE,-0.0292938736578965,0.616915422885572,1,1,FALSE
"FEAS_036","Delta_CDE",TRUE,0.393272551770349,0.0746268656716418,0.863330406789582,1,FALSE
"FEAS_037","Delta_CDE",TRUE,0.0220880253272766,0.641791044776119,1,1,FALSE
"FEAS_038","Delta_CDE",TRUE,-0.00350956629416177,0.960199004975124,1,1,FALSE
"FEAS_039","Delta_CDE",TRUE,0.0521795734818999,0.81592039800995,1,1,FALSE
"FEAS_040","Delta_CDE",TRUE,-0.002952264580661,0.975124378109453,1,1,FALSE
"FEAS_041","Delta_CDE",TRUE,-0.0858683431318368,0.0398009950248756,0.863330406789582,1,TRUE
"FEAS_042","Delta_CDE",TRUE,0.00781539497032946,0.512437810945274,1,1,FALSE
"FEAS_043","Delta_CDE",TRUE,0.0131005058216935,0.517412935323383,1,1,FALSE
"FEAS_044","Delta_CDE",TRUE,-0.0228178770088907,0.736318407960199,1,1,FALSE
"FEAS_045","Delta_CDE",TRUE,0.0111281739045919,0.601990049751244,1,1,FALSE
"FEAS_046","Delta_CDE",TRUE,-0.0858683431318368,0.0398009950248756,0.863330406789582,1,FALSE
"FEAS_047","Delta_CDE",TRUE,0.00781539497032946,0.512437810945274,1,1,FALSE
"FEAS_048","Delta_CDE",TRUE,0.0131005058216935,0.517412935323383,1,1,FALSE
"FEAS_049","Delta_CDE",TRUE,-0.0228178770088907,0.736318407960199,1,1,FALSE
"FEAS_050","Delta_CDE",TRUE,0.0111281739045919,0.601990049751244,1,1,FALSE
"FEAS_051","Delta_CDE",TRUE,0.00164584545683975,0.681592039800995,1,1,FALSE
"FEAS_052","Delta_CDE",TRUE,-0.00731737607794317,0.27363184079602,0.863330406789582,1,FALSE
"FEAS_053","Delta_CDE",TRUE,0.000119889368053935,0.955223880597015,1,1,FALSE
"FEAS_054","Delta_CDE",TRUE,0.00276417248132148,0.562189054726368,1,1,FALSE
"FEAS_055","Delta_CDE",TRUE,0.00164333530037554,0.258706467661692,0.863330406789582,1,FALSE
"FEAS_056","Delta_CDE",TRUE,0.00682185654310922,0.208955223880597,0.863330406789582,1,FALSE
"FEAS_057","Delta_CDE",TRUE,-0.00638975929086576,0.189054726368159,0.863330406789582,1,FALSE
"FEAS_058","Delta_CDE",TRUE,-0.000374007243310152,0.91044776119403,1,1,FALSE
"FEAS_059","Delta_CDE",TRUE,-0.00104936466657083,0.855721393034826,1,1,FALSE
"FEAS_060","Delta_CDE",TRUE,-0.00211093093101893,0.288557213930348,0.863330406789582,1,FALSE
"FEAS_061","Delta_CDE",TRUE,0.00164584545683975,0.681592039800995,1,1,FALSE
"FEAS_062","Delta_CDE",TRUE,-0.00731737607794317,0.27363184079602,0.863330406789582,1,FALSE
"FEAS_063","Delta_CDE",TRUE,0.000119889368053935,0.955223880597015,1,1,FALSE
"FEAS_064","Delta_CDE",TRUE,0.00276417248132148,0.562189054726368,1,1,FALSE
"FEAS_065","Delta_CDE",TRUE,0.00164333530037554,0.258706467661692,0.863330406789582,1,FALSE
"FEAS_066","Delta_CDE",TRUE,0.00682185654310922,0.208955223880597,0.863330406789582,1,FALSE
"FEAS_067","Delta_CDE",TRUE,-0.00638975929086576,0.189054726368159,0.863330406789582,1,FALSE
"FEAS_068","Delta_CDE",TRUE,-0.000374007243310152,0.91044776119403,1,1,FALSE
"FEAS_069","Delta_CDE",TRUE,-0.00104936466657083,0.855721393034826,1,1,FALSE
"FEAS_070","Delta_CDE",TRUE,-0.00211093093101893,0.288557213930348,0.863330406789582,1,FALSE
"FEAS_071","Delta_CDE",FALSE,,,,,FALSE
"FEAS_072","Delta_CDE",FALSE,,,,,FALSE
"FEAS_073","Delta_CDE",FALSE,,,,,FALSE
"FEAS_074","Delta_CDE",FALSE,,,,,FALSE
"FEAS_075","Delta_CDE",FALSE,,,,,FALSE
"FEAS_076","Delta_CDE",FALSE,,,,,FALSE
"FEAS_077","Delta_CDE",FALSE,,,,,FALSE
"FEAS_078","Delta_CDE",FALSE,,,,,FALSE
"FEAS_079","Delta_CDE",FALSE,,,,,FALSE
"FEAS_080","Delta_CDE",FALSE,,,,,FALSE
"FEAS_081","Delta_CDE",TRUE,-0.0019589279849601,0.567164179104478,1,1,FALSE
"FEAS_082","Delta_CDE",TRUE,0.000461531251214261,0.855721393034826,1,1,FALSE
"FEAS_083","Delta_CDE",TRUE,0.000570730063953476,0.870646766169154,1,1,FALSE
"FEAS_084","Delta_CDE",TRUE,0.000519520219443343,0.900497512437811,1,1,FALSE
"FEAS_085","Delta_CDE",TRUE,-0.000618796514284415,0.751243781094527,1,1,FALSE
"FEAS_086","Delta_CDE",TRUE,-0.00110592650504213,0.796019900497512,1,1,FALSE
"FEAS_087","Delta_CDE",TRUE,0.000395548234308586,0.895522388059702,1,1,FALSE
"FEAS_088","Delta_CDE",TRUE,-0.00170960664810543,0.3681592039801,1,1,FALSE
"FEAS_089","Delta_CDE",TRUE,1.1113265862059e-05,1,1,1,FALSE
"FEAS_090","Delta_CDE",TRUE,-0.00165546262612514,0.278606965174129,0.863330406789582,1,FALSE
"FEAS_091","Delta_CDE",TRUE,0.00119511094956369,0.134328358208955,0.863330406789582,1,TRUE
"FEAS_092","Delta_CDE",TRUE,0.00163978611964366,0.223880597014925,0.863330406789582,1,FALSE
"FEAS_093","Delta_CDE",TRUE,0.00106641608536052,0.104477611940299,0.863330406789582,1,TRUE
"FEAS_094","Delta_CDE",TRUE,0.000135825141528741,0.920398009950249,1,1,FALSE
"FEAS_095","Delta_CDE",TRUE,0.000536484605063323,0.248756218905473,0.863330406789582,1,FALSE
"FEAS_096","Delta_CDE",TRUE,0.00119511094956369,0.134328358208955,0.863330406789582,1,FALSE
"FEAS_097","Delta_CDE",TRUE,0.00163978611964366,0.223880597014925,0.863330406789582,1,FALSE
"FEAS_098","Delta_CDE",TRUE,0.00106641608536052,0.104477611940299,0.863330406789582,1,FALSE
"FEAS_099","Delta_CDE",TRUE,0.000135825141528741,0.920398009950249,1,1,FALSE
"FEAS_100","Delta_CDE",TRUE,0.000536484605063323,0.248756218905473,0.863330406789582,1,FALSE
"FEAS_101","Delta_CDE",TRUE,0.00219181922864152,0.45771144278607,1,1,FALSE
"FEAS_102","Delta_CDE",TRUE,-0.0055812817307429,0.27363184079602,0.863330406789582,1,FALSE
"FEAS_103","Delta_CDE",TRUE,0.000384261840393235,0.810945273631841,1,1,FALSE
"FEAS_104","Delta_CDE",TRUE,0.00266616673917405,0.527363184079602,1,1,FALSE
"FEAS_105","Delta_CDE",TRUE,0.00160609796187178,0.194029850746269,0.863330406789582,1,FALSE
"FEAS_106","Delta_CDE",TRUE,0.00456018071586679,0.164179104477612,0.863330406789582,1,FALSE
"FEAS_107","Delta_CDE",TRUE,-0.00536692247963753,0.124378109452736,0.863330406789582,1,TRUE
"FEAS_108","Delta_CDE",TRUE,-0.00114770789866038,0.552238805970149,1,1,FALSE
"FEAS_109","Delta_CDE",TRUE,0.000288457431462536,0.945273631840796,1,1,FALSE
"FEAS_110","Delta_CDE",TRUE,-0.0015794527393999,0.348258706467662,0.967385295743505,1,FALSE
"FEAS_111","Delta_CDE",TRUE,0.00219181922864152,0.45771144278607,1,1,FALSE
"FEAS_112","Delta_CDE",TRUE,-0.0055812817307429,0.27363184079602,0.863330406789582,1,FALSE
"FEAS_113","Delta_CDE",TRUE,0.000384261840393235,0.810945273631841,1,1,FALSE
"FEAS_114","Delta_CDE",TRUE,0.00266616673917405,0.527363184079602,1,1,FALSE
"FEAS_115","Delta_CDE",TRUE,0.00160609796187178,0.194029850746269,0.863330406789582,1,FALSE
"FEAS_116","Delta_CDE",TRUE,0.00456018071586679,0.164179104477612,0.863330406789582,1,FALSE
"FEAS_117","Delta_CDE",TRUE,-0.00536692247963753,0.124378109452736,0.863330406789582,1,FALSE
"FEAS_118","Delta_CDE",TRUE,-0.00114770789866038,0.552238805970149,1,1,FALSE
"FEAS_119","Delta_CDE",TRUE,0.000288457431462536,0.945273631840796,1,1,FALSE
"FEAS_120","Delta_CDE",TRUE,-0.0015794527393999,0.348258706467662,0.967385295743505,1,FALSE
"FEAS_121","Delta_CDE",FALSE,,,,,FALSE
"FEAS_122","Delta_CDE",FALSE,,,,,FALSE
"FEAS_123","Delta_CDE",FALSE,,,,,FALSE
"FEAS_124","Delta_CDE",FALSE,,,,,FALSE
"FEAS_125","Delta_CDE",FALSE,,,,,FALSE
"FEAS_126","Delta_CDE",FALSE,,,,,FALSE
"FEAS_127","Delta_CDE",FALSE,,,,,FALSE
"FEAS_128","Delta_CDE",FALSE,,,,,FALSE
"FEAS_129","Delta_CDE",FALSE,,,,,FALSE
"FEAS_130","Delta_CDE",FALSE,,,,,FALSE
"FEAS_131","Delta_CDE",TRUE,-0.00138678677977248,0.616915422885572,1,1,FALSE
"FEAS_132","Delta_CDE",TRUE,0.000232308624509984,0.900497512437811,1,1,FALSE
"FEAS_133","Delta_CDE",TRUE,0.000631934237306353,0.82089552238806,1,1,FALSE
"FEAS_134","Delta_CDE",TRUE,0.000392781238552969,0.915422885572139,1,1,FALSE
"FEAS_135","Delta_CDE",TRUE,-0.000420689391960995,0.81592039800995,1,1,FALSE
"FEAS_136","Delta_CDE",TRUE,-0.00026145361835818,0.950248756218905,1,1,FALSE
"FEAS_137","Delta_CDE",TRUE,0.000450090871980135,0.855721393034826,1,1,FALSE
"FEAS_138","Delta_CDE",TRUE,-0.00135441493559248,0.402985074626866,1,1,FALSE
"FEAS_139","Delta_CDE",TRUE,-5.87790601390462e-05,0.990049751243781,1,1,FALSE
"FEAS_140","Delta_CDE",TRUE,-0.0014570632967755,0.283582089552239,0.863330406789582,1,FALSE
"FEAS_141","Delta_CDE",TRUE,0.00100612324189422,0.159203980099502,0.863330406789582,1,FALSE
"FEAS_142","Delta_CDE",TRUE,0.00123446798971761,0.208955223880597,0.863330406789582,1,FALSE
"FEAS_143","Delta_CDE",TRUE,0.000931970070741413,0.0895522388059701,0.863330406789582,1,TRUE
"FEAS_144","Delta_CDE",TRUE,0.000113966663820143,0.90547263681592,1,1,FALSE
"FEAS_145","Delta_CDE",TRUE,0.000484314019667213,0.243781094527363,0.863330406789582,1,FALSE
"FEAS_146","Delta_CDE",TRUE,0.00100612324189422,0.159203980099502,0.863330406789582,1,FALSE
"FEAS_147","Delta_CDE",TRUE,0.00123446798971761,0.208955223880597,0.863330406789582,1,FALSE
"FEAS_148","Delta_CDE",TRUE,0.000931970070741413,0.0895522388059701,0.863330406789582,1,FALSE
"FEAS_149","Delta_CDE",TRUE,0.000113966663820143,0.90547263681592,1,1,FALSE
"FEAS_150","Delta_CDE",TRUE,0.000484314019667213,0.243781094527363,0.863330406789582,1,FALSE


## FROZEN_CANDIDATES.csv
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/FROZEN_CANDIDATES.csv

"spec_id","data_support_id","x","m","y","n","clusters","astar","a","mval0","mval1","mreg","yreg","outcome_scale","contrast_in_marginal_range","support_note","sample_sha256","equivalent_m_family","adjustment","time_structure","stage","B_screen","B_verify","parent_spec_id","parent_n","parent_clusters","excluded_n","excluded_fraction","signature","equivalence_group"
"FEAS_003","DATA_003","abs_log1p_10k","self_increase_eligible","support_increase",2991,1277,-0.178315297631551,0.331800575600202,0,1,"logistic","logistic","ratio_log_for_testing",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","4aa4d24c970d203bf9e955542ed415d91cc18f1207158521616aeda2c3cba686","self_increase_eligible","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_003",4096,1641,1105,0.269775390625,"373cff7439204be5a739610c7176510a4b30de64d0422fac9b6c19e692e8ceb3",3
"FEAS_004","DATA_004","rel_transition_eligible","self_increase_eligible","support_increase",2654,1248,0,1,0,1,"logistic","logistic","ratio_log_for_testing",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","f0fde36b712cffa66f97125da0b4203f61b48d415fc5e4b2f856b696c0eeade6","self_increase_eligible","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_004",2654,1248,0,0,"18cfb9884b63ac3305bcfdaced00dfa36cf9462603702ba27c0a0a722d57eec7",4
"FEAS_031","DATA_031","abs_increase","self_relative_transition","support_increase",9879,2939,0,1,0,1,"logistic","logistic","ratio_log_for_testing",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","7807b60590eea3cf4b13d3bb985a394bdb77939de7c28239310b242e62e441dc","self_relative_transition","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_031",9879,2939,0,0,"1ddb2cd3289e3125755672e9b8b45bca29e1a03d0c623ffd31f6f571bcc3b2f5",31
"FEAS_041","DATA_041","abs_increase","self_relative_gap_diff","support_increase",12564,3149,0,1,0,1,"linear","logistic","ratio_log_for_testing",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732","relative_gap_sign_pair","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_041",12625,3151,61,0.00483168316831683,"1b4315364fca6f90fbd3c9284fc71f47323b5321a50660e6f0199b4b18fb424f",41
"FEAS_060","DATA_060","rel_share_diff","spouse_increase_eligible","support_diff_10k",2698,1140,-0.0952380952380952,0.094481981981982,0,1,"logistic","linear","difference",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","46cfb5b6adb99a5d9a1dd7345f78b1b9dae3f089b858ededbac7edd97d99543e","spouse_increase_eligible","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_060",4028,1573,1330,0.330188679245283,"4788be7113004532a47a709a056bbb170d21ade2b8852deb8b13ed9237305f59",60
"FEAS_091","DATA_091","abs_increase","self_relative_gap_diff","support_diff_10k",12564,3149,0,1,0,1,"linear","linear","difference",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","fb71bce2db3c1bd6a45fe169a20456659d76e440c622be4a94466f976541f732","relative_gap_sign_pair","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_091",12625,3151,61,0.00483168316831683,"8139becd9999351e6e49e6d366e392855a4014fc44edf277404d205331587496",91
"FEAS_092","DATA_092","abs_diff_10k","self_relative_gap_diff","support_diff_10k",8417,2538,-0.593056894889103,1.27062842999159,0,1,"linear","linear","difference",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c","relative_gap_sign_pair","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_092",12625,3151,4208,0.333306930693069,"900e8712ab0fffaf5330388f521c01ed5a692244caa57f350779a5105bada7ec",92
"FEAS_093","DATA_093","abs_log1p_10k","self_relative_gap_diff","support_diff_10k",9295,2701,-0.178315297631551,0.331800575600202,0,1,"linear","linear","difference",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889","relative_gap_sign_pair","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_093",12625,3151,3330,0.263762376237624,"193b5eb35baf97be353dbd4787b4a64b849428ec88dd1b4a519ef9fa40470af7",93
"FEAS_107","DATA_107","abs_diff_10k","spouse_increase_eligible","support_log1p_10k",2875,1211,-0.593056894889103,1.27062842999159,0,1,"logistic","linear","difference",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","8db95d04183e99d83fe9434f57b6f61fb77aa0bb88c1a338ebcdf45f2a3bb94a","spouse_increase_eligible","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_107",4028,1573,1153,0.286246276067527,"d0da47232f503dbad5c13c974cf4464972b256ca81e957a2e1d305b2f4719f43",107
"FEAS_142","DATA_142","abs_diff_10k","self_relative_gap_diff","support_log1p_10k",8417,2538,-0.593056894889103,1.27062842999159,0,1,"linear","linear","difference",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","b177c6ed2638d1655a0c31432aeab3365b256da2d9e7dea769a5288ae6e2fe4c","relative_gap_sign_pair","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_142",12625,3151,4208,0.333306930693069,"403db57750e4dae9054ba2bdbad2d0e669d23c263ccbd6f128ba06fbb892720d",142
"FEAS_143","DATA_143","abs_log1p_10k","self_relative_gap_diff","support_log1p_10k",9295,2701,-0.178315297631551,0.331800575600202,0,1,"linear","linear","difference",TRUE,"Necessary endpoint bounds passed; conditional support, intervention versions and natural mediator simulation remain separate","06a8ed3711bd916667f822cc9540e6d12a75b5ef829bd7be6405263cfeaaa889","relative_gap_sign_pair","fixed23_baseline","concurrent_two_year_changes","FEASIBLE_BASELINE_POPULATION_REGISTERED_NOT_ADMITTED",200,1000,"CORE_143",12625,3151,3330,0.263762376237624,"7c21c45d1426f5b2b1d73b93c305b88ae6ec4ec412d8e10a7cc40bbd06c589de",143


## STABILITY.csv
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/STABILITY.csv

"spec_id","metric","eligible","rankable","same_sign_fraction","fixed_se_selection_frequency","median_within_y_rank"
"FEAS_001","TNIE",TRUE,TRUE,0.44,0.07,22
"FEAS_002","TNIE",TRUE,TRUE,0.505,0.085,20
"FEAS_003","TNIE",TRUE,TRUE,0.47,0.06,21
"FEAS_004","TNIE",TRUE,TRUE,0.815,0.165,14
"FEAS_005","TNIE",TRUE,TRUE,0.54,0.065,19
"FEAS_006","TNIE",TRUE,TRUE,0.655,0.095,17
"FEAS_007","TNIE",TRUE,TRUE,0.5,0.065,22
"FEAS_008","TNIE",TRUE,TRUE,0.51,0.06,19.5
"FEAS_009","TNIE",TRUE,TRUE,0.52,0.1,19
"FEAS_010","TNIE",TRUE,TRUE,0.525,0.095,22
"FEAS_011","TNIE",TRUE,TRUE,0.44,0,22
"FEAS_012","TNIE",TRUE,TRUE,0.505,0,20
"FEAS_013","TNIE",TRUE,TRUE,0.47,0,21
"FEAS_014","TNIE",TRUE,TRUE,0.815,0,14
"FEAS_015","TNIE",TRUE,TRUE,0.54,0,19
"FEAS_016","TNIE",TRUE,TRUE,0.655,0,17
"FEAS_017","TNIE",TRUE,TRUE,0.5,0,22
"FEAS_018","TNIE",TRUE,TRUE,0.51,0,19.5
"FEAS_019","TNIE",TRUE,TRUE,0.52,0,19
"FEAS_020","TNIE",TRUE,TRUE,0.525,0,22
"FEAS_021","TNIE",FALSE,FALSE,,,
"FEAS_022","TNIE",FALSE,FALSE,,,
"FEAS_023","TNIE",FALSE,FALSE,,,
"FEAS_024","TNIE",FALSE,FALSE,,,
"FEAS_025","TNIE",FALSE,FALSE,,,
"FEAS_026","TNIE",FALSE,FALSE,,,
"FEAS_027","TNIE",FALSE,FALSE,,,
"FEAS_028","TNIE",FALSE,FALSE,,,
"FEAS_029","TNIE",FALSE,FALSE,,,
"FEAS_030","TNIE",FALSE,FALSE,,,
"FEAS_031","TNIE",TRUE,TRUE,0.47,0.08,20
"FEAS_032","TNIE",TRUE,TRUE,0.385,0.07,23
"FEAS_033","TNIE",TRUE,TRUE,0.395,0.07,20
"FEAS_034","TNIE",TRUE,TRUE,0.615,0.075,21
"FEAS_035","TNIE",TRUE,TRUE,0.535,0.09,25
"FEAS_036","TNIE",TRUE,TRUE,0.385,0.08,17
"FEAS_037","TNIE",TRUE,TRUE,0.59,0.055,18
"FEAS_038","TNIE",TRUE,TRUE,0.485,0.065,24
"FEAS_039","TNIE",TRUE,TRUE,0.7,0.095,24.5
"FEAS_040","TNIE",TRUE,TRUE,0.49,0.09,23.5
"FEAS_041","TNIE",TRUE,TRUE,0.65,0.01,19
"FEAS_042","TNIE",TRUE,TRUE,0.635,0.035,19
"FEAS_043","TNIE",TRUE,TRUE,0.51,0.03,22
"FEAS_044","TNIE",TRUE,TRUE,0.595,0.06,22
"FEAS_045","TNIE",TRUE,TRUE,0.6,0.055,19.5
"FEAS_046","TNIE",TRUE,TRUE,0.65,0.055,19
"FEAS_047","TNIE",TRUE,TRUE,0.635,0.035,19
"FEAS_048","TNIE",TRUE,TRUE,0.51,0.025,23
"FEAS_049","TNIE",TRUE,TRUE,0.595,0.035,22
"FEAS_050","TNIE",TRUE,TRUE,0.6,0.03,19
"FEAS_051","TNIE",TRUE,TRUE,0.385,0.06,20
"FEAS_052","TNIE",TRUE,TRUE,0.55,0.105,20
"FEAS_053","TNIE",TRUE,TRUE,0.45,0.075,21
"FEAS_054","TNIE",TRUE,TRUE,0.595,0.095,19
"FEAS_055","TNIE",TRUE,TRUE,0.515,0.055,23
"FEAS_056","TNIE",TRUE,TRUE,0.55,0.085,19
"FEAS_057","TNIE",TRUE,TRUE,0.615,0.095,20.5
"FEAS_058","TNIE",TRUE,TRUE,0.555,0.08,18
"FEAS_059","TNIE",TRUE,TRUE,0.445,0.06,21
"FEAS_060","TNIE",TRUE,TRUE,0.505,0.09,21
"FEAS_061","TNIE",TRUE,TRUE,0.385,0,20
"FEAS_062","TNIE",TRUE,TRUE,0.55,0,20
"FEAS_063","TNIE",TRUE,TRUE,0.45,0,21
"FEAS_064","TNIE",TRUE,TRUE,0.595,0,19
"FEAS_065","TNIE",TRUE,TRUE,0.515,0,23
"FEAS_066","TNIE",TRUE,TRUE,0.55,0,19
"FEAS_067","TNIE",TRUE,TRUE,0.615,0,20.5
"FEAS_068","TNIE",TRUE,TRUE,0.555,0,18
"FEAS_069","TNIE",TRUE,TRUE,0.445,0,21
"FEAS_070","TNIE",TRUE,TRUE,0.505,0,21
"FEAS_071","TNIE",FALSE,FALSE,,,
"FEAS_072","TNIE",FALSE,FALSE,,,
"FEAS_073","TNIE",FALSE,FALSE,,,
"FEAS_074","TNIE",FALSE,FALSE,,,
"FEAS_075","TNIE",FALSE,FALSE,,,
"FEAS_076","TNIE",FALSE,FALSE,,,
"FEAS_077","TNIE",FALSE,FALSE,,,
"FEAS_078","TNIE",FALSE,FALSE,,,
"FEAS_079","TNIE",FALSE,FALSE,,,
"FEAS_080","TNIE",FALSE,FALSE,,,
"FEAS_081","TNIE",TRUE,TRUE,0.525,0.055,22
"FEAS_082","TNIE",TRUE,TRUE,0.42,0.06,22
"FEAS_083","TNIE",TRUE,TRUE,0.4,0.045,22.5
"FEAS_084","TNIE",TRUE,TRUE,0.585,0.085,22
"FEAS_085","TNIE",TRUE,TRUE,0.46,0.045,23
"FEAS_086","TNIE",TRUE,TRUE,0.49,0.11,22
"FEAS_087","TNIE",TRUE,TRUE,0.43,0.09,20.5
"FEAS_088","TNIE",TRUE,TRUE,0.55,0.05,23
"FEAS_089","TNIE",TRUE,TRUE,0.595,0.09,23
"FEAS_090","TNIE",TRUE,TRUE,0.525,0.06,24
"FEAS_091","TNIE",TRUE,TRUE,0.695,0.06,17
"FEAS_092","TNIE",TRUE,TRUE,0.78,0.06,15
"FEAS_093","TNIE",TRUE,TRUE,0.665,0.04,16
"FEAS_094","TNIE",TRUE,TRUE,0.46,0.025,21
"FEAS_095","TNIE",TRUE,TRUE,0.575,0.05,19.5
"FEAS_096","TNIE",TRUE,TRUE,0.695,0.04,16.5
"FEAS_097","TNIE",TRUE,TRUE,0.78,0.12,14
"FEAS_098","TNIE",TRUE,TRUE,0.665,0.045,16
"FEAS_099","TNIE",TRUE,TRUE,0.46,0.05,21
"FEAS_100","TNIE",TRUE,TRUE,0.575,0.02,20
"FEAS_101","TNIE",TRUE,TRUE,0.385,0.055,20
"FEAS_102","TNIE",TRUE,TRUE,0.555,0.095,20
"FEAS_103","TNIE",TRUE,TRUE,0.45,0.075,21
"FEAS_104","TNIE",TRUE,TRUE,0.62,0.105,19
"FEAS_105","TNIE",TRUE,TRUE,0.51,0.07,22
"FEAS_106","TNIE",TRUE,TRUE,0.57,0.09,20
"FEAS_107","TNIE",TRUE,TRUE,0.6,0.095,21
"FEAS_108","TNIE",TRUE,TRUE,0.445,0.085,18
"FEAS_109","TNIE",TRUE,TRUE,0.48,0.07,20
"FEAS_110","TNIE",TRUE,TRUE,0.49,0.09,21
"FEAS_111","TNIE",TRUE,TRUE,0.385,0,20
"FEAS_112","TNIE",TRUE,TRUE,0.555,0,20
"FEAS_113","TNIE",TRUE,TRUE,0.45,0,21
"FEAS_114","TNIE",TRUE,TRUE,0.62,0,19
"FEAS_115","TNIE",TRUE,TRUE,0.51,0,22
"FEAS_116","TNIE",TRUE,TRUE,0.57,0,20
"FEAS_117","TNIE",TRUE,TRUE,0.6,0,21
"FEAS_118","TNIE",TRUE,TRUE,0.445,0,18
"FEAS_119","TNIE",TRUE,TRUE,0.48,0,20
"FEAS_120","TNIE",TRUE,TRUE,0.49,0,21
"FEAS_121","TNIE",FALSE,FALSE,,,
"FEAS_122","TNIE",FALSE,FALSE,,,
"FEAS_123","TNIE",FALSE,FALSE,,,
"FEAS_124","TNIE",FALSE,FALSE,,,
"FEAS_125","TNIE",FALSE,FALSE,,,
"FEAS_126","TNIE",FALSE,FALSE,,,
"FEAS_127","TNIE",FALSE,FALSE,,,
"FEAS_128","TNIE",FALSE,FALSE,,,
"FEAS_129","TNIE",FALSE,FALSE,,,
"FEAS_130","TNIE",FALSE,FALSE,,,
"FEAS_131","TNIE",TRUE,TRUE,0.525,0.055,22
"FEAS_132","TNIE",TRUE,TRUE,0.475,0.07,24
"FEAS_133","TNIE",TRUE,TRUE,0.425,0.055,22.5
"FEAS_134","TNIE",TRUE,TRUE,0.565,0.085,21
"FEAS_135","TNIE",TRUE,TRUE,0.47,0.055,23
"FEAS_136","TNIE",TRUE,TRUE,0.495,0.095,20
"FEAS_137","TNIE",TRUE,TRUE,0.455,0.08,21
"FEAS_138","TNIE",TRUE,TRUE,0.55,0.05,23
"FEAS_139","TNIE",TRUE,TRUE,0.615,0.085,23
"FEAS_140","TNIE",TRUE,TRUE,0.53,0.07,22
"FEAS_141","TNIE",TRUE,TRUE,0.695,0.07,17
"FEAS_142","TNIE",TRUE,TRUE,0.765,0.105,15
"FEAS_143","TNIE",TRUE,TRUE,0.65,0.045,15.5
"FEAS_144","TNIE",TRUE,TRUE,0.44,0.055,21
"FEAS_145","TNIE",TRUE,TRUE,0.55,0.025,20
"FEAS_146","TNIE",TRUE,TRUE,0.695,0.04,17
"FEAS_147","TNIE",TRUE,TRUE,0.765,0.05,15.5
"FEAS_148","TNIE",TRUE,TRUE,0.65,0.035,15.5
"FEAS_149","TNIE",TRUE,TRUE,0.44,0.015,21
"FEAS_150","TNIE",TRUE,TRUE,0.55,0.03,19
"FEAS_001","Delta_CDE",TRUE,TRUE,0.505,0,25
"FEAS_002","Delta_CDE",TRUE,TRUE,0.635,0.01,25
"FEAS_003","Delta_CDE",TRUE,TRUE,0.775,0.04,22
"FEAS_004","Delta_CDE",TRUE,TRUE,0.95,0.1,17
"FEAS_005","Delta_CDE",TRUE,TRUE,0.945,0.14,11
"FEAS_006","Delta_CDE",TRUE,TRUE,0.955,0.12,10
"FEAS_007","Delta_CDE",TRUE,TRUE,0.815,0.04,21
"FEAS_008","Delta_CDE",TRUE,TRUE,0.58,0.005,25.5
"FEAS_009","Delta_CDE",TRUE,TRUE,0.75,0.03,23
"FEAS_010","Delta_CDE",TRUE,TRUE,0.855,0.04,17.5
"FEAS_011","Delta_CDE",TRUE,TRUE,0.505,0,25
"FEAS_012","Delta_CDE",TRUE,TRUE,0.635,0,25
"FEAS_013","Delta_CDE",TRUE,TRUE,0.775,0,22
"FEAS_014","Delta_CDE",TRUE,TRUE,0.95,0,17
"FEAS_015","Delta_CDE",TRUE,TRUE,0.945,0,11
"FEAS_016","Delta_CDE",TRUE,TRUE,0.955,0,10
"FEAS_017","Delta_CDE",TRUE,TRUE,0.815,0,21
"FEAS_018","Delta_CDE",TRUE,TRUE,0.58,0,25.5
"FEAS_019","Delta_CDE",TRUE,TRUE,0.75,0,23
"FEAS_020","Delta_CDE",TRUE,TRUE,0.855,0,17.5
"FEAS_021","Delta_CDE",FALSE,FALSE,,,
"FEAS_022","Delta_CDE",FALSE,FALSE,,,
"FEAS_023","Delta_CDE",FALSE,FALSE,,,
"FEAS_024","Delta_CDE",FALSE,FALSE,,,
"FEAS_025","Delta_CDE",FALSE,FALSE,,,
"FEAS_026","Delta_CDE",FALSE,FALSE,,,
"FEAS_027","Delta_CDE",FALSE,FALSE,,,
"FEAS_028","Delta_CDE",FALSE,FALSE,,,
"FEAS_029","Delta_CDE",FALSE,FALSE,,,
"FEAS_030","Delta_CDE",FALSE,FALSE,,,
"FEAS_031","Delta_CDE",TRUE,TRUE,1,0.74,1
"FEAS_032","Delta_CDE",TRUE,TRUE,0.83,0.055,23
"FEAS_033","Delta_CDE",TRUE,TRUE,0.845,0.025,19
"FEAS_034","Delta_CDE",TRUE,TRUE,0.905,0.075,15
"FEAS_035","Delta_CDE",TRUE,TRUE,0.68,0.01,26
"FEAS_036","Delta_CDE",TRUE,TRUE,0.985,0.205,8
"FEAS_037","Delta_CDE",TRUE,TRUE,0.71,0.03,25
"FEAS_038","Delta_CDE",TRUE,TRUE,0.465,0.01,28
"FEAS_039","Delta_CDE",TRUE,TRUE,0.625,0.02,28
"FEAS_040","Delta_CDE",TRUE,TRUE,0.515,0,25
"FEAS_041","Delta_CDE",TRUE,TRUE,0.99,0.22,6
"FEAS_042","Delta_CDE",TRUE,TRUE,0.72,0.045,25
"FEAS_043","Delta_CDE",TRUE,TRUE,0.7,0.02,21
"FEAS_044","Delta_CDE",TRUE,TRUE,0.635,0,26
"FEAS_045","Delta_CDE",TRUE,TRUE,0.695,0.02,23
"FEAS_046","Delta_CDE",TRUE,TRUE,0.99,0,6
"FEAS_047","Delta_CDE",TRUE,TRUE,0.72,0,25
"FEAS_048","Delta_CDE",TRUE,TRUE,0.7,0,21
"FEAS_049","Delta_CDE",TRUE,TRUE,0.635,0,26
"FEAS_050","Delta_CDE",TRUE,TRUE,0.695,0,23
"FEAS_051","Delta_CDE",TRUE,TRUE,0.655,0.03,23
"FEAS_052","Delta_CDE",TRUE,TRUE,0.73,0.105,14
"FEAS_053","Delta_CDE",TRUE,TRUE,0.575,0.01,23
"FEAS_054","Delta_CDE",TRUE,TRUE,0.695,0.05,23
"FEAS_055","Delta_CDE",TRUE,TRUE,0.84,0.1,18
"FEAS_056","Delta_CDE",TRUE,TRUE,0.89,0.205,15
"FEAS_057","Delta_CDE",TRUE,TRUE,0.875,0.225,13
"FEAS_058","Delta_CDE",TRUE,TRUE,0.615,0.02,23
"FEAS_059","Delta_CDE",TRUE,TRUE,0.625,0.05,24.5
"FEAS_060","Delta_CDE",TRUE,TRUE,0.86,0.16,16
"FEAS_061","Delta_CDE",TRUE,TRUE,0.655,0,23
"FEAS_062","Delta_CDE",TRUE,TRUE,0.73,0,14
"FEAS_063","Delta_CDE",TRUE,TRUE,0.575,0,23
"FEAS_064","Delta_CDE",TRUE,TRUE,0.695,0,23
"FEAS_065","Delta_CDE",TRUE,TRUE,0.84,0,18
"FEAS_066","Delta_CDE",TRUE,TRUE,0.89,0,15
"FEAS_067","Delta_CDE",TRUE,TRUE,0.875,0,13
"FEAS_068","Delta_CDE",TRUE,TRUE,0.615,0,23
"FEAS_069","Delta_CDE",TRUE,TRUE,0.625,0,24.5
"FEAS_070","Delta_CDE",TRUE,TRUE,0.86,0,16
"FEAS_071","Delta_CDE",FALSE,FALSE,,,
"FEAS_072","Delta_CDE",FALSE,FALSE,,,
"FEAS_073","Delta_CDE",FALSE,FALSE,,,
"FEAS_074","Delta_CDE",FALSE,FALSE,,,
"FEAS_075","Delta_CDE",FALSE,FALSE,,,
"FEAS_076","Delta_CDE",FALSE,FALSE,,,
"FEAS_077","Delta_CDE",FALSE,FALSE,,,
"FEAS_078","Delta_CDE",FALSE,FALSE,,,
"FEAS_079","Delta_CDE",FALSE,FALSE,,,
"FEAS_080","Delta_CDE",FALSE,FALSE,,,
"FEAS_081","Delta_CDE",TRUE,TRUE,0.72,0.07,24
"FEAS_082","Delta_CDE",TRUE,TRUE,0.51,0,24
"FEAS_083","Delta_CDE",TRUE,TRUE,0.53,0.02,25
"FEAS_084","Delta_CDE",TRUE,TRUE,0.515,0.04,25
"FEAS_085","Delta_CDE",TRUE,TRUE,0.625,0.045,26
"FEAS_086","Delta_CDE",TRUE,TRUE,0.58,0.025,24
"FEAS_087","Delta_CDE",TRUE,TRUE,0.59,0.04,25
"FEAS_088","Delta_CDE",TRUE,TRUE,0.795,0.05,22
"FEAS_089","Delta_CDE",TRUE,TRUE,0.525,0.015,24
"FEAS_090","Delta_CDE",TRUE,TRUE,0.815,0.07,17
"FEAS_091","Delta_CDE",TRUE,TRUE,0.91,0.17,12
"FEAS_092","Delta_CDE",TRUE,TRUE,0.79,0.095,16.5
"FEAS_093","Delta_CDE",TRUE,TRUE,0.92,0.295,9
"FEAS_094","Delta_CDE",TRUE,TRUE,0.475,0.025,25
"FEAS_095","Delta_CDE",TRUE,TRUE,0.86,0.085,18
"FEAS_096","Delta_CDE",TRUE,TRUE,0.91,0,12
"FEAS_097","Delta_CDE",TRUE,TRUE,0.79,0,16.5
"FEAS_098","Delta_CDE",TRUE,TRUE,0.92,0,9
"FEAS_099","Delta_CDE",TRUE,TRUE,0.475,0,25
"FEAS_100","Delta_CDE",TRUE,TRUE,0.86,0,18
"FEAS_101","Delta_CDE",TRUE,TRUE,0.77,0.055,21
"FEAS_102","Delta_CDE",TRUE,TRUE,0.735,0.075,16
"FEAS_103","Delta_CDE",TRUE,TRUE,0.615,0.015,24
"FEAS_104","Delta_CDE",TRUE,TRUE,0.715,0.045,22.5
"FEAS_105","Delta_CDE",TRUE,TRUE,0.88,0.135,16.5
"FEAS_106","Delta_CDE",TRUE,TRUE,0.91,0.22,14
"FEAS_107","Delta_CDE",TRUE,TRUE,0.915,0.255,12
"FEAS_108","Delta_CDE",TRUE,TRUE,0.745,0.06,22
"FEAS_109","Delta_CDE",TRUE,TRUE,0.47,0.03,25
"FEAS_110","Delta_CDE",TRUE,TRUE,0.825,0.14,18
"FEAS_111","Delta_CDE",TRUE,TRUE,0.77,0,21
"FEAS_112","Delta_CDE",TRUE,TRUE,0.735,0,16
"FEAS_113","Delta_CDE",TRUE,TRUE,0.615,0,24
"FEAS_114","Delta_CDE",TRUE,TRUE,0.715,0,22.5
"FEAS_115","Delta_CDE",TRUE,TRUE,0.88,0,16.5
"FEAS_116","Delta_CDE",TRUE,TRUE,0.91,0,14
"FEAS_117","Delta_CDE",TRUE,TRUE,0.915,0,12
"FEAS_118","Delta_CDE",TRUE,TRUE,0.745,0,22
"FEAS_119","Delta_CDE",TRUE,TRUE,0.47,0,25
"FEAS_120","Delta_CDE",TRUE,TRUE,0.825,0,18
"FEAS_121","Delta_CDE",FALSE,FALSE,,,
"FEAS_122","Delta_CDE",FALSE,FALSE,,,
"FEAS_123","Delta_CDE",FALSE,FALSE,,,
"FEAS_124","Delta_CDE",FALSE,FALSE,,,
"FEAS_125","Delta_CDE",FALSE,FALSE,,,
"FEAS_126","Delta_CDE",FALSE,FALSE,,,
"FEAS_127","Delta_CDE",FALSE,FALSE,,,
"FEAS_128","Delta_CDE",FALSE,FALSE,,,
"FEAS_129","Delta_CDE",FALSE,FALSE,,,
"FEAS_130","Delta_CDE",FALSE,FALSE,,,
"FEAS_131","Delta_CDE",TRUE,TRUE,0.7,0.055,25
"FEAS_132","Delta_CDE",TRUE,TRUE,0.49,0,24
"FEAS_133","Delta_CDE",TRUE,TRUE,0.555,0.01,28
"FEAS_134","Delta_CDE",TRUE,TRUE,0.515,0.035,25
"FEAS_135","Delta_CDE",TRUE,TRUE,0.595,0.03,26.5
"FEAS_136","Delta_CDE",TRUE,TRUE,0.525,0.01,25
"FEAS_137","Delta_CDE",TRUE,TRUE,0.61,0.035,25
"FEAS_138","Delta_CDE",TRUE,TRUE,0.785,0.045,23
"FEAS_139","Delta_CDE",TRUE,TRUE,0.485,0.01,24
"FEAS_140","Delta_CDE",TRUE,TRUE,0.815,0.08,18
"FEAS_141","Delta_CDE",TRUE,TRUE,0.895,0.15,13
"FEAS_142","Delta_CDE",TRUE,TRUE,0.805,0.085,16.5
"FEAS_143","Delta_CDE",TRUE,TRUE,0.93,0.335,9
"FEAS_144","Delta_CDE",TRUE,TRUE,0.485,0.015,25.5
"FEAS_145","Delta_CDE",TRUE,TRUE,0.86,0.075,18
"FEAS_146","Delta_CDE",TRUE,TRUE,0.895,0,13
"FEAS_147","Delta_CDE",TRUE,TRUE,0.805,0,16.5
"FEAS_148","Delta_CDE",TRUE,TRUE,0.93,0,9
"FEAS_149","Delta_CDE",TRUE,TRUE,0.485,0,25.5
"FEAS_150","Delta_CDE",TRUE,TRUE,0.86,0,18


## RESULT.json
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/RESULT.json

{
  "status": "PASS_FROZEN_EXPLORATORY_SELECTION",
  "at": "2026-10-05 13:45:05.450763",
  "registered": 150,
  "validated": 120,
  "unsuitable": 30,
  "candidate_ids": ["FEAS_003", "FEAS_004", "FEAS_031", "FEAS_041", "FEAS_060", "FEAS_091", "FEAS_092", "FEAS_093", "FEAS_107", "FEAS_142", "FEAS_143"],
  "new_candidate_B1000_completed": 0,
  "independent_confirmation": false,
  "all_results_retained": true,
  "input_audit": {
    "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/selection_inputs_complete_v1/RESULT.json",
    "sha256": "80c5813a15a15814efd30cd6962418779b01f8661331277286ac53cb5d558977",
    "bytes": 1291
  },
  "selection_code": {
    "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/selection_and_stability_v1.R",
    "sha256": "6539a1c06437ec03e73c890f907a2bac717de9d95651ec79c115f9910e59e11f",
    "bytes": 4435
  },
  "driver": {
    "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/run_final_selection_v1.R",
    "sha256": "c9f61d286c489658f1c48314a33b7e80d50c04bfa75af0b555ca15eefd98e3b0",
    "bytes": 3774
  },
  "artifacts": [
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/SELECTION.rds",
      "sha256": "ba6ae159e1cb07a2ea48a9fd615cabd3b5b39e1599603d831de84a204f3b01d3",
      "bytes": 21520
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/ALL_300_ADJUSTED.csv",
      "sha256": "d892e85dbd0efb085f8d70ec9b8de2959b91dc6fedb548ad87fc4a97cecb9b6e",
      "bytes": 20803
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/STABILITY.csv",
      "sha256": "8eaf2fcd626391f91013d7715de0b2d6a9989f754a8c7f1f0d15ed0682d27660",
      "bytes": 12688
    },
    {
      "path": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/final_selection_v1/FROZEN_CANDIDATES.csv",
      "sha256": "c4325b5001c796adc75576dde287a1fc4f0bac235dfd8a1b7a4a2a58ce28c8dd",
      "bytes": 7047
    }
  ]
}


## SPECIFICATION_DECISIONS.csv
来源：/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/continuousM_adjudication_v2/SPECIFICATION_DECISIONS.csv

spec_id,mediator,status,reason,expected_tail_min,expected_tail_max,max_individual_tail,effect_estimated
FEAS_021,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.142072909428807,0.14239666156483,0.416495243518403,False
FEAS_022,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134470229050362,0.134687401173608,0.397685477119559,False
FEAS_023,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134760288584694,0.13629073423078,0.436430720932406,False
FEAS_024,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.119876024221086,0.141740229248677,0.433307426272527,False
FEAS_025,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134934315150451,0.135394091174737,0.420498122935998,False
FEAS_026,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.144503666233663,0.144581471861324,0.359107061614228,False
FEAS_027,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.131930824709796,0.133561603094232,0.366694601651319,False
FEAS_028,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.137328391769156,0.137509155773641,0.369697480138396,False
FEAS_029,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.160315110839926,0.167485499394195,0.397360868161265,False
FEAS_030,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.138954031027438,0.140294482811706,0.345946039490351,False
FEAS_041,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000234895966029465,0.000235499872680156,0.00901845170195361,False
FEAS_042,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000159721585602673,0.000159731703051076,0.0108109273842716,False
FEAS_043,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000174126920358759,0.00017425863574695,0.0107709780168278,False
FEAS_044,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000248532773954439,0.000262520504418518,0.00983008469051477,False
FEAS_045,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000210474131099423,0.000211215181074046,0.0103070275184752,False
FEAS_046,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000234895966029465,0.000235499872680156,0.00901845170195361,False
FEAS_047,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000159721585602673,0.000159731703051076,0.0108109273842716,False
FEAS_048,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000174126920358759,0.00017425863574695,0.0107709780168278,False
FEAS_049,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000248532773954439,0.000262520504418518,0.00983008469051477,False
FEAS_050,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000210474131099423,0.000211215181074046,0.0103070275184752,False
FEAS_071,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.142072909428807,0.14239666156483,0.416495243518403,False
FEAS_072,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134470229050362,0.134687401173608,0.397685477119559,False
FEAS_073,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134760288584694,0.13629073423078,0.436430720932406,False
FEAS_074,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.119876024221086,0.141740229248677,0.433307426272527,False
FEAS_075,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134934315150451,0.135394091174737,0.420498122935998,False
FEAS_076,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.144503666233663,0.144581471861324,0.359107061614228,False
FEAS_077,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.131930824709796,0.133561603094232,0.366694601651319,False
FEAS_078,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.137328391769156,0.137509155773641,0.369697480138396,False
FEAS_079,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.160315110839926,0.167485499394195,0.397360868161265,False
FEAS_080,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.138954031027438,0.140294482811706,0.345946039490351,False
FEAS_091,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000234895966029465,0.000235499872680156,0.00901845170195361,False
FEAS_092,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000159721585602673,0.000159731703051076,0.0108109273842716,False
FEAS_093,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000174126920358759,0.00017425863574695,0.0107709780168278,False
FEAS_094,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000248532773954439,0.000262520504418518,0.00983008469051477,False
FEAS_095,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000210474131099423,0.000211215181074046,0.0103070275184752,False
FEAS_096,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000234895966029465,0.000235499872680156,0.00901845170195361,False
FEAS_097,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000159721585602673,0.000159731703051076,0.0108109273842716,False
FEAS_098,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000174126920358759,0.00017425863574695,0.0107709780168278,False
FEAS_099,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000248532773954439,0.000262520504418518,0.00983008469051477,False
FEAS_100,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000210474131099423,0.000211215181074046,0.0103070275184752,False
FEAS_121,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.142072909428807,0.14239666156483,0.416495243518403,False
FEAS_122,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134470229050362,0.134687401173608,0.397685477119559,False
FEAS_123,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134760288584694,0.13629073423078,0.436430720932406,False
FEAS_124,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.119876024221086,0.141740229248677,0.433307426272527,False
FEAS_125,self_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.134934315150451,0.135394091174737,0.420498122935998,False
FEAS_126,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.144503666233663,0.144581471861324,0.359107061614228,False
FEAS_127,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.131930824709796,0.133561603094232,0.366694601651319,False
FEAS_128,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.137328391769156,0.137509155773641,0.369697480138396,False
FEAS_129,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.160315110839926,0.167485499394195,0.397360868161265,False
FEAS_130,spouse_score_diff,UNSUITABLE_REGISTERED_UNBOUNDED_GAUSSIAN,Substantial fitted Gaussian mass outside baseline-dependent legal scale; no truncation or bootstrap execution,0.138954031027438,0.140294482811706,0.345946039490351,False
FEAS_141,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000234895966029465,0.000235499872680156,0.00901845170195361,False
FEAS_142,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000159721585602673,0.000159731703051076,0.0108109273842716,False
FEAS_143,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000174126920358759,0.00017425863574695,0.0107709780168278,False
FEAS_144,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000248532773954439,0.000262520504418518,0.00983008469051477,False
FEAS_145,self_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000210474131099423,0.000211215181074046,0.0103070275184752,False
FEAS_146,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000234895966029465,0.000235499872680156,0.00901845170195361,False
FEAS_147,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000159721585602673,0.000159731703051076,0.0108109273842716,False
FEAS_148,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000174126920358759,0.00017425863574695,0.0107709780168278,False
FEAS_149,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000248532773954439,0.000262520504418518,0.00983008469051477,False
FEAS_150,spouse_relative_gap_diff,ADMITTED_MODEL_BASED_EXPLORATION_NOT_CAUSALLY_IDENTIFIED,"Small but nonzero Gaussian leakage across frozen resamples; retain as model-based exploratory approximation with joint-intervention/version and temporal-order limitations; no clipping, recoding or p-driven selection",0.000210474131099423,0.000211215181074046,0.0103070275184752,False

