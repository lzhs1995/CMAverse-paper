# 新版 v4 本地核查接续

本记录仅为数据/代码核查，不是新版估计结果或NLM共识。旧六项B=1000仍未启动。

## 已实际执行

- 原RStudio PID89434中解析云端原函数成功；MASS、digest、jsonlite、haven、sandwich、ordinal可用。
- 私有audit_guards_v1.R及test_audit_guards_v1.R已在该会话执行，12项合成对象/文件保护测试通过，见GUARD_TEST_RESULTS.csv。未改Downloads原件。
- SHA冻结校验、数据与抽样计划绑定、配偶匹配有效分母和歧义标记已作为私有补丁实现。它们尚未替代完整科学冻结合同，NLM裁决文件的内容/身份还须在最终驱动中绑定。
- 原time_test虽模拟Y，却保留真实满意度并拟合中介；已在私有补丁禁用。纯合成计时及完整self_test尚未执行。
- predata_FE_16_22_unbal.dta原始1–5经济满意度提取通过。与目标13092行的dyad_id/period匹配13092/13092；本人基期/期末有效数13085/13085，配偶基期/期末13083/13085。见MSATECO_COVERAGE.csv、msateco_intervals_audit.csv。这证明键覆盖及取值，不独立证明角色映射正确或C3/C4已合格。
- 上游元数据读取首次因R属性部分匹配触发label/labels混淆报错；改用exact=TRUE后读取成功，相关字段无变量标签。原脚本注释支持msateco_c2_为“配偶对本人收入满意度”，仍需交叉身份核对。

## 来源追溯

sources/extracted/v751_empirical/research/20260904_basic_mechanism_v6/scripts/20260904_basic_mechanism_v6.R：
- 202–211行列出上游原字段；261–262行把qf602_a__负数转NA再CPI平减，未读qf601。
- 342–343行生成支持端点；358行附近把上游协变量的区间起点读成_begin。
- 963–982行已记录满意度访谈时点与支持过去半年窗口重叠的限制。因此C同波间接对比不能自动称因果自然间接效应。

sources/extracted/v751_empirical/stata_source_snapshot/20240619 DV_IV_descriptives_2016_2022_unbal.do：
- 5918–5941行附近：child来自各期childnumb，dwm来自downward_mean，不能仅凭_begin判断无未来信息。
- 5946–5948行：ahw来自各期actor_housew；5954–5964行：prtmarr/prtcor来自对应年度状态，fmlincc来自fincome_cpi_ln。就这层重命名而言，它们不是同名的区间变化变量；其上游构造及插补仍需审查。
- 6521–6524行：本人/配偶婚姻、收入满意度角色注释。
- 6796–6800附近：删除原始满意度并用百分位变量同名替换。当前C3/C4不得取替换后数据。

## 待解决后才冻结

1. qf601未保留在本次上游长表；不能从qf602缺失反推是否支持，须继续沿更上游来源核结构性零与项目缺失。
2. 完成23项逐项时间/构造审查与经济满意度角色核查。
3. 支持门槛必须进入驱动；明确有效bootstrap比例不达标的处理；校准补both-zero和簇依赖；纯合成self_test/计时。
4. 给NLM恢复稿PDF、新提案与本地证据，完成新请求后逐条裁决，冻结全部输入SHA、检验/对比分支及预算，再运行新A/B。

本轮最近df可用11578144 KiB（快照，非永久预算）。未执行新上传或删除；前轮已核释放5,867,017,863字节不重做。
