# 当前 Pro v3 与 Claude v4 方法审核材料

这是新一轮方案咨询。旧不同14项已看结果列于末尾，不是本v4结果。主W已由用户确定5对≤3。新版真实模型尚未运行。合成self_test通过只证明运行和特定真值回收，不代表完整零假设校准。控制变量时间属性、原QF601与配偶经济满意度语义仍须核清；请就未决点给有限处理建议。


## 来源：融合方案v2_审阅与定点优化_v3.md
SHA256: c583ed709078c85c59a9cc871da9f9b27ee8198cd0436420146edbb820aa67e9

# Claude融合方案v2审阅与定点优化建议

研究项目：Lu_CMAverse。文件日期标签：2026-10-05。
状态：对已上传方案全文的审阅与新增执行合同建议；不是新实证结果，不是已经冻结的预注册。

## 一、证据范围

已通过GitHub连接器读取 lzhs1995/CMAverse-paper 根目录，确认：

| 文件 | 字节数 | Git blob SHA |
|---|---:|---|
| CMAverse_云端复核资料_20261005_v1_1.zip | 8,919,085 | c7fcaf58f5bc2e31445c8ff6f5d58be81f38b0e9 |
| CMAverse_云端复核资料_20261005_v1_2.zip | 18,028,650 | 6a9e2c0835eb605b67682ac3767df05f22747f86 |

当前GitHub接口不支持这些ZIP的二进制读取；容器下载也未成功。以上仅为远端文件元数据，不是本地ZIP哈希验收。没有读取包内当前150项注册表、当前搜索脚本和逐次结果。因此114/30/6、11项候选、FEAS031最小p及4564条三波二元组等，仍按Claude/Astra报告引用，不称本轮独立复算。

本轮已阅读全文：20261005_ChatGPT-Pro建议对照与融合方案_v2.md；并读取native_accept.docx的相关控制变量、模型和结果来源说明。native_accept.docx作为用户指定的10月5日内容基线，不当作9月8日稿的接受修订副本。

已完成的独立数值检查仅为BH/BY分辨率算术，见audit/。没有拟合CFPS模型，没有运行CMAverse，没有调用NLM/Claude Code，没有修改Word稿。

## 二、总裁定

保留：不扩充旧150笛卡尔网格；基期婚姻状态调节优先；非负期末支持的两部分模型；满意度1—5分有序分布；现有亲属/家庭关联组；原paired-mval、样本/版本与Word资产；全部结果报告。

修改：B200/BH/BY措辞、联合标准误、14项主检验登记、C模块的完整间接对比、D模块的时序和启动门槛、协变量的逐项时间核验、多重比较范围。

不承诺：更换模型或p值算法必然产生显著性；BN次数增加构成独立验证；只要关联显著就能证明因果中介。

## 三、逐项修改融合方案

### 1. B=200限制的是尾计数的分辨率，不是BH/BY普遍无法拒绝

在既定加一公式p=(1+k)/(B+1)下，B=200的最小p为1/201=0.004975。

150项、alpha=.05时：

- BH排序首位阈值为.05/150=.000333333；
- BY排序首位阈值为.05/(150 H150)=.0000596177，H150=5.59118059。

但BH/BY是逐步升阶程序，不是只看第一位。构造例子：15个p都等于1/201，其余为1，BH可拒绝这15项；84个p为1/201，其余为1，BY可拒绝这84项。这些是数学示例，不是当前数据的发现。

替换措辞：B200难以区分少数孤立的很小尾概率；现有拒绝数为0可能受分辨率限制，但不能断言有潜在显著信号被校正程序消除。若q值真为0，那是很强证据；应说“拒绝数为0”，而不是“BH/BY全为0”。

TNIE最小p=.279若复核属实，说明本轮方法下没有原始p<.05的间接证据，不能推断真实中介必为零，也不能将其归因于p下限。

### 2. 解析推断不是绕过校正的方法

A/B的平滑标准化对比可使用聚类稳健协方差与Delta法，但必须估计对应目标量的方差。简单模型系数的聚类SE不是任意非线性合成指标的SE。

主要报告一套一致的估计值、SE、CI和p；整簇bootstrap用于方法对照、区间形状及稳定性，而不是只挑更显著的那一种。

不要把这里“使用Delta法”写成在CMAverse中调用 estimation='imputation', inference='delta'。该组合与历史接口问题不同；新增标准化推断必须由确有支持的后处理/推断程序实现。

中介复合零假设下，Delta正则性和bootstrap校准不能仅由“p值连续”保证。C/D在报告中介显著性之前需复用已有有限测试核验，不能等发现显著候选后才核验。

### 3. 22项只是候选清单，不是已证明合法的调整集

当前跨2016—2022累计的dwm不能作为两区间的纯处理前变量。若没有已验收的逐期来源，新主设定先不含它；旧23项设定称“历史定义对照”，不是同等因果有效的敏感性证据。

检查剩余每一项真实测量时点。native_accept.docx提及的区间变化项、缺失合并、累计状态要按实际新清单核查，不能推断它们一定仍在当前23项中，也不能仅凭_begin后缀宣布基期合格。

新模块还要核对：Y0的调整、本人/配偶S0的调整、时期固定效应、配偶与父母基期信息、固定的缺失规则。去掉dwm不等于除此之外不需要任何模型特定基期项。

模型之间尽可能保持同一数据定义；但A是否提供支持与B金额可观测性不同，不能假定缺失样本完全一致。

### 4. C模块必须有完整间接对比

S1~X+S0+C只估计X—M关系。它不能单独回答中介显著性。

对每个角色先拟合有序概率 p_i(s|a,C), s=1,...,5；结局模型需包含期末焦点满意度S1，而不是直接挪用A/B只包含基期W0的拟合对象。若以两部分均值Q(a,s,C)为结局，则模型化对比为：

    psi(a,a') = average_i sum_{s=1}^5 Q(a,s,C_i) p_i(s|a',C_i)
    I = psi(1,1) - psi(1,0)

有限五类可以直接求和，不需要大量额外中介随机抽样。这是新模型下的标准化间接对比，不是旧CMAverse比率字段的改名。

只有相应无未测量混杂、无未处理暴露诱发中介—结局混杂、时序和一致性等成立时才能给予相应因果名称；缺乏这些条件时按模型化间接关联报告。不能因不传postc而假定处理后混杂消失。

### 5. 有序模型的假设检查

有序logit保持1—5类。检查比例优势假设应针对相同五分类结局，例如合适的非比例项诊断/部分比例优势比较；把五分类重新压成三分类multinomial并不是同一模型假设的直接检验。

ordinal::nominal_test等提供模型诊断工具，但其常规似然比参照分布不会自动适应本研究组内依赖。不要把一次常规LR p值作为唯一自动换模门槛。

事先限定一个诊断处理方案，不按显著性反复切换模型。有序中介本身也不决定Y模型中S应线性还是分类，需冻结相应函数形式。

### 6. D模块不得由第一段显著性决定是否估计中介

删去“仅当第一段有方向性证据时才做中介”的运行门槛。路径诊断可报告，但完整间接对比的估计资格应由设计、支持、变量合法性和可估性决定。

三波X(2018—2020)、S2020、Y2022改善M—Y先后，但不自动解决X—M窗口重叠。

Y2020发生在X变化区间内。将它加入结局模型不能无条件称为处理前控制；这是可能改变估计对象的后处理调整。D主设定优先保留Y2018；如另调Y2020，要单列目标和识别假设。

4564个二元组是报告中的初步可用数，须按身份连续性、同配偶、各角色变量、缺失与聚类重新报告链条特定N，不称4564名独立受访者。

## 四、可执行的14项登记建议（须确认后冻结）

本表是对v2模糊“14项”的建议替代，而不是宣称原表已经包含下述检验。

按v2全局设定保留两种X：

- XA：实际收入是否增加，0对1。
- XL：固定单位的log1p收入变化；建议比较0与其预定总体的75分位正值。对比分位点在新结果出现前固定；若无正值或缺乏支持则标记不可估，不扫描新对比。

W为基期本人/配偶原始QM801评分。主对比建议为4对5，并核查支持；完整1—5曲线可展示，不逐点增加成功判据。选择4对5基于已知上端集中这一测量特征，不因其p值最小。W不是本期收入造成的中介。

| ID | 模块 | X | 角色/状态 | 主要估计量及零假设 |
|---|---|---|---|---|
| A1 | 是否提供支持 | XA | 本人W0 | 概率尺度X对比在W=5与4之间的差=0 |
| A2 | 是否提供支持 | XA | 配偶W0 | 同上 |
| A3 | 是否提供支持 | XL | 本人W0 | 同上 |
| A4 | 是否提供支持 | XL | 配偶W0 | 同上 |
| B1 | 总体支持金额 | XA | 本人W0 | 两部分合成均值上的X对比差=0 |
| B2 | 总体支持金额 | XA | 配偶W0 | 同上 |
| B3 | 总体支持金额 | XL | 本人W0 | 同上 |
| B4 | 总体支持金额 | XL | 配偶W0 | 同上 |
| C1 | 有序M完整间接 | XA | 本人S1，调S0 | 同期两波模型化间接金额对比=0 |
| C2 | 有序M完整间接 | XA | 配偶S1，调S0 | 同上 |
| D1 | 三波间接 | XA18—20 | 本人S2020，Y2022 | 完整滞后间接对比=0 |
| D2 | 三波间接 | XA18—20 | 配偶S2020，Y2022 | 同上 |
| D3 | 三波基期修饰 | XA18—20 | 本人W2018，Y2022 | 基期情景的X对比差=0 |
| D4 | 三波基期修饰 | XA18—20 | 配偶W2018，Y2022 | 同上 |

v2的联合本人/配偶模型、第三个X=x_rel、是否增长Y，不能全部再当主检验而保持14不变。建议联合模型作为预先登记的角色比较辅助；x_rel及原y_growth保留在原150/原八链对应结果中，不自动晋升第三主X。若绝对/相对并列是本轮不可缺少的目的，可以在新结果前用x_rel替换XL并重新固定风险集，但不能两者都追加后仍称14项。

C/D尚未授权或未通过设计资格时标记“预留/未执行”，不是阴性结果。A/B完成后的暂停点用于检查数据、支持与资源，不以p值决定开启哪个新模块。

## 五、A/B的具体模型与目标量

观察单位仍为亲子二元组—区间，聚类使用已经核查的unified_component；它必须为有效关联组，不因特殊PID把大量无关记录并到一组。聚类改标准误，不改变每条亲子区间等权的点估计对象。

定义正值发生概率pi和正值条件均值nu：

    pi(x,w,c) = Pr(Y1>0 | x,w,c,Y0)
    nu(x,w,c) = E(Y1 | Y1>0,x,w,c,Y0)
    g(x,w,c) = pi(x,w,c) * nu(x,w,c)

第一部分使用Logit；第二部分可预先固定Gamma/log作为非负正值均值模型，并检查拟合与大额影响。若使用log金额OLS，则需正确回转并处理相应不确定性，不能直接exp预测替代均值。

在同一样本、同一协变量分布上：

    T_P(w) = mean[pi(a1,w,C)-pi(a0,w,C)]
    T_Y(w) = mean[g(a1,w,C)-g(a0,w,C)]
    d_P = T_P(5)-T_P(4)
    d_Y = T_Y(5)-T_Y(4)

A检验d_P，单位百分点；B检验d_Y，单位实际月均支持金额。X主对比、两部分各自参数、预测曲线完整报告，但不临时拿任意显著系数替代d_P/d_Y。

A与B的第一部分可以复用同一个拟合，仅限样本、公式、权重完全相同。QF601确认未给可产生结构零；确认给但金额不知道不能赋零；A能保留而B无法利用的记录要单独说明。

新Y为期末水平控制基期，是问题的显式扩展，不是简单把差分变量改名后仍声称估计完全相同。收入与期末支持回顾窗口仍重叠，结果的因果解释不因W在基期而自动成立。

## 六、联合不确定性合同

B的参数theta=(alpha,beta)来自概率和正值两个方程。主要对比h(theta)=d_Y的Delta方差为：

    Var(h_hat) ≈ grad(h)' V_joint grad(h)

V_joint需要使用同一关联组的堆叠得分。对不进入正值方程的记录，该方程得分记0，再按组汇总。不能把两个单独vcov无条件拼成块对角矩阵；在相关簇中跨方程协方差可能非零。

C还包含有序中介参数，需同时计入，而不是把拟合中介概率当已知。

若对比按随机目标样本的协变量分布平均，解析方差还要反映经验标准化平均的变化；可通过额外估计方程/影响函数处理。若做固定协变量条件推断，要明确，并不要与每次对抽样数据重新求均值的bootstrap混称同一个方差目标。

已有成熟程序支持所需组合时优先复用；不支持时，使用已验证的整簇重拟合得到相应联合抽样分布，不为取得更小p值而临时选择另一套标准误。主p与CI的来源统一；备用方法只作预定对照。

## 七、多重比较、历史搜索与停止

新14项有一个总的主要探索性检验清单，统一报告BH/BY；模块内调整可另外展示，不只挑最有利的一列。BH的依赖条件不能假定当然满足；BY更保守的同时也要求原始p有效。

A/B中期只报告8项时，可以按已登记14项保留调整分母；未执行C/D在公开结果中标待执行，内部占位不解释为p=1的实证结果。C/D若另立新批次，则明确修订和新增搜索，不能追认原14已完整运行。

旧150项及其11项细化候选独立归档，但必须披露选择来源。只对旧11项再校正不会擦掉旧150项搜索。B1000新随机种子只是数值复核，不是独立样本验证。

新14项也来源于已经看过数据的探索；它们的批内调整不控制整个研究历史的所有自适应选择，不称事前确认性研究。没有无效且未曾分析的数据时，内部划分不能追认成外部确认。

停止规则：A/B完成即交付，不因不显著再换切点、添加第三种X或恢复交叉分组。C/D按事前设计、支持及资源裁定，不以单条路径p过线作资格。确认新结果并完成技术解释前不改写论文主结论。

## 八、论文及协作交付

native_accept.docx保持不动。统计阶段只生成完整结果、图表和研究问题对应表。原8链、150项探索和新增模块分别成套报告；新基期W信号不能写成原满意度增长中介假设获得验证。

NLM负责原稿理论与可估计问题之间的文献对应，主稿绑定当前native_accept的已核对PDF；Claude Code负责实际输入、字段、推断和注册表落实。没有真实提交记录时不称获得它们认可。微观记录无需转发给外部文献咨询。

最小输出：

- analysis_amendment与test_registry，逐项记估计量、对比、样本、family、链接、方差、家族、理论方向。
- sample_flow和variable_role_audit，区分身份、资格、核心缺失、协变量缺失。
- effects_long，全部估计量/区间/p/调整值/运行状态，不显著不删除。
- estimation_manifest，保存加载软件版本、输入哈希、公式、抽样计划和失败记录。
- hypothesis_alignment，区分原假设、新探索、方向相反发现和不能判断。

## 九、外部方法依据（与用户资料区分）

1. R stats：p.adjust官方说明，BH/BY及固定比较数。
2. sandwich：vcovCL官方说明，按簇汇总估计函数的稳健协方差。
3. Belotti, Deb, Manning & Norton (2015), Twopm: Two-Part Models，合并两部分后的预测和边际效应推断。
4. ordinal官方文档：clm、nominal_test及比例优势假设诊断。
5. He, Song & Xu，Adaptive Bootstrap Tests for Composite Null Hypotheses in the Mediation Pathway Analysis，说明简单中介复合零假设下的校准问题；不将其直接当作当前复杂模型的现成验证。
6. Wasserstein & Lazar (2016), The ASA Statement on p-Values，完整报告与p值解释。

上述依据用于本轮审阅意见；不是声称用户文件已经采用或已验证这些实现。


## 来源：20261005_astra本地执行方案_v4.md
SHA256: a681e9be61eb6238f4adb11a8f9fe4920294ebbfd31e809074d6141c2d6bbe9e

# astra 本地执行方案 v4（2026-10-05，取代 v3）

**执行边界**：云端只读取 GitHub 资料包，用 Python 标准库做计数核对，并写方案和代码；没有安装 R，也没有拟合任何模型。配套 R 代码从未运行过。astra 必须先在本机跑通 `self_test()`（只用合成数据），之后才碰真实数据。

**配套文件**（都在 `notes/`）：
- `20261005_test_registry_v4.csv`：检验登记表，共 33 行。主检验 16 行，其中含 2 对条件名额；次级 4 行；稳健性与诊断 12 行；历史 1 行。
- `20261005_astra_v4_functions.R`：全部函数和分步驱动，共 54 个函数。

---

## 一、Pro 的意见是否合理

**总体合理，8 条全部采纳。** 其中 3 条是对 v2 的实质纠错：B200 措辞、Delta 法不能绕开联合不确定性、C 模块缺完整间接对比。2 条是设计纪律：D 模块的门槛，以及“14 项”表述模糊。其余是规范要求。

Pro 写作时打不开 ZIP。下表“核实与落实”一列中的事实，是我在资料包内查到的。

| # | Pro 的意见 | 裁定 | 核实与落实 |
|---|---|---|---|
| 1 | B=200 限制的是尾计数分辨率。应说“拒绝数为 0”，不应说“BH/BY 不可能拒绝” | 采纳 | v3 已写明：BH 至少需要 15 个 p 同时落在 1/201。v4 统一改为“拒绝数为 0，可能受分辨率限制”。新 14 项用 B=2,000，最小 p 为 0.0005，低于 BH 首位门槛 0.0036，也低于 BY 首位门槛 0.0011，分辨率不再限制结论 |
| 2 | 解析推断不能绕开校正。SE 必须对应目标量；两部分模型要有联合方差；标准化平均本身也有变异；不能写成 CMAverse 的 `inference='delta'` | 采纳 | v4 的主推断统一为整簇 bootstrap。每次重抽样都重拟合 logit、Gamma 和有序中介模型，并在重抽样后的协变量分布上重新标准化。因此跨方程协方差、中介模型的不确定性和标准化带来的变异都已计入。主 p 和主 CI 来自同一个中心化分布。Delta（影响函数）只对 A 做预定对照（R8）。新检验不经过 CMAverse |
| 3 | 22 项只是候选清单，要逐项核实测量时点 | 采纳，已核 | build 脚本用 `getv(x, begin)` 取区间起点波次。跨期比较中，只有 dwm、性别、lifetime（2016 年年龄≥40）和父母性别在两期完全相同；后三项本来就是固定特征。dwm 是 2016—2022 年的累计量，主设定剔除；含 dwm 的 23 项版本改称“历史定义对照”（R1）。稿件第 1099 段提到的 prtmarr_1、prtcor_1 是区间变化项，属于旧八链的 Stata 调整集，不在当前 23 项中；当前用的是起点波次的状态值。留给 astra 在原库核对的有三处：约 30 个二元组年龄增量异常；actor_edu2 两期不同的 8.7%；ahw 的含义与波次 |
| 4 | C 模块必须有完整的间接对比 | 采纳 | ψ(a,a') 对有序五类的概率求和，Y 模型包含期末 M（见第四节） |
| 5 | 比例优势检查要在同一个五分类上做；常规 LR 没有考虑聚类；不能用作自动换模门槛 | 采纳 | 主设定固定为比例优势模型，不随诊断结果切换。报告 X 名义效应的 LR，注明未计聚类。部分比例优势模型作为预定稳健性 R11 |
| 6 | D 模块不能以第一段显著为门槛；Y2020 属于处理后变量 | 采纳 | 删除门槛。D 的主设定只调 2018 年支持；加入 2020 年支持的版本单列为 R10，并写明估计对象不同。链条样本量按完整案例重报，不写成“4,564 名独立受访者” |
| 7 | 新 14 项作为一个总清单统一做 BH/BY；旧 150 项的搜索不能被抹掉；不称事前确认 | 采纳 | 主族 n=14。中期只报 A/B 时，分母仍为 14。旧 300 项加新 18 项的合并校正作为参照（m=318）。11 个旧候选单独归档 |
| 8 | 产出清单 | 采纳 | 见第七节 |

Pro 引用但无法独立复算的数字，我已在包内核实如下：
- 最新状态是 120 个规格在 B=200 下完成、30 个不适用（ALL_300_STATUS 中 240 行有效、60 行不适用）。Pro 引用的 114/30/6 是更早的状态。
- ΔCDE 最小 p=0.004975（FEAS_031）；TNIE 最小 p=0.279。
- 两期都在的二元组有 4,564 个；2020 年满意度在两条记录间完全一致。
- unified_component 共 3,212 簇，最大 18 行（占 0.14%），中位 4 行；同一 actor-period 从不跨簇。不存在“特殊 PID 把大量无关记录并成一组”的问题。

## 二、我与 Pro 不同的 4 处（都在看结果之前定死）

1. **W 的主对比用 5 对 ≤3，不用 Pro 建议的 5 对 4。**
   - 推力、拉力假设说的是“满意与否”。对三类有序 W 来说，单自由度的趋势对比正好是 T(5)−T(≤3)。
   - 4↔5 是量表里最不稳定的部分：两期重测相关约 0.40，“提升”事件中有一半是 4→5。≤3 才对应“婚姻困扰”。
   - ≤3 格的支持足够：XA 下最少 757 行，XR 下最少 204 行。
   - 5 对 4 和完整曲线作为 R2 必报。
   - 需要披露：云端看过满意度水平与给钱的粗描述（≤3 与 ≥4 差约 7 个百分点，4 与 5 几乎相同），也看过分性别的粗交互（0—2 个百分点）。没有人算过调整后的 X×W 对比。
   - **如果你想按 Pro 用 5 对 4 作主对比，只能在第 1 步之前换。两者只能有一个是主对比。**
2. **第二种 X 用 XR（夫妻内收入位置升级），替换 Pro 方案里的 XL（log1p 变化）。**
   - XR 是稿件理论的第二个维度（相对资源与议价），原 8 链中有 4 条用它。XL 只是 XA 的函数形式变体。
   - Pro 本身允许“在新结果前用 x_rel 替换 XL，并重新固定风险集”。
   - 风险集固定为“基期本人收入≤配偶”，共 7,989 行，其中取 1 的有 1,601 行。
   - XL 降为 R3。
3. **C/D 的结局用“期末是否给”，不用金额。**
   - 这与 A 对齐，原稿的 Y 也是二元的。
   - 两步链上的金额对比由右尾主导（正值的 p99 为 2,664 元/月，最大值为 44,405 元/月），方差会很大。
   - 金额版作为 R9。
4. **Pro 的 D3/D4（三波基期修饰）换成 C3/C4：以“配偶对本人收入的满意度”（msateco_c2）为中介。**
   - D3/D4 基本就是 A1/A2 换成滞后结局，样本还缩到约三分之一，新增信息少。
   - 诊断已经显示，收入几乎不改变总体婚姻满意度（a 路径≈0）。这是 C1/C2/D1/D2 很难成立的结构性原因。msateco 直接评价本人收入，a 路径在理论上最可能存在，也最贴近稿件的“拉力”机制。
   - msateco 不在资料包里，任何人都没看过它与结局的关系，所以是真正的盲检验。
   - 条件：第 0 步三项数据检查通过才启用，否则 D3/D4 原样替补。判定只看数据可用性，不看任何结局。

另外新增**次级族 S**（4 项，单独做 BH）：
- S1 是 Pro 认可的本人/配偶联合模型角色对比。
- S2—S4 是女儿与儿子之间的世系差异。这是我在诊断阶段看过粗描述后提出的，必须标为“数据启发，只作假设生成”。

**一个必须注意的数据陷阱。** 旧 Stata 流程（20240619 do 文件第 6796—6800 行）把 msat 和 msateco 改写成了年内百分位，这就是 Pro 所说“旧别名尺度不一致”的来源。`identity_target_13092.rds` 里的 msateco_c1/c2 就是百分位版本（13,081 个不同取值），不能用。astra 必须从 v6 读取的同一个上游长表 `predata_FE_16_22_unbal.dta` 中取原始的 1—5 分。

## 三、对 v3 的更正

1. v3 写的是“新模块用 Delta 法加聚类稳健标准误做主检验，bootstrap 只给区间”。撤回，改为统一用 bootstrap（Pro 第 2 条）。
2. v3 以“模块内 BH 为主、合并校正为参照”。改为 14 项一个族为主，BH 与 BY 都报；模块内校正只作展示。
3. v3 的 C 只有 X→M。补上完整的间接对比。
4. v3 的 D 设有“第一段有方向性证据才做中介”的门槛。删除。
5. v3 的 X 次级编码（收入金额变化，单位万元）取消，改为 XR。
6. v2、v3 结尾说不显著“同样是可以发表的结果”。删除。是否可以发表，不由本方案判断。

## 四、检验登记（冻结版以 `test_registry_v4.csv` 为准）

### 通用定义

- **观察单位**：亲子二元组—区间，共 13,092 行。聚类变量为 unified_component。
- **结局**：
  - y1_any：期末是否给父母钱（support_real_end > 0）。
  - y1_amt：期末金额（实际元/月）。
  - 期初支持以 y0_any 和 baseline_support_ihs 两种形式进入协变量。
- **W（修饰变量）**：基期满意度分为三类：≤3 / 4 / 5。本人用 self_sat_begin；配偶用 spouse_sat_begin（配偶本人自评，对接已核实 0 不一致）。
- **M（中介）**：期末满意度。
  - 中介模型用五类有序。
  - Y 模型用三类（≤3/4/5），已冻结。
  - 基期同项 S0 用四类（≤2/3/4/5），因为 1 分和 2 分合计只占约 2%。
- **X**：
  - XA = x_abs（实际年收入增加记为 1）。
  - XR = x_rel，风险集为“基期本人收入≤配偶”；取 1 表示期末本人收入超过配偶。
- **协变量**：
  - COV22 = 23 项去掉 dwm_begin。
  - 焦点满意度从协变量中移出，改由 W 或 S0 因子承担；另加 y0_any。
  - 数值协变量在拟合前标准化。这对线性项的预测没有影响，只为数值稳定：total_debts 的原值最高达 1,015 万元。
- **缺失**：完整案例。A 与 B 共用同一样本和第一部分的拟合。support 起点缺失 109 行、期末缺失 129 行，由 astra 到原始 QF601/QF602 查明原因，并报告其中“确认给了但金额不详”的行数。

### 主族 P（14 项；BH 与 BY，n=14；全部双侧）

| ID | 内容 | 估计量 | 理论方向 |
|---|---|---|---|
| A1 | XA × 本人 W → 期末是否给 | d_P = T_P(5) − T_P(≤3) | −（推力） |
| A2 | XA × 配偶 W → 期末是否给 | 同上 | +（拉力） |
| A3 | XR × 本人 W → 期末是否给 | 同上 | − |
| A4 | XR × 配偶 W → 期末是否给 | 同上 | + |
| B1—B4 | 同 A1—A4，结局为两部分合成金额 | d_Y（元/月） | 同 A |
| C1 | XA → 本人期末满意度 → 是否给 | I = ψ(1,1) − ψ(1,0) | − |
| C2 | XA → 配偶期末满意度 → 是否给 | 同上 | + |
| C3 | XA → 配偶对本人收入的满意度 → 是否给 | 同上 | +（条件启用） |
| C4 | XR → 配偶对本人收入的满意度 → 是否给 | 同上 | +（条件启用） |
| D1 | 三波：XA(2018→20) → 本人 2020 满意度 → 2022 年是否给 | 同上 | − |
| D2 | 三波：XA(2018→20) → 配偶 2020 满意度 → 2022 年是否给 | 同上 | + |
| （D3/D4） | 备用：三波基期修饰，只在 C3/C4 停用时启用 | d_P | −/+ |

公式说明：
- T_P(w) = 样本平均 [π(1,w,C) − π(0,w,C)]，按本分析样本全部协变量的分布平均，即 Pro 所说的“同一协变量分布”。
- ψ(a,a') = 样本平均 Σ_s Q(a,s,C)·P(s | a',C)。
- 同时报告 direct = ψ(1,0)−ψ(0,0)、total、a 路径 logOR 和 b 路径诊断。这些都不作资格门槛。

### 次级族 S（4 项；单独做 BH 与 BY，n=4）

- S1：本人与配偶修饰对比之差（联合模型），理论方向为负。
- S2：XA 总效应，女儿减儿子；方向为正，属数据启发。
- S3、S4：A1、A2 型修饰对比，女儿减儿子；无事先方向，属数据启发。

### 稳健性与诊断（B=500，只报估计和区间，不做发现声明）

- R1：23 项历史定义对照。
- R2：5 对 4 对比与 T 曲线（取自主抽样）。
- R3：XL。
- R4：actor-period 汇总（8,196 行）。
- R5：线性概率模型。
- R6：金额 p99 封顶。
- R7：原结局 y_growth。
- R8：影响函数标准误。
- R9：C/D 改用金额结局。
- R10：D 加入 2020 年支持。
- R11：部分比例优势中介模型。
- PO 诊断。

### 历史 E

原 11 个冻结候选按原登记跑 B=1,000，用 astra 现有脚本，单独归档，不进入任何族。新种子只是数值复核，不是独立验证。

## 五、估计与推断规则

- **一个全局抽样计划**：
  - 3,212 簇 × 2,000 次，种子 20261005，事先生成并保存。
  - 全部主检验和次级检验共用这一计划，因此跨检验的比较有联合分布。
  - 子样本（XR 风险集、三波链）使用同一计划中落在子样本内的簇。
  - 稳健性另用 B=500，种子 20261006。
- **每次重抽样**：重拟合全部模型（logit、Gamma、有序中介），并在重抽样后的协变量分布上重新标准化。失败的重复不补抽。有效重复低于 98% 时标记“推断不稳定”，照常报告。
- **p 与 CI**：
  - p = (1 + #{|t_b − t̂| ≥ |t̂|}) / (B_valid + 1)，与 150 项历史筛选用的是同一公式。
  - 主 CI = t̂ ± q95(|t_b − t̂|)。它与 p 来自同一个中心化分布，所以“p < 0.05”与“主 CI 不含 0”一致。
  - 百分位 CI 另列，只用来看分布形状。
- **多重比较**：
  - 主族用 `p.adjust(p, "BH"/"BY", n = 14)`。未执行的检验标“待执行”，不当作 p=1 的结果来解释。
  - 次级族 n=4。
  - 参照：旧 300 项（150 TNIE + 150 ΔCDE，不适用者按 1 计）加新 18 项，合并做 BH/BY（m=318）。
- **中介检验的合成数据校准**（Pro 第 2、4 条）：
  - 在看 C/D 真实结果之前，用拟合模型生成两类“没有间接效应”的合成数据（a=0 或 b=0），每类 200 套，每套 B=99，统计 p ≤ 0.05 的比例。
  - 共三组：C1（a=0）、D1（a=0）、C3（b=0；C3 停用时改为 C1）。
  - 拒绝率高于 8.1%（0.05 加两个蒙特卡罗标准误）时，在报告中把对应检验标为“可能偏宽松”。
  - 校准只决定解读措辞，不改变检验本身。

## 六、支持与可估性（第 0 步执行，只输出是否达标）

- **A/B**：每个 X×W 格至少 100 行，且 Y>0 的行至少 30 行。只输出最小格是否达标，不输出各格的给钱比例。云端已知（不含结局）：XA×W 最小格 757 行，XR×W 最小格 204 行。
- **C/D**：每个 X 组 × M 三类至少 30 行；三波链完整案例至少 2,000 行。
- **msateco 三项检查**：
  - 取值只有 1—5。
  - 配偶对接 0 不一致；同时用总体满意度做阳性对照，也应为 0。
  - 在 C 的分析样本中非缺失比例至少 80%。
- 不达标的主检验标“不可估（支持不足）”，仍留在 14 的分母里，不替补。C3/C4 例外，因为它的替补规则在看结果之前已经写定。

## 七、astra 的执行步骤

### 第 0 步：不看任何结局比较

1. **环境**：R ≥ 4.2；安装 sandwich、ordinal、haven。把 R 文件和登记表放进资料包根目录。在终端用 `VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 Rscript …` 运行，不要在 RStudio 里并行。
2. **代码自检**：
   - `parse()` 无误。
   - `self_test()` 全部 PASS。它用合成数据检验 d_P、d_Y、间接对比和 a 路径能否回收真值，以及影响函数 SE 与 bootstrap SE 是否同量级。
   - `time_test(d)` 用合成结局计时。
3. **数据断言**：`prep_data()` 的端点断言全部通过。
4. **提取 msateco**：运行 `extract_msateco()`。
   - 从 `predata_FE_16_22_unbal.dta` 读取 pid、year、msateco_c1_、msateco_c2_（2018/2020/2022 三年），负值设为缺失。
   - 按 v6 的区间规则生成 begin/end，写入 `data/msateco_intervals.csv`。
   - 如果读到 0—1 之间的小数，说明拿到的是百分位版本，函数会停止。
5. **数据检查**：运行 `step0_checks(d)`。输出 sample_flow、positivity、variable_role_audit、variable_role_flags、support_missing_rows、msateco 对接检查，以及判定文件 `msateco_decision.txt`。
6. **写合同**：写 `ANALYSIS_AMENDMENT_v4.md`，内容包括本方案第二、四、五、六节，第八节的披露清单，msateco 判定，以及 support 缺失的核查结果。
7. **冻结**：运行 `step0_freeze()`，对登记表、amendment 和判定文件计算 md5，写入 `FREEZE_v4.txt`。此后不再修改。代码会拒绝在冻结之前运行任何真实结局模型。

### 第 1 步

`step1_AB(d)`：A1—A4、B1—B4。

### 第 2 步：技术暂停与中期汇报

- 报告 8 项全部结果，包括不显著的；BH/BY 按 n=14 计算。
- 诊断包括收敛情况、有效重复率、Gamma 拟合与大额影响。
- 这一步只检查数据、支持与资源，不按 p 值决定后续。

### 第 3 步

先运行 `step3a_calibration(d)`。这一步只产生拒绝率，不产生真实的 C/D 估计。然后运行 `step3b_CD(d)`。

### 第 4 步

`step4_S(d)`。

### 第 5 步

`step5_robustness(d)`，其中包括 PO 诊断。

### 第 6 步

`step6_assemble()`，输出 primary_family_P14、secondary_family_S4、joint_scope_318、effects_long、hypothesis_alignment 和 estimation_manifest。astra 另画森林图和 T(w) 曲线。

原 11 个候选（历史 E）可以与第 1 步并行。

### 时间

以 time_test 的结果为准。粗估在 7 核下：
- 主估计加次级族约 1 小时；
- 校准 2—4 小时，可以过夜跑；
- 稳健性约 1 小时。

### 停止规则

- A/B 出结果后，不换切点，不加第三种 X，不恢复交叉分组。
- C/D 按设计执行，不看 A/B 的 p 值。
- 确认结果并完成技术解释之前，不改论文的主结论。
- native_accept.docx 不动。

## 八、披露清单（写进 amendment）

- **云端在登记前看过的描述统计**（未调整，未计聚类）：
  - 满意度水平与给钱：≤3 与 ≥4 相差约 7 个百分点；4 分与 5 分分别为 44.3% 与 44.8%。
  - 收入增加与支持增长的性别差异：女 +5.2 个百分点，男 +0.7 个百分点。
  - 分性别的粗交互为 0—2 个百分点。
  - 收入变化与满意度变化几乎无关。
  - X×W 各格人数。
- **稿件已有结果**：AR-S 加性交互 −8.76 个百分点（q=.032），AR-P +6.82 个百分点（q=.094）。
- 新 14 项仍是看过数据之后的探索，不称事前确认。
- 新检验没有 postc。C/D 若要称为因果中介，还需要“不存在受暴露影响的 M—Y 混杂”等假设；否则按“模型化间接关联”报告。
- 收入的回顾窗口与期末支持重叠；W 虽测于基期，也不自动带来因果解释。

## 九、结果怎么读（hypothesis_alignment）

- **方向符合理论，且 BH(14) 后 q < 0.05**：探索性支持。
- **方向符合，主 CI 不含 0，但没通过校正**：弱证据。
- **主 CI 不含 0，但方向与理论相反**：照实报告为与理论相反的发现。
- **主 CI 含 0**：不能判断，不等于效应为 0；同时报告区间宽度。
- S 族即使通过 n=4 的 BH，也只作假设生成。
- 新的基期 W 信号不能写成“满意度增长的中介假设获得验证”。

## 十、需要你确认或知道的事

1. **W 主对比**：已确认用 5 对 ≤3（Dario 于 2026-10-05 在选择卡上确认）。5 对 4 作为 R2 照常报告，不再更换。
2. **C3/C4**：取决于能否取到 msateco 的原始 1—5 分。取不到就自动换回 D3/D4。
3. **NLM 咨询**：由你在本机进行，主稿绑定 native_accept 的核对版 PDF。没有真实回执的，不写“经其认可”。


## 来源：20261005_test_registry_v4.csv
SHA256: d501fd9ad04e09fc6d3a93a7a40e62454e443910259ab982ccc60a99b9071706

"test_id","family","status_rule","module","label","X","risk_set","W_or_M","outcome","model","estimand_key","estimand","null","theory_direction","theory_basis","covariates","inference","B","seed","multiplicity","notes"
"A1","P14","ALWAYS","A 基期修饰·是否给","XA×本人基期满意度→期末是否给","xa = x_abs（实际年收入增加=1）","全样本完整案例","W = 本人基期满意度三类（≤3/4/5）","y1_any = 1[期末支持>0]","logit: y1_any ~ 协变量 + xa×W","d_P","d_P = T_P(5) − T_P(≤3)；T_P(w) = 样本平均[π(1,w,C) − π(0,w,C)]，单位：概率","d_P = 0","-","推力：本人满意度高时，收入更多留在核心家庭","COV22（23 项去 dwm_begin）去 self_sat_begin，加 y0_any","整簇 bootstrap（unified_component），每次重拟合并重新标准化；p = (1+#|t_b−t̂|≥|t̂|)/(B_valid+1)；主 CI = t̂ ± q95|t_b−t̂|","2000","20261005","BH 与 BY，n = 14","5 对 4 与 T 曲线作 R2 报告"
"A2","P14","ALWAYS","A 基期修饰·是否给","XA×配偶基期满意度→期末是否给","xa = x_abs","全样本完整案例","W = 配偶基期满意度三类（配偶本人自评）","y1_any","logit: y1_any ~ 协变量 + xa×W","d_P","d_P = T_P(5) − T_P(≤3)","d_P = 0","+","拉力：配偶满意度高时，更支持伴侣向父母提供经济支持","COV22 去 spouse_sat_begin，加 y0_any","同 A1","2000","20261005","BH 与 BY，n = 14","同 A1"
"A3","P14","ALWAYS","A 基期修饰·是否给","XR×本人基期满意度→期末是否给","xr = x_rel（期末本人收入超过配偶=1）","基期本人收入≤配偶（7,989 行）完整案例","W = 本人基期满意度三类","y1_any","logit: y1_any ~ 协变量 + xr×W","d_P","d_P = T_P(5) − T_P(≤3)","d_P = 0","-","推力（相对资源维度）","COV22 去 self_sat_begin，加 y0_any","同 A1","2000","20261005","BH 与 BY，n = 14","XR 替换 Pro 方案中的 XL（Pro 允许在新结果前替换并固定风险集）"
"A4","P14","ALWAYS","A 基期修饰·是否给","XR×配偶基期满意度→期末是否给","xr = x_rel","基期本人收入≤配偶（7,989 行）完整案例","W = 配偶基期满意度三类","y1_any","logit: y1_any ~ 协变量 + xr×W","d_P","d_P = T_P(5) − T_P(≤3)","d_P = 0","+","拉力（相对资源维度）","COV22 去 spouse_sat_begin，加 y0_any","同 A1","2000","20261005","BH 与 BY，n = 14","同 A3"
"B1","P14","ALWAYS","B 基期修饰·两部分金额","XA×本人基期满意度→期末支持金额","xa = x_abs","同 A1（与 A1 共用第一部分拟合）","W = 本人基期满意度三类","y1_amt（实际元/月，含 0）","两部分：logit P(Y>0) × Gamma(log) E(Y|Y>0)，两部分右侧相同","d_Y","d_Y = T_Y(5) − T_Y(≤3)；g = π×ν；单位：实际元/月","d_Y = 0","-","同 A1","同 A1","同 A1（两部分在每次重抽样中一起重拟合，跨方程协方差自动计入）","2000","20261005","BH 与 BY，n = 14","p99 封顶作 R6"
"B2","P14","ALWAYS","B 基期修饰·两部分金额","XA×配偶基期满意度→期末支持金额","xa = x_abs","同 A2","W = 配偶基期满意度三类","y1_amt","两部分","d_Y","d_Y = T_Y(5) − T_Y(≤3)","d_Y = 0","+","同 A2","同 A2","同 B1","2000","20261005","BH 与 BY，n = 14",""
"B3","P14","ALWAYS","B 基期修饰·两部分金额","XR×本人基期满意度→期末支持金额","xr = x_rel","同 A3","W = 本人基期满意度三类","y1_amt","两部分","d_Y","d_Y = T_Y(5) − T_Y(≤3)","d_Y = 0","-","同 A3","同 A3","同 B1","2000","20261005","BH 与 BY，n = 14",""
"B4","P14","ALWAYS","B 基期修饰·两部分金额","XR×配偶基期满意度→期末支持金额","xr = x_rel","同 A4","W = 配偶基期满意度三类","y1_amt","两部分","d_Y","d_Y = T_Y(5) − T_Y(≤3)","d_Y = 0","+","同 A4","同 A4","同 B1","2000","20261005","BH 与 BY，n = 14",""
"C1","P14","ALWAYS","C 同期中介（完整间接对比）","XA→本人期末满意度→期末是否给","xa = x_abs","全样本完整案例","M = 本人期末满意度（中介模型五类有序；Y 模型三类 ≤3/4/5）；S0 = 本人基期满意度四类（≤2/3/4/5）","y1_any","M：polr(S_end ~ xa + S0 + 协变量)；Y：logit(y1_any ~ xa×M3 + S0 + 协变量)","indirect","I = ψ(1,1) − ψ(1,0)；ψ(a,a') = 样本平均 Σ_s Q(a,s,C)·P(s|a',C)","I = 0","-","推力（传导）","COV22 去 self_sat_begin，加 y0_any","同 A1（中介模型、Y 模型一起重拟合）；看真实结果前先做合成数据校准","2000","20261005","BH 与 BY，n = 14","同时报告 direct、total、a 路径 logOR、b 路径诊断，不作资格门槛"
"C2","P14","ALWAYS","C 同期中介（完整间接对比）","XA→配偶期末满意度→期末是否给","xa = x_abs","全样本完整案例","M = 配偶期末满意度；S0 = 配偶基期满意度四类","y1_any","同 C1","indirect","I = ψ(1,1) − ψ(1,0)","I = 0","+","拉力（传导）","COV22 去 spouse_sat_begin，加 y0_any","同 C1","2000","20261005","BH 与 BY，n = 14",""
"C3","P14","IF_MSATECO_PASS","C 同期中介（完整间接对比）","XA→配偶对本人收入的满意度→期末是否给","xa = x_abs","全样本完整案例","M = msateco_c2（配偶对本人收入满意度，1–5，期末）；S0 = 基期同项四类","y1_any","同 C1","indirect","I = ψ(1,1) − ψ(1,0)","I = 0","+","拉力：配偶认可本人的经济贡献","COV22 加 y0_any（两项总体满意度保留为协变量）","同 C1","2000","20261005","BH 与 BY，n = 14","第 0 步三项检查（1–5 原始分、配偶对接 0 不一致、非缺失≥80%）不通过时停用，由 D3 替补"
"C4","P14","IF_MSATECO_PASS","C 同期中介（完整间接对比）","XR→配偶对本人收入的满意度→期末是否给","xr = x_rel","基期本人收入≤配偶完整案例","M = msateco_c2；S0 = 基期同项四类","y1_any","同 C1","indirect","I = ψ(1,1) − ψ(1,0)","I = 0","+","拉力（相对资源维度）","COV22 加 y0_any","同 C1","2000","20261005","BH 与 BY，n = 14","不通过时停用，由 D4 替补"
"D1","P14","ALWAYS","D 三波滞后中介","XA(2018→2020)→本人 2020 满意度→2022 是否给","xa（2018→2020）","2018–2020 与 2020–2022 都在的二元组（4,564）完整案例","M = 本人 2020 满意度；S0 = 本人 2018 满意度四类","1[2022 年支持>0]","同 C1","indirect","I = ψ(1,1) − ψ(1,0)","I = 0","-","推力（滞后传导）","2018 年 COV22 去 period_fe 与 self_sat_begin，加 y0_any（2018）；不调 2020 年支持","同 C1","2000","20261005","BH 与 BY，n = 14","不设第一段门槛；X 区间与 M 测量时点仍重叠"
"D2","P14","ALWAYS","D 三波滞后中介","XA(2018→2020)→配偶 2020 满意度→2022 是否给","xa（2018→2020）","同 D1","M = 配偶 2020 满意度；S0 = 配偶 2018 满意度四类","1[2022 年支持>0]","同 C1","indirect","I = ψ(1,1) − ψ(1,0)","I = 0","+","拉力（滞后传导）","2018 年 COV22 去 period_fe 与 spouse_sat_begin，加 y0_any","同 C1","2000","20261005","BH 与 BY，n = 14",""
"D3","P14","IF_MSATECO_FAIL","D 三波基期修饰（备用）","XA(2018→2020)×本人 2018 满意度→2022 是否给","xa（2018→2020）","同 D1","W = 本人 2018 满意度三类","1[2022 年支持>0]","logit: y ~ 协变量 + xa×W","d_P","d_P = T_P(5) − T_P(≤3)","d_P = 0","-","推力","同 D1","同 A1","2000","20261005","BH 与 BY，n = 14","只在 C3/C4 停用时启用"
"D4","P14","IF_MSATECO_FAIL","D 三波基期修饰（备用）","XA(2018→2020)×配偶 2018 满意度→2022 是否给","xa（2018→2020）","同 D1","W = 配偶 2018 满意度三类","1[2022 年支持>0]","logit: y ~ 协变量 + xa×W","d_P","d_P = T_P(5) − T_P(≤3)","d_P = 0","+","拉力","同 D2","同 A1","2000","20261005","BH 与 BY，n = 14","只在 C3/C4 停用时启用"
"S1","S4","ALWAYS","S 角色对比","联合模型：d_本人 − d_配偶","xa = x_abs","全样本完整案例","W = 本人与配偶基期满意度三类（同时进入）","y1_any","logit: y1_any ~ 协变量 + xa×W本人 + xa×W配偶","S1","S1 = d_本人 − d_配偶（各自 5 对 ≤3，另一方取观测值）","S1 = 0","-","推力为负且拉力为正时，差为负","COV22 去两项满意度，加 y0_any","同 A1（与主检验共用同一抽样计划）","2000","20261005","BH 与 BY，n = 4（单独成族）","v2 已有的联合模型；Pro 认可为预先登记的角色比较辅助"
"S2","S4","ALWAYS","S 世系差异","XA 总效应：女儿 − 儿子","xa = x_abs","全样本完整案例","按本人性别分层（0=女）","y1_any","分层 logit：y1_any ~ 协变量 + xa；分层标准化","S2","S2 = T_女 − T_男","S2 = 0","+","女儿支持更依赖自身资源与议价（郑丹丹、狄金华 2017）","COV22 去 gender_begin，加 y0_any","同 S1","2000","20261005","BH 与 BY，n = 4","数据启发：云端看过粗描述（女 +5.2、男 +0.7 个百分点），只作假设生成"
"S3","S4","ALWAYS","S 世系差异","A1 型修饰对比：女儿 − 儿子","xa = x_abs","全样本完整案例","W = 本人基期满意度三类，按性别分层","y1_any","分层 logit：y1_any ~ 协变量 + xa×W","diff","d_P(女) − d_P(男)","差 = 0","?","无事先方向","COV22 去 gender_begin 与 self_sat_begin，加 y0_any","同 S1","2000","20261005","BH 与 BY，n = 4","数据启发：看过分性别粗交互（0–2 个百分点）"
"S4","S4","ALWAYS","S 世系差异","A2 型修饰对比：女儿 − 儿子","xa = x_abs","全样本完整案例","W = 配偶基期满意度三类，按性别分层","y1_any","分层 logit：y1_any ~ 协变量 + xa×W","diff","d_P(女) − d_P(男)","差 = 0","?","无事先方向","COV22 去 gender_begin 与 spouse_sat_begin，加 y0_any","同 S1","2000","20261005","BH 与 BY，n = 4","同 S3"
"R1","ROB","ALWAYS","稳健性","23 项协变量（含 dwm）：历史定义对照","同主检验","同主检验","同主检验","同主检验","同主检验","同主检验","同主检验","—","—","—","COV23 加 y0_any","整簇 bootstrap","500","20261006","不做发现声明","适用于全部已启用主检验"
"R2","ROB","ALWAYS","稳健性","W 的 5 对 4 对比与 T(≤3)/T(4)/T(5) 曲线","同 A/B","同 A/B","同 A/B","同 A/B","同 A/B","d_P_5v4 / d_Y_5v4","T_P(5) − T_P(4)","—","—","Pro 建议的对比","同 A/B","来自主抽样","2000","20261005","不做发现声明","不重跑，取第 1 步结果"
"R3","ROB","ALWAYS","稳健性","XL：log1p(收入/万元) 变化，0 对正值 75 分位","xl","同 A1/A2","同 A1/A2","同 A1/B1","同 A/B","d_P / d_Y","T(x=q75) − T(x=0) 的修饰差","—","—","—","同 A1/A2","整簇 bootstrap","500","20261006","不做发现声明","q75 在 A1 分析样本中一次性固定；用于 A1、A2、B1、B2"
"R4","ROB","ALWAYS","稳健性","actor-period 汇总（父母两行合一）","同 A/B","8,196 个 actor-period","同 A/B","任一父母是否给 / 合计金额","同 A/B","d_P / d_Y","同 A/B","—","—","—","父母层变量改为汇总（人数、平均年龄、是否同住、是否失婚、最高教育）","整簇 bootstrap","500","20261006","不做发现声明","A1–A4、B1–B4"
"R5","ROB","ALWAYS","稳健性","线性概率模型（簇稳健 HC1）","同 A","同 A","同 A","y1_any","lm","d_P_LPM","交互系数 xa:W5","—","—","—","同 A","sandwich::vcovCL","","","不做发现声明","A1–A4"
"R6","ROB","ALWAYS","稳健性","金额 p99 封顶","同 B","同 B","同 B","min(y1_amt, p99)","两部分","d_Y","同 B","—","—","—","同 B","整簇 bootstrap","500","20261006","不做发现声明","B1–B4"
"R7","ROB","ALWAYS","稳健性","原结局 y_growth","同 A","同 A","同 A","y_growth（支持增长=1）","logit","d_P","同 A","—","—","—","同 A","整簇 bootstrap","500","20261006","不做发现声明","A1–A4；与原稿结局衔接"
"R8","ROB","ALWAYS","稳健性","影响函数（Delta）标准误","同 A","同 A","同 A","y1_any","logit","d_P","同 A","—","—","—","同 A","系数误差 + 标准化平均变异，按簇汇总","","","不做发现声明","A1–A4；与 bootstrap 对照"
"R9","ROB","ALWAYS","稳健性","C/D 改用两部分金额结局","同 C/D","同 C/D","同 C/D","y1_amt","两部分 Y 模型","indirect","同 C/D","—","—","—","同 C/D","整簇 bootstrap","500","20261006","不做发现声明","已启用的 C 与 D1/D2"
"R10","ROB","ALWAYS","稳健性","D 的 Y 模型加入 2020 年支持","同 D","同 D","同 D","同 D","同 D","indirect","条件于 2020 年支持的间接对比（估计对象不同）","—","—","—","同 D 加 y2020_any、y2020_ihs","整簇 bootstrap","500","20261006","不做发现声明","2020 年支持在 X 区间内，属处理后调整"
"R11","ROB","ALWAYS","稳健性","部分比例优势中介模型（X 名义效应）","同 C","同 C","同 C","同 C","ordinal::clm(nominal = ~X)","indirect","同 C","—","—","—","同 C","整簇 bootstrap","500","20261006","不做发现声明","已启用的 C"
"PO","ROB","ALWAYS","诊断","比例优势诊断：X 的名义效应 LR（同一五分类）","同 C/D","同 C/D","同 C/D","—","clm PO 对 clm nominal","LR","—","—","—","—","同 C/D","常规 LR，不计聚类","","","只作诊断","不作换模门槛；主设定始终为 PO"
"E","HIST","ALWAYS","历史","原 11 个冻结候选 B=1000 数值复核","—","—","—","—","CMAverse（原登记）","—","—","—","—","—","原 23 项","沿用 astra 现有脚本","1000","原独立随机流","单独归档，不进入任何族","数值复核，不是独立验证"


## 来源：20261005_astra_v4_functions.R
SHA256: 928566461039724f078ddf6af068e5c675841fc04f1033e2f57444178e6faffe

# =====================================================================
# 20261005_astra_v4_functions.R
# 配套：20261005_astra本地执行方案_v4.md、20261005_test_registry_v4.csv
#
# 状态：云端只写、从未运行。云端没有安装 R，也没有拟合任何模型。
# astra 在本机必须按顺序：
#   1) parse("20261005_astra_v4_functions.R") 无语法错误；
#   2) self_test() 全部 PASS（只用合成数据，不碰真实结局）；
#   3) time_test(d) 计时（用合成结局，不碰真实结局）；
#   4) 之后才按 step0 → step6 运行真实数据。
# 运行：把本文件和登记表放进解压后的资料包根目录（含 data/、screening/），在终端执行
#   VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 Rscript run_v4.R
# 不要在 RStudio 里用 mclapply 并行。
# 依赖：MASS、parallel、tools（R 自带）；sandwich（R5）；ordinal（PO 诊断、R11）；
#       haven（只在第 0 步提取 msateco 时用）。
# =====================================================================

suppressPackageStartupMessages({
  library(MASS)
  library(parallel)
})

# ---------------------------------------------------------------------
# 0. 配置
# ---------------------------------------------------------------------
PKG_DIR   <- Sys.getenv("CMA_PKG", ".")
OUT_DIR   <- Sys.getenv("CMA_OUT", file.path(PKG_DIR, "v4_outputs"))
REGISTRY  <- file.path(PKG_DIR, "20261005_test_registry_v4.csv")
CLUSTER   <- "unified_component"
LV3       <- c("le3", "4", "5")
SEED_MAIN <- 20261005L   # 主抽样计划：全部主检验与次级检验共用同一组簇抽样
SEED_ROB  <- 20261006L   # 稳健性抽样计划
SEED_CAL  <- 20261105L   # 中介检验的合成数据校准
B_MAIN    <- 2000L
B_ROB     <- 500L
N_PRIMARY <- 14L
N_SECOND  <- 4L
N_CORES   <- max(1L, parallel::detectCores() - 1L)

COV23 <- NULL
COV22 <- NULL
load_covariates <- function() {
  v <- trimws(readLines(file.path(PKG_DIR, "data/fixed_23_covariates.txt"), warn = FALSE))
  v <- v[nzchar(v)]
  stopifnot(length(v) == 23L, "dwm_begin" %in% v)
  COV23 <<- v
  COV22 <<- setdiff(v, "dwm_begin")   # 主设定：去掉累计到 2022 年的 dwm
  invisible(v)
}

# ---------------------------------------------------------------------
# 1. 小工具
# ---------------------------------------------------------------------
same_or_both_na <- function(a, b) all((is.na(a) & is.na(b)) | (!is.na(a) & !is.na(b) & a == b))
cut3 <- function(s) factor(ifelse(is.na(s), NA_character_, ifelse(s <= 3, "le3", as.character(s))),
                           levels = LV3)
cut4 <- function(s) factor(ifelse(is.na(s), NA_character_, ifelse(s <= 2, "le2", as.character(s))),
                           levels = c("le2", "3", "4", "5"))
ord5 <- function(s) factor(s, levels = 1:5, ordered = TRUE)
fml  <- function(response, terms) stats::reformulate(terms, response = response)
ensure_out <- function() dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)
bind_fill <- function(lst) {
  lst <- Filter(function(x) !is.null(x) && nrow(x) > 0, lst)
  if (!length(lst)) return(NULL)
  cols <- unique(unlist(lapply(lst, names)))
  do.call(rbind, lapply(lst, function(x) {
    for (cc in setdiff(cols, names(x))) x[[cc]] <- NA
    x[cols]
  }))
}
prefix_specs <- function(specs, pre) lapply(specs, function(sp) {
  for (k in intersect(c("A", "B", "id"), names(sp))) sp[[k]] <- paste0(pre, "_", sp[[k]])
  sp
})
# 最小格计数：二值 X × 因子；空表返回 0（避免 min(integer(0)) = Inf 被误判为达标）
min_cell <- function(x, f) {
  if (!length(x)) return(0L)
  tb <- table(factor(x, levels = 0:1), f)
  if (!length(tb)) 0L else min(tb)
}

# ---------------------------------------------------------------------
# 2. 数据准备（不做标准化；标准化在每个分析样本内完成）
# ---------------------------------------------------------------------
prep_data <- function(path = file.path(PKG_DIR, "data/analysis_13092.rds")) {
  d <- as.data.frame(readRDS(path), stringsAsFactors = FALSE)
  stopifnot(nrow(d) == 13092L, !anyDuplicated(d$stable_row_id))
  d$period <- as.character(d$period)
  for (v in c("self_sat_begin", "self_sat_end", "spouse_sat_begin", "spouse_sat_end"))
    stopifnot(all(d[[v]] %in% c(1:5, NA)))
  d$y0_any <- as.integer(d$support_real_begin > 0)
  d$y1_any <- as.integer(d$support_real_end > 0)
  d$y1_amt <- d$support_real_end                      # 实际元/月
  d$w_self3    <- cut3(d$self_sat_begin)
  d$w_spouse3  <- cut3(d$spouse_sat_begin)
  d$s0_self4   <- cut4(d$self_sat_begin)
  d$s0_spouse4 <- cut4(d$spouse_sat_begin)
  d$s1_self    <- ord5(d$self_sat_end)
  d$s1_spouse  <- ord5(d$spouse_sat_end)
  d$m3_self    <- cut3(d$self_sat_end)
  d$m3_spouse  <- cut3(d$spouse_sat_end)
  d$xa <- as.integer(d$x_abs)
  d$xr <- as.integer(d$x_rel)                         # 只在“基期本人收入<=配偶”时非缺失
  d$xl <- log1p(d$actor_income_real_end / 1e4) - log1p(d$actor_income_real_begin / 1e4)
  d$female <- as.integer(d$gender_begin == 0)         # CFPS：0=女
  # 端点断言（云端已用 Python 核对为 0 不一致，本机再核一次）
  xa_chk <- ifelse(is.na(d$actor_income_real_begin) | is.na(d$actor_income_real_end), NA_integer_,
                   as.integer(d$actor_income_real_end > d$actor_income_real_begin))
  stopifnot(same_or_both_na(d$xa, xa_chk))
  elig <- !is.na(d$actor_income_real_begin) & !is.na(d$partner_income_real_begin) &
    d$actor_income_real_begin <= d$partner_income_real_begin
  stopifnot(all(is.na(d$xr) | elig))
  xr_chk <- ifelse(elig, as.integer(d$actor_income_real_end > d$partner_income_real_end), NA_integer_)
  stopifnot(same_or_both_na(d$xr, xr_chk))
  stopifnot(sum(!is.na(d$xr)) == 7989L)
  d
}

covs_for <- function(drop_sat = c("self", "spouse", "both", "none"), base = COV22,
                     drop = character(0), add = "y0_any") {
  drop_sat <- match.arg(drop_sat)
  ds <- switch(drop_sat, self = "self_sat_begin", spouse = "spouse_sat_begin",
               both = c("self_sat_begin", "spouse_sat_begin"), none = character(0))
  unique(c(setdiff(base, c(ds, drop)), add))
}

analysis_sample <- function(d, vars, cluster = CLUSTER) {
  vars <- unique(c(vars, cluster))
  miss <- setdiff(vars, names(d))
  if (length(miss)) stop("缺少变量：", paste(miss, collapse = ", "))
  keep <- unique(c(vars, intersect(c("stable_row_id", "dyad_id", "period"), names(d))))
  d[stats::complete.cases(d[, vars, drop = FALSE]), keep, drop = FALSE]
}

# 数值协变量标准化：对线性项的预测和标准化对比没有影响，只为数值稳定
# （total_debts_begin 原值最高 1,015 万元，会拖慢有序 logit 的优化）。
zscale <- function(dat, vars) {
  for (v in intersect(vars, names(dat))) {
    x <- dat[[v]]
    if (is.numeric(x) && length(unique(x[!is.na(x)])) > 2L) {
      s <- stats::sd(x, na.rm = TRUE)
      if (is.finite(s) && s > 0) dat[[v]] <- (x - mean(x, na.rm = TRUE)) / s
    }
  }
  dat
}

# ---------------------------------------------------------------------
# 3. 模型与标准化对比（A/B）
# ---------------------------------------------------------------------
fit_logit <- function(f, dat) {
  m <- glm(f, family = binomial(), data = dat, control = glm.control(maxit = 100))
  if (!isTRUE(m$converged)) stop("logit 未收敛")
  if (anyNA(coef(m))) stop("logit 有 NA 系数（共线或某水平为空）")
  m
}

fit_gamma <- function(f, dat) {
  yv  <- all.vars(f[[2]])
  pos <- dat[dat[[yv]] > 0, , drop = FALSE]
  X   <- model.matrix(f, data = pos)
  st  <- c(log(mean(pos[[yv]])), rep(0, ncol(X) - 1L))
  m <- glm(f, family = Gamma(link = "log"), data = pos, start = st,
           control = glm.control(maxit = 200))
  if (!isTRUE(m$converged)) stop("Gamma 未收敛")
  if (anyNA(coef(m))) stop("Gamma 有 NA 系数")
  m
}

set_cf <- function(dat, x, xv, w = NULL, wv = NULL) {
  dat[[x]] <- rep(xv, nrow(dat))
  if (!is.null(w)) dat[[w]] <- factor(rep(wv, nrow(dat)), levels = levels(dat[[w]]))
  dat
}

# T_P(w) = mean_i[pi(x_hi,w,C_i) - pi(x_lo,w,C_i)]，按本分析样本的协变量分布平均
# d_P = T_P(5) - T_P(le3)；B 部分 g = pi * nu，d_Y 单位为实际元/月
stat_AB <- function(dat, fA, fB = NULL, x, w, x_hi = 1, x_lo = 0) {
  m1 <- fit_logit(fA, dat)
  pA <- function(xv, l) predict(m1, newdata = set_cf(dat, x, xv, w, l), type = "response")
  TP <- vapply(LV3, function(l) mean(pA(x_hi, l) - pA(x_lo, l)), numeric(1))
  out <- c(T_P_le3 = TP[["le3"]], T_P_4 = TP[["4"]], T_P_5 = TP[["5"]],
           d_P = TP[["5"]] - TP[["le3"]], d_P_5v4 = TP[["5"]] - TP[["4"]])
  if (!is.null(fB)) {
    m2 <- fit_gamma(fB, dat)
    g <- function(xv, l) {
      nd <- set_cf(dat, x, xv, w, l)
      predict(m1, newdata = nd, type = "response") * predict(m2, newdata = nd, type = "response")
    }
    TY <- vapply(LV3, function(l) mean(g(x_hi, l) - g(x_lo, l)), numeric(1))
    out <- c(out, T_Y_le3 = TY[["le3"]], T_Y_4 = TY[["4"]], T_Y_5 = TY[["5"]],
             d_Y = TY[["5"]] - TY[["le3"]], d_Y_5v4 = TY[["5"]] - TY[["4"]])
  }
  out
}

# ---------------------------------------------------------------------
# 4. 中介（C/D）：完整间接对比
#    psi(a,a') = mean_i sum_s Q(a,s,C_i) * P(S=s | a',C_i)
#    I = psi(1,1) - psi(1,0)；D = psi(1,0) - psi(0,0)；T = psi(1,1) - psi(0,0)
#    中介模型：有序 logit，五类；Y 模型中中介为三类（le3/4/5），等价于对五类求和
# ---------------------------------------------------------------------
pm_probs <- function(fit, nd, mvar, model = c("po", "ppo")) {
  model <- match.arg(model)
  if (model == "po") {
    P <- predict(fit, newdata = nd, type = "probs")
    if (is.null(dim(P))) P <- matrix(P, nrow = 1L, dimnames = list(NULL, names(P)))
  } else {
    nd[[mvar]] <- NULL                      # clm 只有在 newdata 不含结局时才返回全部类别概率
    P <- predict(fit, newdata = nd, type = "prob")$fit
    colnames(P) <- fit$y.levels
  }
  full <- matrix(0, nrow(P), 5L, dimnames = list(NULL, as.character(1:5)))
  full[, colnames(P)] <- P
  full
}

collapse3 <- function(P5) cbind(le3 = P5[, "1"] + P5[, "2"] + P5[, "3"], `4` = P5[, "4"], `5` = P5[, "5"])

stat_med <- function(dat, fM, fY, x, m3, a_hi = 1, a_lo = 0, fY2 = NULL, m_model = c("po", "ppo")) {
  m_model <- match.arg(m_model)
  mvar <- all.vars(fM[[2]])
  dat[[mvar]] <- droplevels(dat[[mvar]])    # 防止某一类在重抽样中为空
  if (m_model == "po") {
    mM <- MASS::polr(fM, data = dat, method = "logistic", Hess = FALSE, control = list(maxit = 500))
    if (!is.null(mM$convergence) && mM$convergence != 0) stop("polr 未收敛")
  } else {
    if (!requireNamespace("ordinal", quietly = TRUE)) stop("R11 需要 ordinal 包")
    fLoc <- stats::update(fM, stats::as.formula(paste(". ~ . -", x)))
    mM <- ordinal::clm(fLoc, nominal = stats::as.formula(paste("~", x)), data = dat, link = "logit")
  }
  mY <- fit_logit(fY, dat)
  m2 <- if (is.null(fY2)) NULL else fit_gamma(fY2, dat)
  P_hi <- collapse3(pm_probs(mM, set_cf(dat, x, a_hi), mvar, m_model))
  P_lo <- collapse3(pm_probs(mM, set_cf(dat, x, a_lo), mvar, m_model))
  Qmat <- function(a) vapply(LV3, function(s) {
    nd <- set_cf(dat, x, a, m3, s)
    q <- predict(mY, newdata = nd, type = "response")
    if (!is.null(m2)) q <- q * predict(m2, newdata = nd, type = "response")
    unname(q)
  }, numeric(nrow(dat)))
  Q_hi <- Qmat(a_hi)
  Q_lo <- Qmat(a_lo)
  psi <- function(Q, P) mean(rowSums(Q * P))
  p11 <- psi(Q_hi, P_hi); p10 <- psi(Q_hi, P_lo); p00 <- psi(Q_lo, P_lo)
  out <- c(indirect = p11 - p10, direct = p10 - p00, total = p11 - p00,
           b_diag = mean(Q_lo[, "5"] - Q_lo[, "le3"]))      # 路径诊断，不作资格门槛
  if (m_model == "po") out <- c(out, a_logOR = unname(coef(mM)[x]))
  out
}

# ---------------------------------------------------------------------
# 5. 整簇 bootstrap：事先生成的全局抽样计划，所有检验共用
# ---------------------------------------------------------------------
make_plan <- function(ids, B, seed) {
  ids <- sort(unique(ids))
  set.seed(seed, kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
  draws <- matrix(sample.int(length(ids), length(ids) * B, replace = TRUE), ncol = B)
  list(ids = ids, draws = draws, B = B, seed = seed)
}

make_or_load_plan <- function(d, B, seed, file) {
  ensure_out()
  f <- file.path(OUT_DIR, file)
  if (file.exists(f)) {
    p <- readRDS(f)
    stopifnot(p$B == B, p$seed == seed)
    return(p)
  }
  p <- make_plan(d[[CLUSTER]], B, seed)
  saveRDS(p, f)
  p
}

# 子样本（XR 风险集、三波链）沿用同一计划：抽到的簇若不在子样本中则贡献 0 行
run_boot <- function(dat, plan, stat_fun, cores = N_CORES, cluster = CLUSTER) {
  gi <- match(dat[[cluster]], plan$ids)
  if (anyNA(gi)) stop("样本中有簇不在抽样计划里")
  rows_by <- split(seq_len(nrow(dat)), factor(gi, levels = seq_along(plan$ids)))
  one <- function(b) {
    rows <- unlist(rows_by[plan$draws[, b]], use.names = FALSE)
    if (!length(rows)) return(list(ok = FALSE, err = "空样本"))
    r <- tryCatch(stat_fun(dat[rows, , drop = FALSE]), error = function(e) e)
    if (inherits(r, "error")) return(list(ok = FALSE, err = conditionMessage(r)))
    if (!all(is.finite(r))) return(list(ok = FALSE, err = "非有限值"))
    list(ok = TRUE, val = r)
  }
  res <- if (cores > 1L) parallel::mclapply(seq_len(plan$B), one, mc.cores = cores) else lapply(seq_len(plan$B), one)
  ok  <- vapply(res, function(z) is.list(z) && isTRUE(z$ok), logical(1))
  mat <- if (any(ok)) do.call(rbind, lapply(res[ok], `[[`, "val")) else NULL
  if (!is.null(mat)) rownames(mat) <- which(ok)
  err <- vapply(res[!ok], function(z) if (is.list(z) && !is.null(z$err)) z$err else "子进程失败", character(1))
  list(mat = mat, ok_idx = which(ok), fail_idx = which(!ok), fail_msg = err, B = plan$B)
}

# p = (1 + #{|t_b - t0| >= |t0|}) / (B_valid + 1)（与 150 项历史筛选同一公式）
# 主 CI = t0 ± q95(|t_b - t0|)：与 p 来自同一中心化分布；百分位 CI 只看形状
summ_boot <- function(est, bt, name) {
  t0 <- unname(est[[name]])
  if (is.null(bt$mat) || !(name %in% colnames(bt$mat))) stop("没有有效重复：", name)
  tb  <- bt$mat[, name]
  dev <- abs(tb - t0)
  q   <- unname(stats::quantile(dev, 0.95, type = 7))
  nv  <- length(tb)
  data.frame(estimand = name, estimate = t0, se_boot = stats::sd(tb),
             ci_low = t0 - q, ci_high = t0 + q,
             pct_low = unname(stats::quantile(tb, 0.025)), pct_high = unname(stats::quantile(tb, 0.975)),
             p_raw = (1 + sum(dev >= abs(t0))) / (nv + 1),
             n_valid = nv, B = bt$B, valid_share = nv / bt$B,
             boot_flag = if (nv / bt$B < 0.98) "有效重复<98%" else "",
             stringsAsFactors = FALSE)
}

# ---------------------------------------------------------------------
# 6. 预定对照：影响函数（Delta）标准误（R8）与线性概率模型（R5）
#    影响函数同时计入系数估计误差和“按样本协变量分布平均”的变异，并按簇汇总
# ---------------------------------------------------------------------
if_dP_logit <- function(m, dat, x, w, x_hi = 1, x_lo = 0, hi = "5", lo = "le3", cluster = CLUSTER) {
  tt <- delete.response(terms(m))
  b  <- coef(m)
  Xof <- function(nd) model.matrix(tt, model.frame(tt, nd, xlev = m$xlevels), contrasts.arg = m$contrasts)
  parts <- list(list(xv = x_hi, wl = hi, s = 1), list(xv = x_lo, wl = hi, s = -1),
                list(xv = x_hi, wl = lo, s = -1), list(xv = x_lo, wl = lo, s = 1))
  n <- nrow(dat); h <- numeric(n); G <- numeric(length(b))
  for (p in parts) {
    Xc <- Xof(set_cf(dat, x, p$xv, w, p$wl))
    stopifnot(identical(colnames(Xc), names(b)))
    pr <- plogis(drop(Xc %*% b))
    h  <- h + p$s * pr
    G  <- G + p$s * colMeans(Xc * (pr * (1 - pr)))
  }
  theta <- mean(h)
  X  <- model.matrix(m); mu <- fitted(m); y <- m$y
  stopifnot(nrow(X) == n)
  S   <- X * (y - mu)
  A   <- crossprod(X, X * (mu * (1 - mu)))
  phi <- (h - theta) / n + drop(S %*% solve(A, G))
  pg  <- rowsum(phi, dat[[cluster]])
  Gc  <- nrow(pg)
  se  <- sqrt(sum(pg^2) * Gc / (Gc - 1))
  data.frame(estimand = "d_P", estimate = theta, se_if = se,
             ci_low = theta - 1.959964 * se, ci_high = theta + 1.959964 * se,
             p_if = 2 * pnorm(-abs(theta / se)), stringsAsFactors = FALSE)
}

lpm_dP <- function(f, dat, x, w, hi = "5", cluster = CLUSTER) {
  if (!requireNamespace("sandwich", quietly = TRUE)) stop("R5 需要 sandwich 包")
  m  <- lm(f, data = dat)
  nm <- paste0(x, ":", w, hi)
  if (!nm %in% names(coef(m))) nm <- paste0(w, hi, ":", x)
  V  <- sandwich::vcovCL(m, cluster = dat[[cluster]], type = "HC1")
  est <- unname(coef(m)[nm]); se <- sqrt(V[nm, nm])
  data.frame(estimand = "d_P_LPM", estimate = est, se_cl = se,
             ci_low = est - 1.959964 * se, ci_high = est + 1.959964 * se,
             p_cl = 2 * pnorm(-abs(est / se)), stringsAsFactors = FALSE)
}

# ---------------------------------------------------------------------
# 7. 派生数据：三波链、actor-period 汇总、msateco
# ---------------------------------------------------------------------
build_threewave <- function(d) {
  p1 <- d[d$period == "2018-2020", , drop = FALSE]
  p2 <- d[d$period == "2020-2022", c("dyad_id", "support_real_end", "self_sat_begin", "spouse_sat_begin"), drop = FALSE]
  names(p2) <- c("dyad_id", "support_2022", "self_sat_2020_chk", "spouse_sat_2020_chk")
  stopifnot(!anyDuplicated(p1$dyad_id), !anyDuplicated(p2$dyad_id))
  w <- merge(p1, p2, by = "dyad_id", sort = FALSE)
  stopifnot(nrow(w) == 4564L,
            all(w$self_sat_end == w$self_sat_2020_chk, na.rm = TRUE),
            all(w$spouse_sat_end == w$spouse_sat_2020_chk, na.rm = TRUE))
  w$y2020_any <- as.integer(w$support_real_end > 0)    # X 区间内，处理后，只用于 R10
  w$y2020_ihs <- asinh(w$support_real_end)
  w$y1_any <- as.integer(w$support_2022 > 0)            # 结局：2022 年是否给
  w$y1_amt <- w$support_2022
  w                                                     # y0_any 与 baseline_support_ihs 仍是 2018 年值
}
covs_D <- function(drop_sat, base = COV22) setdiff(covs_for(drop_sat, base = base), "period_fe")

PARENT_VARS <- c("prtmarr_begin", "prtcor_begin", "prtgender_begin", "prtage_begin", "prtedu_begin")
AGG_VARS    <- c("n_parents", "prtage_mean", "prtcor_any", "prtmarr_any", "prtedu_max")
build_actor_period <- function(d) {
  key <- paste(d$actor_pid_begin, d$period)
  g   <- split(seq_len(nrow(d)), key)
  actor_vars <- c("period", "period_fe", CLUSTER, "xa", "xr", "xl", "female", "gender_begin", "aage_begin",
                  "actor_edu2_begin", "actor_siops_begin", "child_begin", "ahw_begin", "ahk_begin",
                  "total_debts_begin", "qp201_actor_begin", "fmlincc_begin", "lifetime_begin",
                  "baseline_actor_income_ihs", "baseline_partner_income_ihs", "self_sat_begin",
                  "spouse_sat_begin", "dwm_begin")
  for (v in actor_vars) {
    same <- vapply(g, function(ix) length(unique(d[[v]][ix])) == 1L, logical(1))
    if (!all(same)) warning("actor 层变量在父母两行间不一致：", v, "（", sum(!same), " 组），取第一行")
  }
  first <- vapply(g, function(ix) ix[1L], integer(1))
  a <- d[first, actor_vars, drop = FALSE]
  sum_na <- function(x) if (anyNA(x)) NA_real_ else sum(x)
  a$y1_amt <- vapply(g, function(ix) sum_na(d$support_real_end[ix]), numeric(1))
  a$y0_amt <- vapply(g, function(ix) sum_na(d$support_real_begin[ix]), numeric(1))
  a$y1_any <- as.integer(a$y1_amt > 0)
  a$y0_any <- as.integer(a$y0_amt > 0)
  a$baseline_support_ihs <- asinh(a$y0_amt)
  a$w_self3   <- cut3(a$self_sat_begin)
  a$w_spouse3 <- cut3(a$spouse_sat_begin)
  a$n_parents   <- lengths(g)
  a$prtage_mean <- vapply(g, function(ix) mean(d$prtage_begin[ix]), numeric(1))
  a$prtcor_any  <- vapply(g, function(ix) max(d$prtcor_begin[ix]), numeric(1))
  a$prtmarr_any <- vapply(g, function(ix) max(d$prtmarr_begin[ix]), numeric(1))
  a$prtedu_max  <- vapply(g, function(ix) max(d$prtedu_begin[ix]), numeric(1))
  rownames(a) <- NULL
  stopifnot(nrow(a) == 8196L)
  a
}
covs_R4 <- function(drop_sat, base = COV22) unique(c(setdiff(covs_for(drop_sat, base = base), PARENT_VARS), AGG_VARS))

# 第 0 步：从 v6 的上游长表（predata_FE_16_22_unbal.dta）提取 msateco 原始 1–5 分。
# 注意：旧 Stata 流程（20240619 do 文件第 6796–6800 行）曾把 msat/msateco 改写成年内百分位；
# identity_target_13092.rds 里的 msateco_c1/c2 就是百分位版本，不能用。
extract_msateco <- function(raw_dta = Sys.getenv("CMA_PREDATA"),
                            out = file.path(PKG_DIR, "data/msateco_intervals.csv")) {
  if (!requireNamespace("haven", quietly = TRUE)) stop("需要 haven 包")
  raw <- as.data.frame(haven::read_dta(raw_dta, col_select = c("pid", "year", "msateco_c1_", "msateco_c2_")))
  nn  <- function(x) { x <- as.numeric(haven::zap_labels(x)); x[!is.na(x) & x < 0] <- NA_real_; x }
  raw$year <- nn(raw$year)
  raw <- raw[raw$year %in% c(2018, 2020, 2022), , drop = FALSE]
  raw$e1 <- nn(raw$msateco_c1_)     # 本人对配偶收入的满意度
  raw$e2 <- nn(raw$msateco_c2_)     # 配偶对本人收入的满意度（C3/C4 的中介）
  bad <- setdiff(unique(c(raw$e1, raw$e2)), c(1:5, NA))
  if (length(bad)) stop("msateco 不是 1–5 原始分（可能是百分位版本）：", paste(head(bad), collapse = ", "))
  raw$dyad_id <- sprintf("%.0f", nn(raw$pid))
  stopifnot(!anyDuplicated(paste(raw$dyad_id, raw$year)))
  getv <- function(yr, v) { s <- raw[raw$year == yr, , drop = FALSE]; stats::setNames(s[[v]], s$dyad_id) }
  mk <- function(b, e) {
    ids <- union(names(getv(b, "e1")), names(getv(e, "e1")))
    data.frame(dyad_id = ids, period = paste0(b, "-", e),
               eco_self_begin = unname(getv(b, "e1")[ids]), eco_self_end = unname(getv(e, "e1")[ids]),
               eco_spouse_begin = unname(getv(b, "e2")[ids]), eco_spouse_end = unname(getv(e, "e2")[ids]),
               stringsAsFactors = FALSE)
  }
  res <- rbind(mk(2018, 2020), mk(2020, 2022))
  utils::write.csv(res, out, row.names = FALSE, na = "NA")
  invisible(res)
}

add_msateco <- function(d, path = file.path(PKG_DIR, "data/msateco_intervals.csv")) {
  e <- utils::read.csv(path, stringsAsFactors = FALSE, colClasses = c(dyad_id = "character", period = "character"))
  need <- c("eco_self_begin", "eco_self_end", "eco_spouse_begin", "eco_spouse_end")
  stopifnot(all(need %in% names(e)), !anyDuplicated(paste(e$dyad_id, e$period)))
  for (v in need) stopifnot(all(e[[v]] %in% c(1:5, NA)))
  k <- match(paste(d$dyad_id, d$period), paste(e$dyad_id, e$period))
  attr(d, "msateco_row_match") <- mean(!is.na(k))
  for (v in need) d[[v]] <- e[[v]][k]
  d$s1_eco_sp  <- ord5(d$eco_spouse_end)
  d$m3_eco_sp  <- cut3(d$eco_spouse_end)
  d$s0_eco_sp4 <- cut4(d$eco_spouse_begin)
  d
}

# 配偶对接校验：行 (A,P) 的“配偶评分”应等于行 (P,A) 的“本人评分”
link_check <- function(d, spouse_b, spouse_e, self_b, self_e, label) {
  key_self <- paste(d$actor_pid_begin, d$partner_pid_begin, d$period)
  key_rev  <- paste(d$partner_pid_begin, d$actor_pid_begin, d$period)
  j   <- match(key_rev, key_self)
  has <- !is.na(j)
  data.frame(check = label, linked_rows = sum(has),
             mismatch_begin = sum(d[[spouse_b]][has] != d[[self_b]][j[has]], na.rm = TRUE),
             mismatch_end   = sum(d[[spouse_e]][has] != d[[self_e]][j[has]], na.rm = TRUE),
             stringsAsFactors = FALSE)
}

# ---------------------------------------------------------------------
# 8. 检验定义（与 test_registry_v4.csv 一一对应）
# ---------------------------------------------------------------------
AB_SPECS <- list(
  list(A = "A1", B = "B1", x = "xa", w = "w_self3",   drop = "self"),
  list(A = "A2", B = "B2", x = "xa", w = "w_spouse3", drop = "spouse"),
  list(A = "A3", B = "B3", x = "xr", w = "w_self3",   drop = "self"),
  list(A = "A4", B = "B4", x = "xr", w = "w_spouse3", drop = "spouse")
)
C_SPECS <- list(
  list(id = "C1", x = "xa", s1 = "s1_self",   m3 = "m3_self",   s0 = "s0_self4",   drop = "self"),
  list(id = "C2", x = "xa", s1 = "s1_spouse", m3 = "m3_spouse", s0 = "s0_spouse4", drop = "spouse"),
  list(id = "C3", x = "xa", s1 = "s1_eco_sp", m3 = "m3_eco_sp", s0 = "s0_eco_sp4", drop = "none"),
  list(id = "C4", x = "xr", s1 = "s1_eco_sp", m3 = "m3_eco_sp", s0 = "s0_eco_sp4", drop = "none")
)
D_SPECS <- list(
  list(id = "D1", x = "xa", s1 = "s1_self",   m3 = "m3_self",   s0 = "s0_self4",   drop = "self"),
  list(id = "D2", x = "xa", s1 = "s1_spouse", m3 = "m3_spouse", s0 = "s0_spouse4", drop = "spouse")
)
# 备用：只有第 0 步判定 msateco 不可用时才启用，替补 C3/C4 的两个名额
D_RESERVE <- list(
  list(A = "D3", x = "xa", w = "w_self3",   drop = "self"),
  list(A = "D4", x = "xa", w = "w_spouse3", drop = "spouse")
)

run_AB_specs <- function(specs, base, plan, covs_fun = covs_for, tag, with_B = TRUE,
                         yA = "y1_any", yB = "y1_amt", x_hi = 1, x_lo = 0,
                         extra_est = c("d_P_5v4", "T_P_le3", "T_P_4", "T_P_5"), cores = N_CORES) {
  rows <- list()
  for (sp in specs) {
    covs <- covs_fun(sp$drop)
    rhs  <- c(covs, paste(sp$x, "*", sp$w))
    fA   <- fml(yA, rhs)
    fB   <- if (with_B) fml(yB, rhs) else NULL
    dat  <- zscale(analysis_sample(base, unique(c(all.vars(fA), if (with_B) yB))), covs)
    sfun <- function(z) stat_AB(z, fA, fB, sp$x, sp$w, x_hi = x_hi, x_lo = x_lo)
    pos_ok <- if (all(dat[[sp$x]] %in% 0:1)) min_cell(dat[[sp$x]], dat[[sp$w]]) >= 100 else NA
    est  <- sfun(dat)
    bt   <- run_boot(dat, plan, sfun, cores = cores)
    n_cl <- length(unique(dat[[CLUSTER]]))
    saveRDS(list(spec = sp, fA = fA, fB = fB, est = est, boot = bt, n = nrow(dat), n_cl = n_cl,
                 x_hi = x_hi, x_lo = x_lo, positivity_ok = pos_ok),
            file.path(OUT_DIR, sprintf("%s_%s.rds", tag, sp$A)))
    one_row <- function(id, nm) cbind(test_id = id, tag = tag, n = nrow(dat), n_cl = n_cl,
                                      positivity_ok = pos_ok, summ_boot(est, bt, nm))
    for (nm in c("d_P", extra_est)) rows[[length(rows) + 1L]] <- one_row(sp$A, nm)
    if (with_B) for (nm in sub("_P", "_Y", c("d_P", extra_est), fixed = TRUE))
      rows[[length(rows) + 1L]] <- one_row(sp$B, nm)
  }
  do.call(rbind, rows)
}

run_med <- function(specs, base, plan, covs_fun, tag, y_type = c("binary", "twopart"),
                    m_model = c("po", "ppo"), extra_y = character(0), cores = N_CORES) {
  y_type <- match.arg(y_type); m_model <- match.arg(m_model)
  rows <- list()
  for (sp in specs) {
    covs <- covs_fun(sp$drop)
    fM   <- fml(sp$s1, c(sp$x, sp$s0, covs))
    rhsY <- c(paste(sp$x, "*", sp$m3), sp$s0, covs, extra_y)
    fY   <- fml("y1_any", rhsY)
    fY2  <- if (y_type == "twopart") fml("y1_amt", rhsY) else NULL
    vars <- unique(c(all.vars(fM), all.vars(fY), if (!is.null(fY2)) all.vars(fY2)))
    dat  <- zscale(analysis_sample(base, vars), c(covs, extra_y))
    pos_min <- min_cell(dat[[sp$x]], dat[[sp$m3]])
    sfun <- function(z) stat_med(z, fM, fY, sp$x, sp$m3, fY2 = fY2, m_model = m_model)
    est  <- sfun(dat)
    bt   <- run_boot(dat, plan, sfun, cores = cores)
    n_cl <- length(unique(dat[[CLUSTER]]))
    saveRDS(list(spec = sp, fM = fM, fY = fY, fY2 = fY2, est = est, boot = bt, n = nrow(dat),
                 n_cl = n_cl, positivity_min_xm = pos_min),
            file.path(OUT_DIR, sprintf("%s_%s.rds", tag, sp$id)))
    for (nm in intersect(c("indirect", "direct", "total", "a_logOR", "b_diag"), names(est)))
      rows[[length(rows) + 1L]] <- cbind(test_id = sp$id, tag = tag, n = nrow(dat), n_cl = n_cl,
                                         positivity_ok = pos_min >= 30, summ_boot(est, bt, nm))
  }
  do.call(rbind, rows)
}

# ---------------------------------------------------------------------
# 9. 次级族 S（单独 BH，n = 4；S2–S4 为数据启发）
# ---------------------------------------------------------------------
stat_S1 <- function(dat, f) {                 # 角色对比：联合模型中本人与配偶两个修饰对比之差
  m <- fit_logit(f, dat)
  Tw <- function(w, l) mean(predict(m, set_cf(dat, "xa", 1, w, l), type = "response") -
                              predict(m, set_cf(dat, "xa", 0, w, l), type = "response"))
  d_self   <- Tw("w_self3", "5") - Tw("w_self3", "le3")
  d_spouse <- Tw("w_spouse3", "5") - Tw("w_spouse3", "le3")
  c(S1 = d_self - d_spouse, d_self_joint = d_self, d_spouse_joint = d_spouse)
}
stat_S2 <- function(dat, f) {                 # 世系：XA 总效应，女儿减儿子（各自分层拟合、分层标准化）
  tf <- function(sub) {
    m <- fit_logit(f, sub)
    mean(predict(m, set_cf(sub, "xa", 1), type = "response") - predict(m, set_cf(sub, "xa", 0), type = "response"))
  }
  tF <- tf(dat[dat$female == 1L, , drop = FALSE]); tM <- tf(dat[dat$female == 0L, , drop = FALSE])
  c(S2 = tF - tM, T_female = tF, T_male = tM)
}
stat_S34 <- function(dat, f, w) {             # 世系：A1/A2 型修饰对比，女儿减儿子
  dF <- stat_AB(dat[dat$female == 1L, , drop = FALSE], f, NULL, "xa", w)[["d_P"]]
  dM <- stat_AB(dat[dat$female == 0L, , drop = FALSE], f, NULL, "xa", w)[["d_P"]]
  c(diff = dF - dM, d_female = dF, d_male = dM)
}

# ---------------------------------------------------------------------
# 10. 中介检验的合成数据校准（在看 C/D 真实结果之前运行）
#     a0：中介模型去掉 X（a=0），Y 模型用实际拟合；b0：中介模型用实际拟合，Y 模型去掉中介（b=0）
# ---------------------------------------------------------------------
calib_med <- function(dat, fM, fY, x, m3, scenario = c("a0", "b0"), R = 200L, B = 99L,
                      seed = SEED_CAL, cores = N_CORES) {
  scenario <- match.arg(scenario)
  mvar <- all.vars(fM[[2]]); yvar <- all.vars(fY[[2]])
  dat[[mvar]] <- droplevels(dat[[mvar]])    # 生成模型同样去掉空类；pm_probs 会补回五列
  if (scenario == "a0") {
    gen_M <- MASS::polr(stats::update(fM, stats::as.formula(paste(". ~ . -", x))), data = dat,
                        method = "logistic", Hess = FALSE, control = list(maxit = 500))
    gen_Y <- fit_logit(fY, dat)
  } else {
    gen_M <- MASS::polr(fM, data = dat, method = "logistic", Hess = FALSE, control = list(maxit = 500))
    gen_Y <- fit_logit(stats::update(fY, stats::as.formula(paste(". ~ . -", m3, "-", paste0(x, ":", m3)))), dat)
  }
  cumP <- t(apply(pm_probs(gen_M, dat, mvar, "po"), 1, cumsum))
  ids  <- sort(unique(dat[[CLUSTER]]))
  one <- function(r) tryCatch({
    set.seed(seed + r)
    u  <- runif(nrow(dat))
    s1 <- pmin(5L, 1L + as.integer(rowSums(u > cumP)))
    z  <- dat
    z[[mvar]] <- ord5(s1)
    z[[m3]]   <- cut3(s1)
    z[[yvar]] <- rbinom(nrow(z), 1L, predict(gen_Y, newdata = z, type = "response"))
    est <- stat_med(z, fM, fY, x, m3)
    bt  <- run_boot(z, make_plan(ids, B, seed + 100000L + r), function(q) stat_med(q, fM, fY, x, m3), cores = 1L)
    c(r = r, ok = 1, p = summ_boot(est, bt, "indirect")$p_raw)
  }, error = function(e) c(r = r, ok = 0, p = NA_real_))
  res <- if (cores > 1L) parallel::mclapply(seq_len(R), one, mc.cores = cores) else lapply(seq_len(R), one)
  res <- do.call(rbind, lapply(res, function(v) if (is.numeric(v) && length(v) == 3L) v else c(r = NA, ok = 0, p = NA)))
  ok   <- res[, "ok"] == 1
  rate <- mean(res[ok, "p"] <= 0.05)
  mcse <- sqrt(0.05 * 0.95 / max(1L, sum(ok)))
  list(scenario = scenario, R_ok = sum(ok), reject_rate = rate, threshold = 0.05 + 2 * mcse,
       flag = if (rate > 0.05 + 2 * mcse) "可能偏宽松：报告中加注" else "未见偏宽松",
       detail = res)
}

# ---------------------------------------------------------------------
# 11. 自检（只用合成数据）。全部 PASS 之前不要碰真实数据。
# ---------------------------------------------------------------------
self_test <- function(n = 20000L, B = 40L, seed = 7L, cores = N_CORES) {
  ok_all <- TRUE
  report <- function(name, pass, detail = "") {
    cat(sprintf("[%s] %s %s\n", if (isTRUE(pass)) "PASS" else "FAIL", name, detail))
    if (!isTRUE(pass)) ok_all <<- FALSE
  }
  set.seed(seed)
  cl  <- rep(seq_len(ceiling(n / 4)), each = 4L)[seq_len(n)]
  c1  <- rnorm(n); c2 <- rbinom(n, 1, 0.5)
  xa  <- rbinom(n, 1, plogis(0.2 * c1))
  s0  <- sample(1:5, n, replace = TRUE, prob = c(0.01, 0.015, 0.10, 0.20, 0.675))
  sp0 <- sample(1:5, n, replace = TRUE, prob = c(0.01, 0.015, 0.10, 0.20, 0.675))
  female <- rbinom(n, 1, 0.5)
  w3 <- cut3(s0); wsp3 <- cut3(sp0)

  # (1) A/B：已知真值
  etaA <- function(x, w) -0.3 + 0.4 * c1 - 0.2 * c2 + 0.3 * x + 0.2 * (w == "4") + 0.1 * (w == "5") -
    0.1 * x * (w == "4") - 0.5 * x * (w == "5")
  muB  <- function(x, w) exp(5 + 0.2 * c1 + 0.3 * x + 0.1 * (w == "5") - 0.2 * x * (w == "5"))
  y   <- rbinom(n, 1, plogis(etaA(xa, w3)))
  amt <- ifelse(y == 1, rgamma(n, shape = 1.5, rate = 1.5 / muB(xa, w3)), 0)
  T_P <- function(l) mean(plogis(etaA(1, l)) - plogis(etaA(0, l)))
  T_Y <- function(l) mean(plogis(etaA(1, l)) * muB(1, l) - plogis(etaA(0, l)) * muB(0, l))
  true_dP <- T_P("5") - T_P("le3"); true_dY <- T_Y("5") - T_Y("le3")
  dat <- data.frame(unified_component = cl, c1 = c1, c2 = c2, xa = xa, w_self3 = w3, w_spouse3 = wsp3,
                    female = female, y1_any = y, y1_amt = amt)
  fA <- y1_any ~ c1 + c2 + xa * w_self3
  fB <- y1_amt ~ c1 + c2 + xa * w_self3
  est <- stat_AB(dat, fA, fB, "xa", "w_self3")
  bt  <- run_boot(dat, make_plan(dat$unified_component, B, seed + 1L),
                  function(z) stat_AB(z, fA, fB, "xa", "w_self3"), cores = cores)
  sP <- summ_boot(est, bt, "d_P"); sY <- summ_boot(est, bt, "d_Y")
  report("A：d_P 回收真值", abs(sP$estimate - true_dP) < 4 * sP$se_boot,
         sprintf("est=%.4f true=%.4f se=%.4f", sP$estimate, true_dP, sP$se_boot))
  report("B：d_Y 回收真值", abs(sY$estimate - true_dY) < 4 * sY$se_boot,
         sprintf("est=%.2f true=%.2f se=%.2f", sY$estimate, true_dY, sY$se_boot))
  report("bootstrap 有效重复", sP$n_valid >= B - 1L, sprintf("%d/%d", sP$n_valid, B))
  report("主 CI 与 p 一致", (sP$p_raw <= 0.05) == (sP$ci_low > 0 | sP$ci_high < 0) || abs(sP$p_raw - 0.05) < 0.03,
         sprintf("p=%.3f CI=[%.4f, %.4f]", sP$p_raw, sP$ci_low, sP$ci_high))
  m1  <- fit_logit(fA, dat)
  ifr <- if_dP_logit(m1, dat, "xa", "w_self3")
  report("R8：影响函数点估计 = 标准化点估计", abs(ifr$estimate - sP$estimate) < 1e-8)
  report("R8：影响函数 SE 与 bootstrap SE 同量级", ifr$se_if / sP$se_boot > 0.6 && ifr$se_if / sP$se_boot < 1.6,
         sprintf("if=%.4f boot=%.4f", ifr$se_if, sP$se_boot))
  if (requireNamespace("sandwich", quietly = TRUE)) {
    lp <- lpm_dP(fA, dat, "xa", "w_self3")
    report("R5：LPM 可运行", is.finite(lp$estimate) && is.finite(lp$se_cl))
  } else report("R5：未安装 sandwich", FALSE)

  # (2) 中介：已知真值
  zeta <- c(-4.0, -3.2, -1.6, -0.1)                  # logit P(S<=k) = zeta_k - eta
  etaM <- function(x) 0.5 * x + 0.4 * (s0 == 4) + 0.9 * (s0 == 5) + 0.3 * c1
  pS   <- function(x) { cum <- sapply(zeta, function(z) plogis(z - etaM(x))); cbind(cum, 1) - cbind(0, cum) }
  u    <- runif(n)
  s1   <- pmin(5L, 1L + as.integer(rowSums(u > t(apply(pS(xa), 1, cumsum)))))
  etaY <- function(x, m) -0.8 + 0.3 * c1 + 0.2 * x + 0.5 * (m == "4") + 0.7 * (m == "5") + 0.2 * (s0 == 5)
  m3   <- cut3(s1)
  ym   <- rbinom(n, 1, plogis(etaY(xa, m3)))
  Qk   <- sapply(1:5, function(k) plogis(etaY(1, if (k <= 3) "le3" else as.character(k))))
  true_ind <- mean(rowSums(Qk * (pS(1) - pS(0))))
  dm <- data.frame(unified_component = cl, c1 = c1, xa = xa, s1_self = ord5(s1), m3_self = m3,
                   s0_self4 = cut4(s0), y1_any = ym)
  fM <- s1_self ~ xa + s0_self4 + c1
  fY <- y1_any ~ xa * m3_self + s0_self4 + c1
  estm <- stat_med(dm, fM, fY, "xa", "m3_self")
  btm  <- run_boot(dm, make_plan(dm$unified_component, B, seed + 2L),
                   function(z) stat_med(z, fM, fY, "xa", "m3_self"), cores = cores)
  sI <- summ_boot(estm, btm, "indirect"); sa <- summ_boot(estm, btm, "a_logOR")
  report("C：间接对比回收真值", abs(sI$estimate - true_ind) < 4 * sI$se_boot,
         sprintf("est=%.5f true=%.5f se=%.5f", sI$estimate, true_ind, sI$se_boot))
  report("C：a 路径 logOR 回收 0.5", abs(sa$estimate - 0.5) < 4 * sa$se_boot,
         sprintf("est=%.3f se=%.3f", sa$estimate, sa$se_boot))
  if (requireNamespace("ordinal", quietly = TRUE)) {
    ep <- tryCatch(stat_med(dm, fM, fY, "xa", "m3_self", m_model = "ppo"), error = function(e) NULL)
    report("R11：部分比例优势中介模型可运行", !is.null(ep) && all(is.finite(ep)))
  } else report("R11：未安装 ordinal", FALSE)

  # (3) 次级族、校准、多重比较的冒烟测试
  report("S1 可运行", all(is.finite(stat_S1(dat, y1_any ~ c1 + c2 + xa * w_self3 + xa * w_spouse3))))
  report("S2 可运行", all(is.finite(stat_S2(dat, y1_any ~ c1 + c2 + xa))))
  report("S3/S4 可运行", all(is.finite(stat_S34(dat, fA, "w_self3"))))
  cal <- calib_med(dm[seq_len(4000), ], fM, fY, "xa", "m3_self", "a0", R = 2L, B = 9L, cores = 1L)
  report("校准函数可运行", cal$R_ok >= 1L, sprintf("R_ok=%d", cal$R_ok))
  report("p.adjust(n=14) 按预期", isTRUE(all.equal(p.adjust(c(0.001, 0.02), "BH", n = 14), c(0.014, 0.14))))
  if (!ok_all) stop("self_test 未全部通过：先修代码，不要运行真实数据。")
  cat("self_test 全部通过。\n")
  invisible(TRUE)
}

# 计时：真实协变量 + 合成结局，不看真实结局
time_test <- function(d, B = 20L, cores = N_CORES) {
  if (is.null(COV22)) load_covariates()
  set.seed(99)
  z <- d
  z$y1_any <- rbinom(nrow(z), 1, 0.45)
  z$y1_amt <- ifelse(z$y1_any == 1, rgamma(nrow(z), 1.2, 1.2 / 300), 0)
  plan <- make_plan(z[[CLUSTER]], B, 1L)
  sp <- AB_SPECS[[1]]; covs <- covs_for(sp$drop)
  fA <- fml("y1_any", c(covs, paste(sp$x, "*", sp$w))); fB <- fml("y1_amt", c(covs, paste(sp$x, "*", sp$w)))
  dat <- zscale(analysis_sample(z, c(all.vars(fA), "y1_amt")), covs)
  tAB <- system.time(run_boot(dat, plan, function(q) stat_AB(q, fA, fB, sp$x, sp$w), cores = cores))[["elapsed"]]
  cs <- C_SPECS[[1]]; covs <- covs_for(cs$drop)
  fM <- fml(cs$s1, c(cs$x, cs$s0, covs)); fY <- fml("y1_any", c(paste(cs$x, "*", cs$m3), cs$s0, covs))
  datm <- zscale(analysis_sample(z, unique(c(all.vars(fM), all.vars(fY)))), covs)
  tC <- system.time(run_boot(datm, plan, function(q) stat_med(q, fM, fY, cs$x, cs$m3), cores = cores))[["elapsed"]]
  per_AB <- tAB / B; per_C <- tC / B
  main_min <- (4 * per_AB + 4 * per_C + 2 * 0.4 * per_C + 4 * per_AB) * B_MAIN / 60
  cal_min  <- 3 * 200 * 100 * per_C / 60
  cat(sprintf("每次重复（%d 核墙钟）：A/B %.2f 秒，C %.2f 秒。\n主估计与次级族约 %.0f 分钟；校准约 %.0f 分钟。\n",
              cores, per_AB, per_C, main_min, cal_min))
  invisible(c(per_AB = per_AB, per_C = per_C, main_min = main_min, cal_min = cal_min))
}

# ---------------------------------------------------------------------
# 12. 分步驱动
# ---------------------------------------------------------------------
# 第 0 步：只输出计数、达标与否和数据核查；不输出任何 X×W 或 X×M 的结局比较
step0_checks <- function(d, msateco_path = file.path(PKG_DIR, "data/msateco_intervals.csv")) {
  ensure_out()
  if (is.null(COV22)) load_covariates()
  # (1) 样本流与支持（A/B）
  flow <- list(); posi <- list()
  for (sp in AB_SPECS) {
    covs <- covs_for(sp$drop)
    s <- analysis_sample(d, c(sp$x, sp$w, "y1_any", "y1_amt", covs))
    flow[[sp$A]] <- data.frame(tests = paste(sp$A, sp$B, sep = "/"), universe = nrow(d),
      has_x = sum(!is.na(d[[sp$x]])), has_x_w = sum(!is.na(d[[sp$x]]) & !is.na(d[[sp$w]])),
      has_x_w_y = sum(!is.na(d[[sp$x]]) & !is.na(d[[sp$w]]) & !is.na(d$y1_amt)),
      complete = nrow(s), clusters = length(unique(s[[CLUSTER]])), stringsAsFactors = FALSE)
    tab <- table(s[[sp$x]], s[[sp$w]])
    pos <- s[s$y1_any == 1L, , drop = FALSE]
    min_pos <- min(table(factor(pos[[sp$x]], levels = 0:1), pos[[sp$w]]))
    posi[[sp$A]] <- data.frame(tests = paste(sp$A, sp$B, sep = "/"), min_cell_rows = min(tab),
      cells_ge_100 = all(tab >= 100), min_cell_positive_ge_30 = min_pos >= 30, stringsAsFactors = FALSE)
    utils::write.csv(as.data.frame(tab), file.path(OUT_DIR, sprintf("step0_cells_%s.csv", sp$A)), row.names = FALSE)
  }
  w <- build_threewave(d)
  for (sp in D_SPECS) {
    covs <- covs_D(sp$drop)
    s <- analysis_sample(w, c(sp$x, sp$s1, sp$m3, sp$s0, "y1_any", covs))
    flow[[sp$id]] <- data.frame(tests = sp$id, universe = nrow(w), has_x = sum(!is.na(w[[sp$x]])),
      has_x_w = NA, has_x_w_y = NA, complete = nrow(s), clusters = length(unique(s[[CLUSTER]])),
      stringsAsFactors = FALSE)
    posi[[sp$id]] <- data.frame(tests = sp$id, min_cell_rows = NA, cells_ge_100 = NA,
      min_cell_positive_ge_30 = NA, xm_min_ge_30 = min_cell(s[[sp$x]], s[[sp$m3]]) >= 30,
      chain_ge_2000 = nrow(s) >= 2000, stringsAsFactors = FALSE)
  }
  for (sp in C_SPECS[1:2]) {
    covs <- covs_for(sp$drop)
    s <- analysis_sample(d, c(sp$x, sp$s1, sp$m3, sp$s0, "y1_any", covs))
    flow[[sp$id]] <- data.frame(tests = sp$id, universe = nrow(d), has_x = sum(!is.na(d[[sp$x]])),
      has_x_w = NA, has_x_w_y = NA, complete = nrow(s), clusters = length(unique(s[[CLUSTER]])),
      stringsAsFactors = FALSE)
    posi[[sp$id]] <- data.frame(tests = sp$id, min_cell_rows = NA, cells_ge_100 = NA,
      min_cell_positive_ge_30 = NA, xm_min_ge_30 = min_cell(s[[sp$x]], s[[sp$m3]]) >= 30,
      chain_ge_2000 = NA, stringsAsFactors = FALSE)
  }
  # (2) msateco：三项检查后写判定
  decision <- "D3D4_RESERVE_ACTIVE"; why <- "未找到 msateco_intervals.csv"
  if (file.exists(msateco_path)) {
    de <- add_msateco(d, msateco_path)
    lk <- rbind(link_check(de, "spouse_sat_begin", "spouse_sat_end", "self_sat_begin", "self_sat_end", "阳性对照：总体满意度"),
                link_check(de, "eco_spouse_begin", "eco_spouse_end", "eco_self_begin", "eco_self_end", "msateco"))
    utils::write.csv(lk, file.path(OUT_DIR, "step0_msateco_link_check.csv"), row.names = FALSE)
    idx <- stats::complete.cases(de[, unique(c("xa", "y1_any", covs_for("none"), CLUSTER)), drop = FALSE])
    nonmiss <- mean(!is.na(de$eco_spouse_begin[idx]) & !is.na(de$eco_spouse_end[idx]))
    xm_ok <- all(vapply(C_SPECS[3:4], function(sp) {
      s <- analysis_sample(de, c(sp$x, sp$s1, sp$m3, sp$s0, "y1_any", covs_for(sp$drop)))
      min_cell(s[[sp$x]], s[[sp$m3]]) >= 30
    }, logical(1)))
    pass <- lk$mismatch_begin[1] == 0 && lk$mismatch_end[1] == 0 &&
      lk$mismatch_begin[2] == 0 && lk$mismatch_end[2] == 0 && nonmiss >= 0.80 && xm_ok
    decision <- if (pass) "C3C4_ACTIVE" else "D3D4_RESERVE_ACTIVE"
    why <- sprintf("行匹配率 %.3f；对接不一致 %d/%d；非缺失 %.3f；X×M 最小格达标 %s",
                   attr(de, "msateco_row_match"), lk$mismatch_begin[2], lk$mismatch_end[2], nonmiss, xm_ok)
  }
  writeLines(c(decision, why), file.path(OUT_DIR, "msateco_decision.txt"))
  # (3) 协变量时间属性：跨两个区间的同一二元组，起点值是否相同
  p1 <- d[d$period == "2018-2020", ]; p2 <- d[d$period == "2020-2022", ]
  j  <- match(p1$dyad_id, p2$dyad_id); k <- !is.na(j)
  aud <- do.call(rbind, lapply(setdiff(COV23, "period_fe"), function(v) {
    a <- p1[[v]][k]; b <- p2[[v]][j[k]]; ok <- !is.na(a) & !is.na(b)
    data.frame(variable = v, linked_dyads = sum(ok), share_identical = mean(a[ok] == b[ok]),
               stringsAsFactors = FALSE)
  }))
  aud$role <- ifelse(aud$variable == "dwm_begin", "剔除：2016–2022 累计，含区间之后信息（只在 R1 历史定义对照中使用）",
              ifelse(aud$variable %in% c("gender_begin", "prtgender_begin", "lifetime_begin"), "固定特征",
                     "区间起点值（build 脚本 getv(x, begin)）"))
  age_jump <- p2$aage_begin[j[k]] - p1$aage_begin[k]
  edu_chg  <- mean(p2$actor_edu2_begin[j[k]] != p1$actor_edu2_begin[k], na.rm = TRUE)
  utils::write.csv(aud, file.path(OUT_DIR, "variable_role_audit.csv"), row.names = FALSE)
  writeLines(c(sprintf("年龄两期差不等于 2 的二元组：%d", sum(age_jump != 2, na.rm = TRUE)),
               sprintf("actor_edu2 两期不同的比例：%.3f", edu_chg),
               "请在原始库核对：上述异常、ahw_ 的含义与波次、支持缺失行的 QF601/QF602 原因。"),
             file.path(OUT_DIR, "variable_role_flags.txt"))
  # (4) 支持缺失行：交给 astra 去原始 QF601/QF602 查原因
  miss <- d[is.na(d$support_real_begin) | is.na(d$support_real_end),
            c("dyad_id", "period", "actor_pid_begin", "parent_pid_begin", "support_real_begin", "support_real_end")]
  utils::write.csv(miss, file.path(OUT_DIR, "support_missing_rows.csv"), row.names = FALSE)
  utils::write.csv(bind_fill(flow), file.path(OUT_DIR, "sample_flow.csv"), row.names = FALSE)
  utils::write.csv(bind_fill(posi), file.path(OUT_DIR, "positivity.csv"), row.names = FALSE)
  cat("第 0 步完成。msateco 判定：", decision, "\n", why, "\n")
  invisible(list(flow = bind_fill(flow), positivity = bind_fill(posi), decision = decision))
}

step0_freeze <- function(amendment_path = file.path(PKG_DIR, "ANALYSIS_AMENDMENT_v4.md")) {
  ensure_out()
  files <- c(REGISTRY, amendment_path, file.path(OUT_DIR, "msateco_decision.txt"))
  stopifnot(all(file.exists(files)))
  h <- tools::md5sum(files)
  writeLines(c(paste("frozen_at:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")), paste(h, names(h))),
             file.path(OUT_DIR, "FREEZE_v4.txt"))
}
check_frozen <- function() {
  f <- file.path(OUT_DIR, "FREEZE_v4.txt")
  if (!file.exists(f)) stop("还没有冻结（step0_freeze）。冻结之前不运行任何真实结局模型。")
  invisible(TRUE)
}
read_decision <- function() {
  f <- file.path(OUT_DIR, "msateco_decision.txt")
  stopifnot(file.exists(f))
  identical(readLines(f, n = 1L), "C3C4_ACTIVE")
}

step1_AB <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_MAIN, SEED_MAIN, "plan_main_B2000.rds")
  out <- run_AB_specs(AB_SPECS, d, plan, covs_for, tag = "step1")
  utils::write.csv(out, file.path(OUT_DIR, "step1_AB_results.csv"), row.names = FALSE)
  out
}

step3a_calibration <- function(d, R = 200L, B = 99L) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  use_eco <- read_decision()
  runs <- list(list(sp = C_SPECS[[1]], base = d, cf = covs_for, sc = "a0"),
               list(sp = D_SPECS[[1]], base = build_threewave(d), cf = covs_D, sc = "a0"))
  runs[[3]] <- if (use_eco) list(sp = C_SPECS[[3]], base = add_msateco(d), cf = covs_for, sc = "b0") else
    list(sp = C_SPECS[[1]], base = d, cf = covs_for, sc = "b0")
  out <- lapply(runs, function(r) {
    covs <- r$cf(r$sp$drop)
    fM <- fml(r$sp$s1, c(r$sp$x, r$sp$s0, covs))
    fY <- fml("y1_any", c(paste(r$sp$x, "*", r$sp$m3), r$sp$s0, covs))
    dat <- zscale(analysis_sample(r$base, unique(c(all.vars(fM), all.vars(fY)))), covs)
    cal <- calib_med(dat, fM, fY, r$sp$x, r$sp$m3, r$sc, R = R, B = B)
    data.frame(test_id = r$sp$id, scenario = cal$scenario, R_ok = cal$R_ok,
               reject_rate = cal$reject_rate, threshold = cal$threshold, flag = cal$flag,
               stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, out)
  utils::write.csv(out, file.path(OUT_DIR, "step3a_calibration.csv"), row.names = FALSE)
  out
}

step3b_CD <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_MAIN, SEED_MAIN, "plan_main_B2000.rds")
  use_eco <- read_decision()
  resC <- run_med(if (use_eco) C_SPECS else C_SPECS[1:2], if (use_eco) add_msateco(d) else d,
                  plan, covs_for, tag = "step3")
  w <- build_threewave(d)
  resD <- run_med(D_SPECS, w, plan, covs_D, tag = "step3")
  resR <- if (!use_eco) run_AB_specs(D_RESERVE, w, plan, covs_D, tag = "step3", with_B = FALSE) else NULL
  out <- bind_fill(list(resC, resD, resR))
  utils::write.csv(out, file.path(OUT_DIR, "step3_CD_results.csv"), row.names = FALSE)
  out
}

step4_S <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_MAIN, SEED_MAIN, "plan_main_B2000.rds")
  rows <- list()
  go <- function(id, f, covs, sfun, keys) {
    dat <- zscale(analysis_sample(d, unique(c(all.vars(f), "female"))), covs)
    est <- sfun(dat); bt <- run_boot(dat, plan, sfun)
    saveRDS(list(f = f, est = est, boot = bt, n = nrow(dat)), file.path(OUT_DIR, sprintf("step4_%s.rds", id)))
    lapply(keys, function(k) cbind(test_id = id, tag = "step4", n = nrow(dat),
                                   n_cl = length(unique(dat[[CLUSTER]])), summ_boot(est, bt, k)))
  }
  c1 <- covs_for("both")
  f1 <- fml("y1_any", c(c1, "xa * w_self3", "xa * w_spouse3"))
  rows <- c(rows, go("S1", f1, c1, function(z) stat_S1(z, f1), c("S1", "d_self_joint", "d_spouse_joint")))
  c2 <- covs_for("none", drop = "gender_begin")
  f2 <- fml("y1_any", c(c2, "xa"))
  rows <- c(rows, go("S2", f2, c2, function(z) stat_S2(z, f2), c("S2", "T_female", "T_male")))
  c3 <- covs_for("self", drop = "gender_begin")
  f3 <- fml("y1_any", c(c3, "xa * w_self3"))
  rows <- c(rows, go("S3", f3, c3, function(z) stat_S34(z, f3, "w_self3"), c("diff", "d_female", "d_male")))
  c4 <- covs_for("spouse", drop = "gender_begin")
  f4 <- fml("y1_any", c(c4, "xa * w_spouse3"))
  rows <- c(rows, go("S4", f4, c4, function(z) stat_S34(z, f4, "w_spouse3"), c("diff", "d_female", "d_male")))
  out <- do.call(rbind, rows)
  utils::write.csv(out, file.path(OUT_DIR, "step4_S_results.csv"), row.names = FALSE)
  out
}

step5_robustness <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_ROB, SEED_ROB, "plan_rob_B500.rds")
  use_eco <- read_decision()
  specsC <- if (use_eco) C_SPECS else C_SPECS[1:2]
  dC <- if (use_eco) add_msateco(d) else d
  w  <- build_threewave(d)
  c23  <- function(dr) covs_for(dr, base = COV23)
  c23D <- function(dr) covs_D(dr, base = COV23)
  save_csv <- function(x, name) { utils::write.csv(x, file.path(OUT_DIR, paste0(name, ".csv")), row.names = FALSE); x }
  # R1 历史定义对照（23 项，含 dwm）
  save_csv(bind_fill(list(run_AB_specs(prefix_specs(AB_SPECS, "R1"), d, plan, c23, tag = "R1"),
                      run_med(prefix_specs(specsC, "R1"), dC, plan, c23, tag = "R1"),
                      run_med(prefix_specs(D_SPECS, "R1"), w, plan, c23D, tag = "R1"))), "R1_cov23")
  # R2 来自第 1 步主抽样（d_P_5v4、d_Y_5v4 与 T 曲线），在 step6 汇总，不重跑
  # R3 XL：0 对正值 75 分位（在 A1 分析样本中一次性固定）
  s_a1 <- analysis_sample(d, c("xl", "w_self3", "y1_any", "y1_amt", covs_for("self")))
  q75  <- unname(stats::quantile(s_a1$xl[s_a1$xl > 0], 0.75))
  writeLines(sprintf("XL 对比：0 对 %.6f（A1 分析样本正值 75 分位）", q75), file.path(OUT_DIR, "R3_xl_contrast.txt"))
  xl_specs <- lapply(prefix_specs(AB_SPECS[1:2], "R3"), function(sp) { sp$x <- "xl"; sp })
  save_csv(run_AB_specs(xl_specs, d, plan, covs_for, tag = "R3", x_hi = q75, x_lo = 0), "R3_xl")
  # R4 actor-period 汇总（父母两行合为一行）
  a <- build_actor_period(d)
  save_csv(run_AB_specs(prefix_specs(AB_SPECS, "R4"), a, plan, covs_R4, tag = "R4"), "R4_actor_period")
  # R5 线性概率模型（簇稳健）
  save_csv(do.call(rbind, lapply(AB_SPECS, function(sp) {
    covs <- covs_for(sp$drop); f <- fml("y1_any", c(covs, paste(sp$x, "*", sp$w)))
    dat <- zscale(analysis_sample(d, all.vars(f)), covs)
    cbind(test_id = paste0("R5_", sp$A), lpm_dP(f, dat, sp$x, sp$w))
  })), "R5_lpm")
  # R6 金额 p99 封顶（只看 B）
  cap <- unname(stats::quantile(d$y1_amt[!is.na(d$y1_amt) & d$y1_amt > 0], 0.99))
  d6 <- d; d6$y1_amt_cap <- pmin(d6$y1_amt, cap)
  r6 <- run_AB_specs(prefix_specs(AB_SPECS, "R6"), d6, plan, covs_for, tag = "R6", yB = "y1_amt_cap")
  save_csv(r6[grepl("_Y", r6$estimand), ], "R6_cap99")
  # R7 原结局 y_growth
  save_csv(run_AB_specs(prefix_specs(AB_SPECS, "R7"), d, plan, covs_for, tag = "R7", with_B = FALSE,
                    yA = "y_growth"), "R7_ygrowth")
  # R8 影响函数（Delta）标准误，对照 A 的 bootstrap
  save_csv(do.call(rbind, lapply(AB_SPECS, function(sp) {
    covs <- covs_for(sp$drop); f <- fml("y1_any", c(covs, paste(sp$x, "*", sp$w)))
    dat <- zscale(analysis_sample(d, c(all.vars(f), "y1_amt")), covs)
    cbind(test_id = paste0("R8_", sp$A), if_dP_logit(fit_logit(f, dat), dat, sp$x, sp$w))
  })), "R8_influence")
  # R9 C/D 改用两部分金额结局
  save_csv(bind_fill(list(run_med(prefix_specs(specsC, "R9"), dC, plan, covs_for, tag = "R9", y_type = "twopart"),
                      run_med(prefix_specs(D_SPECS, "R9"), w, plan, covs_D, tag = "R9", y_type = "twopart"))),
       "R9_amount")
  # R10 D 的 Y 模型加入 2020 年支持（处理后调整，估计对象不同）
  save_csv(run_med(prefix_specs(D_SPECS, "R10"), w, plan, covs_D, tag = "R10",
               extra_y = c("y2020_any", "y2020_ihs")), "R10_y2020")
  # R11 部分比例优势中介模型
  save_csv(run_med(prefix_specs(specsC, "R11"), dC, plan, covs_for, tag = "R11", m_model = "ppo"), "R11_ppo")
  # 比例优势诊断（同一五分类；常规 LR 不计聚类，只作诊断）
  po <- function(specs, base, cf, tag) do.call(rbind, lapply(specs, function(sp) {
    covs <- cf(sp$drop); fM <- fml(sp$s1, c(sp$x, sp$s0, covs))
    dat <- zscale(analysis_sample(base, all.vars(fM)), covs)
    dat[[sp$s1]] <- droplevels(dat[[sp$s1]])
    m0 <- ordinal::clm(fM, data = dat, link = "logit")
    m1 <- ordinal::clm(stats::update(fM, stats::as.formula(paste(". ~ . -", sp$x))),
                       nominal = stats::as.formula(paste("~", sp$x)), data = dat, link = "logit")
    lr <- 2 * (as.numeric(logLik(m1)) - as.numeric(logLik(m0)))
    df <- length(coef(m1)) - length(coef(m0))
    data.frame(test_id = sp$id, LR = lr, df = df, p_naive = stats::pchisq(lr, df, lower.tail = FALSE),
               note = "常规 LR，未计聚类；只作诊断，不作换模门槛", stringsAsFactors = FALSE)
  }))
  if (requireNamespace("ordinal", quietly = TRUE))
    save_csv(rbind(po(specsC, dC, covs_for, "C"), po(D_SPECS, w, covs_D, "D")), "PO_diagnostic")
  invisible(TRUE)
}

# 第 6 步：汇总、校正、与理论方向对照
align_label <- function(est, lo, hi, q, direction) {
  excl0 <- lo > 0 | hi < 0
  dir_ok <- (direction == "+" & est > 0) | (direction == "-" & est < 0)
  ifelse(is.na(est), "待执行或不可估",
  ifelse(!excl0, "不能判断（主 CI 含 0，不等于效应为 0）",
  ifelse(direction == "?", ifelse(q < 0.05, "通过本族校正（无事先方向）", "主 CI 不含 0，未通过本族校正"),
  ifelse(dir_ok & q < 0.05, "方向符合理论且通过本族校正（探索性）",
  ifelse(dir_ok, "方向符合理论，主 CI 不含 0，但未通过本族校正",
  ifelse(q < 0.05, "方向与理论相反，且通过本族校正（照实报告）",
         "方向与理论相反，主 CI 不含 0，未通过本族校正（照实报告）"))))))
}

step6_assemble <- function() {
  ensure_out()
  rd  <- function(f) { p <- file.path(OUT_DIR, f); if (file.exists(p)) utils::read.csv(p, stringsAsFactors = FALSE) else NULL }
  reg <- utils::read.csv(REGISTRY, stringsAsFactors = FALSE)
  allres <- bind_fill(list(rd("step1_AB_results.csv"), rd("step3_CD_results.csv"), rd("step4_S_results.csv")))
  if (is.null(allres)) stop("还没有任何结果文件")
  key <- paste(allres$test_id, allres$estimand)
  pick <- function(fam) {
    r <- reg[reg$family == fam, ]
    merge(r[, c("test_id", "estimand_key", "theory_direction", "label")],
          allres[key %in% paste(r$test_id, r$estimand_key), ],
          by.x = c("test_id", "estimand_key"), by.y = c("test_id", "estimand"), all.x = TRUE)
  }
  # 条件名额：按第 0 步冻结的 msateco 判定，只保留 C3/C4 或 D3/D4 其中一对；未运行的检验保留为“待执行”
  dec <- if (file.exists(file.path(OUT_DIR, "msateco_decision.txt"))) read_decision() else NA
  drop_ids <- if (identical(dec, FALSE)) c("C3", "C4") else c("D3", "D4")
  P <- pick("P14")
  P <- P[!(P$test_id %in% drop_ids), ]
  stopifnot(nrow(P) <= N_PRIMARY)
  ran <- !is.na(P$p_raw)
  P$p_BH14 <- NA_real_; P$p_BY14 <- NA_real_
  P$p_BH14[ran] <- p.adjust(P$p_raw[ran], "BH", n = N_PRIMARY)
  P$p_BY14[ran] <- p.adjust(P$p_raw[ran], "BY", n = N_PRIMARY)
  P$alignment <- align_label(P$estimate, P$ci_low, P$ci_high, P$p_BH14, P$theory_direction)
  S <- pick("S4")
  ranS <- !is.na(S$p_raw)
  S$p_BH4 <- NA_real_; S$p_BY4 <- NA_real_
  S$p_BH4[ranS] <- p.adjust(S$p_raw[ranS], "BH", n = N_SECOND)
  S$p_BY4[ranS] <- p.adjust(S$p_raw[ranS], "BY", n = N_SECOND)
  S$alignment <- paste0(align_label(S$estimate, S$ci_low, S$ci_high, S$p_BH4, S$theory_direction),
                        ifelse(S$test_id == "S1", "", "；数据启发，只作假设生成"))
  utils::write.csv(P, file.path(OUT_DIR, "primary_family_P14.csv"), row.names = FALSE)
  utils::write.csv(S, file.path(OUT_DIR, "secondary_family_S4.csv"), row.names = FALSE)
  # 全部检验合并校正（参照）：旧 150×2（不适用者内部按 1）+ 新 14 + 4
  hist <- utils::read.csv(file.path(PKG_DIR, "screening/status_120_specs_v1/ALL_300_STATUS.csv"), stringsAsFactors = FALSE)
  hp <- ifelse(is.na(hist$p_exploratory), 1, hist$p_exploratory)
  J <- data.frame(source = c(paste(hist$spec_id, hist$metric), paste("v4", P$test_id), paste("v4", S$test_id)),
                  p_raw = c(hp, P$p_raw, S$p_raw), stringsAsFactors = FALSE)
  m_all <- 300L + N_PRIMARY + N_SECOND
  okJ <- !is.na(J$p_raw)
  J$p_BH_all <- NA_real_; J$p_BY_all <- NA_real_
  J$p_BH_all[okJ] <- p.adjust(J$p_raw[okJ], "BH", n = m_all)
  J$p_BY_all[okJ] <- p.adjust(J$p_raw[okJ], "BY", n = m_all)
  utils::write.csv(J, file.path(OUT_DIR, "joint_scope_318.csv"), row.names = FALSE)
  # 长表：全部估计量（主、次级、R2 及其余稳健性），不显著不删除
  rob <- lapply(c("R1_cov23", "R3_xl", "R4_actor_period", "R5_lpm", "R6_cap99", "R7_ygrowth", "R8_influence",
                  "R9_amount", "R10_y2020", "R11_ppo", "PO_diagnostic"), function(f) {
    x <- rd(paste0(f, ".csv")); if (!is.null(x)) x$source_file <- f; x })
  long <- bind_fill(c(list(allres), rob))
  utils::write.csv(long, file.path(OUT_DIR, "effects_long.csv"), row.names = FALSE)
  utils::write.csv(rbind(P[, c("test_id", "label", "theory_direction", "estimate", "ci_low", "ci_high",
                               "p_raw", "alignment")],
                         S[, c("test_id", "label", "theory_direction", "estimate", "ci_low", "ci_high",
                               "p_raw", "alignment")]),
                   file.path(OUT_DIR, "hypothesis_alignment.csv"), row.names = FALSE)
  write_manifest()
  invisible(list(P = P, S = S))
}

write_manifest <- function() {
  ensure_out()
  inputs <- file.path(PKG_DIR, c("data/analysis_13092.rds", "data/fixed_23_covariates.txt",
                                 "data/msateco_intervals.csv", "20261005_test_registry_v4.csv",
                                 "20261005_astra_v4_functions.R", "ANALYSIS_AMENDMENT_v4.md"))
  inputs <- inputs[file.exists(inputs)]
  writeLines(c(capture.output(sessionInfo()), "", "md5:", paste(tools::md5sum(inputs), inputs), "",
               sprintf("seeds: main=%d rob=%d cal=%d", SEED_MAIN, SEED_ROB, SEED_CAL),
               sprintf("B: main=%d rob=%d; cores=%d", B_MAIN, B_ROB, N_CORES),
               "抽样计划：v4_outputs/plan_main_B2000.rds、plan_rob_B500.rds（事先生成，已保存）",
               "失败记录：各 RDS 的 boot$fail_idx 与 boot$fail_msg"),
             file.path(OUT_DIR, "estimation_manifest.txt"))
}

# ---------------------------------------------------------------------
# run_v4.R 示例（逐步运行，每步看输出再进下一步）
# ---------------------------------------------------------------------
# source("20261005_astra_v4_functions.R")
# self_test()                                  # 必须全部 PASS
# load_covariates(); d <- prep_data()
# time_test(d)                                 # 合成结局计时
# Sys.setenv(CMA_PREDATA = "/Users/lzhs/.../predata_FE_16_22_unbal.dta"); extract_msateco()
# step0_checks(d)                              # 只看计数、达标与否、msateco 判定
# # 写 ANALYSIS_AMENDMENT_v4.md（方案第二、四、五、六节 + 第八节披露 + msateco 判定 + support 缺失核查），然后：
# step0_freeze()
# r1 <- step1_AB(d)                            # 第 1 步
# # 第 2 步：技术暂停，汇报 A/B 全部 8 项（BH/BY 按 n=14），不按 p 值改后续
# cal <- step3a_calibration(d)                 # 第 3a 步（只产生拒绝率，不产生真实 C/D 估计）
# r3 <- step3b_CD(d)                           # 第 3b 步
# r4 <- step4_S(d)                             # 第 4 步
# step5_robustness(d)                          # 第 5 步
# step6_assemble()                             # 第 6 步


## 来源：LOCAL_COUNTS.json
SHA256: ee176038e77f806026ffdd09be52b391cbc0b4961027f04b1f7e02fd4675a761

{
  "source": "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/delivery/Claude云端分析资料_20261005_v1/data/analysis_13092.csv",
  "sha256": "882923dabc66eb15767df9307ec2f1392540a9e8c4c30eed89fca2e1d439bedc",
  "rows": 13092,
  "clusters": 3212,
  "new_models": 0,
  "self_sat_begin": {
    "4": 2549,
    "5": 8871,
    "3": 1368,
    "1": 121,
    "2": 180,
    "NA": 3
  },
  "spouse_sat_begin": {
    "3": 1331,
    "5": 8916,
    "4": 2567,
    "2": 162,
    "1": 109,
    "NA": 7
  },
  "x_abs": {
    "1": 6639,
    "0": 6453
  },
  "x_rel": {
    "NA": 5103,
    "0": 6388,
    "1": 1601
  },
  "support_real_begin": {
    "missing": 109,
    "zero": 7303,
    "positive": 5680,
    "negative": 0
  },
  "support_real_end": {
    "missing": 129,
    "zero": 6984,
    "positive": 5979,
    "negative": 0
  },
  "threewave_dyads": 4564
}

## 来源：PLAN_AND_STATIC_AUDIT.md
SHA256: f8838603e9c3ee977196b88c158cdd67742f48ac265ee8b93279664bfd880140

# 新版融合方案：执行前审查与计划

状态：源文件已绑定，静态代码审查进行中；尚未运行新版真实模型，尚未提交新版 NLM。旧六项 B=1000 保持优先级暂停，已完成五项不重跑。

目标：探索数据和理论允许的收入—婚姻满意度—代际支持中介与调节组合，识别证据最强且可解释的结果；完整披露搜索与不显著结果，最终对应修订 Word。不得保证显著性或把提高 bootstrap 次数称为独立验证。

## 拟保留，待数据核查及 NLM 审核后冻结
- 主满意度对比按已确认的 5 分对 ≤3 分；4 分保留模型中，5 对 4 为辅助。
- 主 X 为绝对收入增加 XA 与夫妻相对位置升级 XR；XR 必须限定基期风险集。连续收入变化列为辅助。
- A/B 各四项：期末是否支持的概率对比差，以及两部分合成总体金额对比差。不是仅检验 logit 交互系数。
- C/D 计算完整模型化间接对比，不能仅凭 X→M 显著代替中介；不按路径 p 值决定运行资格。
- 条件 C3/C4 与备用 D3/D4 按数据资格选一组，最终逐项冻结 14 项主检验；不依据结果切换。
- 新主检验全族 BH/BY；旧 150 规格及此前已完成的另一批 14 项均披露。318 项只能称特定合并集合，不能声称覆盖全部自适应分析历史。

## 已核代码缺口及待决点
1. check_frozen 只检查 FREEZE 文件存在：必须改为核数据、代码、注册表、资格决定、抽样计划的 SHA256，运行前逐项校验。
2. step0_checks 的 A/B、C/D 支持门槛部分只落表；执行入口须强制检查。补零事件、正事件、有效簇与空水平，不只看总行数。
3. step0_checks 用规则自动标注“区间起点值”不能证明处理前属性。逐项追查23控制来源、时点；dwm 不进入新主设定，其他变量不按 p 值取舍。
4. y_any 目前由金额>0生成。需从原 QF601/QF602 区分未支持与支持但金额缺失；A 与 B 不为复用模型强制同样本。
5. msateco 必须回原始 predata 取1—5值，核题义、本人/配偶对应、波次、非缺失和行匹配。百分位变量不可当原量表。
6. centered-bootstrap 加一 p 与 type=7 分位 CI 不保证有限样本下严格一致；需明确检验与区间定义、边界及模拟检验，不以连续或更小 p 作为正确标准。
7. 中介零假设包含 a=0、b=0、两者为0；审查模拟是否保留簇依赖及模型复杂度，不能以少量自测宣称全面校准。
8. 有效 bootstrap<98% 时不能只贴标签后进入主结论；预设失败处置，保留全部失败索引，不挑成功重复补齐。
9. 共享抽样计划加载只核B/seed，须核簇全集与数据身份。每个结果保存原draw索引，合成两部分共同重拟合。
10. self_test、比例优势诊断、三波时间假设及每个估计目标仍需细核；不盲用7核或迁移原R会话。

## 执行顺序
1. 当前历史库云端分片回下载、整流解压 SHA 校验后，确认源未使用，再按原授权精确释放；恢复统计作业磁盘底线。
2. 独立沙盒完成数据来源/角色/缺失/风险集/聚类及脚本审查，保留云端原件。模拟自测先于真实新模型。
3. 给 NLM 当前恢复后的论文 PDF、两方方案、注册表、本地事实及上述分歧；包含此前已见的结果。逐项裁决后形成唯一合同，不把旧咨询称本次共识。
4. 合同固定正式 B、推断、14项身份及辅助清单。B=200 用于用户原筛选策略；v4建议正式B=2000的成本/必要性在共识中明确，不暗中替换B=1000。
5. A/B先运行和技术核收；C/D按支持/时序/校准继续，不以A/B是否显著决定；辅助按预登记执行。
6. 恢复旧六项B=1000历史复核，完整报告原选择来源；更新论文理论与结果对应，原中介负结果保留，最终修订Word/PDF及备份。

当前无需用户重复解释已确认选择；真正无法由材料解决的问题将整理成可直接转发的短清单。

## 补充实核
calib_med目前只实现a0/b0，M用逐行runif、Y用逐行rbinom，未显式生成簇内相关。link_check只累计非缺失不一致，零有效对接也可能报0，资格须补匹配覆盖率及有效配对数。详细频数见LOCAL_COUNTS.json；这些不是新模型结果。


## 来源：LOCAL_AUDIT_CONTINUATION.md
SHA256: 4bb7c77255f28b0e5e125f81c4de52bf764c9bdd82268a4e2c06613aa61966eb

# 新版 v4 本地核查接续

本记录仅为数据/代码核查，不是新版估计结果或NLM共识。旧六项B=1000仍未启动。

## 已实际执行

- 原RStudio PID89434中解析云端原函数成功；MASS、digest、jsonlite、haven、sandwich、ordinal可用。
- 私有audit_guards_v1.R及test_audit_guards_v1.R已在该会话执行，12项合成对象/文件保护测试通过，见GUARD_TEST_RESULTS.csv。未改Downloads原件。
- SHA冻结校验、数据与抽样计划绑定、配偶匹配有效分母和歧义标记已作为私有补丁实现。它们尚未替代完整科学冻结合同，NLM裁决文件的内容/身份还须在最终驱动中绑定。
- 原time_test虽模拟Y，却保留真实满意度并拟合中介；已在私有补丁禁用。纯合成计时及完整self_test尚未执行。
- predata_FE_16_22_unbal.dta原始1–5经济满意度提取通过。与目标13092行的dyad_id/period匹配13092/13092；本人基期/期末有效数13085/13085，配偶基期/期末13083/13085。见MSATECO_COVERAGE.csv、msateco_intervals_audit.csv。这证明键覆盖及取值，不独立证明角色映射正确或C3/C4已合格。
- 上游元数据读取首次因R属性部分匹配触发label/labels混淆报错；改用exact=TRUE后读取成功，相关字段无变量标签。原脚本注释支持msateco_c2_为“配偶对本人收入满意度”，仍需交叉身份核对。

## 来源追溯

sources/extracted/v751_empirical/research/20260904_basic_mechanism_v6/scripts/20260904_basic_mechanism_v6.R：
- 202–211行列出上游原字段；261–262行把qf602_a__负数转NA再CPI平减，未读qf601。
- 342–343行生成支持端点；358行附近把上游协变量的区间起点读成_begin。
- 963–982行已记录满意度访谈时点与支持过去半年窗口重叠的限制。因此C同波间接对比不能自动称因果自然间接效应。

sources/extracted/v751_empirical/stata_source_snapshot/20240619 DV_IV_descriptives_2016_2022_unbal.do：
- 5918–5941行附近：child来自各期childnumb，dwm来自downward_mean，不能仅凭_begin判断无未来信息。
- 5946–5948行：ahw来自各期actor_housew；5954–5964行：prtmarr/prtcor来自对应年度状态，fmlincc来自fincome_cpi_ln。就这层重命名而言，它们不是同名的区间变化变量；其上游构造及插补仍需审查。
- 6521–6524行：本人/配偶婚姻、收入满意度角色注释。
- 6796–6800附近：删除原始满意度并用百分位变量同名替换。当前C3/C4不得取替换后数据。

## 待解决后才冻结

1. qf601未保留在本次上游长表；不能从qf602缺失反推是否支持，须继续沿更上游来源核结构性零与项目缺失。
2. 完成23项逐项时间/构造审查与经济满意度角色核查。
3. 支持门槛必须进入驱动；明确有效bootstrap比例不达标的处理；校准补both-zero和簇依赖；纯合成self_test/计时。
4. 给NLM恢复稿PDF、新提案与本地证据，完成新请求后逐条裁决，冻结全部输入SHA、检验/对比分支及预算，再运行新A/B。

本轮最近df可用11578144 KiB（快照，非永久预算）。未执行新上传或删除；前轮已核释放5,867,017,863字节不重做。


## 来源：MSATECO_COVERAGE.csv
SHA256: 710f4023de2de1f49a2b3913126f62d755c72b72436a648813886072f58b72c8

"variable","matched_rows","total_rows","observed"
"eco_self_begin",13092,13092,13085
"eco_self_end",13092,13092,13085
"eco_spouse_begin",13092,13092,13083
"eco_spouse_end",13092,13092,13085


## 来源：GUARD_TEST_RESULTS.csv
SHA256: eb7845762da6df8ce61ee83f00c6d2c0c57312116dda2ec28d036eb5d795e090

"test","pass"
"unchanged_source_accepted",TRUE
"changed_source_rejected",TRUE
"missing_source_rejected",TRUE
"same_plan_reused",TRUE
"changed_data_rejected",TRUE
"changed_draws_rejected",TRUE
"known_reciprocal_pairs_accepted",TRUE
"zero_effective_pairs_rejected",TRUE
"mismatch_detected",TRUE
"ambiguous_identity_detected",TRUE
"unreviewed_production_rejected",TRUE
"nonblind_timing_disabled",TRUE


## 来源：self_test.log
SHA256: 03ab93e7366fe925591da708181cc10da4f5008adf62dfd307f425568f014cf3

[PASS] A：d_P 回收真值 est=-0.0942 true=-0.1173 se=0.0205
[PASS] B：d_Y 回收真值 est=-27.86 true=-37.93 se=5.02
[PASS] bootstrap 有效重复 40/40
[PASS] 主 CI 与 p 一致 p=0.024 CI=[-0.1350, -0.0535]
[PASS] R8：影响函数点估计 = 标准化点估计 
[PASS] R8：影响函数 SE 与 bootstrap SE 同量级 if=0.0217 boot=0.0205
[PASS] R5：LPM 可运行 
[PASS] C：间接对比回收真值 est=0.01198 true=0.00887 se=0.00149
[PASS] C：a 路径 logOR 回收 0.5 est=0.551 se=0.032
[PASS] R11：部分比例优势中介模型可运行 
[PASS] S1 可运行 
[PASS] S2 可运行 
[PASS] S3/S4 可运行 
[PASS] 校准函数可运行 R_ok=2
[PASS] p.adjust(n=14) 按预期 
self_test 全部通过。


## 来源：RESULT.json
SHA256: fe707b7daf8948621c9dca28d4b78e63f1ae2bf7a4475f1bca4d755bf050af7d

{
  "status": "PASS",
  "elapsed_seconds": 16.261,
  "pid": 23628,
  "real_data_read": false,
  "completed_at": "2026-10-05 08:45:56 UTC"
}


## 来源：ALL_14_TESTS.csv
SHA256: 43e5496ebb537cc62b36cb14ff4451c2b2e6d1c1c5ca77a01c8cba8650196c13

"id","estimate","se","lower","upper","p","N","G","status","unit","note","q_BH14","q_BY14","q_BH_module","q_BY_module"
"A1",-0.0176169881707778,0.0120016640685298,-0.0411402497450961,0.00590627340354054,0.142137149570597,12634,3153,"ESTIMATED","probability","",0.33165334899806,1,0.547305939053286,1
"A2",-0.00443129201353021,0.0126566532272604,-0.0292383323389606,0.0203757483119002,0.72625192753758,12634,3153,"ESTIMATED","probability","",0.84729391546051,1,0.72625192753758,1
"A3",0.0131856961572476,0.0181634670939412,-0.0224146993468772,0.0487860916613723,0.467871879464508,12634,3153,"ESTIMATED","probability","",0.727800701389235,1,0.623829172619344,1
"A4",0.0323413903936973,0.0295439110558664,-0.0255646752758008,0.0902474560631954,0.273652969526643,7708,2665,"ESTIMATED","probability","",0.478892696671625,1,0.547305939053286,1
"B1",0.0287138755633078,0.0131569539566584,0.00292624580825731,0.0545015053183583,0.0290792439189716,7106,2405,"ESTIMATED","probability","",0.102927548555067,0.334675339247069,0.0294078710157333,0.0612663979494444
"B2",-0.043062729082566,0.0150202425344001,-0.0725024044499901,-0.0136230537151418,0.00414409711172025,5528,2286,"ESTIMATED","probability","",0.0290086797820417,0.0943235303225972,0.0082881942234405,0.0172670712988344
"B3",0.0663475317806354,0.030462939529873,0.00664017030208434,0.126054893259186,0.0294078710157333,3675,1684,"ESTIMATED","log_amount","post-exposure selected conditional association",0.102927548555067,0.334675339247069,0.0294078710157333,0.0612663979494444
"B4",25.8178148824966,8.34359431836656,9.46437001849812,42.171259746495,0.00197259484649612,12634,3153,"ESTIMATED","real_amount","Original1000 connected-cluster draws; stable Gamma score solver only for52 failed draws;948 preserved",0.0276163278509457,0.0897962112381289,0.00789037938598448,0.0164382903874677
"C1",-0.000532338984687852,0.00930134279750264,-0.018762970867793,0.0176982928984173,0.954359999342113,12749,3168,"ESTIMATED","probability","Same specification with scaled nuisance predictors; supersedes numerically invalid v1 C1",1,1,0.954359999342113,1
"C2",-0.00572994273329552,0.0123439372543686,-0.029924059751858,0.018464174285267,0.642511015785883,12629,3152,"ESTIMATED","probability","Contemporaneous association; decline intervention at baseline1 is outside observed support",0.84729391546051,1,0.954359999342113,1
"D1",0.0113014523766957,0.0295133808978821,-0.0465447741831533,0.0691476789365446,0.701774344303363,4476,1783,"ESTIMATED","satisfaction_points","",0.84729391546051,1,0.935699125737817,1
"D2",-0.0143133545688852,0.0106197092135243,-0.0351279846273928,0.00650127548962249,0.177719370672105,4403,1767,"ESTIMATED","probability","",0.35543874134421,1,0.35543874134421,0.740497377800437
"D3",0.0286619210250115,0.0194705487652423,-0.00950035455486345,0.0668241966048865,0.141003219598632,4403,1767,"ESTIMATED","probability","post-exposure modifier; association only",0.33165334899806,1,0.35543874134421,0.740497377800437
"D4",NA,NA,NA,NA,NA,0,0,"NOT_IDENTIFIED","probability","Overlapping X/M measurement and unverified mediator-outcome identification; not gated on D1 p",1,1,1,1
