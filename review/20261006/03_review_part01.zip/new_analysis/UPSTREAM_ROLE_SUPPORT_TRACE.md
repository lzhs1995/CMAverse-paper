# 上游源链新发现（未宣称逐行重建完成）
Source: /Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/20230918 couple_relat_interg_relat2016_2022 - 副本.do
SHA256: 382beff897f0c2f98b9d1467c0ef8c49d73ee90612c763d72169ce2c9e506510
原脚本明确QF601=0时QF602赋0；当前129个缺失仍不能按此规则直接推断或填零。原QM802→msateco映射已找到，角色合并链与目标数据一致性继续核查。
```
450: tostring pid pid_s , gen(person1_str person2_str)
451: gen couple_numb = cond(pid < pid_s, person1_str + person2_str, person2_str + person1_str)
452: drop person1_str person2_str
453: 
454: * 对组合后的变量排序
455: sort couple_numb
456: 
457: * 使用duplicates命令查找重复的夫妻对
458: duplicates report couple_numb
459: 
460: order pid pid_s pair_pid couple_numb
461: 
462: keep pid pid_s
463: rename (pid pid_s) (pid_c1 pid_c2)
464: save "$pre_data\20230910 couple_sample_2022.dta",replace
465: 
466: 
467: *(2) 2022 夫妻配对样本 匹配 
468: *夫妻婚姻匹配(年龄匹配\教育匹配\职业匹配？家庭经济背景匹配？户口匹配？)
469: *夫妻互动特征(工资性收入互动、自雇收入、家务劳动、父母信任度)
470: cls
471: clear
472: cd "C:\Users\LZHS\Desktop\开题报告\预处理"
473: use "C:\Users\LZHS\Desktop\20230505 毕业论文\开题报告\开题报告\CFPS\20230808 CFPS官网\[CFPS Public Data] CFPS2022\Data\cfps2022person_202410.dta"
474: count
475: //保留夫妻互动原始指标
476: keep fid22 pid age qf* pid_a_f pid_a_m xchildpid_a_* tb6_a22_p qn10021 emp_income qq9010 qq9011 qq9012 qn10021 employ proxyrpt school gender qq400 qg303code_siops cfps2022edu qm801 qm802 qm803
477: 
478: *** 婚姻满意度*3
479: tab1 qm801 qm802 qm803,nolab miss
480: recode qm801 qm802 qm803 (min/0=.)
481: rename (qm801 qm802 qm803) (msat msateco msathw)
482: tab1 msat msateco msathw,nolab miss
```
```
990: label var qf603_a_ "子女报_是否给父母料理家务生活起居"
991: label var qf604_a_ "子女报_给父母料理家务生活起居频率"
992: label var qf703_a_ "子女报_父母是否为您料理家务看孩子"
993: label var qf704_a_ "子女报_父母料理家务看孩子频率"
994: label var qf705_a_ "子女报_见面频率"
995: label var qf706_a_ "子女报_联系频率"
996: order pair_pid pair_pid_1 age qf5_a_ qf601_a_ qf602_a_ qf701_a_ qf702_a_ qf603_a_ qf604_a_ qf703_a_ qf704_a_ qf705_a_ qf706_a_ tb6_a22p pdead_
997: 
998: rename age age_child
999: tab age_child
1000: *missings report qf701_a_ qf703_a_
1001: *list qf701_a_ qf703_a_ pdead_ if pdead_ ==1
1002: tab1 qf701_a_ qf703_a_ if age<16
1003: 
1004: drop if age<16 //仅16(含)-60岁(不含)询问了 子女回答对与父母的关系(0 observations deleted) 
1005: codebook pid //12,506 个个体, 21,856对亲子关系
1006: 
1007: replace qf602_a_=0 if qf601_a_==0 //若"子女报_是否给父母提供经济帮助"为否=0, "子女报_给父母经济帮助的资金（元）"均视为0支持
1008: 
1009: replace qf702_a_=0 if qf701_a_==0 //若"子女报_父母是否提供经济帮助"为否=0, "子女报_父母经济帮助的数额（元）"均视为0支持
1010: 
1011: replace qf604_a_=7 if qf603_a_==0 //若"子女报_是否给父母料理家务生活起居"为否=0, "子女报_给父母料理家务生活起居频率",均赋值为7,标签为"从不"
1012: label define instrument 1 "几乎每天" 2 "一周3-4天" 3 "一周1-2天" 4 "一月2-3天" 5 "一月一天" 6 "几个月一天" 7 "从不",replace
1013: label values qf604_a_ instrument
1014: tab qf604_a_
1015: 
```
```
1813: use "C:\Users\LZHS\Desktop\20230505 毕业论文\开题报告\开题报告\CFPS\20230808 CFPS官网\[CFPS Public Data] CFPS2020\Data\cfps2020person_202306.dta"
1814: 
1815: //保留夫妻互动原始指标
1816: keep fid20 pid age qf* pid_a_f pid_a_m xchildpid_a_* tb6_a20_p qn10021 emp_income qq9010 qq9011 qq9012 qn10021 employ proxyrpt school gender qq400 qg303code_siops cfps2020edu qm801 qm802 qm803
1817: 
1818: 
1819: *** 婚姻满意度*3
1820: tab1 qm801 qm802 qm803,nolab miss
1821: recode qm801 qm802 qm803 (min/0=.)
1822: rename (qm801 qm802 qm803) (msat msateco msathw)
1823: tab1 msat msateco msathw,nolab miss
```
```
2708: label var qf602_a_ "子女报_给父母经济帮助的资金（元）"
2709: label var qf701_a_ "子女报_父母是否提供经济帮助"
2710: label var qf702_a_ "子女报_父母经济帮助的数额（元）"
2711: label var qf603_a_ "子女报_是否给父母料理家务生活起居"
2712: label var qf604_a_ "子女报_给父母料理家务生活起居频率"
2713: label var qf703_a_ "子女报_父母是否为您料理家务看孩子"
2714: label var qf704_a_ "子女报_父母料理家务看孩子频率"
2715: label var qf705_a_ "子女报_见面频率"
2716: label var qf706_a_ "子女报_联系频率"
2717: order pair_pid pair_pid_1 age qf5_a_ qf601_a_ qf602_a_ qf701_a_ qf702_a_ qf603_a_ qf604_a_ qf703_a_ qf704_a_ qf705_a_ qf706_a_ tb6_a20p pdead_
2718: 
2719: rename age age_child
2720: tab age_child
2721: drop if age<16 //仅16(含)-60岁(不含)询问了 子女回答对与父母的关系(0 observations deleted) 
2722: 
2723: replace qf602_a_=0 if qf601_a_==0 //若"子女报_是否给父母提供经济帮助"为否=0, "子女报_给父母经济帮助的资金（元）"均视为0支持
2724: 
2725: replace qf702_a_=0 if qf701_a_==0 //若"子女报_父母是否提供经济帮助"为否=0, "子女报_父母经济帮助的数额（元）"均视为0支持
2726: 
2727: replace qf604_a_=7 if qf603_a_==0 //若"子女报_是否给父母料理家务生活起居"为否=0, "子女报_给父母料理家务生活起居频率",均赋值为7,标签为"从不"
2728: label define instrument 1 "几乎每天" 2 "一周3-4天" 3 "一周1-2天" 4 "一月2-3天" 5 "一月一天" 6 "几个月一天" 7 "从不",replace
2729: label values qf604_a_ instrument
2730: tab qf604_a_
```
```
3650: *夫妻互动特征(工资性收入互动、自雇收入、家务劳动、父母信任度)
3651: *cls
3652: *clear
3653: *cd "C:\Users\LZHS\Desktop\开题报告\预处理"
3654: use "C:\Users\LZHS\Desktop\20230505 毕业论文\开题报告\开题报告\CFPS\20230808 CFPS官网\[CFPS Public Data] CFPS2018\Data\cfps2018person_202012.dta",clear
3655: 
3656: //保留夫妻互动原始指标
3657: keep fid18 pid age qf* pid_a_f pid_a_m xchildpid_a_* tb6_a18_p qn10021 income qq9010 qq9011 qq9012 qn10021 employ proxyrpt school gender employ qg303code_siops cfps2018edu qm801 qm802 qm803
3658: 
3659: 
3660: *** 婚姻满意度*3
3661: tab1 qm801 qm802 qm803,nolab miss
3662: recode qm801 qm802 qm803 (min/0=.)
3663: rename (qm801 qm802 qm803) (msat msateco msathw)
3664: tab1 msat msateco msathw,nolab miss
3665: 
3666: 
3667: drop if proxyrpt==1 //代答样本没有 代际关系问项，故删除(4,257 observations deleted)
3668: 
3669: tab1 age,miss // 9-96岁; 无缺失值"."
3670: 
```
```
4510: label var qf701_a_ "子女报_父母是否提供经济帮助"
4511: label var qf702_a_ "子女报_父母经济帮助的数额（元）"
4512: label var qf603_a_ "子女报_是否给父母料理家务生活起居"
4513: label var qf604_a_ "子女报_给父母料理家务生活起居频率"
4514: label var qf703_a_ "子女报_父母是否为您料理家务看孩子"
4515: label var qf704_a_ "子女报_父母料理家务看孩子频率"
4516: label var qf705_a_ "子女报_见面频率"
4517: label var qf706_a_ "子女报_联系频率"
4518: order pair_pid age qf5_a_ qf601_a_ qf602_a_ qf701_a_ qf702_a_ qf603_a_ qf604_a_ qf703_a_ qf704_a_ qf705_a_ qf706_a_ tb6_a18p pdead_
4519: 
4520: rename age age_child
4521: tab age_child
4522: drop if age<16 //(4,957 observations deleted)
4523: 
4524: replace qf602_a_=0 if qf601_a_==0 //若"子女报_是否给父母提供经济帮助"为否=0, "子女报_给父母经济帮助的资金（元）"均视为0支持
4525: 
4526: replace qf702_a_=0 if qf701_a_==0 //若"子女报_父母是否提供经济帮助"为否=0, "子女报_父母经济帮助的数额（元）"均视为0支持
4527: 
4528: replace qf604_a_=7 if qf603_a_==0 //若"子女报_是否给父母料理家务生活起居"为否=0, "子女报_给父母料理家务生活起居频率",均赋值为7,标签为"从不"
4529: label define instrument 1 "几乎每天" 2 "一周3-4天" 3 "一周1-2天" 4 "一月2-3天" 5 "一月一天" 6 "几个月一天" 7 "从不",replace
4530: label values qf604_a_ instrument
```
```
15685: 
15686: clonevar child_edu1_ = actor_edu1_
15687: clonevar child_edu1_c_ = partner_edu1_
15688: 
15689: clonevar child_edu2_ = actor_edu2_
15690: clonevar child_edu2_c_ = partner_edu2_
15691: 
15692: clonevar child_housew_ = actor_housew_
15693: clonevar child_housew_c_ = partner_housew_
15694: 
15695: clonevar child_msat_ = msat_c1_
15696: clonevar child_msat_c_ = msat_c2_
15697: 
15698: clonevar child_msateco_ = msateco_c1_
15699: clonevar child_msateco_c_ = msateco_c2_
15700: 
15701: clonevar child_msathw_ = msathw_c1_
15702: clonevar child_msathw_c_ = msathw_c2_
15703: 
15704: sum child_age_ child_age_c_ child_siops_ child_siops_c_ child_income_ child_income_c_ child_edu1_ child_edu1_c_ child_edu2_ child_edu2_c_ child_housew_ child_housew_c_ child_msat_ child_msat_c_ child_msateco_ child_msateco_c_ child_msathw_ child_msathw_c_
```
## 角色合并补证
2022行538–574：同一个人数据分别按pid_c1/pid_c2合并；837将pid_c1改为pid，1446将pid_c2改为pid_partner。2020行1877–1915、2018行3705–3744同构。15695–15699复制本人/配偶总体及经济满意度。实际目标数据按actor×partner×period归并多亲本记录，检查组内一致后再反向匹配；详细计数见RECIPROCAL_ROLE_AUDIT.json。此检查证明角色对应，不单凭变量名推断问题语义，亦不证明未配对记录完整。
