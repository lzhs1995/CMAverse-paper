# 从已核保存结果汇总新14；不重新拟合。
local({
p <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e<-new.env();sys.source(file.path(p,"inference_patch_v1.R"),e)
tab<-read.csv(file.path(p,"production_two_stage_v1/B200_ALL_ESTIMANDS.csv"))
sel<-read.csv(file.path(p,"probability_recovery_v1/B200_PRIMARY_SELECTION_CORRECTED.csv"))
out<-list()
for(i in seq_len(nrow(sel))){
 s<-sel[i,];r<-tab[tab$test_id==s$test_id & tab$estimand==s$estimand,,drop=FALSE]
 stopifnot(nrow(r)==1)
 if(startsWith(s$test_id,"A")){
 obj<-readRDS(file.path(p,"probability_recovery_v1",paste0(s$test_id,".rds")))
 z<-e$summ_boot(obj$est,obj$boot,s$estimand)
 for(k in names(z))r[[k]]<-z[[k]]
 }
 stopifnot(isTRUE(all.equal(r$estimate,s$estimate)),r$n_valid==s$n_valid)
 if(s$eligible)stopifnot(isTRUE(all.equal(r$p_raw,s$p_screen)))
 r$q_BH_14<-s$q_BH_14;r$q_BY_14<-s$q_BY_14;r$selected<-s$selected
 out[[i]]<-r
}
dest<-file.path(dirname(p),"manuscript_integration_v1")
write.csv(do.call(rbind,out),file.path(dest,"NEW14_PRIMARY_METRICS_v1.csv"),row.names=FALSE)
cat("14 primary estimates, intervals, N and cluster counts reconciled.\n")
})

