# 私有审查补丁；须先载入云端原函数。尚未批准真实模型执行。
N_CORES <- 1L

sha_file <- function(path) {
  stopifnot(length(path) == 1L, file.exists(path))
  digest::digest(file = path, algo = "sha256")
}
freeze_bound_files <- function(paths, manifest) {
  stopifnot(length(paths) > 0L, !file.exists(manifest))
  paths <- normalizePath(paths, mustWork = TRUE)
  stopifnot(!anyDuplicated(paths))
  z <- data.frame(path = paths, sha256 = vapply(paths, sha_file, character(1)),
                  bytes = as.numeric(file.info(paths)$size))
  saveRDS(z, manifest)
  invisible(z)
}
verify_bound_files <- function(manifest) {
  stopifnot(file.exists(manifest))
  z <- readRDS(manifest)
  stopifnot(nrow(z) > 0L, all(file.exists(z$path)),
    identical(unname(vapply(z$path, sha_file, character(1))), unname(z$sha256)),
    identical(as.numeric(file.info(z$path)$size), z$bytes))
  invisible(TRUE)
}
# 正式驱动还须显式登记全部依赖；此函数不自动产生科学共识。
check_frozen <- function() {
  verify_bound_files(file.path(OUT_DIR, "FREEZE_SHA256.rds"))
  if (!file.exists(file.path(OUT_DIR, "NLM_ADJUDICATED.json")))
    stop("新版NLM裁决尚未落盘，禁止真实模型。")
  invisible(TRUE)
}

make_or_load_plan <- function(d, B, seed, file) {
  ensure_out()
  stopifnot(B > 0L, !anyNA(d[[CLUSTER]]))
  key <- digest::digest(d, algo = "sha256")
  f <- file.path(OUT_DIR, file)
  if (file.exists(f)) {
    p <- readRDS(f)
    stopifnot(identical(p$B, B), identical(p$seed, seed),
      identical(p$ids, sort(unique(d[[CLUSTER]]))), identical(p$data_sha256, key),
      identical(p$draw_sha256, digest::digest(p$draws, algo = "sha256")))
    return(p)
  }
  p <- make_plan(d[[CLUSTER]], B, seed)
  p$data_sha256 <- key
  p$draw_sha256 <- digest::digest(p$draws, algo = "sha256")
  saveRDS(p, f)
  p
}

link_check <- function(d, spouse_b, spouse_e, self_b, self_e, label) {
  vars <- c("actor_pid_begin", "partner_pid_begin", "period", spouse_b, spouse_e, self_b, self_e)
  stopifnot(all(vars %in% names(d)))
  valid_id <- complete.cases(d[c("actor_pid_begin", "partner_pid_begin", "period")])
  ks <- paste(d$actor_pid_begin, d$partner_pid_begin, d$period)
  kr <- paste(d$partner_pid_begin, d$actor_pid_begin, d$period)
  # 多亲本记录的反向匹配可能不唯一；保留标志，不将首个命中当身份验证。
  dup <- duplicated(ks) | duplicated(ks, fromLast = TRUE)
  j <- match(kr, ks)
  has <- valid_id & !is.na(j)
  vb <- has & !is.na(d[[spouse_b]]) & !is.na(d[[self_b]][j])
  ve <- has & !is.na(d[[spouse_e]]) & !is.na(d[[self_e]][j])
  mb <- sum(d[[spouse_b]][vb] != d[[self_b]][j[vb]])
  me <- sum(d[[spouse_e]][ve] != d[[self_e]][j[ve]])
  data.frame(check = label, linked_rows = sum(has), total_rows = nrow(d),
    linked_share = mean(has), effective_begin = sum(vb), effective_end = sum(ve),
    mismatch_begin = mb, mismatch_end = me, ambiguous_keys = sum(dup),
    status = if (!any(vb) || !any(ve)) "NO_EFFECTIVE_PAIRS" else
      if (mb + me > 0) "MISMATCH" else if (any(dup)) "AMBIGUOUS_KEY_REQUIRES_AUDIT" else "MATCHED_OBSERVED_PAIRS")
}

# 原 time_test 使用真实中介；正式纯合成计时实现前明确禁用，防止误称盲测。
time_test <- function(...) stop("原time_test会拟合真实中介；请使用独立纯合成计时脚本。")
