# 目标样本户口源值核查；不修改历史输入或会话对象
local({
 stopifnot(Sys.getpid()==89434L)
 root<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
 pkg<-file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
 d<-read.csv(file.path(pkg,"data/analysis_13092.csv"),stringsAsFactors=FALSE)
 src<-"/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/Prepare_data"
 out<-list(); sources<-list()
 for(yr in c(2018L,2020L)) {
  f<-file.path(src,paste0("actor_hukou_merge_",yr,".dta"))
  z<-as.data.frame(haven::read_dta(f)); id<-paste0("pid_",yr); v<-paste0("hukou_a",substr(yr,3,4),"_p_",yr)
  ids<-as.character(z[[id]]); vals<-as.numeric(z[[v]])
  keep<-!is.na(z[[id]])
  sp<-split(vals[keep],ids[keep]); conflicts<-vapply(sp,function(a)length(unique(a))>1L,logical(1))
  stopifnot(!any(conflicts))
  ii<-which(d$begin_year==yr); j<-match(as.character(d$actor_pid_begin[ii]),ids)
  raw<-vals[j]; derived<-ifelse(is.na(raw),NA_integer_,as.integer(raw==1))
  out[[as.character(yr)]]<-data.frame(stable_row_id=d$stable_row_id[ii],actor_pid=d$actor_pid_begin[ii],begin_year=yr,matched=!is.na(j),raw_hukou=raw,old_ahk=d$ahk_begin[ii],observed_recode=derived)
  sources[[as.character(yr)]]<-list(path=f,sha256=digest::digest(file=f,algo="sha256"),rows=nrow(z),duplicate_keys=sum(duplicated(ids[keep])),conflicting_keys=sum(conflicts))
 }
 a<-do.call(rbind,out);stopifnot(nrow(a)==nrow(d),!anyDuplicated(a$stable_row_id))
 write.csv(a,file.path(root,"HUKOU_TARGET_AUDIT_ROWS_v1.csv"),row.names=FALSE)
 summary<-lapply(split(a,a$begin_year),function(z)list(n=nrow(z),unmatched=sum(!z$matched),source_missing=sum(is.na(z$raw_hukou)),missing_old_zero=sum(is.na(z$raw_hukou)&z$old_ahk==0,na.rm=TRUE),observed_disagreement=sum(z$old_ahk!=z$observed_recode,na.rm=TRUE),raw_counts=as.list(table(z$raw_hukou,useNA="always"))))
 jsonlite::write_json(list(status="AUDITED_NOT_APPLIED",summary=summary,sources=sources),file.path(root,"HUKOU_TARGET_AUDIT_v1.json"),auto_unbox=TRUE,pretty=TRUE,na="null")
 print(summary)
})
