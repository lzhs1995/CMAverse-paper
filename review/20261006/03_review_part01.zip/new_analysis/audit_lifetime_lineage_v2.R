# 只读原始输入；不修改研究数据或原有变量。
local({
  stopifnot(Sys.getpid()==89434L)
  root <- '/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927'
  out <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1')
  csv <- file.path(root,'next_phase/PLAN13_全稿实证复核与修订_20260929/delivery/Claude云端分析资料_20261005_v1/data/analysis_13092.csv')
  src <- '/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/Prepare_data/20230928 temple_2016_22_unbal.dta'
  cat('读取上游年龄谱系\n');flush.console()
  raw <- haven::read_dta(src,col_select=tidyselect::matches('^(pair_pid_1|age_child_20(16|18|20|22)|actor_age_20(16|18|20|22))$'))
  d <- read.csv(csv,stringsAsFactors=FALSE)
  stopifnot(!anyDuplicated(raw$pair_pid_1))
  j <- match(d$dyad_id,as.character(raw$pair_pid_1))
  stopifnot(!anyNA(j))
  a <- as.numeric(raw$age_child_2016)
  origin <- ifelse(is.na(a),'unresolved','observed_2016')
  # 按原脚本143–145行先后顺序，后波只回填缺失2016年龄。
  for(yr in c(2018L,2020L,2022L)) {
    v <- as.numeric(raw[[paste0('age_child_',yr)]])-(yr-2016L)
    take <- is.na(a)&!is.na(v);a[take]<-v[take];origin[take]<-paste0('backcast_',yr)
  }
  # Stata数值缺失>=40为真；显式复现，不把该行为包装成合理编码。
  expected <- as.integer(is.na(a)|a>=40)
  obs <- data.frame(stable_row_id=d$stable_row_id,dyad_id=d$dyad_id,
    begin_year=d$begin_year,lifetime_observed=d$lifetime_begin,
    source_age_2016=a[j],age_source=origin[j],lifetime_source_expected=expected[j],
    actor_age_begin=d$aage_begin,actor_backcast=d$aage_begin-(d$begin_year-2016))
  obs$matches_source <- obs$lifetime_observed==obs$lifetime_source_expected
  obs$matches_actor_backcast <- obs$lifetime_observed==as.integer(obs$actor_backcast>=40)
  write.csv(obs,file.path(out,'LIFETIME_LINEAGE_ROWS_v2.csv'),row.names=FALSE)
  ans <- list(rows=nrow(obs),source_sha256=digest::digest(file=src,algo='sha256'),
    source_definition_mismatches=sum(!obs$matches_source),
    actor_backcast_mismatches=sum(!obs$matches_actor_backcast),
    source_age_missing=sum(is.na(obs$source_age_2016)),age_source=as.list(table(obs$age_source)),
    manual_corrections='Source lines 3868–3928 lie inside nested block comment 3818–3934; not applied',
    raw_data_modified=FALSE,pid=Sys.getpid())
  jsonlite::write_json(ans,file.path(out,'LIFETIME_LINEAGE_RESULT_v2.json'),auto_unbox=TRUE,pretty=TRUE)
  cat(jsonlite::toJSON(ans,auto_unbox=TRUE,pretty=TRUE),'\n')
})
