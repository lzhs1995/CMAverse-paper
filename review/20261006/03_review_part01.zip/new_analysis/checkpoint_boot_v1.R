# 私有整簇续算器：调用者绑定完整2000计划及内容SHA合同；不使用主会话fork。
checkpoint_boot <- function(dat, plan, stat_fun, checkpoint, identity,
                            cluster, chunk=10L, progress=function(b,B) NULL) {
 stopifnot(is.character(identity),length(identity)==1L,nchar(identity)>0,
           chunk>=1L,plan$B==ncol(plan$draws))
 dir.create(dirname(checkpoint),recursive=TRUE,showWarnings=FALSE)
 state <- if(file.exists(checkpoint)) readRDS(checkpoint) else
   list(identity=identity,ids=plan$ids,draws=plan$draws,res=list())
 stopifnot(identical(state$identity,identity),identical(state$ids,plan$ids))
 shared <- min(ncol(state$draws),ncol(plan$draws))
 stopifnot(identical(state$draws[,seq_len(shared),drop=FALSE],plan$draws[,seq_len(shared),drop=FALSE]))
 if(ncol(plan$draws)>ncol(state$draws)) state$draws<-plan$draws
 gi<-match(dat[[cluster]],plan$ids)
 if(anyNA(gi)) stop("样本中有簇不在计划中")
 rows_by<-split(seq_len(nrow(dat)),factor(gi,levels=seq_along(plan$ids)))
 persist<-function() {
   tmp<-paste0(checkpoint,".tmp-",Sys.getpid());saveRDS(state,tmp)
   if(!file.rename(tmp,checkpoint)) stop("原子检查点写入失败")
 }
 if(length(state$res)<plan$B) for(b in seq.int(length(state$res)+1L,plan$B)) {
   rows<-unlist(rows_by[plan$draws[,b]],use.names=FALSE)
   ans<-if(length(rows)) tryCatch(stat_fun(dat[rows,,drop=FALSE]),error=function(e)e) else simpleError("空样本")
   state$res[[b]]<-if(inherits(ans,"error")) list(ok=FALSE,err=conditionMessage(ans)) else
     if(!length(ans)||!all(is.finite(ans))) list(ok=FALSE,err="非有限值或空统计量") else list(ok=TRUE,val=ans)
   if(b%%chunk==0L||b==plan$B) { persist(); progress(b,plan$B) }
 }
 res<-state$res[seq_len(plan$B)]
 ok<-vapply(res,function(z)isTRUE(z$ok),logical(1))
 mat<-if(any(ok))do.call(rbind,lapply(res[ok],`[[`,"val"))else NULL
 if(!is.null(mat))rownames(mat)<-which(ok)
 list(mat=mat,ok_idx=which(ok),fail_idx=which(!ok),
      fail_msg=vapply(res[!ok],`[[`,character(1),"err"),B=plan$B)
}
