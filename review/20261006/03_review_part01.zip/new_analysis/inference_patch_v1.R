# 私有推断修正；载入原函数后使用，尚不授权生产模型。
# 反演同一有限B、严格p<alpha检验；不声称解决复合零假设校准。
summ_boot <- function(est, bt, name, alpha=0.05) {
  stopifnot(alpha>0, alpha<1, bt$B>0)
  t0 <- unname(est[[name]])
  tb <- if (is.null(bt$mat) || !(name %in% colnames(bt$mat))) numeric() else bt$mat[,name]
  stopifnot(is.finite(t0), all(is.finite(tb)), length(tb)<=bt$B)
  nv <- length(tb); valid <- nv/bt$B
  dev <- abs(tb-t0)
  p <- if(nv) (1+sum(dev>=abs(t0)))/(nv+1) else NA_real_
  # 至多ceil(alpha*(nv+1))-2个尾部值才能严格拒绝；边界保留在区间内。
  k <- nv-ceiling(alpha*(nv+1))+2L
  radius <- if(nv && k>=1 && k<=nv) sort(dev)[k] else Inf
  stable <- valid>=0.98 && nv>1
  data.frame(estimand=name, estimate=t0,
    se_boot=if(stable) stats::sd(tb) else NA_real_,
    ci_low=if(stable) t0-radius else NA_real_,
    ci_high=if(stable) t0+radius else NA_real_,
    pct_low=if(nv) unname(stats::quantile(tb,.025)) else NA_real_,
    pct_high=if(nv) unname(stats::quantile(tb,.975)) else NA_real_,
    p_raw=if(stable) p else NA_real_, diagnostic_p=p,
    n_valid=nv, B=bt$B, valid_share=valid,
    boot_flag=if(stable) "" else "INFERENCE_UNSTABLE",
    interval_method="inversion_of_strict_centered_add_one_test",
    calibration_status="NOT_ESTABLISHED_BY_THIS_FUNCTION",
    stringsAsFactors=FALSE)
}
