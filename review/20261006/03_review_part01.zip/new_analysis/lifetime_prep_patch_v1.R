# 私有新规格的数据准备补丁；原始数据及历史结果保持原样。
# 在原云端函数后加载；绑定全体逐行谱系，拒绝只按四个位置改值。
prep_data_historical_lifetime <- prep_data
prep_data <- function(path = file.path(PKG_DIR, "data/analysis_13092.rds")) {
  d <- prep_data_historical_lifetime(path)
  root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
  lineage <- file.path(root, "LIFETIME_LINEAGE_ROWS_v2.csv")
  src <- "/Users/lzhs/Documents/cnm/tasks/07_Stata-workbench/开题报告/0_data/Prepare_data/20230928 temple_2016_22_unbal.dta"
  stopifnot(
    digest::digest(file=lineage,algo="sha256")=="88bc0b01700ddcd2f7b3d2d99af4e52ef9b6d110f1667f8d284b4cc3048b300e",
    digest::digest(file=src,algo="sha256")=="6ec8690bdf778626fb97a6912be92bc92d9bc39c33ef67f754e8aa36c7f5212c")
  z <- read.csv(lineage, stringsAsFactors=FALSE)
  stopifnot(nrow(d)==nrow(z),!anyDuplicated(d$stable_row_id),!anyDuplicated(z$stable_row_id))
  j <- match(d$stable_row_id,z$stable_row_id)
  stopifnot(!anyNA(j), all(as.character(d$dyad_id)==as.character(z$dyad_id[j])),
    all(d$begin_year==z$begin_year[j]),all(d$lifetime_begin==z$lifetime_observed[j]),
    !anyNA(z$source_age_2016))
  rebuilt <- as.integer(z$source_age_2016[j]>=40)
  stopifnot(all(rebuilt==z$lifetime_source_expected[j]),sum(rebuilt!=d$lifetime_begin)==4L)
  d$lifetime_begin <- rebuilt
  d
}
