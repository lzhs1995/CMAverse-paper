# R11专用：不修改冻结主分析；失败保留，不改优化器择优。
check_clm_fit <- function(fit) {
 code <- fit$convergence$code
 if(length(code)!=1L || is.na(code) || code!=0L) stop("PPO_NOT_CONVERGED")
 if(anyNA(coef(fit)) || any(!is.finite(coef(fit)))) stop("PPO_NONFINITE_COEFFICIENT")
 if(any(unlist(fit$aliased))) stop("PPO_ALIASED")
 if(!is.finite(fit$maxGradient) || fit$maxGradient>1e-4) stop("PPO_GRADIENT")
 invisible(TRUE)
}
.original_pm_probs <- pm_probs
pm_probs <- function(fit,nd,mvar,model=c("po","ppo")) {
 model<-match.arg(model)
 if(model=="ppo")check_clm_fit(fit)
 P<-.original_pm_probs(fit,nd,mvar,model)
 if(any(!is.finite(P)) || any(P< -1e-10) || any(P>1+1e-10) ||
    any(abs(rowSums(P)-1)>1e-7))stop("INVALID_MEDIATOR_PROBABILITIES")
 P
}

