local({
root<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e<-new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
patches<-c("inference_patch_v1.R","sample_gates_v1.R","lifetime_prep_patch_v1.R","audit_guards_v1.R","production_gates_v2.R","two_stage_selection_v1.R","checkpoint_boot_v1.R")
for(f in patches)sys.source(file.path(root,f),e)
e$PKG_DIR<-file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR<-file.path(root,"production_two_stage_v1");e$N_CORES<-1L
e$ensure_out();e$load_covariates()

stopifnot(!file.exists(file.path(e$OUT_DIR,"FREEZE_SHA256.rds")))
d<-e$add_msateco(e$prep_data(),file.path(root,"msateco_intervals_audit.csv"))
w<-e$build_threewave(d)
gates<-read.csv(file.path(root,"LOCAL_SAMPLE_GATES_LIFETIME_PATCHED_v2.csv"))
stopifnot(nrow(gates)==14L,all(gates$eligible))
saveRDS(list(d=d,w=w),file.path(e$OUT_DIR,"prepared_data.rds"))
p<-e$make_or_load_plan(d,2000L,20261005L,"plan2000.rds")
writeLines(c("C3C4_ACTIVE","raw scale, reciprocal role and coverage audits passed"),file.path(e$OUT_DIR,"msateco_decision.txt"))
jsonlite::write_json(list(status="ADJUDICATED",receipt="f3366c39a05ec98a6e96a6920829cf3bcd4fc0a79b15127c08123ba6cf841f8f"),file.path(e$OUT_DIR,"NLM_ADJUDICATED.json"),auto_unbox=TRUE)
files<-c("/Users/lzhs/Downloads/20261005_astra_v4_functions.R","/Users/lzhs/Downloads/20261005_test_registry_v4.csv",
 file.path(root,patches),file.path(root,c("CONTROL_CONTRACT_v1.md","CONTROL_DECISION_v1.csv","TWO_STAGE_COMPUTE_AMENDMENT_v1.md","TWO_STAGE_NLM_ADJUDICATION_v1.md","msateco_intervals_audit.csv","run_production_two_stage_v1.R","prepare_production_two_stage_v1.R","LIFETIME_LINEAGE_ROWS_v2.csv","LOCAL_SAMPLE_GATES_LIFETIME_PATCHED_v2.csv")),
 file.path(e$PKG_DIR,"data",c("analysis_13092.rds","fixed_23_covariates.txt")),file.path(e$OUT_DIR,c("prepared_data.rds","plan2000.rds","msateco_decision.txt","NLM_ADJUDICATED.json")))
e$freeze_bound_files(files,file.path(e$OUT_DIR,"FREEZE_SHA256.rds"));e$check_frozen()
print(data.frame(rows=nrow(d),threewave=nrow(w),clusters=length(p$ids),B=p$B))
})
