# 绑定已验收初筛及续算入口；不改原数据/模型/抽样身份。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
out <- file.path(root,"production_two_stage_v1")
e <- new.env()
sys.source(file.path(root,"audit_guards_v1.R"),e)
e$OUT_DIR <- out
e$check_frozen()
stopifnot(!dir.exists(file.path(out,"RUNNING.lock")))
v <- read.csv(file.path(out,"B200_VALIDATION.csv"))
s <- readRDS(file.path(out,"B200_PRIMARY_SELECTION.rds"))
stopifnot(nrow(v)==14L,all(v$status=="SAVED_OBJECT_AND_TABLE_MATCH"),
          nrow(s)==14L,!anyDuplicated(s$test_id))
files <- c(file.path(root,c("run_production_refinement_v1.R",
 "select_production_candidates_v1.R","validate_production_screening_v1.R",
 "prepare_refinement_freeze_v1.R")),
 file.path(out,c("B200_VALIDATION.csv","B200_PRIMARY_SELECTION.csv",
 "B200_PRIMARY_SELECTION.rds","B200_ALL_ESTIMANDS.csv","FREEZE_SHA256.rds")),
 list.files(out,pattern="^B200_[ABCD][0-9]+\\.rds$",full.names=TRUE))
e$freeze_bound_files(files,file.path(out,"REFINEMENT_FREEZE_SHA256.rds"))
e$verify_bound_files(file.path(out,"REFINEMENT_FREEZE_SHA256.rds"))
print(s[s$selected,c("test_id","group","p_screen","reason")])
})
