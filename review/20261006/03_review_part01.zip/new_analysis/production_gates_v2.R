# 私有主检验执行器；先载入原函数、inference_patch及sample_gates。
# 此处只适用于冻结的二值主X；连续辅助规格必须另设支持规则。
run_AB_specs <- function(specs, base, plan, covs_fun=covs_for, tag, with_B=TRUE,
 yA="y1_any", yB="y1_amt", x_hi=1, x_lo=0,
 extra_est=c("d_P_5v4","T_P_le3","T_P_4","T_P_5"), cores=N_CORES) {
 rows <- list()
 for(sp in specs) {
  covs <- covs_fun(sp$drop)
  ss <- prepare_AB_samples(base,sp,covs,with_B,yA,yB)
  # 所有拟合前检查；A与B缺失样本分别构造。
  eligible_A <- isTRUE(ss$gateA$ok)
  eligible_B <- with_B && isTRUE(ss$gateB$ok)
  same <- eligible_A && eligible_B && !is.null(ss$A$stable_row_id) &&
    !anyDuplicated(ss$A$stable_row_id) &&
    identical(ss$A$stable_row_id,ss$B$stable_row_id) &&
    identical(ss$A,ss$B[,names(ss$A),drop=FALSE])
  fit_one <- function(dat, amount) {
   fB <- if(amount) ss$fB else NULL
   stat <- function(z) stat_AB(z,ss$fA,fB,sp$x,sp$w,x_hi=x_hi,x_lo=x_lo)
   est <- stat(dat)
   bt <- run_boot(dat,plan,stat,cores=cores)
   list(est=est,boot=bt,n=nrow(dat),n_cl=length(unique(dat[[CLUSTER]])))
  }
  aa <- if(eligible_A) fit_one(if(same) ss$B else ss$A,same) else NULL
  bb <- if(same) aa else if(eligible_B) fit_one(ss$B,TRUE) else NULL
  # B两方程始终在同一B样本联合重抽样，保留跨方程依赖。
  saveRDS(list(spec=sp,A=aa,B=bb,fA=ss$fA,fB=ss$fB,
    gateA=ss$gateA,gateB=ss$gateB,reused=same,x_hi=x_hi,x_lo=x_lo),
    file.path(OUT_DIR,sprintf("%s_%s.rds",tag,sp$A)))
  row <- function(id,result,nm) cbind(test_id=id,tag=tag,n=result$n,
    n_cl=result$n_cl,positivity_ok=TRUE,summ_boot(result$est,result$boot,nm))
  skipped <- function(id,dat,gate,nm) data.frame(test_id=id,tag=tag,n=nrow(dat),
    n_cl=length(unique(dat[[CLUSTER]])),positivity_ok=FALSE,estimand=nm,
    estimate=NA_real_,p_raw=NA_real_,status=gate$status)
  if(eligible_A) for(nm in c("d_P",extra_est)) {
    rr<-row(sp$A,aa,nm);rr$status<-"ESTIMATED";rows[[length(rows)+1L]]<-rr
  } else rows[[length(rows)+1L]]<-skipped(sp$A,ss$A,ss$gateA,"d_P")
  if(with_B) {
    if(eligible_B) for(nm in sub("_P","_Y",c("d_P",extra_est),fixed=TRUE)) {
      rr<-row(sp$B,bb,nm);rr$status<-"ESTIMATED";rows[[length(rows)+1L]]<-rr
    } else rows[[length(rows)+1L]]<-skipped(sp$B,ss$B,ss$gateB,"d_Y")
  }
 }
 bind_fill(rows)
}

run_med <- function(specs, base, plan, covs_fun, tag, y_type = c("binary", "twopart"),
                    m_model = c("po", "ppo"), extra_y = character(0), cores = N_CORES) {
  y_type <- match.arg(y_type); m_model <- match.arg(m_model)
  rows <- list()
  for (sp in specs) {
    covs <- covs_fun(sp$drop)
    fM   <- fml(sp$s1, c(sp$x, sp$s0, covs))
    rhsY <- c(paste(sp$x, "*", sp$m3), sp$s0, covs, extra_y)
    fY   <- fml("y1_any", rhsY)
    fY2  <- if (y_type == "twopart") fml("y1_amt", rhsY) else NULL
    vars <- unique(c(all.vars(fM), all.vars(fY), if (!is.null(fY2)) all.vars(fY2)))
    prepared <- prepare_med_sample(base, sp, covs,
      three_wave = sp$id %in% c("D1", "D2"), extra_y = extra_y, y_type = y_type)
    require_sample_gate(prepared$gate)
    dat <- prepared$data
    pos_min <- min_cell(dat[[sp$x]], dat[[sp$m3]])
    sfun <- function(z) stat_med(z, fM, fY, sp$x, sp$m3, fY2 = fY2, m_model = m_model)
    est  <- sfun(dat)
    bt   <- run_boot(dat, plan, sfun, cores = cores)
    n_cl <- length(unique(dat[[CLUSTER]]))
    saveRDS(list(spec = sp, fM = fM, fY = fY, fY2 = fY2, est = est, boot = bt, n = nrow(dat),
                 n_cl = n_cl, positivity_min_xm = pos_min),
            file.path(OUT_DIR, sprintf("%s_%s.rds", tag, sp$id)))
    for (nm in intersect(c("indirect", "direct", "total", "a_logOR", "b_diag"), names(est)))
      rows[[length(rows) + 1L]] <- cbind(test_id = sp$id, tag = tag, n = nrow(dat), n_cl = n_cl,
                                         positivity_ok = pos_min >= 30, summ_boot(est, bt, nm))
  }
  do.call(rbind, rows)
}

