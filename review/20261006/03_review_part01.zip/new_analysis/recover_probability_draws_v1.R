# 修复共享金额拟合失败导致的概率抽样丢失；原生产输出不覆盖。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e <- new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R", e)
for(f in c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","two_stage_selection_v1.R")) sys.source(file.path(root,f),e)
e$PKG_DIR <- file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR <- file.path(root,"production_two_stage_v1")
e$load_covariates(); e$check_frozen()
dest <- file.path(root,"probability_recovery_v1")
dir.create(dest,showWarnings=FALSE)
stopifnot(!file.exists(file.path(dest,"RESULT.json")))
z <- readRDS(file.path(e$OUT_DIR,"prepared_data.rds"))
plan <- readRDS(file.path(e$OUT_DIR,"plan2000.rds"))
original_files <- list.files(e$OUT_DIR,recursive=TRUE,full.names=TRUE)
original_files <- original_files[!dir.exists(original_files)]
hash_before <- vapply(original_files,e$sha_file,character(1))
selection <- read.csv(file.path(e$OUT_DIR,"B200_PRIMARY_SELECTION.csv"))
checks <- list(); audit <- list()
for(sp in e$AB_SPECS) {
 obj <- readRDS(file.path(e$OUT_DIR,paste0("B200_",sp$A,".rds")))
 stopifnot(isTRUE(obj$reused))
 ss <- e$prepare_AB_samples(z$d,sp,e$covs_for(sp$drop),TRUE,"y1_any","y1_amt")
 dat <- ss$B
 rows_by <- split(seq_len(nrow(dat)),factor(match(dat[[e$CLUSTER]],plan$ids),levels=seq_along(plan$ids)))
 one <- function(b) {
   rows <- unlist(rows_by[plan$draws[,b]],use.names=FALSE)
   e$stat_AB(dat[rows,,drop=FALSE],obj$fA,NULL,sp$x,sp$w,x_hi=obj$x_hi,x_lo=obj$x_lo)
 }
 # 点估计及首个成功抽样必须与原共享结果一致。
 point <- e$stat_AB(dat,obj$fA,NULL,sp$x,sp$w,x_hi=obj$x_hi,x_lo=obj$x_lo)
 nm <- names(point); bt <- obj$A$boot
 stopifnot(isTRUE(all.equal(point,obj$A$est[nm],tolerance=1e-12)))
 b0 <- bt$ok_idx[1L]
 stopifnot(isTRUE(all.equal(unname(one(b0)),unname(bt$mat[1L,nm]),tolerance=1e-12)))
 old_idx <- bt$ok_idx; failed <- bt$fail_idx
 stopifnot(all(bt$fail_msg=="Gamma 未收敛"))
 mat <- bt$mat[,nm,drop=FALSE]
 for(b in failed) {
   val <- one(b);stopifnot(all(is.finite(val)))
   mat <- rbind(mat,val);rownames(mat)[nrow(mat)] <- as.character(b)
   audit[[length(audit)+1L]] <- data.frame(test_id=sp$A,draw=b,original_error="Gamma 未收敛",action="PROBABILITY_ONLY_SAME_DRAW")
 }
 idx <- as.integer(rownames(mat));mat <- mat[order(idx),,drop=FALSE]
 stopifnot(identical(as.integer(rownames(mat)),1:200),
   identical(unname(mat[as.character(old_idx),,drop=FALSE]),unname(bt$mat[,nm,drop=FALSE])))
 corrected <- list(mat=mat,ok_idx=1:200,fail_idx=integer(),fail_msg=character(),B=200L)
 saveRDS(list(est=point,boot=corrected,original_file=paste0("B200_",sp$A,".rds"),recovered_draws=failed),file.path(dest,paste0(sp$A,".rds")))
 sel <- e$select_for_refinement(point,corrected,"d_P",TRUE)
 row <- match(sp$A,selection$test_id)
 for(k in names(sel)) selection[row,k] <- sel[1,k]
 checks[[sp$A]] <- data.frame(test_id=sp$A,original_valid=length(old_idx),corrected_valid=nrow(mat),recovered=length(failed),point_and_successful_draw_match=TRUE)
}
selection$q_BH_14 <- selection$q_BY_14 <- NA_real_
ok <- which(selection$eligible)
selection$q_BH_14[ok] <- p.adjust(selection$p_screen[ok],"BH",n=14)
selection$q_BY_14[ok] <- p.adjust(selection$p_screen[ok],"BY",n=14)
stopifnot(identical(hash_before,vapply(original_files,e$sha_file,character(1))))
write.csv(selection,file.path(dest,"B200_PRIMARY_SELECTION_CORRECTED.csv"),row.names=FALSE)
write.csv(do.call(rbind,checks),file.path(dest,"VALIDATION.csv"),row.names=FALSE)
write.csv(do.call(rbind,audit),file.path(dest,"RECOVERED_DRAWS.csv"),row.names=FALSE)
saveRDS(hash_before,file.path(dest,"ORIGINAL_SHA256.rds"))
jsonlite::write_json(list(status="PROBABILITY_RECOVERY_COMPLETED",pid=Sys.getpid(),at=as.character(Sys.time()),original_files_unchanged=TRUE,recovered=length(audit),selected=selection$test_id[selection$selected],amount_failures_preserved=TRUE),file.path(dest,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
print(selection[,c("test_id","n_valid","p_screen","eligible","selected")])
})
