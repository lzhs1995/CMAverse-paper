# 已登记R2/R5/R8：原生产只读，使用修正概率抽样；不筛选推断方法。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e <- new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
for(f in c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R")) sys.source(file.path(root,f),e)
e$PKG_DIR <- file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR <- file.path(root,"production_two_stage_v1")
e$load_covariates();e$check_frozen()
dest <- file.path(root,"auxiliary_fast_v1");dir.create(dest,showWarnings=FALSE)
stopifnot(!file.exists(file.path(dest,"RESULT.json")))
original <- list.files(e$OUT_DIR,recursive=TRUE,full.names=TRUE)
original <- original[!dir.exists(original)]
hashes <- vapply(original,e$sha_file,character(1))
d <- readRDS(file.path(e$OUT_DIR,"prepared_data.rds"))$d
r2 <- r5 <- r8 <- checks <- list()
for(sp in e$AB_SPECS) {
  obj <- readRDS(file.path(e$OUT_DIR,paste0("B200_",sp$A,".rds")))
  pr <- readRDS(file.path(root,"probability_recovery_v1",paste0(sp$A,".rds")))
  ss <- e$prepare_AB_samples(d,sp,e$covs_for(sp$drop),TRUE)
  e$require_sample_gate(ss$gateA)
  dat <- ss$A
  m <- e$fit_logit(ss$fA,dat)
  ri <- e$if_dP_logit(m,dat,sp$x,sp$w)
  stopifnot(isTRUE(all.equal(ri$estimate,unname(pr$est["d_P"]),tolerance=1e-10)))
  rl <- e$lpm_dP(ss$fA,dat,sp$x,sp$w)
  # LPM交互系数须与反事实平均差的差一致。
  ml <- lm(ss$fA,data=dat)
  pred <- function(x,w) mean(predict(ml,newdata=e$set_cf(dat,sp$x,x,sp$w,w)))
  dl <- pred(1,"5")-pred(0,"5")-pred(1,"le3")+pred(0,"le3")
  stopifnot(isTRUE(all.equal(unname(dl),rl$estimate,tolerance=1e-10)))
  r5[[sp$A]] <- cbind(test_id=paste0("R5_",sp$A),n=nrow(dat),n_cl=length(unique(dat[[e$CLUSTER]])),rl)
  r8[[sp$A]] <- cbind(test_id=paste0("R8_",sp$A),n=nrow(dat),n_cl=length(unique(dat[[e$CLUSTER]])),ri)
  for(k in setdiff(names(pr$est),"d_P")) {
    r2[[length(r2)+1L]] <- cbind(test_id=paste0("R2_",sp$A),source="corrected_probability_B200",e$summ_boot(pr$est,pr$boot,k))
  }
  stopifnot(isTRUE(obj$reused))
  for(k in names(obj$B$est)[grepl("_Y",names(obj$B$est)) & names(obj$B$est)!="d_Y"]) {
    r2[[length(r2)+1L]] <- cbind(test_id=paste0("R2_",sp$B),source="original_amount_B200",e$summ_boot(obj$B$est,obj$B$boot,k))
  }
  checks[[sp$A]] <- data.frame(test_id=sp$A,IF_matches_primary_point=TRUE,LPM_finite_contrast_matches=TRUE,n=nrow(dat))
}
write.csv(e$bind_fill(r2),file.path(dest,"R2_alternative_contrasts.csv"),row.names=FALSE)
write.csv(do.call(rbind,r5),file.path(dest,"R5_lpm.csv"),row.names=FALSE)
write.csv(do.call(rbind,r8),file.path(dest,"R8_influence.csv"),row.names=FALSE)
write.csv(do.call(rbind,checks),file.path(dest,"VALIDATION.csv"),row.names=FALSE)
stopifnot(identical(hashes,vapply(original,e$sha_file,character(1))))
jsonlite::write_json(list(status="COMPLETED",at=as.character(Sys.time()),pid=Sys.getpid(),original_production_unchanged=TRUE,
 interpretation="Registered auxiliary comparisons; no substitution for primary inference; B200 amount invalid draws retained",
 files=c("R2_alternative_contrasts.csv","R5_lpm.csv","R8_influence.csv","VALIDATION.csv")),file.path(dest,"RESULT.json"),pretty=TRUE,auto_unbox=TRUE)
print(do.call(rbind,r8));cat("REGISTERED_R2_R5_R8_COMPLETED\n")
})
