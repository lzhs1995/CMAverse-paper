# 纯合成簇数据的复合零假设检查；不读取研究数据，不选择最小p算法。
local({
  root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
  out <- file.path(root,"cluster_null_calibration_v1")
  dir.create(out,recursive=TRUE,showWarnings=FALSE)
  stopifnot(!file.exists(file.path(out,"STARTED.json")))
  e <- new.env(parent=globalenv())
  sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
  sys.source(file.path(root,"inference_patch_v1.R"),e)
  R <- 100L; B <- 200L; G <- 200L; size <- 4L
  started <- Sys.time()
  jsonlite::write_json(list(pid=Sys.getpid(),R=R,B=B,clusters=G,cluster_size=size,
    seed=610050L,real_data_read=FALSE,started_at=as.character(started),
    scope="finite synthetic DGP diagnostic, not universal calibration proof",
    decision_rule="strict p<0.05; exact binomial MC interval; no automatic validation claim"),
    file.path(out,"STARTED.json"),auto_unbox=TRUE,pretty=TRUE)
  # 各方程单独的高斯copula残差产生簇内相关；方程间独立，不引入M-Y隐藏共同原因。
  # pnorm边际均匀，保留指定的有序logit和结果logit边际模型。
  correlated_u <- function() {
    pnorm(sqrt(.3)*rep(rnorm(G),each=size)+sqrt(.7)*rnorm(G*size))
  }
  generate <- function(scenario,seed) {
    set.seed(seed)
    n <- G*size; cl <- rep(seq_len(G),each=size)
    c1 <- rep(rnorm(G),each=size)+rnorm(n)*.3
    x <- rbinom(n,1,plogis(.2*c1))
    a <- if(scenario %in% c("a0","both0")) 0 else .55
    b <- if(scenario %in% c("b0","both0")) 0 else .55
    eta <- a*x+.25*c1
    cp <- vapply(c(-2,-1.2,-.3,.6),function(z) plogis(z-eta),numeric(n))
    m <- 1L+rowSums(correlated_u()>cp)
    p <- plogis(-.4+.25*x+.2*c1+b*(m==4)+1.4*b*(m==5))
    y <- as.integer(correlated_u()<p)
    data.frame(unified_component=cl,c1=c1,x=x,m=e$ord5(m),m3=e$cut3(m),y=y)
  }
  records <- list()
  for(si in seq_along(c("a0","b0","both0"))) {
    scenario <- c("a0","b0","both0")[[si]]
    for(r in seq_len(R)) {
      if(as.numeric(difftime(Sys.time(),started,units="secs"))>2400) stop("bounded calibration exceeded 2400 seconds; retain partial records")
      clauder_progress("cluster_null_calibration",paste(scenario,r,"of",R,"B",B))
      z <- tryCatch({
        dat <- generate(scenario,610050L+si*1000L+r)
        stat <- function(q) e$stat_med(q,m~x+c1,y~x*m3+c1,"x","m3")
        est <- stat(dat)
        bt <- e$run_boot(dat,e$make_plan(dat$unified_component,B,810050L+si*1000L+r),stat,cores=1L)
        su <- e$summ_boot(est,bt,"indirect")
        data.frame(scenario=scenario,replicate=r,p=su$p_raw,estimate=su$estimate,
                   valid_share=su$valid_share,error="",stringsAsFactors=FALSE)
      },error=function(err) data.frame(scenario=scenario,replicate=r,p=NA_real_,
             estimate=NA_real_,valid_share=NA_real_,error=conditionMessage(err)))
      records[[length(records)+1L]] <- z
      write.csv(do.call(rbind,records),file.path(out,"REPLICATES.csv"),row.names=FALSE)
    }
  }
  detail <- do.call(rbind,records)
  summary <- do.call(rbind,lapply(split(detail,detail$scenario),function(z) {
    valid <- is.finite(z$p); n <- sum(valid); k <- sum(z$p[valid]<.05)
    ci <- if(n) binom.test(k,n)$conf.int else c(NA_real_,NA_real_)
    data.frame(scenario=z$scenario[1],R_requested=R,R_valid=n,rejections=k,
      reject_rate=if(n) k/n else NA_real_,mc_low=ci[1],mc_high=ci[2],
      diagnostic=if(n<R*.98) "UNSTABLE" else if(ci[1]>.05) "EVIDENCE_OF_OVERSIZE" else "NO_OVERSIZE_DETECTED_IN_THIS_DGP")
  }))
  write.csv(summary,file.path(out,"SUMMARY.csv"),row.names=FALSE)
  jsonlite::write_json(list(status="COMPLETED",pid=Sys.getpid(),
    elapsed_seconds=as.numeric(difftime(Sys.time(),started,units="secs")),
    real_data_read=FALSE,universal_calibration_claim=FALSE),file.path(out,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
  print(summary)
  clauder_progress("cluster_null_calibration_complete","three composite-null scenarios finished; inspect MC uncertainty")
})
