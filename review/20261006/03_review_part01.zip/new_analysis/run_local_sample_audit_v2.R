local({
 stopifnot(Sys.getpid()==89434L)
 root<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
 e<-new.env(parent=globalenv());sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
 sys.source(file.path(root,"sample_gates_v1.R"),e)
 sys.source(file.path(root,"lifetime_prep_patch_v1.R"),e)
 e$PKG_DIR<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/delivery/Claude云端分析资料_20261005_v1";e$load_covariates()
 d<-e$prep_data();d<-e$add_msateco(d,file.path(root,"msateco_intervals_audit.csv"))
 rows<-list()
 for(sp in e$AB_SPECS){z<-e$prepare_AB_samples(d,sp,e$covs_for(sp$drop))
  for(k in c("A","B")){g<-z[[paste0("gate",k)]];dd<-z[[k]]
   rows[[length(rows)+1L]]<-data.frame(id=sp[[k]],n=nrow(dd),clusters=length(unique(dd[[e$CLUSTER]])),
    eligible=g$ok,status=g$status,min_cell=g$min_cell,min_positive=g$min_positive,coverage=NA_real_)}}
 w<-e$build_threewave(d)
 for(kind in c("C","D")){base<-if(kind=="C") d else w;specs<-if(kind=="C")e$C_SPECS else e$D_SPECS
  for(sp in specs){cf<-if(kind=="C")e$covs_for else e$covs_D
   z<-e$prepare_med_sample(base,sp,cf(sp$drop),three_wave=kind=="D")
   cover<-NA_real_
   if(sp$id %in% c("C3","C4")) {
    pre<-e$analysis_sample(base,unique(c(sp$x,"y1_any",cf(sp$drop))))
    cover<-mean(complete.cases(pre <- base[match(pre$stable_row_id,base$stable_row_id),c("eco_spouse_begin","eco_spouse_end")]))
   }
   rows[[length(rows)+1L]]<-data.frame(id=sp$id,n=nrow(z$data),clusters=length(unique(z$data[[e$CLUSTER]])),
    eligible=z$gate$ok && (is.na(cover)||cover>=.8),status=z$gate$status,min_cell=z$gate$min_cell,
    min_positive=NA_integer_,coverage=cover)
  }}
 out<-do.call(rbind,rows);out$control_status<-"LIFETIME_PATCHED_22_TIMING_DISCLOSURE_PENDING"
 write.csv(out,file.path(root,"LOCAL_SAMPLE_GATES_LIFETIME_PATCHED_v2.csv"),row.names=FALSE)
 print(out[,c("id","n","eligible","coverage")],row.names=FALSE)
})
