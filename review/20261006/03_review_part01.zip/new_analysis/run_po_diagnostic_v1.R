# 同一五分类比例优势诊断；未计聚类的LR只作诊断，不作选择门槛。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e<-new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
for(f in c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","production_gates_v2.R","ordinal_guard_v1.R"))sys.source(file.path(root,f),e)
e$PKG_DIR<-file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR<-file.path(root,"production_two_stage_v1")
e$load_covariates();e$check_frozen()
z<-readRDS(file.path(e$OUT_DIR,"prepared_data.rds"))
dest<-file.path(root,"po_diagnostic_v1");dir.create(dest,showWarnings=FALSE)
rows<-list()
for(sp in c(e$C_SPECS,e$D_SPECS)){
 cat("PO diagnostic ",sp$id,"\n");flush.console()
 rows[[sp$id]]<-tryCatch({
 isD<-startsWith(sp$id,"D")
 covs<-if(isD)e$covs_D(sp$drop)else e$covs_for(sp$drop)
 fM<-e$fml(sp$s1,c(sp$x,sp$s0,covs))
 dat<-e$zscale(e$analysis_sample(if(isD)z$w else z$d,all.vars(fM)),covs)
 dat[[sp$s1]]<-droplevels(dat[[sp$s1]])
 if(nlevels(dat[[sp$s1]])!=5L)stop("FIVE_CATEGORIES_REQUIRED")
 m0<-ordinal::clm(fM,data=dat,link="logit")
 m1<-ordinal::clm(update(fM,as.formula(paste(". ~ . -",sp$x))),nominal=as.formula(paste("~",sp$x)),data=dat,link="logit")
 e$check_clm_fit(m0);e$check_clm_fit(m1)
 lr<-2*(as.numeric(logLik(m1))-as.numeric(logLik(m0)))
 df<-length(coef(m1))-length(coef(m0))
 if(df<=0||lr< -1e-6)stop("INVALID_LR")
 saveRDS(list(po=m0,ppo=m1),file.path(dest,paste0(sp$id,".rds")))
 data.frame(test_id=sp$id,status="DIAGNOSTIC_ONLY",n=nrow(dat),LR=lr,df=df,p_naive=pchisq(max(lr,0),df,lower.tail=FALSE),note="常规LR未计聚类；不作主检验或换模门槛")
 },error=function(err)data.frame(test_id=sp$id,status="FAILED",note=conditionMessage(err)))
 write.csv(e$bind_fill(rows),file.path(dest,"RESULTS.csv"),row.names=FALSE)
}
jsonlite::write_json(list(status="COMPLETED",at=as.character(Sys.time()),pid=Sys.getpid(),note="诊断失败原样保留"),file.path(dest,"PROCESS_RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
})

