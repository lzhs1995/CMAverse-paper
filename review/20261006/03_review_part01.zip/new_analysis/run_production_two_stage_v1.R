local({
root<-"/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e<-new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
patches<-c("inference_patch_v1.R","sample_gates_v1.R","lifetime_prep_patch_v1.R","audit_guards_v1.R","production_gates_v2.R","two_stage_selection_v1.R","checkpoint_boot_v1.R")
for(f in patches)sys.source(file.path(root,f),e)
e$PKG_DIR<-file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR<-file.path(root,"production_two_stage_v1");e$N_CORES<-1L
e$ensure_out();e$load_covariates()

e$check_frozen()
lock<-file.path(e$OUT_DIR,"RUNNING.lock")
if(!dir.create(lock,showWarnings=FALSE))stop("已有运行锁；先核原进程，禁止重复提交")
on.exit(unlink(lock,recursive=TRUE),add=TRUE)
jsonlite::write_json(list(pid=Sys.getpid(),at=as.character(Sys.time())),file.path(lock,"OWNER.json"),auto_unbox=TRUE)
z<-readRDS(file.path(e$OUT_DIR,"prepared_data.rds"));p<-readRDS(file.path(e$OUT_DIR,"plan2000.rds"))
manifest_sha<-e$sha_file(file.path(e$OUT_DIR,"FREEZE_SHA256.rds"))
current<-"";call_index<-0L
check_disk<-function(){
 lines<-system2("/bin/df",c("-k",shQuote(e$OUT_DIR)),stdout=TRUE)
 fields<-strsplit(trimws(tail(lines,1L)),"[[:space:]]+")[[1L]]
 free<-as.numeric(fields[4L])*1024
 if(!is.finite(free)||free<10e9)stop("DISK_FLOOR: 检查点已保留，需完成备份释放后续算")
}
emit<-function(stage,message){
 jsonlite::write_json(list(stage=stage,message=message,pid=Sys.getpid(),updated_at=as.character(Sys.time())),file.path(e$OUT_DIR,"PROGRESS.json"),auto_unbox=TRUE)
 clauder_progress(stage,message)
 check_disk()
}
e$run_boot<-function(dat,plan,stat_fun,cores=1L,cluster=e$CLUSTER){
 call_index<<-call_index+1L
 key<-paste0(current,"_fit",call_index)
 ident<-digest::digest(list(manifest_sha=manifest_sha,data=dat,full_plan=p,fit_key=key),algo="sha256")
 e$checkpoint_boot(dat,plan,stat_fun,file.path(e$OUT_DIR,"checkpoints",paste0(key,".rds")),ident,cluster,
 progress=function(b,B)emit(current,paste("bootstrap",b,"/",B)))
}
allrows<-list()
for(kind in c("AB","C","D")){
 specs<-switch(kind,AB=e$AB_SPECS,C=e$C_SPECS,D=e$D_SPECS)
 for(sp in specs){
 current<-if(kind=="AB")paste0(sp$A,"_",sp$B)else sp$id
 call_index<-0L
 target<-file.path(e$OUT_DIR,paste0("summary_B200_",current,".rds"))
 if(file.exists(target)){allrows[[current]]<-readRDS(target);next}
 emit(current,"point estimate and fixed B200 started")
 rr<-tryCatch({
  if(kind=="AB")e$run_AB_specs(list(sp),z$d,e$plan_prefix(p,200L),tag="B200",cores=1L)
  else e$run_med(list(sp),if(kind=="C")z$d else z$w,e$plan_prefix(p,200L),
   if(kind=="C")e$covs_for else e$covs_D,tag="B200",cores=1L)
 },error=function(err){
   jsonlite::write_json(list(spec=current,error=conditionMessage(err),at=as.character(Sys.time())),file.path(e$OUT_DIR,paste0("ERROR_",current,".json")),auto_unbox=TRUE)
   NULL
 })
 if(!is.null(rr)){saveRDS(rr,target);allrows[[current]]<-rr}
 emit(current,if(is.null(rr))"FAILED; retained error, continuing next registered spec"else"B200 complete")
 }
}
summary<-e$bind_fill(allrows)
write.csv(summary,file.path(e$OUT_DIR,"B200_ALL_ESTIMANDS.csv"),row.names=FALSE)
jsonlite::write_json(list(status="SCREENING_PROCESS_COMPLETED",pid=Sys.getpid(),completed_groups=names(allrows),at=as.character(Sys.time())),file.path(e$OUT_DIR,"SCREENING_TERMINAL.json"),auto_unbox=TRUE,pretty=TRUE)
emit("B200_complete","Inspect all registered primary rows and select fixed refinement candidates")
})
