# 登记次级S1—S4；原计划B2000，固定抽样、私有检查点、零主产物修改。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e <- new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
for(f in c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","checkpoint_boot_v1.R")) sys.source(file.path(root,f),e)
e$PKG_DIR <- file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR <- file.path(root,"production_two_stage_v1")
e$load_covariates(); e$check_frozen()
d <- readRDS(file.path(e$OUT_DIR,"prepared_data.rds"))$d
p <- readRDS(file.path(e$OUT_DIR,"plan2000.rds")); stopifnot(p$B==2000L)
dest <- file.path(root,"secondary_S_v1");dir.create(dest,showWarnings=FALSE)
defs <- list(S1=list(role="both",drop=NULL,terms=c("xa * w_self3","xa * w_spouse3"),keys=c("S1","d_self_joint","d_spouse_joint")),
 S2=list(role="none",drop="gender_begin",terms="xa",keys=c("S2","T_female","T_male")),
 S3=list(role="self",drop="gender_begin",terms="xa * w_self3",keys=c("diff","d_female","d_male")),
 S4=list(role="spouse",drop="gender_begin",terms="xa * w_spouse3",keys=c("diff","d_female","d_male")))
rows <- list(); gates <- list()
for(id in names(defs)) {
 sp<-defs[[id]]; cv<-e$covs_for(sp$role,drop=sp$drop)
 f<-e$fml("y1_any",c(cv,sp$terms))
 dat<-e$zscale(e$analysis_sample(d,unique(c(all.vars(f),"female"))),cv)
 # 先核收入×满意度×性别的实际样本支持，不按估计结果择样。
 groups<-if(id=="S1")list(all=dat)else split(dat,dat$female)
 gate<-lapply(names(groups),function(g) {
  z<-groups[[g]]; ws<-intersect(c("w_self3","w_spouse3"),all.vars(f))
  if(!length(ws))ws<-NA_character_
  do.call(rbind,lapply(ws,function(w) {
   tt<-if(is.na(w))table(factor(z$xa,levels=0:1))else table(factor(z$xa,levels=0:1),factor(z[[w]],levels=c("le3","4","5")))
   data.frame(id=id,stratum=g,w=if(is.na(w))"none"else w,n=nrow(z),clusters=length(unique(z[[e$CLUSTER]])),min_cell=min(tt),outcome_levels=length(unique(z$y1_any)),support_ok=min(tt)>=30&&length(unique(z$y1_any))==2)
  }))
 })
 gates[[id]]<-do.call(rbind,gate)
 write.csv(do.call(rbind,gates),file.path(dest,"SAMPLE_GATES.csv"),row.names=FALSE)
 if(!all(gates[[id]]$support_ok))stop(paste(id,"样本支持不合格，保留证据"))
 sf<-switch(id,S1=function(z)e$stat_S1(z,f),S2=function(z)e$stat_S2(z,f),
 S3=function(z)e$stat_S34(z,f,"w_self3"),S4=function(z)e$stat_S34(z,f,"w_spouse3"))
 ident<-digest::digest(list(data=dat,plan=p,formula=f,code=e$sha_file(file.path(root,"run_secondary_S_v1.R")),
  original=e$sha_file("/Users/lzhs/Downloads/20261005_astra_v4_functions.R"),
  patches=vapply(c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","checkpoint_boot_v1.R"),function(x)e$sha_file(file.path(root,x)),character(1))),algo="sha256")
 emit<-function(b,B) {
  free<-as.numeric(strsplit(trimws(tail(system2("/bin/df",c("-k",shQuote(dest)),stdout=TRUE),1)),"[[:space:]]+")[[1]][4])*1024
  jsonlite::write_json(list(stage=id,message=paste("bootstrap",b,"/",B),pid=Sys.getpid(),updated_at=as.character(Sys.time()),free_bytes=free),file.path(dest,"PROGRESS.json"),auto_unbox=TRUE)
  clauder_progress(id,paste("bootstrap",b,"/",B))
  if(!is.finite(free)||free<10e9)stop("DISK_FLOOR; 原检查点保留")
 }
 emit(0,p$B)
 est<-sf(dat)
 bt<-e$checkpoint_boot(dat,p,sf,file.path(dest,paste0("checkpoint_",id,".rds")),ident,e$CLUSTER,progress=emit)
 saveRDS(list(id=id,formula=f,est=est,boot=bt,n=nrow(dat),clusters=length(unique(dat[[e$CLUSTER]])),identity=ident),file.path(dest,paste0(id,".rds")))
 rows[[id]]<-do.call(rbind,lapply(sp$keys,function(k)cbind(test_id=id,n=nrow(dat),n_cl=length(unique(dat[[e$CLUSTER]])),e$summ_boot(est,bt,k))))
 write.csv(do.call(rbind,rows),file.path(dest,"ALL_ESTIMANDS.csv"),row.names=FALSE)
}
out<-do.call(rbind,rows)
primary<-out[paste(out$test_id,out$estimand)%in%c("S1 S1","S2 S2","S3 diff","S4 diff"),]
stopifnot(nrow(primary)==4)
primary$q_BH_S4<-p.adjust(primary$p_raw,"BH",n=4);primary$q_BY_S4<-p.adjust(primary$p_raw,"BY",n=4)
write.csv(primary,file.path(dest,"PRIMARY_S4.csv"),row.names=FALSE)
jsonlite::write_json(list(status="COMPLETED",pid=Sys.getpid(),at=as.character(Sys.time()),B=2000,interpretation="Registered secondary exploratory family; not independent confirmation"),file.path(dest,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
cat("SECONDARY_S4_COMPLETED\n")
})

