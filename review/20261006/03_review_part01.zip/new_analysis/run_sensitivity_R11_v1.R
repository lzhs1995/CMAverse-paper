# 登记R11部分比例优势中介；B500，检查收敛与预测概率。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e<-new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
for(f in c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","production_gates_v2.R","checkpoint_boot_v1.R","ordinal_guard_v1.R"))sys.source(file.path(root,f),e)
e$PKG_DIR<-file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR<-file.path(root,"production_two_stage_v1")
e$load_covariates();e$check_frozen()
z<-readRDS(file.path(e$OUT_DIR,"prepared_data.rds"))
dest<-file.path(root,"sensitivity_R11_v1");dir.create(dest,showWarnings=FALSE)
e$OUT_DIR<-dest
plan<-e$make_or_load_plan(z$d,500L,e$SEED_ROB,"plan500.rds")
# 原函数按exact id识别D；保持原id执行，以tag区分敏感性输出。
tasks<-setNames(e$C_SPECS,paste0("R11_",vapply(e$C_SPECS,function(sp)sp$id,character(1))))
original_boot<-e$run_boot
current<-""; fit_index<-0L
emit<-function(b,B) {
 free<-as.numeric(strsplit(trimws(tail(system2("/bin/df",c("-k",shQuote(dest)),stdout=TRUE),1)),"[[:space:]]+")[[1]][4])*1024
 jsonlite::write_json(list(stage=current,message=paste("bootstrap",b,"/",B),updated_at=as.character(Sys.time()),pid=Sys.getpid(),free_bytes=free),file.path(dest,"PROGRESS.json"),auto_unbox=TRUE)
 clauder_progress(current,paste("bootstrap",b,"/",B))
 if(!is.finite(free)||free<10e9)stop("DISK_FLOOR")
}
sources<-c("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",file.path(root,c("run_sensitivity_R11_v1.R","inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","production_gates_v2.R","checkpoint_boot_v1.R","ordinal_guard_v1.R")))
sources<-c(sources,file.path(root,"production_two_stage_v1","prepared_data.rds"))
hashes<-vapply(sources,e$sha_file,character(1))
write.csv(data.frame(path=sources,sha256=unname(hashes),bytes=file.info(sources)$size),file.path(dest,"SOURCE_MANIFEST.csv"),row.names=FALSE)
e$run_boot<-function(dat,plan,stat_fun,cores=1L,cluster=e$CLUSTER) {
 fit_index<<-fit_index+1L
 identity<-digest::digest(list(data=dat,plan=plan,task=current,fit=fit_index,sources=hashes),algo="sha256")
 e$checkpoint_boot(dat,plan,stat_fun,file.path(dest,"checkpoints",paste0(current,"_",fit_index,".rds")),identity,cluster,progress=emit)
}
rows<-list();failures<-list()
for(id in names(tasks)) {
 current<-id;fit_index<-0L;sp<-tasks[[id]]
 saved<-file.path(dest,paste0("summary_",id,".rds"))
 if(file.exists(saved)){rows[[id]]<-readRDS(saved);next}
 emit(0,500L)
 rr<-tryCatch({
  ans<-e$run_med(list(sp),z$d,plan,e$covs_for,tag="R11",cores=1L,m_model="ppo")
  ans$test_id<-id;ans
 },error=function(err) {
  failures[[id]]<<-list(task=id,error=conditionMessage(err),at=as.character(Sys.time()))
  jsonlite::write_json(failures,file.path(dest,"FAILURES.json"),auto_unbox=TRUE,pretty=TRUE)
  if(grepl("DISK_FLOOR",conditionMessage(err),fixed=TRUE))stop(err)
  NULL
 })
 if(!is.null(rr)){rows[[id]]<-rr;saveRDS(rr,saved)}
 write.csv(e$bind_fill(rows),file.path(dest,"ALL_ESTIMANDS.csv"),row.names=FALSE)
}
stopifnot(identical(hashes,vapply(sources,e$sha_file,character(1))))
jsonlite::write_json(list(status="PROCESS_COMPLETED",pid=Sys.getpid(),at=as.character(Sys.time()),B=500,completed=names(rows),failed=names(failures),expected=names(tasks)),file.path(dest,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
cat("R11_PROCESS_COMPLETED\n")
})

