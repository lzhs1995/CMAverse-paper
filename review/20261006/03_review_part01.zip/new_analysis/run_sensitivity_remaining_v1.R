# 登记R3/R4/R6/R9/R10；B500，复用固定准备数据，尚需原生验收。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
e<-new.env(parent=environment())
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
for(f in c("inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","production_gates_v2.R","checkpoint_boot_v1.R"))sys.source(file.path(root,f),e)
e$PKG_DIR<-file.path(dirname(dirname(root)),"delivery/Claude云端分析资料_20261005_v1")
e$OUT_DIR<-file.path(root,"production_two_stage_v1")
e$load_covariates();e$check_frozen()
z<-readRDS(file.path(e$OUT_DIR,"prepared_data.rds"))
dest<-file.path(root,"sensitivity_remaining_v1");dir.create(dest,showWarnings=FALSE)
e$OUT_DIR<-dest
plan<-e$make_or_load_plan(z$d,500L,e$SEED_ROB,"plan500.rds")
# 原函数按exact id识别D；保持原id执行，以tag区分敏感性输出。
a<-readRDS(file.path(dest,"actor_period_prepared.rds"))
# dwm_begin有645组父母行不一致，但R4不使用此列；禁止加入新调整集。
stopifnot(!"dwm_begin"%in%e$covs_R4("self"),!"dwm_begin"%in%e$covs_R4("spouse"))
s0<-e$analysis_sample(z$d,c("xl","w_self3","y1_any","y1_amt",e$covs_for("self")))
q75<-unname(quantile(s0$xl[s0$xl>0],.75))
cap<-unname(quantile(z$d$y1_amt[!is.na(z$d$y1_amt)&z$d$y1_amt>0],.99))
write.csv(data.frame(XL_low=0,XL_high=q75,amount_cap99=cap),file.path(dest,"FIXED_CONTRASTS.csv"),row.names=FALSE)
d6<-z$d;d6$y1_amt<-pmin(d6$y1_amt,cap)
old_gate<-e$cell_gate
e$cell_gate<-function(dat,x,w,positive=NULL,min_n=100L,min_positive=30L){
 if(x!="xl")return(old_gate(dat,x,w,positive,min_n,min_positive))
 # 连续X以零点两侧的实际支持检查；对比端点须在每个W组观测范围内。
 tmp<-dat;tmp$xl<-as.integer(tmp$xl>0)
 g<-old_gate(tmp,x,w,positive,min_n,min_positive)
 ranges<-vapply(split(dat$xl,dat[[w]],drop=FALSE),function(v)length(v)>0&&min(v)<=0&&max(v)>=q75,logical(1))
 g$ok<-g$ok&&all(ranges);g$status<-if(g$ok)"ELIGIBLE"else"CONTINUOUS_CONTRAST_UNSUPPORTED";g
}
tasks<-list()
for(sp in e$AB_SPECS){
 for(k in c("A","B"))tasks[[paste0("R4_",sp[[k]])]]<-list(kind=k,sp=sp,tag="R4",base=a)
 tasks[[paste0("R6_",sp$B)]]<-list(kind="B",sp=sp,tag="R6",base=d6)
}
for(sp in e$AB_SPECS[1:2]){sp$x<-"xl";for(k in c("A","B"))tasks[[paste0("R3_",sp[[k]])]]<-list(kind=k,sp=sp,tag="R3",base=z$d)}
for(sp in e$C_SPECS)tasks[[paste0("R9_",sp$id)]]<-list(kind="C",sp=sp,tag="R9")
for(sp in e$D_SPECS)for(tag in c("R9","R10"))tasks[[paste0(tag,"_",sp$id)]]<-list(kind="D",sp=sp,tag=tag)
original_boot<-e$run_boot
current<-""; fit_index<-0L
emit<-function(b,B) {
 free<-as.numeric(strsplit(trimws(tail(system2("/bin/df",c("-k",shQuote(dest)),stdout=TRUE),1)),"[[:space:]]+")[[1]][4])*1024
 jsonlite::write_json(list(stage=current,message=paste("bootstrap",b,"/",B),updated_at=as.character(Sys.time()),pid=Sys.getpid(),free_bytes=free),file.path(dest,"PROGRESS.json"),auto_unbox=TRUE)
 clauder_progress(current,paste("bootstrap",b,"/",B))
 if(!is.finite(free)||free<10e9)stop("DISK_FLOOR")
}
sources<-c("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",file.path(root,c("run_sensitivity_remaining_v1.R","inference_patch_v1.R","sample_gates_v1.R","audit_guards_v1.R","production_gates_v2.R","checkpoint_boot_v1.R")))
sources<-c(sources,file.path(dest,"actor_period_prepared.rds"),file.path(root,"production_two_stage_v1","prepared_data.rds"))
hashes<-vapply(sources,e$sha_file,character(1))
write.csv(data.frame(path=sources,sha256=unname(hashes),bytes=file.info(sources)$size),file.path(dest,"SOURCE_MANIFEST.csv"),row.names=FALSE)
e$run_boot<-function(dat,plan,stat_fun,cores=1L,cluster=e$CLUSTER) {
 fit_index<<-fit_index+1L
 identity<-digest::digest(list(data=dat,plan=plan,task=current,fit=fit_index,sources=hashes),algo="sha256")
 e$checkpoint_boot(dat,plan,stat_fun,file.path(dest,"checkpoints",paste0(current,"_",fit_index,".rds")),identity,cluster,progress=emit)
}
rows<-list();failures<-list()
for(id in names(tasks)) {
 current<-id;fit_index<-0L;t<-tasks[[id]];sp<-t$sp
 saved<-file.path(dest,paste0("summary_",id,".rds"))
 if(file.exists(saved)){rows[[id]]<-readRDS(saved);next}
 emit(0,500L)
 rr<-tryCatch({
  if(t$kind %in%c("A","B")) {
   # A只计算概率；B自身仍联合重抽样两方程，不让B失败污染独立A。
   ss<-e$prepare_AB_samples(t$base,sp,if(t$tag=="R4")e$covs_R4(sp$drop)else e$covs_for(sp$drop),with_B=t$kind=="B")
   amount<-t$kind=="B";dat<-if(amount)ss$B else ss$A
   e$require_sample_gate(if(amount)ss$gateB else ss$gateA)
   sf<-function(q)e$stat_AB(q,ss$fA,if(amount)ss$fB else NULL,sp$x,sp$w,x_hi=if(t$tag=="R3")q75 else 1,x_lo=0)
   est<-sf(dat);bt<-e$run_boot(dat,plan,sf)
   saveRDS(list(est=est,boot=bt,n=nrow(dat),n_cl=length(unique(dat[[e$CLUSTER]])),fA=ss$fA,fB=ss$fB,kind=t$kind),file.path(dest,paste0("fit_",id,".rds")))
   keys<-names(est)[grepl(if(amount)"_Y"else"_P",names(est),fixed=TRUE)]
   do.call(rbind,lapply(keys,function(k)cbind(test_id=id,tag=t$tag,n=nrow(dat),n_cl=length(unique(dat[[e$CLUSTER]])),e$summ_boot(est,bt,k))))
  } else {
   cf<-if(t$kind=="C")function(dr)e$covs_for(dr) else function(dr)e$covs_D(dr)
   ans<-e$run_med(list(sp),if(t$kind=="C")z$d else z$w,plan,cf,tag=t$tag,cores=1L,y_type=if(t$tag=="R9")"twopart"else"binary",extra_y=if(t$tag=="R10")c("y2020_any","y2020_ihs")else character())
   ans$test_id<-id;ans
  }
 },error=function(err) {
  failures[[id]]<<-list(task=id,error=conditionMessage(err),at=as.character(Sys.time()))
  jsonlite::write_json(failures,file.path(dest,"FAILURES.json"),auto_unbox=TRUE,pretty=TRUE)
  if(grepl("DISK_FLOOR",conditionMessage(err),fixed=TRUE))stop(err)
  NULL
 })
 if(!is.null(rr)){rows[[id]]<-rr;saveRDS(rr,saved)}
 write.csv(e$bind_fill(rows),file.path(dest,"ALL_ESTIMANDS.csv"),row.names=FALSE)
}
stopifnot(identical(hashes,vapply(sources,e$sha_file,character(1))))
jsonlite::write_json(list(status="PROCESS_COMPLETED",pid=Sys.getpid(),at=as.character(Sys.time()),B=500,completed=names(rows),failed=names(failures),expected=names(tasks)),file.path(dest,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
cat("REMAINING_SENSITIVITY_PROCESS_COMPLETED\n")
})
