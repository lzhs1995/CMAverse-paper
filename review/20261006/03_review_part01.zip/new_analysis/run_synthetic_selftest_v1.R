# 仅合成数据；不读取分析数据，保留云端原代码。
local({
  out <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1/synthetic_selftest_v1"
  dir.create(out, recursive=TRUE, showWarnings=FALSE)
  stopifnot(!file.exists(file.path(out,"RESULT.json")))
  log <- file(file.path(out,"self_test.log"), "wt")
  sink(log, split=TRUE)
  on.exit({sink(); close(log)}, add=TRUE)
  e <- new.env(parent=globalenv())
  sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R", envir=e)
  sys.source("/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1/audit_guards_v1.R", envir=e)
  e$OUT_DIR <- out
  t0 <- Sys.time()
  original_boot <- e$run_boot
  k <- 0L
  e$run_boot <- function(...) {
    k <<- k+1L
    clauder_progress("synthetic_bootstrap", paste("pure synthetic block", k))
    original_boot(...)
  }
  clauder_progress("synthetic_selftest", "n=20000 B=40 seed=7 cores=1; no real data")
  ans <- tryCatch({e$self_test(n=20000L, B=40L, seed=7L, cores=1L); list(status="PASS")},
                  error=function(x) list(status="FAIL", error=conditionMessage(x)))
  ans$elapsed_seconds <- as.numeric(difftime(Sys.time(),t0,units="secs"))
  ans$pid <- Sys.getpid()
  ans$real_data_read <- FALSE
  ans$completed_at <- format(Sys.time(),tz="UTC",usetz=TRUE)
  jsonlite::write_json(ans,file.path(out,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
  clauder_progress("synthetic_selftest_finished", ans$status)
  if(ans$status!="PASS") stop(ans$error)
})
