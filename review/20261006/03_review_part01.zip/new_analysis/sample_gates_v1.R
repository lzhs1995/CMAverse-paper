# 私有样本门槛：先载入原函数；禁止不足样本进入拟合。
# A/B 正值30按每个X×W格执行，预先固定较严格解释。
cell_gate <- function(dat, x, w, positive = NULL, min_n = 100L, min_positive = 30L) {
  stopifnot(all(c(x,w) %in% names(dat)))
  if (!all(dat[[x]] %in% 0:1)) stop("二值主暴露门槛不能用于连续暴露")
  xx <- factor(dat[[x]], levels=0:1)
  ww <- factor(dat[[w]], levels=LV3)
  if (anyNA(xx) || anyNA(ww)) stop("门槛输入尚有缺失或非法分类")
  counts <- table(xx,ww)
  positive_counts <- if (is.null(positive)) NULL else {
    stopifnot(positive %in% names(dat))
    yes <- !is.na(dat[[positive]]) & dat[[positive]] > 0
    table(xx[yes],ww[yes])
  }
  ok <- min(counts) >= min_n &&
    (is.null(positive_counts) || min(positive_counts) >= min_positive)
  list(ok=ok, min_cell=unname(min(counts)),
    min_positive=if(is.null(positive_counts)) NA_integer_ else unname(min(positive_counts)),
    status=if(ok) "ELIGIBLE" else "NOT_ESTIMATED_INSUFFICIENT_SUPPORT")
}
prepare_AB_samples <- function(base, sp, covs, with_B=TRUE, yA="y1_any", yB="y1_amt") {
  rhs <- c(covs,paste(sp$x,"*",sp$w))
  fA <- fml(yA,rhs); fB <- if(with_B) fml(yB,rhs) else NULL
  # A完全案例不依赖金额；B联合概率/金额方程在同一B样本拟合。
  da <- analysis_sample(base,all.vars(fA))
  db <- if(with_B) analysis_sample(base,unique(c(all.vars(fA),all.vars(fB)))) else NULL
  ga <- cell_gate(da,sp$x,sp$w,positive=yA)
  gb <- if(with_B) cell_gate(db,sp$x,sp$w,positive=yB) else NULL
  list(A=zscale(da,covs),B=if(with_B) zscale(db,covs) else NULL,
       fA=fA,fB=fB,gateA=ga,gateB=gb,
       reuse_A_for_B=with_B && identical(da$stable_row_id,db$stable_row_id) && nrow(da)==nrow(db))
}
prepare_med_sample <- function(base,sp,covs,three_wave=FALSE,extra_y=character(),y_type="binary") {
  fM <- fml(sp$s1,c(sp$x,sp$s0,covs))
  rhs <- c(paste(sp$x,"*",sp$m3),sp$s0,covs,extra_y)
  fY <- fml("y1_any",rhs)
  fY2 <- if(y_type=="twopart") fml("y1_amt",rhs) else NULL
  dat <- analysis_sample(base,unique(c(all.vars(fM),all.vars(fY),all.vars(fY2))))
  gate <- cell_gate(dat,sp$x,sp$m3,min_n=30L)
  if(three_wave && nrow(dat)<2000L) {
    gate$ok<-FALSE;gate$status<-"NOT_ESTIMATED_THREE_WAVE_N_LT_2000"
  }
  gate$three_wave_n_ok <- !three_wave || nrow(dat)>=2000L
  list(data=zscale(dat,c(covs,extra_y)),fM=fM,fY=fY,fY2=fY2,gate=gate)
}
require_sample_gate <- function(gate) {
  if(!isTRUE(gate$ok)) stop(gate$status,call.=FALSE)
  invisible(TRUE)
}
