# 全14主项完成后提取；不根据中途结果启动精化。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
out <- file.path(root,"production_two_stage_v1")
e <- new.env()
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
sys.source(file.path(root,"audit_guards_v1.R"),e)
sys.source(file.path(root,"two_stage_selection_v1.R"),e)
e$OUT_DIR <- out
e$check_frozen()
stopifnot(file.exists(file.path(out,"SCREENING_TERMINAL.json")),
          !dir.exists(file.path(out,"RUNNING.lock")))
rows <- list()
for(sp in e$AB_SPECS) {
 z <- readRDS(file.path(out,paste0("B200_",sp$A,".rds")))
 for(role in c("A","B")){
  v <- z[[role]]
  stopifnot(!is.null(v))
  nm <- if(role=="A") "d_P" else "d_Y"
  rows[[sp[[role]]]] <- cbind(test_id=sp[[role]],group=paste0(sp$A,"_",sp$B),
    e$select_for_refinement(v$est,v$boot,nm,isTRUE(z[[paste0("gate",role)]]$ok)))
 }
}
for(sp in c(e$C_SPECS,e$D_SPECS)) {
 z <- readRDS(file.path(out,paste0("B200_",sp$id,".rds")))
 rows[[sp$id]] <- cbind(test_id=sp$id,group=sp$id,
    e$select_for_refinement(z$est,z$boot,"indirect",z$positivity_min_xm>=30))
}
tab <- do.call(rbind,rows)
stopifnot(nrow(tab)==14L,!anyDuplicated(tab$test_id))
tab$q_BH_14 <- p.adjust(ifelse(tab$eligible,tab$p_screen,NA_real_),"BH",n=14L)
tab$q_BY_14 <- p.adjust(ifelse(tab$eligible,tab$p_screen,NA_real_),"BY",n=14L)
write.csv(tab,file.path(out,"B200_PRIMARY_SELECTION.csv"),row.names=FALSE)
saveRDS(tab,file.path(out,"B200_PRIMARY_SELECTION.rds"))
print(tab[,c("test_id","estimate","p_screen","q_BH_14","n_valid","selected")])
})
