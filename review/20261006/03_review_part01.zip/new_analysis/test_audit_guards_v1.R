# 只测试合成对象及临时文件，不拟合真实结局。
test_dir <- tempfile("cma_guard_")
dir.create(test_dir)
OUT_DIR <- test_dir
checks <- list()
record <- function(name, ok) { checks[[name]] <<- isTRUE(ok); stopifnot(isTRUE(ok)) }
fails <- function(expr) inherits(tryCatch({force(expr); NULL}, error = identity), "error")
f <- file.path(test_dir, "source.txt")
writeLines("original", f)
manifest <- file.path(test_dir, "freeze.rds")
freeze_bound_files(f, manifest)
record("unchanged_source_accepted", verify_bound_files(manifest))
writeLines("tampered", f)
record("changed_source_rejected", fails(verify_bound_files(manifest)))
record("missing_source_rejected", {unlink(f); fails(verify_bound_files(manifest))})
d <- data.frame(unified_component = c(1L, 1L, 2L), covariate = c(1,2,3))
p <- make_or_load_plan(d, 10L, 5L, "plan.rds")
record("same_plan_reused", identical(p, make_or_load_plan(d, 10L, 5L, "plan.rds")))
d2 <- d; d2$covariate[1] <- 99
record("changed_data_rejected", fails(make_or_load_plan(d2, 10L, 5L, "plan.rds")))
p$draws[1,1] <- 99L; saveRDS(p, file.path(test_dir, "plan.rds"))
record("changed_draws_rejected", fails(make_or_load_plan(d, 10L, 5L, "plan.rds")))
z <- data.frame(actor_pid_begin=c("a","b"), partner_pid_begin=c("b","a"),
                period="2020-2022", sb=c(4,5), se=c(5,4), ab=c(5,4), ae=c(4,5))
ck <- function(x) link_check(x,"sb","se","ab","ae","synthetic")
record("known_reciprocal_pairs_accepted", ck(z)$status == "MATCHED_OBSERVED_PAIRS")
z0 <- z; z0$sb <- NA_real_
record("zero_effective_pairs_rejected", ck(z0)$status == "NO_EFFECTIVE_PAIRS")
z1 <- z; z1$sb[1] <- 1
record("mismatch_detected", ck(z1)$status == "MISMATCH")
record("ambiguous_identity_detected", ck(rbind(z,z[1,]))$status == "AMBIGUOUS_KEY_REQUIRES_AUDIT")
record("unreviewed_production_rejected", fails(check_frozen()))
record("nonblind_timing_disabled", fails(time_test()))
result <- data.frame(test=names(checks), pass=unlist(checks), row.names=NULL)
unlink(test_dir, recursive=TRUE)
print(result)
