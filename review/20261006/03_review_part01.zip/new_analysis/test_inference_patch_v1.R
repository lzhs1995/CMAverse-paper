local({
  root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
  e <- new.env(parent=globalenv())
  sys.source(file.path(root,"inference_patch_v1.R"),e)
  checks <- list(); k<-0L
  for (B in c(19L,20L,40L,200L,1000L,2000L)) {
    for (ties in c(FALSE,TRUE)) {
      dev <- if(ties) ceiling(seq_len(B)/5) else seq_len(B)
      for(t0 in c(0, .5, B*.95, B*.95+.5, max(dev), max(dev)+1)) {
        for(sgn in c(-1,1)) {
          est<-c(target=sgn*t0)
          bt<-list(mat=matrix(est+dev,ncol=1,dimnames=list(NULL,"target")),B=B)
          z<-e$summ_boot(est,bt,"target")
          excludes<-z$ci_low>0 || z$ci_high<0
          stopifnot(identical(excludes,z$p_raw<.05))
          k<-k+1L
        }
      }
    }
  }
  z<-e$summ_boot(c(target=190.5),list(mat=matrix(190.5+1:200,ncol=1,dimnames=list(NULL,"target")),B=200L),"target")
  stopifnot(z$ci_low == -.5, z$p_raw>.05)
  bad<-e$summ_boot(c(target=1),list(mat=matrix(1:97,ncol=1,dimnames=list(NULL,"target")),B=100L),"target")
  stopifnot(is.na(bad$p_raw),is.na(bad$ci_low),bad$boot_flag=="INFERENCE_UNSTABLE")
  empty<-e$summ_boot(c(target=1),list(mat=NULL,B=200L),"target")
  stopifnot(is.na(empty$p_raw),empty$n_valid==0)
  write.csv(data.frame(status="PASS",equivalence_cases=k,unstable_suppressed=TRUE,empty_handled=TRUE,pid=Sys.getpid()),file.path(root,"INFERENCE_PATCH_TEST.csv"),row.names=FALSE)
  cat("PASS",k,"finite-B inversion cases; unstable/empty inference suppressed\n")
})
