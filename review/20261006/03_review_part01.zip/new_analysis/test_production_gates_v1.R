root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
local({
 e<-new.env(parent=globalenv())
 sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
 sys.source(file.path(root,"sample_gates_v1.R"),e)
 sys.source(file.path(root,"production_gates_v1.R"),e)
 d<-expand.grid(x=0:1,w=c("le3","4","5"),i=1:110)
 d$w<-factor(d$w,levels=e$LV3);d$y1_any<-as.integer(d$i<=40)
 d$y1_amt<-ifelse(d$y1_any==1,100,0);d$unified_component<-d$i
 d$stable_row_id<-seq_len(nrow(d))
 sp<-list(A="A1",B="B1",x="x",w="w",drop="none")
 e$OUT_DIR<-file.path(root,"production_gate_test_outputs");dir.create(e$OUT_DIR,showWarnings=FALSE)
 calls<-list()
 # 此测试只观测执行器传递的样本，不以stub结果证明模型正确。
 e$stat_AB<-function(z,...) {calls[[length(calls)+1L]]<<-nrow(z);c(d_P=0,d_Y=0)}
 e$run_boot<-function(...) matrix(0,2,2,dimnames=list(NULL,c("d_P","d_Y")))
 e$summ_boot<-function(...) data.frame(estimate=0,p=1)
 e$run_AB_specs(list(sp),d,NULL,function(x) character(),"same",extra_est=character())
 stopifnot(identical(unlist(calls),660L))
 calls<-list();z<-d;z$y1_amt[1]<-NA
 e$run_AB_specs(list(sp),z,NULL,function(x) character(),"separate",extra_est=character())
 stopifnot(identical(unlist(calls),c(660L,659L)))
 calls<-list();bad<-d[d$i<=20,]
 failed<-inherits(try(e$run_AB_specs(list(sp),bad,NULL,function(x) character(),"bad",extra_est=character()),silent=TRUE),"try-error")
 stopifnot(failed,length(calls)==0)
 d$s1<-ordered(rep(1:5,length.out=nrow(d)));d$s0<-factor(rep(1:4,length.out=nrow(d)))
 e$stat_med<-function(...) stop("UNEXPECTED_FIT")
 sm<-list(id="D1",x="x",s1="s1",m3="w",s0="s0",drop="none")
 err<-try(e$run_med(list(sm),d,NULL,function(x)character(),"dtest"),silent=TRUE)
 stopifnot(inherits(err,"try-error"),grepl("THREE_WAVE_N_LT_2000",as.character(err)))
 write.csv(data.frame(status="PASS",checks=4L,pid=Sys.getpid(),scope="production dispatch only; no model or inference validation"),file.path(root,"PRODUCTION_GATE_TEST.csv"),row.names=FALSE)
 cat("PRODUCTION_GATE_TEST PASS: reuse, separate samples, A/B prefit rejection, D prefit rejection\n")
})
