local({
 root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
 e<-new.env(parent=globalenv())
 sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
 sys.source(file.path(root,"sample_gates_v1.R"),e)
 d<-expand.grid(x=0:1,w=c("le3","4","5"),i=1:100)
 d$w<-factor(d$w,levels=e$LV3);d$y1_any<-as.integer(d$i<=30)
 d$y1_amt<-ifelse(d$y1_any==1,100,0);d$unified_component<-d$i
 d$stable_row_id<-seq_len(nrow(d));sp<-list(x="x",w="w")
 good<-e$prepare_AB_samples(d,sp,character());stopifnot(good$gateA$ok,good$gateB$ok)
 # 金额缺失但发生已知，A必须保留，B单独排除。
 z<-d;z$y1_amt[z$x==0 & z$w=="le3" & z$i==1]<-NA
 sep<-e$prepare_AB_samples(z,sp,character())
 stopifnot(nrow(sep$A)==600,nrow(sep$B)==599,sep$gateA$ok,!sep$gateB$ok,!sep$reuse_A_for_B)
 # 仅缺正值支持，不得被总格数通过所掩盖。
 z<-d;z$y1_any[z$x==0 & z$w=="le3" & z$i==30]<-0
 low<-e$prepare_AB_samples(z,sp,character());stopifnot(!low$gateA$ok)
 called<-FALSE
 tryCatch({e$require_sample_gate(low$gateA);called<-TRUE},error=function(err)NULL)
 stopifnot(!called)
 # 缺一个完整分类格，必须拒绝。
 z<-d[!(d$x==1 & d$w=="5"),];stopifnot(!e$cell_gate(z,"x","w")$ok)
 # D总样本门槛独立于单格30。
 d$s1<-ordered(rep(1:5,length.out=nrow(d)));d$s0<-factor(rep(1:4,length.out=nrow(d)))
 med<-list(x="x",s1="s1",s0="s0",m3="w")
 stopifnot(e$prepare_med_sample(d,med,character())$gate$ok,
           !e$prepare_med_sample(d,med,character(),three_wave=TRUE)$gate$ok)
 write.csv(data.frame(status="PASS",checks=7L,pid=Sys.getpid()),file.path(root,"SAMPLE_GATE_TEST.csv"),row.names=FALSE)
 cat("PASS: separate A/B samples, zero cells, positive-cell threshold, prefit rejection, D N gate\n")
})
