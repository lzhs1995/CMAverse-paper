# 两阶段筛选只决定计算精度，不改变模型或创造独立确认样本。
select_for_refinement <- function(est, bt, name, support_ok=TRUE) {
 t0 <- unname(est[[name]])
 tb <- if(is.null(bt$mat) || !name %in% colnames(bt$mat)) numeric() else bt$mat[,name]
 stopifnot(length(t0)==1L,is.finite(t0),bt$B==200L,all(is.finite(tb)),length(tb)<=bt$B)
 n <- length(tb); k <- sum(abs(tb-t0)>=abs(t0))
 p <- if(n) (k+1)/(n+1) else NA_real_
 # 精确二项式区间只度量尾部模拟误差，不是效应区间。
 ci <- if(n) unname(stats::binom.test(k,n,conf.level=.95)$conf.int) else c(NA_real_,NA_real_)
 eligible <- isTRUE(support_ok) && n/bt$B>=.98
 boundary <- n>0L && ci[1]<=.05 && ci[2]>=.05
 chosen <- eligible && (p<=.10 || boundary)
 data.frame(estimand=name,estimate=t0,B=bt$B,n_valid=n,tail_count=k,p_screen=p,
 tail_mc_low=ci[1],tail_mc_high=ci[2],support_ok=isTRUE(support_ok),
 eligible=eligible,selected=chosen,
 reason=if(!eligible) "SUPPORT_OR_VALIDITY_FAILED" else if(chosen) "PRESET_SCREEN_OR_MC_BOUNDARY" else "NOT_SELECTED",
 interpretation="EXPLORATORY_REFINEMENT_NOT_INDEPENDENT_VALIDATION")
}
# 固定总计划的前缀，不重新抽样；需要生产驱动另外验证数据与函数内容SHA。
plan_prefix <- function(plan, B) {
 stopifnot(length(B)==1L,B>=1L,B<=plan$B,ncol(plan$draws)==plan$B)
 ans<-plan;ans$draws<-plan$draws[,seq_len(B),drop=FALSE];ans$B<-as.integer(B);ans
}
