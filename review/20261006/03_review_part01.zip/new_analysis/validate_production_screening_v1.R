# 独立读回已保存对象；不重新拟合模型。
local({
root <- "/Users/lzhs/Documents/cnm/tasks/01_R_analysis/CMAverse_恢复工程_20260927/next_phase/PLAN13_全稿实证复核与修订_20260929/exploratory_specification_search_20261005_v1/pro_claude_v4_consensus_20261005_v1"
out <- file.path(root,"production_two_stage_v1")
e <- new.env()
sys.source("/Users/lzhs/Downloads/20261005_astra_v4_functions.R",e)
sys.source(file.path(root,"audit_guards_v1.R"),e)
sys.source(file.path(root,"inference_patch_v1.R"),e)
e$OUT_DIR <- out
e$check_frozen()
stopifnot(!dir.exists(file.path(out,"RUNNING.lock")))
tab <- read.csv(file.path(out,"B200_ALL_ESTIMANDS.csv"))
primary <- tab[(tab$test_id %in% paste0("A",1:4)&tab$estimand=="d_P")|
 (tab$test_id %in% paste0("B",1:4)&tab$estimand=="d_Y")|
 (tab$test_id %in% c(paste0("C",1:4),paste0("D",1:2))&tab$estimand=="indirect"),]
stopifnot(nrow(primary)==14L,!anyDuplicated(primary$test_id))
checks <- list()
verify <- function(id,v,name){
 bt <- v$boot
 stopifnot(bt$B==200L,length(bt$ok_idx)+length(bt$fail_idx)==200L,
  !anyDuplicated(c(bt$ok_idx,bt$fail_idx)),
  identical(sort(c(bt$ok_idx,bt$fail_idx)),1:200),
  nrow(bt$mat)==length(bt$ok_idx),all(is.finite(bt$mat)),
  v$n>0,v$n_cl>0)
 rebuilt <- e$summ_boot(v$est,bt,name)
 row <- primary[primary$test_id==id,]
 for(nm in c("estimate","p_raw","ci_low","ci_high","n_valid"))
   stopifnot(isTRUE(all.equal(as.numeric(rebuilt[[nm]]),as.numeric(row[[nm]]),tolerance=1e-12)))
 checks[[id]] <<- data.frame(test_id=id,n=v$n,clusters=v$n_cl,n_valid=length(bt$ok_idx),
  status="SAVED_OBJECT_AND_TABLE_MATCH")
}
for(sp in e$AB_SPECS){
 z <- readRDS(file.path(out,paste0("B200_",sp$A,".rds")))
 verify(sp$A,z$A,"d_P");verify(sp$B,z$B,"d_Y")
}
for(sp in c(e$C_SPECS,e$D_SPECS)){
 z <- readRDS(file.path(out,paste0("B200_",sp$id,".rds")))
 verify(sp$id,z,"indirect")
}
plan <- readRDS(file.path(out,"plan2000.rds"))
for(f in list.files(file.path(out,"checkpoints"),full.names=TRUE,pattern="\\.rds$")){
 z <- readRDS(f)
 stopifnot(length(z$res)==200L,identical(z$ids,plan$ids),
  identical(z$draws,plan$draws[,1:200,drop=FALSE]))
}
ans <- do.call(rbind,checks)
write.csv(ans,file.path(out,"B200_VALIDATION.csv"),row.names=FALSE)
print(ans)
})
