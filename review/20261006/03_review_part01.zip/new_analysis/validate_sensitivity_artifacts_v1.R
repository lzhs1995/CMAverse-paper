# 独立核验已保存抽样对象；不重新拟合、不写运行目录。
validate_saved_family <- function(dest,out) {
 dir.create(out,recursive=TRUE,showWarnings=FALSE)
 tab<-read.csv(file.path(dest,"ALL_ESTIMANDS.csv"),stringsAsFactors=FALSE)
 checks<-list()
 same<-function(a,b)isTRUE(all.equal(as.numeric(a),as.numeric(b),tolerance=1e-10))
 for(id in unique(tab$test_id)) {
  fp<-file.path(dest,paste0("fit_",id,".rds"))
  if(!file.exists(fp))fp<-file.path(dest,paste0(id,".rds"))
  obj<-readRDS(fp);bt<-obj$boot
  cp<-if(grepl("^S[1-4]$",id))file.path(dest,paste0("checkpoint_",id,".rds"))else file.path(dest,"checkpoints",paste0(id,"_1.rds"))
  st<-readRDS(cp)
  stopifnot(length(st$res)==bt$B,ncol(st$draws)>=bt$B)
  ix<-which(vapply(st$res[seq_len(bt$B)],function(z)isTRUE(z$ok),logical(1)))
  mm<-if(length(ix))do.call(rbind,lapply(st$res[ix],function(z)z$val))else NULL
  stopifnot(identical(ix,bt$ok_idx),identical(which(!seq_len(bt$B)%in%ix),bt$fail_idx))
  if(length(ix))stopifnot(isTRUE(all.equal(unname(mm),unname(bt$mat),tolerance=0)))
  rr<-tab[tab$test_id==id,,drop=FALSE]
  for(j in seq_len(nrow(rr))) {
   r<-rr[j,];k<-r$estimand;t0<-obj$est[[k]];v<-bt$mat[,k]
   nv<-length(v);dev<-abs(v-t0);p<-(1+sum(dev>=abs(t0)))/(nv+1)
   stable<-nv/bt$B>=.98&&nv>1
   rank<-nv-ceiling(.05*(nv+1))+2L
   radius<-if(nv&&rank>=1&&rank<=nv)sort(dev)[rank]else Inf
   stopifnot(same(t0,r$estimate),same(nv,r$n_valid),same(bt$B,r$B),same(p,r$diagnostic_p))
   if(stable)stopifnot(same(p,r$p_raw),same(sd(v),r$se_boot),same(t0-radius,r$ci_low),same(t0+radius,r$ci_high))
   else stopifnot(is.na(r$p_raw),is.na(r$ci_low),is.na(r$ci_high))
   checks[[length(checks)+1L]]<-data.frame(test_id=id,estimand=k,B=bt$B,n_valid=nv,stable=stable,artifact_sha256=digest::digest(file=fp,algo="sha256"),pass=TRUE)
  }
 }
 z<-do.call(rbind,checks)
 write.csv(z,file.path(out,"VALIDATION.csv"),row.names=FALSE)
 jsonlite::write_json(list(status="SAVED_ARTIFACTS_VALIDATED",at=as.character(Sys.time()),rows=nrow(z),tests=unique(z$test_id),scope="Only completed saved rows; live process terminal is a separate requirement"),file.path(out,"RESULT.json"),auto_unbox=TRUE,pretty=TRUE)
 z
}

