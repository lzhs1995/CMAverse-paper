# =====================================================================
# 20261005_astra_v4_functions.R
# 配套：20261005_astra本地执行方案_v4.md、20261005_test_registry_v4.csv
#
# 状态：云端只写、从未运行。云端没有安装 R，也没有拟合任何模型。
# astra 在本机必须按顺序：
#   1) parse("20261005_astra_v4_functions.R") 无语法错误；
#   2) self_test() 全部 PASS（只用合成数据，不碰真实结局）；
#   3) time_test(d) 计时（用合成结局，不碰真实结局）；
#   4) 之后才按 step0 → step6 运行真实数据。
# 运行：把本文件和登记表放进解压后的资料包根目录（含 data/、screening/），在终端执行
#   VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 Rscript run_v4.R
# 不要在 RStudio 里用 mclapply 并行。
# 依赖：MASS、parallel、tools（R 自带）；sandwich（R5）；ordinal（PO 诊断、R11）；
#       haven（只在第 0 步提取 msateco 时用）。
# =====================================================================

suppressPackageStartupMessages({
  library(MASS)
  library(parallel)
})

# ---------------------------------------------------------------------
# 0. 配置
# ---------------------------------------------------------------------
PKG_DIR   <- Sys.getenv("CMA_PKG", ".")
OUT_DIR   <- Sys.getenv("CMA_OUT", file.path(PKG_DIR, "v4_outputs"))
REGISTRY  <- file.path(PKG_DIR, "20261005_test_registry_v4.csv")
CLUSTER   <- "unified_component"
LV3       <- c("le3", "4", "5")
SEED_MAIN <- 20261005L   # 主抽样计划：全部主检验与次级检验共用同一组簇抽样
SEED_ROB  <- 20261006L   # 稳健性抽样计划
SEED_CAL  <- 20261105L   # 中介检验的合成数据校准
B_MAIN    <- 2000L
B_ROB     <- 500L
N_PRIMARY <- 14L
N_SECOND  <- 4L
N_CORES   <- max(1L, parallel::detectCores() - 1L)

COV23 <- NULL
COV22 <- NULL
load_covariates <- function() {
  v <- trimws(readLines(file.path(PKG_DIR, "data/fixed_23_covariates.txt"), warn = FALSE))
  v <- v[nzchar(v)]
  stopifnot(length(v) == 23L, "dwm_begin" %in% v)
  COV23 <<- v
  COV22 <<- setdiff(v, "dwm_begin")   # 主设定：去掉累计到 2022 年的 dwm
  invisible(v)
}

# ---------------------------------------------------------------------
# 1. 小工具
# ---------------------------------------------------------------------
same_or_both_na <- function(a, b) all((is.na(a) & is.na(b)) | (!is.na(a) & !is.na(b) & a == b))
cut3 <- function(s) factor(ifelse(is.na(s), NA_character_, ifelse(s <= 3, "le3", as.character(s))),
                           levels = LV3)
cut4 <- function(s) factor(ifelse(is.na(s), NA_character_, ifelse(s <= 2, "le2", as.character(s))),
                           levels = c("le2", "3", "4", "5"))
ord5 <- function(s) factor(s, levels = 1:5, ordered = TRUE)
fml  <- function(response, terms) stats::reformulate(terms, response = response)
ensure_out <- function() dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)
bind_fill <- function(lst) {
  lst <- Filter(function(x) !is.null(x) && nrow(x) > 0, lst)
  if (!length(lst)) return(NULL)
  cols <- unique(unlist(lapply(lst, names)))
  do.call(rbind, lapply(lst, function(x) {
    for (cc in setdiff(cols, names(x))) x[[cc]] <- NA
    x[cols]
  }))
}
prefix_specs <- function(specs, pre) lapply(specs, function(sp) {
  for (k in intersect(c("A", "B", "id"), names(sp))) sp[[k]] <- paste0(pre, "_", sp[[k]])
  sp
})
# 最小格计数：二值 X × 因子；空表返回 0（避免 min(integer(0)) = Inf 被误判为达标）
min_cell <- function(x, f) {
  if (!length(x)) return(0L)
  tb <- table(factor(x, levels = 0:1), f)
  if (!length(tb)) 0L else min(tb)
}

# ---------------------------------------------------------------------
# 2. 数据准备（不做标准化；标准化在每个分析样本内完成）
# ---------------------------------------------------------------------
prep_data <- function(path = file.path(PKG_DIR, "data/analysis_13092.rds")) {
  d <- as.data.frame(readRDS(path), stringsAsFactors = FALSE)
  stopifnot(nrow(d) == 13092L, !anyDuplicated(d$stable_row_id))
  d$period <- as.character(d$period)
  for (v in c("self_sat_begin", "self_sat_end", "spouse_sat_begin", "spouse_sat_end"))
    stopifnot(all(d[[v]] %in% c(1:5, NA)))
  d$y0_any <- as.integer(d$support_real_begin > 0)
  d$y1_any <- as.integer(d$support_real_end > 0)
  d$y1_amt <- d$support_real_end                      # 实际元/月
  d$w_self3    <- cut3(d$self_sat_begin)
  d$w_spouse3  <- cut3(d$spouse_sat_begin)
  d$s0_self4   <- cut4(d$self_sat_begin)
  d$s0_spouse4 <- cut4(d$spouse_sat_begin)
  d$s1_self    <- ord5(d$self_sat_end)
  d$s1_spouse  <- ord5(d$spouse_sat_end)
  d$m3_self    <- cut3(d$self_sat_end)
  d$m3_spouse  <- cut3(d$spouse_sat_end)
  d$xa <- as.integer(d$x_abs)
  d$xr <- as.integer(d$x_rel)                         # 只在“基期本人收入<=配偶”时非缺失
  d$xl <- log1p(d$actor_income_real_end / 1e4) - log1p(d$actor_income_real_begin / 1e4)
  d$female <- as.integer(d$gender_begin == 0)         # CFPS：0=女
  # 端点断言（云端已用 Python 核对为 0 不一致，本机再核一次）
  xa_chk <- ifelse(is.na(d$actor_income_real_begin) | is.na(d$actor_income_real_end), NA_integer_,
                   as.integer(d$actor_income_real_end > d$actor_income_real_begin))
  stopifnot(same_or_both_na(d$xa, xa_chk))
  elig <- !is.na(d$actor_income_real_begin) & !is.na(d$partner_income_real_begin) &
    d$actor_income_real_begin <= d$partner_income_real_begin
  stopifnot(all(is.na(d$xr) | elig))
  xr_chk <- ifelse(elig, as.integer(d$actor_income_real_end > d$partner_income_real_end), NA_integer_)
  stopifnot(same_or_both_na(d$xr, xr_chk))
  stopifnot(sum(!is.na(d$xr)) == 7989L)
  d
}

covs_for <- function(drop_sat = c("self", "spouse", "both", "none"), base = COV22,
                     drop = character(0), add = "y0_any") {
  drop_sat <- match.arg(drop_sat)
  ds <- switch(drop_sat, self = "self_sat_begin", spouse = "spouse_sat_begin",
               both = c("self_sat_begin", "spouse_sat_begin"), none = character(0))
  unique(c(setdiff(base, c(ds, drop)), add))
}

analysis_sample <- function(d, vars, cluster = CLUSTER) {
  vars <- unique(c(vars, cluster))
  miss <- setdiff(vars, names(d))
  if (length(miss)) stop("缺少变量：", paste(miss, collapse = ", "))
  keep <- unique(c(vars, intersect(c("stable_row_id", "dyad_id", "period"), names(d))))
  d[stats::complete.cases(d[, vars, drop = FALSE]), keep, drop = FALSE]
}

# 数值协变量标准化：对线性项的预测和标准化对比没有影响，只为数值稳定
# （total_debts_begin 原值最高 1,015 万元，会拖慢有序 logit 的优化）。
zscale <- function(dat, vars) {
  for (v in intersect(vars, names(dat))) {
    x <- dat[[v]]
    if (is.numeric(x) && length(unique(x[!is.na(x)])) > 2L) {
      s <- stats::sd(x, na.rm = TRUE)
      if (is.finite(s) && s > 0) dat[[v]] <- (x - mean(x, na.rm = TRUE)) / s
    }
  }
  dat
}

# ---------------------------------------------------------------------
# 3. 模型与标准化对比（A/B）
# ---------------------------------------------------------------------
fit_logit <- function(f, dat) {
  m <- glm(f, family = binomial(), data = dat, control = glm.control(maxit = 100))
  if (!isTRUE(m$converged)) stop("logit 未收敛")
  if (anyNA(coef(m))) stop("logit 有 NA 系数（共线或某水平为空）")
  m
}

fit_gamma <- function(f, dat) {
  yv  <- all.vars(f[[2]])
  pos <- dat[dat[[yv]] > 0, , drop = FALSE]
  X   <- model.matrix(f, data = pos)
  st  <- c(log(mean(pos[[yv]])), rep(0, ncol(X) - 1L))
  m <- glm(f, family = Gamma(link = "log"), data = pos, start = st,
           control = glm.control(maxit = 200))
  if (!isTRUE(m$converged)) stop("Gamma 未收敛")
  if (anyNA(coef(m))) stop("Gamma 有 NA 系数")
  m
}

set_cf <- function(dat, x, xv, w = NULL, wv = NULL) {
  dat[[x]] <- rep(xv, nrow(dat))
  if (!is.null(w)) dat[[w]] <- factor(rep(wv, nrow(dat)), levels = levels(dat[[w]]))
  dat
}

# T_P(w) = mean_i[pi(x_hi,w,C_i) - pi(x_lo,w,C_i)]，按本分析样本的协变量分布平均
# d_P = T_P(5) - T_P(le3)；B 部分 g = pi * nu，d_Y 单位为实际元/月
stat_AB <- function(dat, fA, fB = NULL, x, w, x_hi = 1, x_lo = 0) {
  m1 <- fit_logit(fA, dat)
  pA <- function(xv, l) predict(m1, newdata = set_cf(dat, x, xv, w, l), type = "response")
  TP <- vapply(LV3, function(l) mean(pA(x_hi, l) - pA(x_lo, l)), numeric(1))
  out <- c(T_P_le3 = TP[["le3"]], T_P_4 = TP[["4"]], T_P_5 = TP[["5"]],
           d_P = TP[["5"]] - TP[["le3"]], d_P_5v4 = TP[["5"]] - TP[["4"]])
  if (!is.null(fB)) {
    m2 <- fit_gamma(fB, dat)
    g <- function(xv, l) {
      nd <- set_cf(dat, x, xv, w, l)
      predict(m1, newdata = nd, type = "response") * predict(m2, newdata = nd, type = "response")
    }
    TY <- vapply(LV3, function(l) mean(g(x_hi, l) - g(x_lo, l)), numeric(1))
    out <- c(out, T_Y_le3 = TY[["le3"]], T_Y_4 = TY[["4"]], T_Y_5 = TY[["5"]],
             d_Y = TY[["5"]] - TY[["le3"]], d_Y_5v4 = TY[["5"]] - TY[["4"]])
  }
  out
}

# ---------------------------------------------------------------------
# 4. 中介（C/D）：完整间接对比
#    psi(a,a') = mean_i sum_s Q(a,s,C_i) * P(S=s | a',C_i)
#    I = psi(1,1) - psi(1,0)；D = psi(1,0) - psi(0,0)；T = psi(1,1) - psi(0,0)
#    中介模型：有序 logit，五类；Y 模型中中介为三类（le3/4/5），等价于对五类求和
# ---------------------------------------------------------------------
pm_probs <- function(fit, nd, mvar, model = c("po", "ppo")) {
  model <- match.arg(model)
  if (model == "po") {
    P <- predict(fit, newdata = nd, type = "probs")
    if (is.null(dim(P))) P <- matrix(P, nrow = 1L, dimnames = list(NULL, names(P)))
  } else {
    nd[[mvar]] <- NULL                      # clm 只有在 newdata 不含结局时才返回全部类别概率
    P <- predict(fit, newdata = nd, type = "prob")$fit
    colnames(P) <- fit$y.levels
  }
  full <- matrix(0, nrow(P), 5L, dimnames = list(NULL, as.character(1:5)))
  full[, colnames(P)] <- P
  full
}

collapse3 <- function(P5) cbind(le3 = P5[, "1"] + P5[, "2"] + P5[, "3"], `4` = P5[, "4"], `5` = P5[, "5"])

stat_med <- function(dat, fM, fY, x, m3, a_hi = 1, a_lo = 0, fY2 = NULL, m_model = c("po", "ppo")) {
  m_model <- match.arg(m_model)
  mvar <- all.vars(fM[[2]])
  dat[[mvar]] <- droplevels(dat[[mvar]])    # 防止某一类在重抽样中为空
  if (m_model == "po") {
    mM <- MASS::polr(fM, data = dat, method = "logistic", Hess = FALSE, control = list(maxit = 500))
    if (!is.null(mM$convergence) && mM$convergence != 0) stop("polr 未收敛")
  } else {
    if (!requireNamespace("ordinal", quietly = TRUE)) stop("R11 需要 ordinal 包")
    fLoc <- stats::update(fM, stats::as.formula(paste(". ~ . -", x)))
    mM <- ordinal::clm(fLoc, nominal = stats::as.formula(paste("~", x)), data = dat, link = "logit")
  }
  mY <- fit_logit(fY, dat)
  m2 <- if (is.null(fY2)) NULL else fit_gamma(fY2, dat)
  P_hi <- collapse3(pm_probs(mM, set_cf(dat, x, a_hi), mvar, m_model))
  P_lo <- collapse3(pm_probs(mM, set_cf(dat, x, a_lo), mvar, m_model))
  Qmat <- function(a) vapply(LV3, function(s) {
    nd <- set_cf(dat, x, a, m3, s)
    q <- predict(mY, newdata = nd, type = "response")
    if (!is.null(m2)) q <- q * predict(m2, newdata = nd, type = "response")
    unname(q)
  }, numeric(nrow(dat)))
  Q_hi <- Qmat(a_hi)
  Q_lo <- Qmat(a_lo)
  psi <- function(Q, P) mean(rowSums(Q * P))
  p11 <- psi(Q_hi, P_hi); p10 <- psi(Q_hi, P_lo); p00 <- psi(Q_lo, P_lo)
  out <- c(indirect = p11 - p10, direct = p10 - p00, total = p11 - p00,
           b_diag = mean(Q_lo[, "5"] - Q_lo[, "le3"]))      # 路径诊断，不作资格门槛
  if (m_model == "po") out <- c(out, a_logOR = unname(coef(mM)[x]))
  out
}

# ---------------------------------------------------------------------
# 5. 整簇 bootstrap：事先生成的全局抽样计划，所有检验共用
# ---------------------------------------------------------------------
make_plan <- function(ids, B, seed) {
  ids <- sort(unique(ids))
  set.seed(seed, kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
  draws <- matrix(sample.int(length(ids), length(ids) * B, replace = TRUE), ncol = B)
  list(ids = ids, draws = draws, B = B, seed = seed)
}

make_or_load_plan <- function(d, B, seed, file) {
  ensure_out()
  f <- file.path(OUT_DIR, file)
  if (file.exists(f)) {
    p <- readRDS(f)
    stopifnot(p$B == B, p$seed == seed)
    return(p)
  }
  p <- make_plan(d[[CLUSTER]], B, seed)
  saveRDS(p, f)
  p
}

# 子样本（XR 风险集、三波链）沿用同一计划：抽到的簇若不在子样本中则贡献 0 行
run_boot <- function(dat, plan, stat_fun, cores = N_CORES, cluster = CLUSTER) {
  gi <- match(dat[[cluster]], plan$ids)
  if (anyNA(gi)) stop("样本中有簇不在抽样计划里")
  rows_by <- split(seq_len(nrow(dat)), factor(gi, levels = seq_along(plan$ids)))
  one <- function(b) {
    rows <- unlist(rows_by[plan$draws[, b]], use.names = FALSE)
    if (!length(rows)) return(list(ok = FALSE, err = "空样本"))
    r <- tryCatch(stat_fun(dat[rows, , drop = FALSE]), error = function(e) e)
    if (inherits(r, "error")) return(list(ok = FALSE, err = conditionMessage(r)))
    if (!all(is.finite(r))) return(list(ok = FALSE, err = "非有限值"))
    list(ok = TRUE, val = r)
  }
  res <- if (cores > 1L) parallel::mclapply(seq_len(plan$B), one, mc.cores = cores) else lapply(seq_len(plan$B), one)
  ok  <- vapply(res, function(z) is.list(z) && isTRUE(z$ok), logical(1))
  mat <- if (any(ok)) do.call(rbind, lapply(res[ok], `[[`, "val")) else NULL
  if (!is.null(mat)) rownames(mat) <- which(ok)
  err <- vapply(res[!ok], function(z) if (is.list(z) && !is.null(z$err)) z$err else "子进程失败", character(1))
  list(mat = mat, ok_idx = which(ok), fail_idx = which(!ok), fail_msg = err, B = plan$B)
}

# p = (1 + #{|t_b - t0| >= |t0|}) / (B_valid + 1)（与 150 项历史筛选同一公式）
# 主 CI = t0 ± q95(|t_b - t0|)：与 p 来自同一中心化分布；百分位 CI 只看形状
summ_boot <- function(est, bt, name) {
  t0 <- unname(est[[name]])
  if (is.null(bt$mat) || !(name %in% colnames(bt$mat))) stop("没有有效重复：", name)
  tb  <- bt$mat[, name]
  dev <- abs(tb - t0)
  q   <- unname(stats::quantile(dev, 0.95, type = 7))
  nv  <- length(tb)
  data.frame(estimand = name, estimate = t0, se_boot = stats::sd(tb),
             ci_low = t0 - q, ci_high = t0 + q,
             pct_low = unname(stats::quantile(tb, 0.025)), pct_high = unname(stats::quantile(tb, 0.975)),
             p_raw = (1 + sum(dev >= abs(t0))) / (nv + 1),
             n_valid = nv, B = bt$B, valid_share = nv / bt$B,
             boot_flag = if (nv / bt$B < 0.98) "有效重复<98%" else "",
             stringsAsFactors = FALSE)
}

# ---------------------------------------------------------------------
# 6. 预定对照：影响函数（Delta）标准误（R8）与线性概率模型（R5）
#    影响函数同时计入系数估计误差和“按样本协变量分布平均”的变异，并按簇汇总
# ---------------------------------------------------------------------
if_dP_logit <- function(m, dat, x, w, x_hi = 1, x_lo = 0, hi = "5", lo = "le3", cluster = CLUSTER) {
  tt <- delete.response(terms(m))
  b  <- coef(m)
  Xof <- function(nd) model.matrix(tt, model.frame(tt, nd, xlev = m$xlevels), contrasts.arg = m$contrasts)
  parts <- list(list(xv = x_hi, wl = hi, s = 1), list(xv = x_lo, wl = hi, s = -1),
                list(xv = x_hi, wl = lo, s = -1), list(xv = x_lo, wl = lo, s = 1))
  n <- nrow(dat); h <- numeric(n); G <- numeric(length(b))
  for (p in parts) {
    Xc <- Xof(set_cf(dat, x, p$xv, w, p$wl))
    stopifnot(identical(colnames(Xc), names(b)))
    pr <- plogis(drop(Xc %*% b))
    h  <- h + p$s * pr
    G  <- G + p$s * colMeans(Xc * (pr * (1 - pr)))
  }
  theta <- mean(h)
  X  <- model.matrix(m); mu <- fitted(m); y <- m$y
  stopifnot(nrow(X) == n)
  S   <- X * (y - mu)
  A   <- crossprod(X, X * (mu * (1 - mu)))
  phi <- (h - theta) / n + drop(S %*% solve(A, G))
  pg  <- rowsum(phi, dat[[cluster]])
  Gc  <- nrow(pg)
  se  <- sqrt(sum(pg^2) * Gc / (Gc - 1))
  data.frame(estimand = "d_P", estimate = theta, se_if = se,
             ci_low = theta - 1.959964 * se, ci_high = theta + 1.959964 * se,
             p_if = 2 * pnorm(-abs(theta / se)), stringsAsFactors = FALSE)
}

lpm_dP <- function(f, dat, x, w, hi = "5", cluster = CLUSTER) {
  if (!requireNamespace("sandwich", quietly = TRUE)) stop("R5 需要 sandwich 包")
  m  <- lm(f, data = dat)
  nm <- paste0(x, ":", w, hi)
  if (!nm %in% names(coef(m))) nm <- paste0(w, hi, ":", x)
  V  <- sandwich::vcovCL(m, cluster = dat[[cluster]], type = "HC1")
  est <- unname(coef(m)[nm]); se <- sqrt(V[nm, nm])
  data.frame(estimand = "d_P_LPM", estimate = est, se_cl = se,
             ci_low = est - 1.959964 * se, ci_high = est + 1.959964 * se,
             p_cl = 2 * pnorm(-abs(est / se)), stringsAsFactors = FALSE)
}

# ---------------------------------------------------------------------
# 7. 派生数据：三波链、actor-period 汇总、msateco
# ---------------------------------------------------------------------
build_threewave <- function(d) {
  p1 <- d[d$period == "2018-2020", , drop = FALSE]
  p2 <- d[d$period == "2020-2022", c("dyad_id", "support_real_end", "self_sat_begin", "spouse_sat_begin"), drop = FALSE]
  names(p2) <- c("dyad_id", "support_2022", "self_sat_2020_chk", "spouse_sat_2020_chk")
  stopifnot(!anyDuplicated(p1$dyad_id), !anyDuplicated(p2$dyad_id))
  w <- merge(p1, p2, by = "dyad_id", sort = FALSE)
  stopifnot(nrow(w) == 4564L,
            all(w$self_sat_end == w$self_sat_2020_chk, na.rm = TRUE),
            all(w$spouse_sat_end == w$spouse_sat_2020_chk, na.rm = TRUE))
  w$y2020_any <- as.integer(w$support_real_end > 0)    # X 区间内，处理后，只用于 R10
  w$y2020_ihs <- asinh(w$support_real_end)
  w$y1_any <- as.integer(w$support_2022 > 0)            # 结局：2022 年是否给
  w$y1_amt <- w$support_2022
  w                                                     # y0_any 与 baseline_support_ihs 仍是 2018 年值
}
covs_D <- function(drop_sat, base = COV22) setdiff(covs_for(drop_sat, base = base), "period_fe")

PARENT_VARS <- c("prtmarr_begin", "prtcor_begin", "prtgender_begin", "prtage_begin", "prtedu_begin")
AGG_VARS    <- c("n_parents", "prtage_mean", "prtcor_any", "prtmarr_any", "prtedu_max")
build_actor_period <- function(d) {
  key <- paste(d$actor_pid_begin, d$period)
  g   <- split(seq_len(nrow(d)), key)
  actor_vars <- c("period", "period_fe", CLUSTER, "xa", "xr", "xl", "female", "gender_begin", "aage_begin",
                  "actor_edu2_begin", "actor_siops_begin", "child_begin", "ahw_begin", "ahk_begin",
                  "total_debts_begin", "qp201_actor_begin", "fmlincc_begin", "lifetime_begin",
                  "baseline_actor_income_ihs", "baseline_partner_income_ihs", "self_sat_begin",
                  "spouse_sat_begin", "dwm_begin")
  for (v in actor_vars) {
    same <- vapply(g, function(ix) length(unique(d[[v]][ix])) == 1L, logical(1))
    if (!all(same)) warning("actor 层变量在父母两行间不一致：", v, "（", sum(!same), " 组），取第一行")
  }
  first <- vapply(g, function(ix) ix[1L], integer(1))
  a <- d[first, actor_vars, drop = FALSE]
  sum_na <- function(x) if (anyNA(x)) NA_real_ else sum(x)
  a$y1_amt <- vapply(g, function(ix) sum_na(d$support_real_end[ix]), numeric(1))
  a$y0_amt <- vapply(g, function(ix) sum_na(d$support_real_begin[ix]), numeric(1))
  a$y1_any <- as.integer(a$y1_amt > 0)
  a$y0_any <- as.integer(a$y0_amt > 0)
  a$baseline_support_ihs <- asinh(a$y0_amt)
  a$w_self3   <- cut3(a$self_sat_begin)
  a$w_spouse3 <- cut3(a$spouse_sat_begin)
  a$n_parents   <- lengths(g)
  a$prtage_mean <- vapply(g, function(ix) mean(d$prtage_begin[ix]), numeric(1))
  a$prtcor_any  <- vapply(g, function(ix) max(d$prtcor_begin[ix]), numeric(1))
  a$prtmarr_any <- vapply(g, function(ix) max(d$prtmarr_begin[ix]), numeric(1))
  a$prtedu_max  <- vapply(g, function(ix) max(d$prtedu_begin[ix]), numeric(1))
  rownames(a) <- NULL
  stopifnot(nrow(a) == 8196L)
  a
}
covs_R4 <- function(drop_sat, base = COV22) unique(c(setdiff(covs_for(drop_sat, base = base), PARENT_VARS), AGG_VARS))

# 第 0 步：从 v6 的上游长表（predata_FE_16_22_unbal.dta）提取 msateco 原始 1–5 分。
# 注意：旧 Stata 流程（20240619 do 文件第 6796–6800 行）曾把 msat/msateco 改写成年内百分位；
# identity_target_13092.rds 里的 msateco_c1/c2 就是百分位版本，不能用。
extract_msateco <- function(raw_dta = Sys.getenv("CMA_PREDATA"),
                            out = file.path(PKG_DIR, "data/msateco_intervals.csv")) {
  if (!requireNamespace("haven", quietly = TRUE)) stop("需要 haven 包")
  raw <- as.data.frame(haven::read_dta(raw_dta, col_select = c("pid", "year", "msateco_c1_", "msateco_c2_")))
  nn  <- function(x) { x <- as.numeric(haven::zap_labels(x)); x[!is.na(x) & x < 0] <- NA_real_; x }
  raw$year <- nn(raw$year)
  raw <- raw[raw$year %in% c(2018, 2020, 2022), , drop = FALSE]
  raw$e1 <- nn(raw$msateco_c1_)     # 本人对配偶收入的满意度
  raw$e2 <- nn(raw$msateco_c2_)     # 配偶对本人收入的满意度（C3/C4 的中介）
  bad <- setdiff(unique(c(raw$e1, raw$e2)), c(1:5, NA))
  if (length(bad)) stop("msateco 不是 1–5 原始分（可能是百分位版本）：", paste(head(bad), collapse = ", "))
  raw$dyad_id <- sprintf("%.0f", nn(raw$pid))
  stopifnot(!anyDuplicated(paste(raw$dyad_id, raw$year)))
  getv <- function(yr, v) { s <- raw[raw$year == yr, , drop = FALSE]; stats::setNames(s[[v]], s$dyad_id) }
  mk <- function(b, e) {
    ids <- union(names(getv(b, "e1")), names(getv(e, "e1")))
    data.frame(dyad_id = ids, period = paste0(b, "-", e),
               eco_self_begin = unname(getv(b, "e1")[ids]), eco_self_end = unname(getv(e, "e1")[ids]),
               eco_spouse_begin = unname(getv(b, "e2")[ids]), eco_spouse_end = unname(getv(e, "e2")[ids]),
               stringsAsFactors = FALSE)
  }
  res <- rbind(mk(2018, 2020), mk(2020, 2022))
  utils::write.csv(res, out, row.names = FALSE, na = "NA")
  invisible(res)
}

add_msateco <- function(d, path = file.path(PKG_DIR, "data/msateco_intervals.csv")) {
  e <- utils::read.csv(path, stringsAsFactors = FALSE, colClasses = c(dyad_id = "character", period = "character"))
  need <- c("eco_self_begin", "eco_self_end", "eco_spouse_begin", "eco_spouse_end")
  stopifnot(all(need %in% names(e)), !anyDuplicated(paste(e$dyad_id, e$period)))
  for (v in need) stopifnot(all(e[[v]] %in% c(1:5, NA)))
  k <- match(paste(d$dyad_id, d$period), paste(e$dyad_id, e$period))
  attr(d, "msateco_row_match") <- mean(!is.na(k))
  for (v in need) d[[v]] <- e[[v]][k]
  d$s1_eco_sp  <- ord5(d$eco_spouse_end)
  d$m3_eco_sp  <- cut3(d$eco_spouse_end)
  d$s0_eco_sp4 <- cut4(d$eco_spouse_begin)
  d
}

# 配偶对接校验：行 (A,P) 的“配偶评分”应等于行 (P,A) 的“本人评分”
link_check <- function(d, spouse_b, spouse_e, self_b, self_e, label) {
  key_self <- paste(d$actor_pid_begin, d$partner_pid_begin, d$period)
  key_rev  <- paste(d$partner_pid_begin, d$actor_pid_begin, d$period)
  j   <- match(key_rev, key_self)
  has <- !is.na(j)
  data.frame(check = label, linked_rows = sum(has),
             mismatch_begin = sum(d[[spouse_b]][has] != d[[self_b]][j[has]], na.rm = TRUE),
             mismatch_end   = sum(d[[spouse_e]][has] != d[[self_e]][j[has]], na.rm = TRUE),
             stringsAsFactors = FALSE)
}

# ---------------------------------------------------------------------
# 8. 检验定义（与 test_registry_v4.csv 一一对应）
# ---------------------------------------------------------------------
AB_SPECS <- list(
  list(A = "A1", B = "B1", x = "xa", w = "w_self3",   drop = "self"),
  list(A = "A2", B = "B2", x = "xa", w = "w_spouse3", drop = "spouse"),
  list(A = "A3", B = "B3", x = "xr", w = "w_self3",   drop = "self"),
  list(A = "A4", B = "B4", x = "xr", w = "w_spouse3", drop = "spouse")
)
C_SPECS <- list(
  list(id = "C1", x = "xa", s1 = "s1_self",   m3 = "m3_self",   s0 = "s0_self4",   drop = "self"),
  list(id = "C2", x = "xa", s1 = "s1_spouse", m3 = "m3_spouse", s0 = "s0_spouse4", drop = "spouse"),
  list(id = "C3", x = "xa", s1 = "s1_eco_sp", m3 = "m3_eco_sp", s0 = "s0_eco_sp4", drop = "none"),
  list(id = "C4", x = "xr", s1 = "s1_eco_sp", m3 = "m3_eco_sp", s0 = "s0_eco_sp4", drop = "none")
)
D_SPECS <- list(
  list(id = "D1", x = "xa", s1 = "s1_self",   m3 = "m3_self",   s0 = "s0_self4",   drop = "self"),
  list(id = "D2", x = "xa", s1 = "s1_spouse", m3 = "m3_spouse", s0 = "s0_spouse4", drop = "spouse")
)
# 备用：只有第 0 步判定 msateco 不可用时才启用，替补 C3/C4 的两个名额
D_RESERVE <- list(
  list(A = "D3", x = "xa", w = "w_self3",   drop = "self"),
  list(A = "D4", x = "xa", w = "w_spouse3", drop = "spouse")
)

run_AB_specs <- function(specs, base, plan, covs_fun = covs_for, tag, with_B = TRUE,
                         yA = "y1_any", yB = "y1_amt", x_hi = 1, x_lo = 0,
                         extra_est = c("d_P_5v4", "T_P_le3", "T_P_4", "T_P_5"), cores = N_CORES) {
  rows <- list()
  for (sp in specs) {
    covs <- covs_fun(sp$drop)
    rhs  <- c(covs, paste(sp$x, "*", sp$w))
    fA   <- fml(yA, rhs)
    fB   <- if (with_B) fml(yB, rhs) else NULL
    dat  <- zscale(analysis_sample(base, unique(c(all.vars(fA), if (with_B) yB))), covs)
    sfun <- function(z) stat_AB(z, fA, fB, sp$x, sp$w, x_hi = x_hi, x_lo = x_lo)
    pos_ok <- if (all(dat[[sp$x]] %in% 0:1)) min_cell(dat[[sp$x]], dat[[sp$w]]) >= 100 else NA
    est  <- sfun(dat)
    bt   <- run_boot(dat, plan, sfun, cores = cores)
    n_cl <- length(unique(dat[[CLUSTER]]))
    saveRDS(list(spec = sp, fA = fA, fB = fB, est = est, boot = bt, n = nrow(dat), n_cl = n_cl,
                 x_hi = x_hi, x_lo = x_lo, positivity_ok = pos_ok),
            file.path(OUT_DIR, sprintf("%s_%s.rds", tag, sp$A)))
    one_row <- function(id, nm) cbind(test_id = id, tag = tag, n = nrow(dat), n_cl = n_cl,
                                      positivity_ok = pos_ok, summ_boot(est, bt, nm))
    for (nm in c("d_P", extra_est)) rows[[length(rows) + 1L]] <- one_row(sp$A, nm)
    if (with_B) for (nm in sub("_P", "_Y", c("d_P", extra_est), fixed = TRUE))
      rows[[length(rows) + 1L]] <- one_row(sp$B, nm)
  }
  do.call(rbind, rows)
}

run_med <- function(specs, base, plan, covs_fun, tag, y_type = c("binary", "twopart"),
                    m_model = c("po", "ppo"), extra_y = character(0), cores = N_CORES) {
  y_type <- match.arg(y_type); m_model <- match.arg(m_model)
  rows <- list()
  for (sp in specs) {
    covs <- covs_fun(sp$drop)
    fM   <- fml(sp$s1, c(sp$x, sp$s0, covs))
    rhsY <- c(paste(sp$x, "*", sp$m3), sp$s0, covs, extra_y)
    fY   <- fml("y1_any", rhsY)
    fY2  <- if (y_type == "twopart") fml("y1_amt", rhsY) else NULL
    vars <- unique(c(all.vars(fM), all.vars(fY), if (!is.null(fY2)) all.vars(fY2)))
    dat  <- zscale(analysis_sample(base, vars), c(covs, extra_y))
    pos_min <- min_cell(dat[[sp$x]], dat[[sp$m3]])
    sfun <- function(z) stat_med(z, fM, fY, sp$x, sp$m3, fY2 = fY2, m_model = m_model)
    est  <- sfun(dat)
    bt   <- run_boot(dat, plan, sfun, cores = cores)
    n_cl <- length(unique(dat[[CLUSTER]]))
    saveRDS(list(spec = sp, fM = fM, fY = fY, fY2 = fY2, est = est, boot = bt, n = nrow(dat),
                 n_cl = n_cl, positivity_min_xm = pos_min),
            file.path(OUT_DIR, sprintf("%s_%s.rds", tag, sp$id)))
    for (nm in intersect(c("indirect", "direct", "total", "a_logOR", "b_diag"), names(est)))
      rows[[length(rows) + 1L]] <- cbind(test_id = sp$id, tag = tag, n = nrow(dat), n_cl = n_cl,
                                         positivity_ok = pos_min >= 30, summ_boot(est, bt, nm))
  }
  do.call(rbind, rows)
}

# ---------------------------------------------------------------------
# 9. 次级族 S（单独 BH，n = 4；S2–S4 为数据启发）
# ---------------------------------------------------------------------
stat_S1 <- function(dat, f) {                 # 角色对比：联合模型中本人与配偶两个修饰对比之差
  m <- fit_logit(f, dat)
  Tw <- function(w, l) mean(predict(m, set_cf(dat, "xa", 1, w, l), type = "response") -
                              predict(m, set_cf(dat, "xa", 0, w, l), type = "response"))
  d_self   <- Tw("w_self3", "5") - Tw("w_self3", "le3")
  d_spouse <- Tw("w_spouse3", "5") - Tw("w_spouse3", "le3")
  c(S1 = d_self - d_spouse, d_self_joint = d_self, d_spouse_joint = d_spouse)
}
stat_S2 <- function(dat, f) {                 # 世系：XA 总效应，女儿减儿子（各自分层拟合、分层标准化）
  tf <- function(sub) {
    m <- fit_logit(f, sub)
    mean(predict(m, set_cf(sub, "xa", 1), type = "response") - predict(m, set_cf(sub, "xa", 0), type = "response"))
  }
  tF <- tf(dat[dat$female == 1L, , drop = FALSE]); tM <- tf(dat[dat$female == 0L, , drop = FALSE])
  c(S2 = tF - tM, T_female = tF, T_male = tM)
}
stat_S34 <- function(dat, f, w) {             # 世系：A1/A2 型修饰对比，女儿减儿子
  dF <- stat_AB(dat[dat$female == 1L, , drop = FALSE], f, NULL, "xa", w)[["d_P"]]
  dM <- stat_AB(dat[dat$female == 0L, , drop = FALSE], f, NULL, "xa", w)[["d_P"]]
  c(diff = dF - dM, d_female = dF, d_male = dM)
}

# ---------------------------------------------------------------------
# 10. 中介检验的合成数据校准（在看 C/D 真实结果之前运行）
#     a0：中介模型去掉 X（a=0），Y 模型用实际拟合；b0：中介模型用实际拟合，Y 模型去掉中介（b=0）
# ---------------------------------------------------------------------
calib_med <- function(dat, fM, fY, x, m3, scenario = c("a0", "b0"), R = 200L, B = 99L,
                      seed = SEED_CAL, cores = N_CORES) {
  scenario <- match.arg(scenario)
  mvar <- all.vars(fM[[2]]); yvar <- all.vars(fY[[2]])
  dat[[mvar]] <- droplevels(dat[[mvar]])    # 生成模型同样去掉空类；pm_probs 会补回五列
  if (scenario == "a0") {
    gen_M <- MASS::polr(stats::update(fM, stats::as.formula(paste(". ~ . -", x))), data = dat,
                        method = "logistic", Hess = FALSE, control = list(maxit = 500))
    gen_Y <- fit_logit(fY, dat)
  } else {
    gen_M <- MASS::polr(fM, data = dat, method = "logistic", Hess = FALSE, control = list(maxit = 500))
    gen_Y <- fit_logit(stats::update(fY, stats::as.formula(paste(". ~ . -", m3, "-", paste0(x, ":", m3)))), dat)
  }
  cumP <- t(apply(pm_probs(gen_M, dat, mvar, "po"), 1, cumsum))
  ids  <- sort(unique(dat[[CLUSTER]]))
  one <- function(r) tryCatch({
    set.seed(seed + r)
    u  <- runif(nrow(dat))
    s1 <- pmin(5L, 1L + as.integer(rowSums(u > cumP)))
    z  <- dat
    z[[mvar]] <- ord5(s1)
    z[[m3]]   <- cut3(s1)
    z[[yvar]] <- rbinom(nrow(z), 1L, predict(gen_Y, newdata = z, type = "response"))
    est <- stat_med(z, fM, fY, x, m3)
    bt  <- run_boot(z, make_plan(ids, B, seed + 100000L + r), function(q) stat_med(q, fM, fY, x, m3), cores = 1L)
    c(r = r, ok = 1, p = summ_boot(est, bt, "indirect")$p_raw)
  }, error = function(e) c(r = r, ok = 0, p = NA_real_))
  res <- if (cores > 1L) parallel::mclapply(seq_len(R), one, mc.cores = cores) else lapply(seq_len(R), one)
  res <- do.call(rbind, lapply(res, function(v) if (is.numeric(v) && length(v) == 3L) v else c(r = NA, ok = 0, p = NA)))
  ok   <- res[, "ok"] == 1
  rate <- mean(res[ok, "p"] <= 0.05)
  mcse <- sqrt(0.05 * 0.95 / max(1L, sum(ok)))
  list(scenario = scenario, R_ok = sum(ok), reject_rate = rate, threshold = 0.05 + 2 * mcse,
       flag = if (rate > 0.05 + 2 * mcse) "可能偏宽松：报告中加注" else "未见偏宽松",
       detail = res)
}

# ---------------------------------------------------------------------
# 11. 自检（只用合成数据）。全部 PASS 之前不要碰真实数据。
# ---------------------------------------------------------------------
self_test <- function(n = 20000L, B = 40L, seed = 7L, cores = N_CORES) {
  ok_all <- TRUE
  report <- function(name, pass, detail = "") {
    cat(sprintf("[%s] %s %s\n", if (isTRUE(pass)) "PASS" else "FAIL", name, detail))
    if (!isTRUE(pass)) ok_all <<- FALSE
  }
  set.seed(seed)
  cl  <- rep(seq_len(ceiling(n / 4)), each = 4L)[seq_len(n)]
  c1  <- rnorm(n); c2 <- rbinom(n, 1, 0.5)
  xa  <- rbinom(n, 1, plogis(0.2 * c1))
  s0  <- sample(1:5, n, replace = TRUE, prob = c(0.01, 0.015, 0.10, 0.20, 0.675))
  sp0 <- sample(1:5, n, replace = TRUE, prob = c(0.01, 0.015, 0.10, 0.20, 0.675))
  female <- rbinom(n, 1, 0.5)
  w3 <- cut3(s0); wsp3 <- cut3(sp0)

  # (1) A/B：已知真值
  etaA <- function(x, w) -0.3 + 0.4 * c1 - 0.2 * c2 + 0.3 * x + 0.2 * (w == "4") + 0.1 * (w == "5") -
    0.1 * x * (w == "4") - 0.5 * x * (w == "5")
  muB  <- function(x, w) exp(5 + 0.2 * c1 + 0.3 * x + 0.1 * (w == "5") - 0.2 * x * (w == "5"))
  y   <- rbinom(n, 1, plogis(etaA(xa, w3)))
  amt <- ifelse(y == 1, rgamma(n, shape = 1.5, rate = 1.5 / muB(xa, w3)), 0)
  T_P <- function(l) mean(plogis(etaA(1, l)) - plogis(etaA(0, l)))
  T_Y <- function(l) mean(plogis(etaA(1, l)) * muB(1, l) - plogis(etaA(0, l)) * muB(0, l))
  true_dP <- T_P("5") - T_P("le3"); true_dY <- T_Y("5") - T_Y("le3")
  dat <- data.frame(unified_component = cl, c1 = c1, c2 = c2, xa = xa, w_self3 = w3, w_spouse3 = wsp3,
                    female = female, y1_any = y, y1_amt = amt)
  fA <- y1_any ~ c1 + c2 + xa * w_self3
  fB <- y1_amt ~ c1 + c2 + xa * w_self3
  est <- stat_AB(dat, fA, fB, "xa", "w_self3")
  bt  <- run_boot(dat, make_plan(dat$unified_component, B, seed + 1L),
                  function(z) stat_AB(z, fA, fB, "xa", "w_self3"), cores = cores)
  sP <- summ_boot(est, bt, "d_P"); sY <- summ_boot(est, bt, "d_Y")
  report("A：d_P 回收真值", abs(sP$estimate - true_dP) < 4 * sP$se_boot,
         sprintf("est=%.4f true=%.4f se=%.4f", sP$estimate, true_dP, sP$se_boot))
  report("B：d_Y 回收真值", abs(sY$estimate - true_dY) < 4 * sY$se_boot,
         sprintf("est=%.2f true=%.2f se=%.2f", sY$estimate, true_dY, sY$se_boot))
  report("bootstrap 有效重复", sP$n_valid >= B - 1L, sprintf("%d/%d", sP$n_valid, B))
  report("主 CI 与 p 一致", (sP$p_raw <= 0.05) == (sP$ci_low > 0 | sP$ci_high < 0) || abs(sP$p_raw - 0.05) < 0.03,
         sprintf("p=%.3f CI=[%.4f, %.4f]", sP$p_raw, sP$ci_low, sP$ci_high))
  m1  <- fit_logit(fA, dat)
  ifr <- if_dP_logit(m1, dat, "xa", "w_self3")
  report("R8：影响函数点估计 = 标准化点估计", abs(ifr$estimate - sP$estimate) < 1e-8)
  report("R8：影响函数 SE 与 bootstrap SE 同量级", ifr$se_if / sP$se_boot > 0.6 && ifr$se_if / sP$se_boot < 1.6,
         sprintf("if=%.4f boot=%.4f", ifr$se_if, sP$se_boot))
  if (requireNamespace("sandwich", quietly = TRUE)) {
    lp <- lpm_dP(fA, dat, "xa", "w_self3")
    report("R5：LPM 可运行", is.finite(lp$estimate) && is.finite(lp$se_cl))
  } else report("R5：未安装 sandwich", FALSE)

  # (2) 中介：已知真值
  zeta <- c(-4.0, -3.2, -1.6, -0.1)                  # logit P(S<=k) = zeta_k - eta
  etaM <- function(x) 0.5 * x + 0.4 * (s0 == 4) + 0.9 * (s0 == 5) + 0.3 * c1
  pS   <- function(x) { cum <- sapply(zeta, function(z) plogis(z - etaM(x))); cbind(cum, 1) - cbind(0, cum) }
  u    <- runif(n)
  s1   <- pmin(5L, 1L + as.integer(rowSums(u > t(apply(pS(xa), 1, cumsum)))))
  etaY <- function(x, m) -0.8 + 0.3 * c1 + 0.2 * x + 0.5 * (m == "4") + 0.7 * (m == "5") + 0.2 * (s0 == 5)
  m3   <- cut3(s1)
  ym   <- rbinom(n, 1, plogis(etaY(xa, m3)))
  Qk   <- sapply(1:5, function(k) plogis(etaY(1, if (k <= 3) "le3" else as.character(k))))
  true_ind <- mean(rowSums(Qk * (pS(1) - pS(0))))
  dm <- data.frame(unified_component = cl, c1 = c1, xa = xa, s1_self = ord5(s1), m3_self = m3,
                   s0_self4 = cut4(s0), y1_any = ym)
  fM <- s1_self ~ xa + s0_self4 + c1
  fY <- y1_any ~ xa * m3_self + s0_self4 + c1
  estm <- stat_med(dm, fM, fY, "xa", "m3_self")
  btm  <- run_boot(dm, make_plan(dm$unified_component, B, seed + 2L),
                   function(z) stat_med(z, fM, fY, "xa", "m3_self"), cores = cores)
  sI <- summ_boot(estm, btm, "indirect"); sa <- summ_boot(estm, btm, "a_logOR")
  report("C：间接对比回收真值", abs(sI$estimate - true_ind) < 4 * sI$se_boot,
         sprintf("est=%.5f true=%.5f se=%.5f", sI$estimate, true_ind, sI$se_boot))
  report("C：a 路径 logOR 回收 0.5", abs(sa$estimate - 0.5) < 4 * sa$se_boot,
         sprintf("est=%.3f se=%.3f", sa$estimate, sa$se_boot))
  if (requireNamespace("ordinal", quietly = TRUE)) {
    ep <- tryCatch(stat_med(dm, fM, fY, "xa", "m3_self", m_model = "ppo"), error = function(e) NULL)
    report("R11：部分比例优势中介模型可运行", !is.null(ep) && all(is.finite(ep)))
  } else report("R11：未安装 ordinal", FALSE)

  # (3) 次级族、校准、多重比较的冒烟测试
  report("S1 可运行", all(is.finite(stat_S1(dat, y1_any ~ c1 + c2 + xa * w_self3 + xa * w_spouse3))))
  report("S2 可运行", all(is.finite(stat_S2(dat, y1_any ~ c1 + c2 + xa))))
  report("S3/S4 可运行", all(is.finite(stat_S34(dat, fA, "w_self3"))))
  cal <- calib_med(dm[seq_len(4000), ], fM, fY, "xa", "m3_self", "a0", R = 2L, B = 9L, cores = 1L)
  report("校准函数可运行", cal$R_ok >= 1L, sprintf("R_ok=%d", cal$R_ok))
  report("p.adjust(n=14) 按预期", isTRUE(all.equal(p.adjust(c(0.001, 0.02), "BH", n = 14), c(0.014, 0.14))))
  if (!ok_all) stop("self_test 未全部通过：先修代码，不要运行真实数据。")
  cat("self_test 全部通过。\n")
  invisible(TRUE)
}

# 计时：真实协变量 + 合成结局，不看真实结局
time_test <- function(d, B = 20L, cores = N_CORES) {
  if (is.null(COV22)) load_covariates()
  set.seed(99)
  z <- d
  z$y1_any <- rbinom(nrow(z), 1, 0.45)
  z$y1_amt <- ifelse(z$y1_any == 1, rgamma(nrow(z), 1.2, 1.2 / 300), 0)
  plan <- make_plan(z[[CLUSTER]], B, 1L)
  sp <- AB_SPECS[[1]]; covs <- covs_for(sp$drop)
  fA <- fml("y1_any", c(covs, paste(sp$x, "*", sp$w))); fB <- fml("y1_amt", c(covs, paste(sp$x, "*", sp$w)))
  dat <- zscale(analysis_sample(z, c(all.vars(fA), "y1_amt")), covs)
  tAB <- system.time(run_boot(dat, plan, function(q) stat_AB(q, fA, fB, sp$x, sp$w), cores = cores))[["elapsed"]]
  cs <- C_SPECS[[1]]; covs <- covs_for(cs$drop)
  fM <- fml(cs$s1, c(cs$x, cs$s0, covs)); fY <- fml("y1_any", c(paste(cs$x, "*", cs$m3), cs$s0, covs))
  datm <- zscale(analysis_sample(z, unique(c(all.vars(fM), all.vars(fY)))), covs)
  tC <- system.time(run_boot(datm, plan, function(q) stat_med(q, fM, fY, cs$x, cs$m3), cores = cores))[["elapsed"]]
  per_AB <- tAB / B; per_C <- tC / B
  main_min <- (4 * per_AB + 4 * per_C + 2 * 0.4 * per_C + 4 * per_AB) * B_MAIN / 60
  cal_min  <- 3 * 200 * 100 * per_C / 60
  cat(sprintf("每次重复（%d 核墙钟）：A/B %.2f 秒，C %.2f 秒。\n主估计与次级族约 %.0f 分钟；校准约 %.0f 分钟。\n",
              cores, per_AB, per_C, main_min, cal_min))
  invisible(c(per_AB = per_AB, per_C = per_C, main_min = main_min, cal_min = cal_min))
}

# ---------------------------------------------------------------------
# 12. 分步驱动
# ---------------------------------------------------------------------
# 第 0 步：只输出计数、达标与否和数据核查；不输出任何 X×W 或 X×M 的结局比较
step0_checks <- function(d, msateco_path = file.path(PKG_DIR, "data/msateco_intervals.csv")) {
  ensure_out()
  if (is.null(COV22)) load_covariates()
  # (1) 样本流与支持（A/B）
  flow <- list(); posi <- list()
  for (sp in AB_SPECS) {
    covs <- covs_for(sp$drop)
    s <- analysis_sample(d, c(sp$x, sp$w, "y1_any", "y1_amt", covs))
    flow[[sp$A]] <- data.frame(tests = paste(sp$A, sp$B, sep = "/"), universe = nrow(d),
      has_x = sum(!is.na(d[[sp$x]])), has_x_w = sum(!is.na(d[[sp$x]]) & !is.na(d[[sp$w]])),
      has_x_w_y = sum(!is.na(d[[sp$x]]) & !is.na(d[[sp$w]]) & !is.na(d$y1_amt)),
      complete = nrow(s), clusters = length(unique(s[[CLUSTER]])), stringsAsFactors = FALSE)
    tab <- table(s[[sp$x]], s[[sp$w]])
    pos <- s[s$y1_any == 1L, , drop = FALSE]
    min_pos <- min(table(factor(pos[[sp$x]], levels = 0:1), pos[[sp$w]]))
    posi[[sp$A]] <- data.frame(tests = paste(sp$A, sp$B, sep = "/"), min_cell_rows = min(tab),
      cells_ge_100 = all(tab >= 100), min_cell_positive_ge_30 = min_pos >= 30, stringsAsFactors = FALSE)
    utils::write.csv(as.data.frame(tab), file.path(OUT_DIR, sprintf("step0_cells_%s.csv", sp$A)), row.names = FALSE)
  }
  w <- build_threewave(d)
  for (sp in D_SPECS) {
    covs <- covs_D(sp$drop)
    s <- analysis_sample(w, c(sp$x, sp$s1, sp$m3, sp$s0, "y1_any", covs))
    flow[[sp$id]] <- data.frame(tests = sp$id, universe = nrow(w), has_x = sum(!is.na(w[[sp$x]])),
      has_x_w = NA, has_x_w_y = NA, complete = nrow(s), clusters = length(unique(s[[CLUSTER]])),
      stringsAsFactors = FALSE)
    posi[[sp$id]] <- data.frame(tests = sp$id, min_cell_rows = NA, cells_ge_100 = NA,
      min_cell_positive_ge_30 = NA, xm_min_ge_30 = min_cell(s[[sp$x]], s[[sp$m3]]) >= 30,
      chain_ge_2000 = nrow(s) >= 2000, stringsAsFactors = FALSE)
  }
  for (sp in C_SPECS[1:2]) {
    covs <- covs_for(sp$drop)
    s <- analysis_sample(d, c(sp$x, sp$s1, sp$m3, sp$s0, "y1_any", covs))
    flow[[sp$id]] <- data.frame(tests = sp$id, universe = nrow(d), has_x = sum(!is.na(d[[sp$x]])),
      has_x_w = NA, has_x_w_y = NA, complete = nrow(s), clusters = length(unique(s[[CLUSTER]])),
      stringsAsFactors = FALSE)
    posi[[sp$id]] <- data.frame(tests = sp$id, min_cell_rows = NA, cells_ge_100 = NA,
      min_cell_positive_ge_30 = NA, xm_min_ge_30 = min_cell(s[[sp$x]], s[[sp$m3]]) >= 30,
      chain_ge_2000 = NA, stringsAsFactors = FALSE)
  }
  # (2) msateco：三项检查后写判定
  decision <- "D3D4_RESERVE_ACTIVE"; why <- "未找到 msateco_intervals.csv"
  if (file.exists(msateco_path)) {
    de <- add_msateco(d, msateco_path)
    lk <- rbind(link_check(de, "spouse_sat_begin", "spouse_sat_end", "self_sat_begin", "self_sat_end", "阳性对照：总体满意度"),
                link_check(de, "eco_spouse_begin", "eco_spouse_end", "eco_self_begin", "eco_self_end", "msateco"))
    utils::write.csv(lk, file.path(OUT_DIR, "step0_msateco_link_check.csv"), row.names = FALSE)
    idx <- stats::complete.cases(de[, unique(c("xa", "y1_any", covs_for("none"), CLUSTER)), drop = FALSE])
    nonmiss <- mean(!is.na(de$eco_spouse_begin[idx]) & !is.na(de$eco_spouse_end[idx]))
    xm_ok <- all(vapply(C_SPECS[3:4], function(sp) {
      s <- analysis_sample(de, c(sp$x, sp$s1, sp$m3, sp$s0, "y1_any", covs_for(sp$drop)))
      min_cell(s[[sp$x]], s[[sp$m3]]) >= 30
    }, logical(1)))
    pass <- lk$mismatch_begin[1] == 0 && lk$mismatch_end[1] == 0 &&
      lk$mismatch_begin[2] == 0 && lk$mismatch_end[2] == 0 && nonmiss >= 0.80 && xm_ok
    decision <- if (pass) "C3C4_ACTIVE" else "D3D4_RESERVE_ACTIVE"
    why <- sprintf("行匹配率 %.3f；对接不一致 %d/%d；非缺失 %.3f；X×M 最小格达标 %s",
                   attr(de, "msateco_row_match"), lk$mismatch_begin[2], lk$mismatch_end[2], nonmiss, xm_ok)
  }
  writeLines(c(decision, why), file.path(OUT_DIR, "msateco_decision.txt"))
  # (3) 协变量时间属性：跨两个区间的同一二元组，起点值是否相同
  p1 <- d[d$period == "2018-2020", ]; p2 <- d[d$period == "2020-2022", ]
  j  <- match(p1$dyad_id, p2$dyad_id); k <- !is.na(j)
  aud <- do.call(rbind, lapply(setdiff(COV23, "period_fe"), function(v) {
    a <- p1[[v]][k]; b <- p2[[v]][j[k]]; ok <- !is.na(a) & !is.na(b)
    data.frame(variable = v, linked_dyads = sum(ok), share_identical = mean(a[ok] == b[ok]),
               stringsAsFactors = FALSE)
  }))
  aud$role <- ifelse(aud$variable == "dwm_begin", "剔除：2016–2022 累计，含区间之后信息（只在 R1 历史定义对照中使用）",
              ifelse(aud$variable %in% c("gender_begin", "prtgender_begin", "lifetime_begin"), "固定特征",
                     "区间起点值（build 脚本 getv(x, begin)）"))
  age_jump <- p2$aage_begin[j[k]] - p1$aage_begin[k]
  edu_chg  <- mean(p2$actor_edu2_begin[j[k]] != p1$actor_edu2_begin[k], na.rm = TRUE)
  utils::write.csv(aud, file.path(OUT_DIR, "variable_role_audit.csv"), row.names = FALSE)
  writeLines(c(sprintf("年龄两期差不等于 2 的二元组：%d", sum(age_jump != 2, na.rm = TRUE)),
               sprintf("actor_edu2 两期不同的比例：%.3f", edu_chg),
               "请在原始库核对：上述异常、ahw_ 的含义与波次、支持缺失行的 QF601/QF602 原因。"),
             file.path(OUT_DIR, "variable_role_flags.txt"))
  # (4) 支持缺失行：交给 astra 去原始 QF601/QF602 查原因
  miss <- d[is.na(d$support_real_begin) | is.na(d$support_real_end),
            c("dyad_id", "period", "actor_pid_begin", "parent_pid_begin", "support_real_begin", "support_real_end")]
  utils::write.csv(miss, file.path(OUT_DIR, "support_missing_rows.csv"), row.names = FALSE)
  utils::write.csv(bind_fill(flow), file.path(OUT_DIR, "sample_flow.csv"), row.names = FALSE)
  utils::write.csv(bind_fill(posi), file.path(OUT_DIR, "positivity.csv"), row.names = FALSE)
  cat("第 0 步完成。msateco 判定：", decision, "\n", why, "\n")
  invisible(list(flow = bind_fill(flow), positivity = bind_fill(posi), decision = decision))
}

step0_freeze <- function(amendment_path = file.path(PKG_DIR, "ANALYSIS_AMENDMENT_v4.md")) {
  ensure_out()
  files <- c(REGISTRY, amendment_path, file.path(OUT_DIR, "msateco_decision.txt"))
  stopifnot(all(file.exists(files)))
  h <- tools::md5sum(files)
  writeLines(c(paste("frozen_at:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")), paste(h, names(h))),
             file.path(OUT_DIR, "FREEZE_v4.txt"))
}
check_frozen <- function() {
  f <- file.path(OUT_DIR, "FREEZE_v4.txt")
  if (!file.exists(f)) stop("还没有冻结（step0_freeze）。冻结之前不运行任何真实结局模型。")
  invisible(TRUE)
}
read_decision <- function() {
  f <- file.path(OUT_DIR, "msateco_decision.txt")
  stopifnot(file.exists(f))
  identical(readLines(f, n = 1L), "C3C4_ACTIVE")
}

step1_AB <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_MAIN, SEED_MAIN, "plan_main_B2000.rds")
  out <- run_AB_specs(AB_SPECS, d, plan, covs_for, tag = "step1")
  utils::write.csv(out, file.path(OUT_DIR, "step1_AB_results.csv"), row.names = FALSE)
  out
}

step3a_calibration <- function(d, R = 200L, B = 99L) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  use_eco <- read_decision()
  runs <- list(list(sp = C_SPECS[[1]], base = d, cf = covs_for, sc = "a0"),
               list(sp = D_SPECS[[1]], base = build_threewave(d), cf = covs_D, sc = "a0"))
  runs[[3]] <- if (use_eco) list(sp = C_SPECS[[3]], base = add_msateco(d), cf = covs_for, sc = "b0") else
    list(sp = C_SPECS[[1]], base = d, cf = covs_for, sc = "b0")
  out <- lapply(runs, function(r) {
    covs <- r$cf(r$sp$drop)
    fM <- fml(r$sp$s1, c(r$sp$x, r$sp$s0, covs))
    fY <- fml("y1_any", c(paste(r$sp$x, "*", r$sp$m3), r$sp$s0, covs))
    dat <- zscale(analysis_sample(r$base, unique(c(all.vars(fM), all.vars(fY)))), covs)
    cal <- calib_med(dat, fM, fY, r$sp$x, r$sp$m3, r$sc, R = R, B = B)
    data.frame(test_id = r$sp$id, scenario = cal$scenario, R_ok = cal$R_ok,
               reject_rate = cal$reject_rate, threshold = cal$threshold, flag = cal$flag,
               stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, out)
  utils::write.csv(out, file.path(OUT_DIR, "step3a_calibration.csv"), row.names = FALSE)
  out
}

step3b_CD <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_MAIN, SEED_MAIN, "plan_main_B2000.rds")
  use_eco <- read_decision()
  resC <- run_med(if (use_eco) C_SPECS else C_SPECS[1:2], if (use_eco) add_msateco(d) else d,
                  plan, covs_for, tag = "step3")
  w <- build_threewave(d)
  resD <- run_med(D_SPECS, w, plan, covs_D, tag = "step3")
  resR <- if (!use_eco) run_AB_specs(D_RESERVE, w, plan, covs_D, tag = "step3", with_B = FALSE) else NULL
  out <- bind_fill(list(resC, resD, resR))
  utils::write.csv(out, file.path(OUT_DIR, "step3_CD_results.csv"), row.names = FALSE)
  out
}

step4_S <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_MAIN, SEED_MAIN, "plan_main_B2000.rds")
  rows <- list()
  go <- function(id, f, covs, sfun, keys) {
    dat <- zscale(analysis_sample(d, unique(c(all.vars(f), "female"))), covs)
    est <- sfun(dat); bt <- run_boot(dat, plan, sfun)
    saveRDS(list(f = f, est = est, boot = bt, n = nrow(dat)), file.path(OUT_DIR, sprintf("step4_%s.rds", id)))
    lapply(keys, function(k) cbind(test_id = id, tag = "step4", n = nrow(dat),
                                   n_cl = length(unique(dat[[CLUSTER]])), summ_boot(est, bt, k)))
  }
  c1 <- covs_for("both")
  f1 <- fml("y1_any", c(c1, "xa * w_self3", "xa * w_spouse3"))
  rows <- c(rows, go("S1", f1, c1, function(z) stat_S1(z, f1), c("S1", "d_self_joint", "d_spouse_joint")))
  c2 <- covs_for("none", drop = "gender_begin")
  f2 <- fml("y1_any", c(c2, "xa"))
  rows <- c(rows, go("S2", f2, c2, function(z) stat_S2(z, f2), c("S2", "T_female", "T_male")))
  c3 <- covs_for("self", drop = "gender_begin")
  f3 <- fml("y1_any", c(c3, "xa * w_self3"))
  rows <- c(rows, go("S3", f3, c3, function(z) stat_S34(z, f3, "w_self3"), c("diff", "d_female", "d_male")))
  c4 <- covs_for("spouse", drop = "gender_begin")
  f4 <- fml("y1_any", c(c4, "xa * w_spouse3"))
  rows <- c(rows, go("S4", f4, c4, function(z) stat_S34(z, f4, "w_spouse3"), c("diff", "d_female", "d_male")))
  out <- do.call(rbind, rows)
  utils::write.csv(out, file.path(OUT_DIR, "step4_S_results.csv"), row.names = FALSE)
  out
}

step5_robustness <- function(d) {
  check_frozen(); if (is.null(COV22)) load_covariates()
  plan <- make_or_load_plan(d, B_ROB, SEED_ROB, "plan_rob_B500.rds")
  use_eco <- read_decision()
  specsC <- if (use_eco) C_SPECS else C_SPECS[1:2]
  dC <- if (use_eco) add_msateco(d) else d
  w  <- build_threewave(d)
  c23  <- function(dr) covs_for(dr, base = COV23)
  c23D <- function(dr) covs_D(dr, base = COV23)
  save_csv <- function(x, name) { utils::write.csv(x, file.path(OUT_DIR, paste0(name, ".csv")), row.names = FALSE); x }
  # R1 历史定义对照（23 项，含 dwm）
  save_csv(bind_fill(list(run_AB_specs(prefix_specs(AB_SPECS, "R1"), d, plan, c23, tag = "R1"),
                      run_med(prefix_specs(specsC, "R1"), dC, plan, c23, tag = "R1"),
                      run_med(prefix_specs(D_SPECS, "R1"), w, plan, c23D, tag = "R1"))), "R1_cov23")
  # R2 来自第 1 步主抽样（d_P_5v4、d_Y_5v4 与 T 曲线），在 step6 汇总，不重跑
  # R3 XL：0 对正值 75 分位（在 A1 分析样本中一次性固定）
  s_a1 <- analysis_sample(d, c("xl", "w_self3", "y1_any", "y1_amt", covs_for("self")))
  q75  <- unname(stats::quantile(s_a1$xl[s_a1$xl > 0], 0.75))
  writeLines(sprintf("XL 对比：0 对 %.6f（A1 分析样本正值 75 分位）", q75), file.path(OUT_DIR, "R3_xl_contrast.txt"))
  xl_specs <- lapply(prefix_specs(AB_SPECS[1:2], "R3"), function(sp) { sp$x <- "xl"; sp })
  save_csv(run_AB_specs(xl_specs, d, plan, covs_for, tag = "R3", x_hi = q75, x_lo = 0), "R3_xl")
  # R4 actor-period 汇总（父母两行合为一行）
  a <- build_actor_period(d)
  save_csv(run_AB_specs(prefix_specs(AB_SPECS, "R4"), a, plan, covs_R4, tag = "R4"), "R4_actor_period")
  # R5 线性概率模型（簇稳健）
  save_csv(do.call(rbind, lapply(AB_SPECS, function(sp) {
    covs <- covs_for(sp$drop); f <- fml("y1_any", c(covs, paste(sp$x, "*", sp$w)))
    dat <- zscale(analysis_sample(d, all.vars(f)), covs)
    cbind(test_id = paste0("R5_", sp$A), lpm_dP(f, dat, sp$x, sp$w))
  })), "R5_lpm")
  # R6 金额 p99 封顶（只看 B）
  cap <- unname(stats::quantile(d$y1_amt[!is.na(d$y1_amt) & d$y1_amt > 0], 0.99))
  d6 <- d; d6$y1_amt_cap <- pmin(d6$y1_amt, cap)
  r6 <- run_AB_specs(prefix_specs(AB_SPECS, "R6"), d6, plan, covs_for, tag = "R6", yB = "y1_amt_cap")
  save_csv(r6[grepl("_Y", r6$estimand), ], "R6_cap99")
  # R7 原结局 y_growth
  save_csv(run_AB_specs(prefix_specs(AB_SPECS, "R7"), d, plan, covs_for, tag = "R7", with_B = FALSE,
                    yA = "y_growth"), "R7_ygrowth")
  # R8 影响函数（Delta）标准误，对照 A 的 bootstrap
  save_csv(do.call(rbind, lapply(AB_SPECS, function(sp) {
    covs <- covs_for(sp$drop); f <- fml("y1_any", c(covs, paste(sp$x, "*", sp$w)))
    dat <- zscale(analysis_sample(d, c(all.vars(f), "y1_amt")), covs)
    cbind(test_id = paste0("R8_", sp$A), if_dP_logit(fit_logit(f, dat), dat, sp$x, sp$w))
  })), "R8_influence")
  # R9 C/D 改用两部分金额结局
  save_csv(bind_fill(list(run_med(prefix_specs(specsC, "R9"), dC, plan, covs_for, tag = "R9", y_type = "twopart"),
                      run_med(prefix_specs(D_SPECS, "R9"), w, plan, covs_D, tag = "R9", y_type = "twopart"))),
       "R9_amount")
  # R10 D 的 Y 模型加入 2020 年支持（处理后调整，估计对象不同）
  save_csv(run_med(prefix_specs(D_SPECS, "R10"), w, plan, covs_D, tag = "R10",
               extra_y = c("y2020_any", "y2020_ihs")), "R10_y2020")
  # R11 部分比例优势中介模型
  save_csv(run_med(prefix_specs(specsC, "R11"), dC, plan, covs_for, tag = "R11", m_model = "ppo"), "R11_ppo")
  # 比例优势诊断（同一五分类；常规 LR 不计聚类，只作诊断）
  po <- function(specs, base, cf, tag) do.call(rbind, lapply(specs, function(sp) {
    covs <- cf(sp$drop); fM <- fml(sp$s1, c(sp$x, sp$s0, covs))
    dat <- zscale(analysis_sample(base, all.vars(fM)), covs)
    dat[[sp$s1]] <- droplevels(dat[[sp$s1]])
    m0 <- ordinal::clm(fM, data = dat, link = "logit")
    m1 <- ordinal::clm(stats::update(fM, stats::as.formula(paste(". ~ . -", sp$x))),
                       nominal = stats::as.formula(paste("~", sp$x)), data = dat, link = "logit")
    lr <- 2 * (as.numeric(logLik(m1)) - as.numeric(logLik(m0)))
    df <- length(coef(m1)) - length(coef(m0))
    data.frame(test_id = sp$id, LR = lr, df = df, p_naive = stats::pchisq(lr, df, lower.tail = FALSE),
               note = "常规 LR，未计聚类；只作诊断，不作换模门槛", stringsAsFactors = FALSE)
  }))
  if (requireNamespace("ordinal", quietly = TRUE))
    save_csv(rbind(po(specsC, dC, covs_for, "C"), po(D_SPECS, w, covs_D, "D")), "PO_diagnostic")
  invisible(TRUE)
}

# 第 6 步：汇总、校正、与理论方向对照
align_label <- function(est, lo, hi, q, direction) {
  excl0 <- lo > 0 | hi < 0
  dir_ok <- (direction == "+" & est > 0) | (direction == "-" & est < 0)
  ifelse(is.na(est), "待执行或不可估",
  ifelse(!excl0, "不能判断（主 CI 含 0，不等于效应为 0）",
  ifelse(direction == "?", ifelse(q < 0.05, "通过本族校正（无事先方向）", "主 CI 不含 0，未通过本族校正"),
  ifelse(dir_ok & q < 0.05, "方向符合理论且通过本族校正（探索性）",
  ifelse(dir_ok, "方向符合理论，主 CI 不含 0，但未通过本族校正",
  ifelse(q < 0.05, "方向与理论相反，且通过本族校正（照实报告）",
         "方向与理论相反，主 CI 不含 0，未通过本族校正（照实报告）"))))))
}

step6_assemble <- function() {
  ensure_out()
  rd  <- function(f) { p <- file.path(OUT_DIR, f); if (file.exists(p)) utils::read.csv(p, stringsAsFactors = FALSE) else NULL }
  reg <- utils::read.csv(REGISTRY, stringsAsFactors = FALSE)
  allres <- bind_fill(list(rd("step1_AB_results.csv"), rd("step3_CD_results.csv"), rd("step4_S_results.csv")))
  if (is.null(allres)) stop("还没有任何结果文件")
  key <- paste(allres$test_id, allres$estimand)
  pick <- function(fam) {
    r <- reg[reg$family == fam, ]
    merge(r[, c("test_id", "estimand_key", "theory_direction", "label")],
          allres[key %in% paste(r$test_id, r$estimand_key), ],
          by.x = c("test_id", "estimand_key"), by.y = c("test_id", "estimand"), all.x = TRUE)
  }
  # 条件名额：按第 0 步冻结的 msateco 判定，只保留 C3/C4 或 D3/D4 其中一对；未运行的检验保留为“待执行”
  dec <- if (file.exists(file.path(OUT_DIR, "msateco_decision.txt"))) read_decision() else NA
  drop_ids <- if (identical(dec, FALSE)) c("C3", "C4") else c("D3", "D4")
  P <- pick("P14")
  P <- P[!(P$test_id %in% drop_ids), ]
  stopifnot(nrow(P) <= N_PRIMARY)
  ran <- !is.na(P$p_raw)
  P$p_BH14 <- NA_real_; P$p_BY14 <- NA_real_
  P$p_BH14[ran] <- p.adjust(P$p_raw[ran], "BH", n = N_PRIMARY)
  P$p_BY14[ran] <- p.adjust(P$p_raw[ran], "BY", n = N_PRIMARY)
  P$alignment <- align_label(P$estimate, P$ci_low, P$ci_high, P$p_BH14, P$theory_direction)
  S <- pick("S4")
  ranS <- !is.na(S$p_raw)
  S$p_BH4 <- NA_real_; S$p_BY4 <- NA_real_
  S$p_BH4[ranS] <- p.adjust(S$p_raw[ranS], "BH", n = N_SECOND)
  S$p_BY4[ranS] <- p.adjust(S$p_raw[ranS], "BY", n = N_SECOND)
  S$alignment <- paste0(align_label(S$estimate, S$ci_low, S$ci_high, S$p_BH4, S$theory_direction),
                        ifelse(S$test_id == "S1", "", "；数据启发，只作假设生成"))
  utils::write.csv(P, file.path(OUT_DIR, "primary_family_P14.csv"), row.names = FALSE)
  utils::write.csv(S, file.path(OUT_DIR, "secondary_family_S4.csv"), row.names = FALSE)
  # 全部检验合并校正（参照）：旧 150×2（不适用者内部按 1）+ 新 14 + 4
  hist <- utils::read.csv(file.path(PKG_DIR, "screening/status_120_specs_v1/ALL_300_STATUS.csv"), stringsAsFactors = FALSE)
  hp <- ifelse(is.na(hist$p_exploratory), 1, hist$p_exploratory)
  J <- data.frame(source = c(paste(hist$spec_id, hist$metric), paste("v4", P$test_id), paste("v4", S$test_id)),
                  p_raw = c(hp, P$p_raw, S$p_raw), stringsAsFactors = FALSE)
  m_all <- 300L + N_PRIMARY + N_SECOND
  okJ <- !is.na(J$p_raw)
  J$p_BH_all <- NA_real_; J$p_BY_all <- NA_real_
  J$p_BH_all[okJ] <- p.adjust(J$p_raw[okJ], "BH", n = m_all)
  J$p_BY_all[okJ] <- p.adjust(J$p_raw[okJ], "BY", n = m_all)
  utils::write.csv(J, file.path(OUT_DIR, "joint_scope_318.csv"), row.names = FALSE)
  # 长表：全部估计量（主、次级、R2 及其余稳健性），不显著不删除
  rob <- lapply(c("R1_cov23", "R3_xl", "R4_actor_period", "R5_lpm", "R6_cap99", "R7_ygrowth", "R8_influence",
                  "R9_amount", "R10_y2020", "R11_ppo", "PO_diagnostic"), function(f) {
    x <- rd(paste0(f, ".csv")); if (!is.null(x)) x$source_file <- f; x })
  long <- bind_fill(c(list(allres), rob))
  utils::write.csv(long, file.path(OUT_DIR, "effects_long.csv"), row.names = FALSE)
  utils::write.csv(rbind(P[, c("test_id", "label", "theory_direction", "estimate", "ci_low", "ci_high",
                               "p_raw", "alignment")],
                         S[, c("test_id", "label", "theory_direction", "estimate", "ci_low", "ci_high",
                               "p_raw", "alignment")]),
                   file.path(OUT_DIR, "hypothesis_alignment.csv"), row.names = FALSE)
  write_manifest()
  invisible(list(P = P, S = S))
}

write_manifest <- function() {
  ensure_out()
  inputs <- file.path(PKG_DIR, c("data/analysis_13092.rds", "data/fixed_23_covariates.txt",
                                 "data/msateco_intervals.csv", "20261005_test_registry_v4.csv",
                                 "20261005_astra_v4_functions.R", "ANALYSIS_AMENDMENT_v4.md"))
  inputs <- inputs[file.exists(inputs)]
  writeLines(c(capture.output(sessionInfo()), "", "md5:", paste(tools::md5sum(inputs), inputs), "",
               sprintf("seeds: main=%d rob=%d cal=%d", SEED_MAIN, SEED_ROB, SEED_CAL),
               sprintf("B: main=%d rob=%d; cores=%d", B_MAIN, B_ROB, N_CORES),
               "抽样计划：v4_outputs/plan_main_B2000.rds、plan_rob_B500.rds（事先生成，已保存）",
               "失败记录：各 RDS 的 boot$fail_idx 与 boot$fail_msg"),
             file.path(OUT_DIR, "estimation_manifest.txt"))
}

# ---------------------------------------------------------------------
# run_v4.R 示例（逐步运行，每步看输出再进下一步）
# ---------------------------------------------------------------------
# source("20261005_astra_v4_functions.R")
# self_test()                                  # 必须全部 PASS
# load_covariates(); d <- prep_data()
# time_test(d)                                 # 合成结局计时
# Sys.setenv(CMA_PREDATA = "/Users/lzhs/.../predata_FE_16_22_unbal.dta"); extract_msateco()
# step0_checks(d)                              # 只看计数、达标与否、msateco 判定
# # 写 ANALYSIS_AMENDMENT_v4.md（方案第二、四、五、六节 + 第八节披露 + msateco 判定 + support 缺失核查），然后：
# step0_freeze()
# r1 <- step1_AB(d)                            # 第 1 步
# # 第 2 步：技术暂停，汇报 A/B 全部 8 项（BH/BY 按 n=14），不按 p 值改后续
# cal <- step3a_calibration(d)                 # 第 3a 步（只产生拒绝率，不产生真实 C/D 估计）
# r3 <- step3b_CD(d)                           # 第 3b 步
# r4 <- step4_S(d)                             # 第 4 步
# step5_robustness(d)                          # 第 5 步
# step6_assemble()                             # 第 6 步
