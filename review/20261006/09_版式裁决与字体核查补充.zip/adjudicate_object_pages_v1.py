from pathlib import Path
import json,hashlib,re,copy
import pdfplumber
from docx import Document
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'pdf_visual_diagnosis_v4'
def norm(s):return re.sub(r"\s+", "", s)
def pin(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def adjudicate(texts,images,narrative):
    rows=[]
    for page in [10,11,12,13,25,27,28,29,30,31]:
        t=norm(texts[page]);checks={}
        if page==10:
            checks={'full_body_paragraph_found':norm(narrative) in t,'caption_found':'表1描述性统计' in t}
            reason='Body narrative falsely classified as caption because paragraph starts with 表1; exact full paragraph verified.'
        elif page in [11,12,13]:
            anchors={11:['个体特征','连续年龄','家务时长'],12:['自评健康评分','父母特征','家庭总收入'],13:['2016年年龄分组','必要基期变量','配偶婚姻满意度']}
            checks={'origin_caption': '表1描述性统计' in norm(texts[10]),'repeated_headers':all(x in t for x in ['全样本','2018-2020','2020-2022','N=13092']), 'data_rows_present':all(norm(x) in t for x in anchors[page])}
            reason='Table 1 continuation; full body narrative is on origin page; repeated header and multiple data rows verified.'
        elif page==25:
            checks={'figure_present':images[page]>0,'caption':'图A.1' in t,'interpretation_note':'不将其作为政策效果图解释' in t}
            reason='Appendix figure-only page with caption and explanatory note; figure-only pages allowed by skill.'
        else:
            ci={27:1,28:2,29:3,30:4,31:5}[page]
            checks={'caption':f'表C.{ci}' in t,'first_chain':'AA-S' in t,'last_chain':'RR-P' in t,'interpretation_note':'注：' in t,'rows':len(re.findall(r'(?:AA|AR|RA|RR)-[SP]',t))>=8}
            reason='Appendix table-only page; caption, chain range, data rows and interpretation note verified.'
        rows.append({'page':page,'checks':checks,'pass':all(checks.values()),'reason':reason})
    return {'all_pass':all(r['pass'] for r in rows),'pages':rows}
if __name__=='__main__':
    docx=ROOT/'native_run_v4/artifacts/accepted.docx';pdf=ROOT/'native_run_v4/evidence/accepted.pdf'
    raw=ROOT/'native_run_v4/evidence/adapter_pdf_qa.json'
    original=json.loads(raw.read_text());assert original['publication_layout_qa']['object_page_gate']['object_only_pages']==[10,11,12,13,25,27,28,29,30,31]
    paragraphs=[p.text for p in Document(docx).paragraphs if '汇总相邻两波样本中的主要变量' in p.text];assert len(paragraphs)==1
    texts={};images={}
    with pdfplumber.open(pdf) as d:
        for i,pg in enumerate(d.pages,1):
            texts[i]=pg.filter(lambda o:o.get('object_type')!='char' or not o['text'].isspace()).extract_text(x_tolerance=1,y_tolerance=2) or ''
            images[i]=len(pg.images)
    result=adjudicate(texts,images,paragraphs[0]);assert result['all_pass']
    tests=[]
    for page,needle in [(10,paragraphs[0]),(11,'连续年龄'),(13,'必要基期变量'),(27,'表C.1'),(31,'RR-P')]:
        mutated={i:norm(t) for i,t in texts.items()};mutated[page]=mutated[page].replace(norm(needle),'')
        tests.append({'page':page,'mutation':needle[:20],'detected':not adjudicate(mutated,images,paragraphs[0])['all_pass']})
    missing_images=dict(images);missing_images[25]=0
    tests.append({'page':25,'mutation':'removed image','detected':not adjudicate(texts,missing_images,paragraphs[0])['all_pass']})
    assert all(t['detected'] for t in tests)
    result.update(scope='Object-page narrative adjudication only. Original pipeline FAIL retained; does not establish fonts, full visual or numerical/cell QA.',source_pins=[pin(docx),pin(pdf),pin(raw)],negative_tests=tests,review_mode='solo_self_review',caption_false_positive='CAPTION_RE treats the full explanatory paragraph beginning 表1 as a caption; extraction change alone does not fix it.')
    (OUT/'OBJECT_PAGE_ADJUDICATION_v1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'all_pass':result['all_pass'],'negative_tests':len(tests),'scope':result['scope']}))
